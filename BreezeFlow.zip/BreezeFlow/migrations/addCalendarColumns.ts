/**
 * Migration script to add calendar integration columns to the users table
 */
import { pool } from '../server/db';

async function migrate() {
  const client = await pool.connect();
  
  try {
    // Start transaction
    await client.query('BEGIN');
    
    console.log('Starting migration to add calendar integration columns...');
    
    // Check if the columns already exist
    const columnCheckResult = await client.query(`
      SELECT column_name
      FROM information_schema.columns
      WHERE table_name = 'users'
      AND column_name IN ('google_calendar_connected', 'google_refresh_token', 'outlook_calendar_connected', 'outlook_refresh_token')
    `);
    
    const existingColumns = columnCheckResult.rows.map(row => row.column_name);
    
    // Add google_calendar_connected column if it doesn't exist
    if (!existingColumns.includes('google_calendar_connected')) {
      console.log('Adding google_calendar_connected column...');
      await client.query(`
        ALTER TABLE users 
        ADD COLUMN google_calendar_connected BOOLEAN DEFAULT FALSE
      `);
    } else {
      console.log('google_calendar_connected column already exists.');
    }
    
    // Add google_refresh_token column if it doesn't exist
    if (!existingColumns.includes('google_refresh_token')) {
      console.log('Adding google_refresh_token column...');
      await client.query(`
        ALTER TABLE users 
        ADD COLUMN google_refresh_token TEXT
      `);
    } else {
      console.log('google_refresh_token column already exists.');
    }
    
    // Add outlook_calendar_connected column if it doesn't exist
    if (!existingColumns.includes('outlook_calendar_connected')) {
      console.log('Adding outlook_calendar_connected column...');
      await client.query(`
        ALTER TABLE users 
        ADD COLUMN outlook_calendar_connected BOOLEAN DEFAULT FALSE
      `);
    } else {
      console.log('outlook_calendar_connected column already exists.');
    }
    
    // Add outlook_refresh_token column if it doesn't exist
    if (!existingColumns.includes('outlook_refresh_token')) {
      console.log('Adding outlook_refresh_token column...');
      await client.query(`
        ALTER TABLE users 
        ADD COLUMN outlook_refresh_token TEXT
      `);
    } else {
      console.log('outlook_refresh_token column already exists.');
    }
    
    // Commit transaction
    await client.query('COMMIT');
    console.log('Migration completed successfully!');
    
  } catch (error) {
    // Rollback transaction on error
    await client.query('ROLLBACK');
    console.error('Migration failed:', error);
    throw error;
  } finally {
    // Release client back to the pool
    client.release();
  }
}

// Run the migration
migrate()
  .then(() => {
    console.log('Migration script finished.');
    process.exit(0);
  })
  .catch((error) => {
    console.error('Migration failed with error:', error);
    process.exit(1);
  });