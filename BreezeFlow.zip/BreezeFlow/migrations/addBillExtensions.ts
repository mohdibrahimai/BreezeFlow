/**
 * Migration script to add new bill features (categories, recurring bills, reminders)
 */
import { pool } from '../server/db';

async function migrate() {
  const client = await pool.connect();
  
  try {
    // Start transaction
    await client.query('BEGIN');
    
    console.log('Starting migration to add bill extensions...');
    
    // Check if the columns already exist
    const columnCheckResult = await client.query(`
      SELECT column_name
      FROM information_schema.columns
      WHERE table_name = 'bills'
      AND column_name IN (
        'category', 'recurring', 'recurring_interval', 'reminder_days', 
        'notes', 'created_at', 'paid_at', 'last_reminded_at'
      )
    `);
    
    const existingColumns = columnCheckResult.rows.map(row => row.column_name);
    
    // Add category column if it doesn't exist
    if (!existingColumns.includes('category')) {
      console.log('Adding category column...');
      await client.query(`
        ALTER TABLE bills 
        ADD COLUMN category TEXT DEFAULT 'uncategorized'
      `);
    } else {
      console.log('category column already exists.');
    }
    
    // Add recurring column if it doesn't exist
    if (!existingColumns.includes('recurring')) {
      console.log('Adding recurring column...');
      await client.query(`
        ALTER TABLE bills 
        ADD COLUMN recurring BOOLEAN NOT NULL DEFAULT false
      `);
    } else {
      console.log('recurring column already exists.');
    }
    
    // Add recurring_interval column if it doesn't exist
    if (!existingColumns.includes('recurring_interval')) {
      console.log('Adding recurring_interval column...');
      await client.query(`
        ALTER TABLE bills 
        ADD COLUMN recurring_interval TEXT
      `);
    } else {
      console.log('recurring_interval column already exists.');
    }
    
    // Add reminder_days column if it doesn't exist
    if (!existingColumns.includes('reminder_days')) {
      console.log('Adding reminder_days column...');
      await client.query(`
        ALTER TABLE bills 
        ADD COLUMN reminder_days INTEGER
      `);
    } else {
      console.log('reminder_days column already exists.');
    }
    
    // Add notes column if it doesn't exist
    if (!existingColumns.includes('notes')) {
      console.log('Adding notes column...');
      await client.query(`
        ALTER TABLE bills 
        ADD COLUMN notes TEXT
      `);
    } else {
      console.log('notes column already exists.');
    }
    
    // Add created_at column if it doesn't exist
    if (!existingColumns.includes('created_at')) {
      console.log('Adding created_at column...');
      await client.query(`
        ALTER TABLE bills 
        ADD COLUMN created_at TIMESTAMP NOT NULL DEFAULT NOW()
      `);
    } else {
      console.log('created_at column already exists.');
    }
    
    // Add paid_at column if it doesn't exist
    if (!existingColumns.includes('paid_at')) {
      console.log('Adding paid_at column...');
      await client.query(`
        ALTER TABLE bills 
        ADD COLUMN paid_at TIMESTAMP
      `);
    } else {
      console.log('paid_at column already exists.');
    }
    
    // Add last_reminded_at column if it doesn't exist
    if (!existingColumns.includes('last_reminded_at')) {
      console.log('Adding last_reminded_at column...');
      await client.query(`
        ALTER TABLE bills 
        ADD COLUMN last_reminded_at TIMESTAMP
      `);
    } else {
      console.log('last_reminded_at column already exists.');
    }
    
    // Commit transaction
    await client.query('COMMIT');
    console.log('Migration completed successfully!');
    
  } catch (error) {
    // Rollback transaction on error
    await client.query('ROLLBACK');
    console.error('Migration failed:', error);
    throw error;
  } finally {
    // Release client back to the pool
    client.release();
  }
}

// Run the migration
migrate()
  .then(() => {
    console.log('Migration script finished.');
    process.exit(0);
  })
  .catch((error) => {
    console.error('Migration failed with error:', error);
    process.exit(1);
  });