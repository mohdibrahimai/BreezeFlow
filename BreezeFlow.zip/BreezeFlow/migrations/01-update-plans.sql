-- Update existing basic plans to starter
UPDATE users 
SET plan = 'starter' 
WHERE plan = 'basic';

-- Ensure all plans are valid according to the new enum
UPDATE users
SET plan = 'free'
WHERE plan NOT IN ('free', 'starter', 'pro', 'team');