-- Migration: Add 'starter' plan and safely transition from 'basic'
-- Execute with: npm run migrate:prod

-- Begin transaction for atomic changes
BEGIN;

-- 1. Add 'starter' to the enum (if it doesn't exist)
-- This is a safe operation that doesn't modify existing data
ALTER TYPE "plan_enum" ADD VALUE IF NOT EXISTS 'starter';

-- 2. Backfill existing 'basic' users to 'starter'
UPDATE "users"
SET "plan" = 'starter'
WHERE "plan" = 'basic';

-- 3. Set default for new users to 'free'
ALTER TABLE "users" 
ALTER COLUMN "plan" SET DEFAULT 'free';

-- 4. Commit all changes atomically
COMMIT;

-- Note: After successful migration, a follow-up migration 
-- should be created to remove the 'basic' value from the enum
-- This is a separate operation as dropping values from enums
-- requires recreating the type in PostgreSQL