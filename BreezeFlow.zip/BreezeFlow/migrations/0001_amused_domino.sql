CREATE TABLE "payments" (
	"id" serial PRIMARY KEY NOT NULL,
	"user_id" integer NOT NULL,
	"transaction_id" text NOT NULL,
	"subscription_id" text,
	"amount" integer NOT NULL,
	"currency" text NOT NULL,
	"status" text NOT NULL,
	"payment_method" text NOT NULL,
	"created_at" timestamp DEFAULT now() NOT NULL,
	"metadata" json,
	CONSTRAINT "payments_transaction_id_unique" UNIQUE("transaction_id")
);
--> statement-breakpoint
ALTER TABLE "users" ADD COLUMN "plan_active" boolean DEFAULT false NOT NULL;--> statement-breakpoint
ALTER TABLE "users" ADD COLUMN "plan_expiry" timestamp;--> statement-breakpoint
ALTER TABLE "users" ADD COLUMN "paypal_customer_id" text;--> statement-breakpoint
ALTER TABLE "users" ADD COLUMN "paypal_subscription_id" text;--> statement-breakpoint
ALTER TABLE "users" ADD COLUMN "last_payment_date" timestamp;