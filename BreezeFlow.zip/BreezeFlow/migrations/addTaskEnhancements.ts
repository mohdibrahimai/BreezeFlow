/**
 * Migration script to add new task features (tags, estimated_minutes, reminder_time)
 */
import { pool } from "../server/db";

async function migrate() {
  console.log("Starting task enhancement migration...");
  
  try {
    // Start a transaction
    await pool.query('BEGIN');

    // Check if columns already exist before adding
    const checkResult = await pool.query(`
      SELECT column_name 
      FROM information_schema.columns 
      WHERE table_name = 'tasks' AND column_name IN ('tags', 'estimated_minutes', 'reminder_time');
    `);
    
    const existingColumns = checkResult.rows.map(row => row.column_name);
    
    // Add tags column if it doesn't exist
    if (!existingColumns.includes('tags')) {
      console.log("Adding 'tags' column to tasks table...");
      await pool.query(`
        ALTER TABLE tasks
        ADD COLUMN tags TEXT;
      `);
    } else {
      console.log("'tags' column already exists, skipping...");
    }
    
    // Add estimated_minutes column if it doesn't exist
    if (!existingColumns.includes('estimated_minutes')) {
      console.log("Adding 'estimated_minutes' column to tasks table...");
      await pool.query(`
        ALTER TABLE tasks
        ADD COLUMN estimated_minutes INTEGER;
      `);
    } else {
      console.log("'estimated_minutes' column already exists, skipping...");
    }
    
    // Add reminder_time column if it doesn't exist
    if (!existingColumns.includes('reminder_time')) {
      console.log("Adding 'reminder_time' column to tasks table...");
      await pool.query(`
        ALTER TABLE tasks
        ADD COLUMN reminder_time TIMESTAMP;
      `);
    } else {
      console.log("'reminder_time' column already exists, skipping...");
    }
    
    // Commit the transaction
    await pool.query('COMMIT');
    
    console.log("Task enhancement migration completed successfully!");
  } catch (error) {
    // Rollback in case of error
    await pool.query('ROLLBACK');
    console.error("Error during migration:", error);
    throw error;
  } finally {
    // End the pool
    await pool.end();
  }
}

// Run the migration
migrate().catch(err => {
  console.error("Migration failed:", err);
  process.exit(1);
});