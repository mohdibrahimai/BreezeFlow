/**
 * Migration script to add role column to users table
 */
import { db } from "../server/db";
import { sql } from "drizzle-orm";

async function migrate() {
  try {
    console.log("Starting migration: Add role column to users table");
    
    // Check if the role column exists
    const columnExists = await db.execute(sql`
      SELECT column_name 
      FROM information_schema.columns 
      WHERE table_name='users' AND column_name='role'
    `);
    
    if (columnExists.rows && columnExists.rows.length === 0) {
      console.log("Column 'role' does not exist, creating it...");
      
      // Create type if it doesn't exist
      await db.execute(sql`
        DO $$
        BEGIN
          IF NOT EXISTS (SELECT 1 FROM pg_type WHERE typname = 'user_role') THEN
            CREATE TYPE user_role AS ENUM ('user', 'admin');
          END IF;
        END
        $$;
      `);
      
      // Add role column with default value 'user'
      await db.execute(sql`
        ALTER TABLE users 
        ADD COLUMN role user_role NOT NULL DEFAULT 'user'
      `);
      
      console.log("Column 'role' added successfully to users table");
    } else {
      console.log("Column 'role' already exists, skipping creation");
    }
    
    console.log("Migration completed successfully");
  } catch (error) {
    console.error("Migration failed:", error);
    throw error;
  }
}

// Run the migration
migrate()
  .then(() => {
    console.log("Migration process completed");
    process.exit(0);
  })
  .catch((error) => {
    console.error("Migration process failed:", error);
    process.exit(1);
  });