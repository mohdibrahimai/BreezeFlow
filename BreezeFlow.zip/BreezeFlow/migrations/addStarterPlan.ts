/**
 * Migration script to safely update the database for introducing 'starter' plan tier
 * Run this once before deploying the new pricing system to production
 */

import { db } from '../server/db';
import { users } from '../shared/schema';
import { eq, sql } from 'drizzle-orm';

async function migrate() {
  console.log('Starting migration: Adding starter plan tier');

  try {
    // 1. First check if the database needs migration
    const query = await db.execute(sql`
      SELECT column_name, data_type, character_maximum_length
      FROM information_schema.columns
      WHERE table_name = 'users' AND column_name = 'plan'
    `);

    const planColumn = query.rows[0];
    if (!planColumn) {
      console.error('Plan column not found in users table');
      return;
    }

    // 2. Verify if migration is needed by checking enum values
    const enumCheck = await db.execute(sql`
      SELECT enumlabel
      FROM pg_enum
      JOIN pg_type ON pg_enum.enumtypid = pg_type.oid
      WHERE pg_type.typname = 'plan_enum'
      ORDER BY enumsortorder
    `);

    const existingEnumValues = enumCheck.rows.map(row => row.enumlabel);
    if (existingEnumValues.includes('starter')) {
      console.log('Migration not needed: starter plan already exists in enum');
      return;
    }

    console.log('Current enum values:', existingEnumValues);

    // 3. Perform the migration to add 'starter' to the enum
    await db.execute(sql`
      ALTER TYPE plan_enum ADD VALUE 'starter' AFTER 'free'
    `);

    console.log('Successfully added starter plan to enum type');

    // 4. Update any basic users to free plan for consistency
    const basicUsersCount = await db.update(users)
      .set({ plan: 'free' })
      .where(eq(users.plan, 'basic'))
      .returning();

    console.log(`Updated ${basicUsersCount.length} users from basic to free plan`);

    console.log('Migration completed successfully');
  } catch (error) {
    console.error('Migration failed:', error);
    throw error;
  }
}

// Only run if directly executed (not imported)
if (require.main === module) {
  migrate()
    .then(() => process.exit(0))
    .catch((error) => {
      console.error('Migration failed with error:', error);
      process.exit(1);
    });
}

export default migrate;