import type { Config } from 'jest';

const config: Config = {
  preset: 'ts-jest',
  testEnvironment: 'node',
  verbose: true,
  testMatch: ['**/tests/**/*.test.ts'],
  moduleNameMapper: {
    "^@/(.*)$": "<rootDir>/client/src/$1",
    "^@shared/(.*)$": "<rootDir>/shared/$1"
  },
  setupFilesAfterEnv: ['<rootDir>/tests/utils/setup.ts'],
  testTimeout: 30000, // 30 seconds
  globalTeardown: '<rootDir>/tests/utils/teardown.ts'
};

export default config;