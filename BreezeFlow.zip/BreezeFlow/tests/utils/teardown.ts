import { pool } from '../../server/db';

/**
 * Global teardown function to clean up after all tests
 */
export default async function() {
  // Close the database connection pool
  await pool.end();
  
  console.log('Test environment cleaned up');
}