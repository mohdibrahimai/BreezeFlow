import express from 'express';
import request from 'supertest';
import { createServer } from 'http';
import { db } from '../../server/db';
import { users, tasks, Task, InsertTask } from '../../shared/schema';
import cookieParser from 'cookie-parser';
import dotenv from 'dotenv';
import { setupAuth } from '../../server/auth';
import { registerRoutes } from '../../server/routes';

// Load environment variables
dotenv.config();

/**
 * Create a test application instance for testing
 */
export async function createTestApp() {
  const app = express();
  
  // Setup middleware
  app.use(express.json());
  app.use(cookieParser());
  
  // Setup auth
  setupAuth(app);
  
  // Register all routes
  const server = await registerRoutes(app);
  
  return { app, server };
}

/**
 * Create a test user for testing purposes
 */
export async function createTestUser(username: string, password: string) {
  const user = await db.insert(users).values({
    username,
    password, // In a real app, this would be hashed
    name: 'Test User',
    email: `${username}@test.com`,
    plan: 'free',
    plan_active: true,
    plan_expiry: null,
    flow_score: 0,
    streak_days: 0,
    hourly_rate: 60,
    currency: 'USD',
    razorpay_customer_id: null,
    razorpay_subscription_id: null,
    pref_reduce_motion: false,
    google_refresh_token: null,
    outlook_refresh_token: null,
    created_at: new Date(),
    // Add all required fields
  }).returning();
  
  return user[0];
}

/**
 * Delete a test user
 */
export async function deleteTestUser(userId: number) {
  // Clean up any tasks
  await db.delete(tasks).where({ user_id: userId });
  
  // Clean up user
  await db.delete(users).where({ id: userId });
}

/**
 * Login a test user and return the cookies for authenticated requests
 */
export async function loginTestUser(app: any, username: string, password: string) {
  return await request(app)
    .post('/api/login')
    .send({ username, password });
}

/**
 * Create a test task for a user
 */
export async function createTestTask(userId: number, taskData: Partial<InsertTask> = {}) {
  const task = await db.insert(tasks).values({
    user_id: userId,
    title: taskData.title || 'Test Task',
    description: taskData.description || null,
    status: taskData.status || 'today',
    priority: taskData.priority || 'medium',
    due_date: taskData.due_date || null,
    points: taskData.points || 5,
    completed_at: null,
    created_at: new Date(),
    priority_score: null
  }).returning();
  
  return task[0];
}