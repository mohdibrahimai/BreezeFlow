import { pool, db } from '../../server/db';
import { users, tasks, events, bills } from '../../shared/schema';
import { sql } from 'drizzle-orm';

// Clean up the database before each test
beforeAll(async () => {
  console.log('Setting up test environment...');
  
  try {
    // We'll create a test database if needed
    // For now, we'll just clean existing tables
    await cleanupTestData();
  } catch (error) {
    console.error('Error in test setup:', error);
    throw error;
  }
});

// Clean up after all tests
afterAll(async () => {
  console.log('Cleaning up test environment...');
  
  try {
    await cleanupTestData();
    
    // Close the database connection
    await pool.end();
  } catch (error) {
    console.error('Error in test cleanup:', error);
    throw error;
  }
});

async function cleanupTestData() {
  // Delete all test data
  // Using transaction to ensure all operations succeed or fail together
  try {
    // Delete test users and their associated data
    // Find test user IDs
    const testUsers = await db.select({ id: users.id }).from(users).where(sql`username LIKE 'test_%'`);
    const testUserIds = testUsers.map(user => user.id);
    
    if (testUserIds.length > 0) {
      // Delete associated data
      await db.delete(tasks).where(sql`user_id IN (${testUserIds.join(',')})`);
      await db.delete(events).where(sql`user_id IN (${testUserIds.join(',')})`);
      await db.delete(bills).where(sql`user_id IN (${testUserIds.join(',')})`);
      
      // Delete test users
      await db.delete(users).where(sql`username LIKE 'test_%'`);
    }
  } catch (error) {
    console.error('Error cleaning up test data:', error);
    throw error;
  }
}