import { describe, it, expect, beforeEach, afterEach, vi } from 'vitest';
import { Request, Response } from 'express';
import { User } from '../shared/schema';

// These mocks need to be before any imports that use them due to hoisting
const mockHash = vi.fn().mockResolvedValue('hashed_password');
const mockCompare = vi.fn().mockResolvedValue(true);
const mockSign = vi.fn().mockReturnValue('mock_token');
const mockVerify = vi.fn().mockReturnValue({ userId: 1, username: 'testuser' });

vi.mock('bcrypt', () => ({
  default: {
    hash: mockHash,
    compare: mockCompare
  },
  hash: mockHash,
  compare: mockCompare
}));

vi.mock('jsonwebtoken', () => ({
  default: {
    sign: mockSign,
    verify: mockVerify
  },
  sign: mockSign,
  verify: mockVerify
}));

// Mock storage module
const mockGetUserByUsername = vi.fn();
const mockCreateUser = vi.fn();
const mockGetUser = vi.fn();

vi.mock('../server/storage', () => ({
  storage: {
    getUserByUsername: mockGetUserByUsername,
    createUser: mockCreateUser,
    getUser: mockGetUser
  }
}));

// Import after mocks
import bcrypt from 'bcrypt';
import jwt from 'jsonwebtoken';
import { setupAuth } from '../server/auth';
import { storage } from '../server/storage';

// Tests
describe('Authentication System', () => {
  let req: Partial<Request>;
  let res: Partial<Response>;
  let next: any;
  let app: any;
  
  beforeEach(() => {
    // Reset mocks
    vi.clearAllMocks();
    
    // Mock Express app
    app = {
      post: vi.fn((path, handler) => {
        if (path === '/api/register') {
          app.registerHandler = handler;
        } else if (path === '/api/login') {
          app.loginHandler = handler;
        } else if (path === '/api/logout') {
          app.logoutHandler = handler;
        }
      }),
      get: vi.fn((path, middleware, handler) => {
        if (path === '/api/user') {
          app.authMiddleware = middleware;
          app.userHandler = handler;
        }
      })
    };
    
    // Mock request and response
    req = {
      body: {},
      cookies: {},
      userId: undefined
    };
    
    res = {
      status: vi.fn().mockReturnThis(),
      json: vi.fn().mockReturnThis(),
      cookie: vi.fn().mockReturnThis(),
      clearCookie: vi.fn().mockReturnThis(),
      sendStatus: vi.fn().mockReturnThis()
    };
    
    next = vi.fn();
    
    // Initialize auth routes
    setupAuth(app);
  });
  
  it('should register a user successfully', async () => {
    // Mock implementation
    const mockUser = {
      id: 1,
      username: 'testuser',
      name: 'Test User',
      email: 'test@example.com',
      password: 'hashed_password',
      flow_score: 0,
      streak_days: 0
    } as User;
    
    mockGetUserByUsername.mockResolvedValue(undefined);
    mockCreateUser.mockResolvedValue(mockUser);
    
    // Setup request
    req.body = {
      username: 'testuser',
      name: 'Test User',
      email: 'test@example.com',
      password: 'password123'
    };
    
    // Call handler
    await app.registerHandler(req, res, next);
    
    // Assert function calls
    expect(mockGetUserByUsername).toHaveBeenCalledWith('testuser');
    expect(bcrypt.hash).toHaveBeenCalledWith('password123', 10);
    expect(mockCreateUser).toHaveBeenCalledWith({
      username: 'testuser',
      name: 'Test User',
      email: 'test@example.com',
      password: 'hashed_password'
    });
    
    // Assert response
    expect(res.cookie).toHaveBeenCalledWith('jwt', 'mock_token', expect.any(Object));
    expect(res.status).toHaveBeenCalledWith(201);
    expect(res.json).toHaveBeenCalledWith({
      id: 1,
      username: 'testuser',
      name: 'Test User',
      email: 'test@example.com',
      flow_score: 0,
      streak_days: 0
    });
  });
  
  it('should login a user successfully', async () => {
    // Mock user
    const mockUser = {
      id: 1,
      username: 'testuser',
      name: 'Test User',
      email: 'test@example.com',
      password: 'hashed_password',
      flow_score: 0,
      streak_days: 0
    } as User;
    
    // Setup mocks
    mockGetUserByUsername.mockResolvedValue(mockUser);
    bcrypt.compare.mockResolvedValue(true);
    
    // Setup request
    req.body = {
      username: 'testuser',
      password: 'password123'
    };
    
    // Call handler
    await app.loginHandler(req, res, next);
    
    // Assert function calls
    expect(mockGetUserByUsername).toHaveBeenCalledWith('testuser');
    expect(bcrypt.compare).toHaveBeenCalledWith('password123', 'hashed_password');
    expect(jwt.sign).toHaveBeenCalled();
    
    // Assert response
    expect(res.cookie).toHaveBeenCalledWith('jwt', 'mock_token', expect.any(Object));
    expect(res.status).toHaveBeenCalledWith(200);
    expect(res.json).toHaveBeenCalledWith({
      id: 1,
      username: 'testuser',
      name: 'Test User',
      email: 'test@example.com',
      flow_score: 0,
      streak_days: 0
    });
  });
  
  it('should verify JWT in auth middleware', async () => {
    // Setup request with JWT cookie
    req.cookies = { jwt: 'valid_token' };
    
    // Call middleware
    app.authMiddleware(req, res, next);
    
    // Assert
    expect(mockVerify).toHaveBeenCalledWith('valid_token', expect.any(String));
    expect(req.userId).toBe(1);
    expect(next).toHaveBeenCalled();
  });
  
  it('should logout a user', async () => {
    // Call handler
    app.logoutHandler(req, res);
    
    // Assert
    expect(res.clearCookie).toHaveBeenCalledWith('jwt');
    expect(res.sendStatus).toHaveBeenCalledWith(200);
  });
});