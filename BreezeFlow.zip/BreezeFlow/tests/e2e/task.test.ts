import request from 'supertest';
import { createTestApp, createTestUser, createTestTask, deleteTestUser, loginTestUser } from '../utils/utils';

describe('Task Management API', () => {
  let app: any;
  let server: any;
  let testUserId: number;
  let cookies: string[];
  
  beforeAll(async () => {
    // Create test application
    const testApp = await createTestApp();
    app = testApp.app;
    server = testApp.server;
    
    // Create a test user
    const testUsername = `test_tasks_${Date.now()}`;
    const testPassword = 'TaskPassword123!';
    const user = await createTestUser(testUsername, testPassword);
    testUserId = user.id;
    
    // Login to get session cookies
    const response = await loginTestUser(app, testUsername, testPassword);
    cookies = response.headers['set-cookie'];
  });
  
  afterAll(async () => {
    // Clean up test user and associated data
    await deleteTestUser(testUserId);
    
    // Close server
    if (server) {
      await new Promise((resolve) => server.close(resolve));
    }
  });
  
  describe('Task Creation', () => {
    it('should create a new task', async () => {
      const taskData = {
        title: 'Test Task Creation',
        description: 'Description for test task',
        status: 'today',
        priority: 'medium',
        due_date: new Date(Date.now() + 86400000).toISOString().split('T')[0], // Tomorrow
        points: 5
      };
      
      const response = await request(app)
        .post('/api/tasks')
        .set('Cookie', cookies)
        .send(taskData);
      
      expect(response.status).toBe(201);
      expect(response.body).toHaveProperty('id');
      expect(response.body.title).toBe(taskData.title);
      expect(response.body.user_id).toBe(testUserId);
    });
    
    it('should reject task creation for unauthenticated users', async () => {
      const taskData = {
        title: 'Unauthenticated Task',
        description: 'This should fail',
        status: 'today',
        priority: 'medium'
      };
      
      const response = await request(app)
        .post('/api/tasks')
        .send(taskData);
      
      expect(response.status).toBe(401);
    });
  });
  
  describe('Task Retrieval', () => {
    let testTaskId: number;
    
    beforeAll(async () => {
      // Create a test task
      const task = await createTestTask(testUserId, {
        title: 'Test Retrieval Task'
      });
      testTaskId = task.id;
    });
    
    it('should retrieve all tasks for authenticated user', async () => {
      const response = await request(app)
        .get('/api/tasks')
        .set('Cookie', cookies);
      
      expect(response.status).toBe(200);
      expect(Array.isArray(response.body)).toBe(true);
      expect(response.body.length).toBeGreaterThan(0);
      
      // All tasks should belong to the test user
      response.body.forEach((task: any) => {
        expect(task.user_id).toBe(testUserId);
      });
    });
    
    it('should retrieve a specific task by ID', async () => {
      const response = await request(app)
        .get(`/api/tasks/${testTaskId}`)
        .set('Cookie', cookies);
      
      expect(response.status).toBe(200);
      expect(response.body).toHaveProperty('id');
      expect(response.body.id).toBe(testTaskId);
      expect(response.body.user_id).toBe(testUserId);
    });
    
    it('should return 404 for non-existent task', async () => {
      const nonExistentId = 99999; // Assuming this ID doesn't exist
      
      const response = await request(app)
        .get(`/api/tasks/${nonExistentId}`)
        .set('Cookie', cookies);
      
      expect(response.status).toBe(404);
    });
    
    it('should not allow access to tasks from another user', async () => {
      // Create another user
      const otherUsername = `other_user_${Date.now()}`;
      const otherPassword = 'OtherPassword123!';
      const otherUser = await createTestUser(otherUsername, otherPassword);
      
      // Create a task for the other user
      const otherTask = await createTestTask(otherUser.id, {
        title: 'Other User Task'
      });
      
      // Try to access the other user's task
      const response = await request(app)
        .get(`/api/tasks/${otherTask.id}`)
        .set('Cookie', cookies);
      
      expect(response.status).toBe(404); // Should act as if it doesn't exist
      
      // Clean up
      await deleteTestUser(otherUser.id);
    });
  });
  
  describe('Task Update', () => {
    let testTaskId: number;
    
    beforeAll(async () => {
      // Create a test task
      const task = await createTestTask(testUserId, {
        title: 'Test Update Task',
        description: 'Original description',
        priority: 'medium'
      });
      testTaskId = task.id;
    });
    
    it('should update a task', async () => {
      const updateData = {
        title: 'Updated Task Title',
        description: 'Updated description',
        priority: 'high'
      };
      
      const response = await request(app)
        .patch(`/api/tasks/${testTaskId}`)
        .set('Cookie', cookies)
        .send(updateData);
      
      expect(response.status).toBe(200);
      expect(response.body.title).toBe(updateData.title);
      expect(response.body.description).toBe(updateData.description);
      expect(response.body.priority).toBe(updateData.priority);
    });
    
    it('should reject updates to non-existent tasks', async () => {
      const nonExistentId = 99999; // Assuming this ID doesn't exist
      
      const response = await request(app)
        .patch(`/api/tasks/${nonExistentId}`)
        .set('Cookie', cookies)
        .send({ title: 'This should fail' });
      
      expect(response.status).toBe(404);
    });
  });
  
  describe('Task Completion', () => {
    let testTaskId: number;
    
    beforeAll(async () => {
      // Create a test task
      const task = await createTestTask(testUserId, {
        title: 'Test Completion Task'
      });
      testTaskId = task.id;
    });
    
    it('should mark a task as complete', async () => {
      const response = await request(app)
        .post(`/api/tasks/${testTaskId}/complete`)
        .set('Cookie', cookies);
      
      expect(response.status).toBe(200);
      expect(response.body.completed_at).not.toBeNull();
    });
    
    it('should get all completed tasks', async () => {
      const response = await request(app)
        .get('/api/tasks/completed')
        .set('Cookie', cookies);
      
      expect(response.status).toBe(200);
      expect(Array.isArray(response.body)).toBe(true);
      
      // Verify our completed task is in the list
      const completedTask = response.body.find((task: any) => task.id === testTaskId);
      expect(completedTask).toBeDefined();
      expect(completedTask.completed_at).not.toBeNull();
    });
  });
  
  describe('Task Deletion', () => {
    let testTaskId: number;
    
    beforeAll(async () => {
      // Create a test task
      const task = await createTestTask(testUserId, {
        title: 'Test Deletion Task'
      });
      testTaskId = task.id;
    });
    
    it('should delete a task', async () => {
      const response = await request(app)
        .delete(`/api/tasks/${testTaskId}`)
        .set('Cookie', cookies);
      
      expect(response.status).toBe(200);
      
      // Verify the task is gone
      const getResponse = await request(app)
        .get(`/api/tasks/${testTaskId}`)
        .set('Cookie', cookies);
      
      expect(getResponse.status).toBe(404);
    });
    
    it('should return 404 when deleting non-existent task', async () => {
      const nonExistentId = 99999; // Assuming this ID doesn't exist
      
      const response = await request(app)
        .delete(`/api/tasks/${nonExistentId}`)
        .set('Cookie', cookies);
      
      expect(response.status).toBe(404);
    });
  });
  
  describe('Task Filtering', () => {
    beforeAll(async () => {
      // Create tasks with different statuses for filtering tests
      await createTestTask(testUserId, {
        title: 'Today Task 1',
        status: 'today',
        priority: 'high'
      });
      
      await createTestTask(testUserId, {
        title: 'Today Task 2',
        status: 'today',
        priority: 'medium'
      });
      
      await createTestTask(testUserId, {
        title: 'Tomorrow Task',
        status: 'tomorrow',
        priority: 'medium'
      });
      
      await createTestTask(testUserId, {
        title: 'Someday Task',
        status: 'someday',
        priority: 'low'
      });
    });
    
    it('should filter tasks by status', async () => {
      const response = await request(app)
        .get('/api/tasks?status=today')
        .set('Cookie', cookies);
      
      expect(response.status).toBe(200);
      expect(Array.isArray(response.body)).toBe(true);
      expect(response.body.length).toBeGreaterThan(0);
      
      // All returned tasks should have status 'today'
      response.body.forEach((task: any) => {
        expect(task.status).toBe('today');
      });
    });
    
    it('should filter tasks by priority', async () => {
      const response = await request(app)
        .get('/api/tasks?priority=high')
        .set('Cookie', cookies);
      
      expect(response.status).toBe(200);
      expect(Array.isArray(response.body)).toBe(true);
      
      // All returned tasks should have priority 'high'
      response.body.forEach((task: any) => {
        expect(task.priority).toBe('high');
      });
    });
    
    it('should combine filters', async () => {
      const response = await request(app)
        .get('/api/tasks?status=today&priority=medium')
        .set('Cookie', cookies);
      
      expect(response.status).toBe(200);
      expect(Array.isArray(response.body)).toBe(true);
      
      // All returned tasks should match both criteria
      response.body.forEach((task: any) => {
        expect(task.status).toBe('today');
        expect(task.priority).toBe('medium');
      });
    });
  });
});