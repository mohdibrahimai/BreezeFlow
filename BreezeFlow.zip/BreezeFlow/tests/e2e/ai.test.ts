import request from 'supertest';
import { createTestApp, createTestUser, deleteTestUser, loginTestUser } from '../utils/utils';

describe('AI Features API', () => {
  let app: any;
  let server: any;
  let testUserId: number;
  let cookies: string[];
  
  beforeAll(async () => {
    // Create test application
    const testApp = await createTestApp();
    app = testApp.app;
    server = testApp.server;
    
    // Create a test user
    const testUsername = `test_ai_${Date.now()}`;
    const testPassword = 'AIPassword123!';
    const user = await createTestUser(testUsername, testPassword);
    testUserId = user.id;
    
    // Login to get session cookies
    const response = await loginTestUser(app, testUsername, testPassword);
    cookies = response.headers['set-cookie'];
  });
  
  afterAll(async () => {
    // Clean up test user and associated data
    await deleteTestUser(testUserId);
    
    // Close server
    if (server) {
      await new Promise((resolve) => server.close(resolve));
    }
  });
  
  describe('AI Task Parsing', () => {
    it('should parse a natural language task request', async () => {
      const response = await request(app)
        .post('/api/copilot/parseTask')
        .set('Cookie', cookies)
        .send({
          prompt: 'Submit tax report by Friday'
        });
      
      expect(response.status).toBe(200);
      
      // Check if the response contains the expected fields
      expect(response.body).toHaveProperty('title');
      expect(response.body.title).toContain('tax report');
      
      // Should have a due date
      expect(response.body).toHaveProperty('dueDate');
      
      // Should have priority
      expect(response.body).toHaveProperty('priority');
      expect(['low', 'medium', 'high']).toContain(response.body.priority);
    });
    
    it('should handle complex task parsing', async () => {
      const response = await request(app)
        .post('/api/copilot/parseTask')
        .set('Cookie', cookies)
        .send({
          prompt: 'I need to prepare a presentation for the board meeting next Thursday at 2pm, it\'s very important'
        });
      
      expect(response.status).toBe(200);
      
      // Check for basic task fields
      expect(response.body).toHaveProperty('title');
      expect(response.body.title).toContain('presentation');
      
      // Should have a due date
      expect(response.body).toHaveProperty('dueDate');
      
      // Should be high priority due to "very important"
      expect(response.body).toHaveProperty('priority');
      expect(response.body.priority).toBe('high');
    });
  });
  
  describe('Schedule Optimization', () => {
    it('should optimize a schedule with multiple tasks', async () => {
      const response = await request(app)
        .post('/api/ml/optimize-schedule')
        .set('Cookie', cookies)
        .send({
          tasks: [
            {
              id: 1,
              title: 'Write report',
              status: 'today',
              priority: 'high',
              estimated_minutes: 60
            },
            {
              id: 2,
              title: 'Team meeting',
              status: 'today',
              priority: 'medium',
              estimated_minutes: 30
            }
          ],
          events: [
            {
              id: 1,
              title: 'Lunch',
              start: new Date(new Date().setHours(12, 0, 0, 0)).toISOString(),
              end: new Date(new Date().setHours(13, 0, 0, 0)).toISOString(),
              isFixed: true
            }
          ]
        });
      
      expect(response.status).toBe(200);
      
      // Check for the optimized schedule
      expect(response.body).toHaveProperty('timeBlocks');
      expect(Array.isArray(response.body.timeBlocks)).toBe(true);
      
      // Should have at least 2 time blocks for our tasks
      expect(response.body.timeBlocks.length).toBeGreaterThanOrEqual(2);
      
      // Time blocks should be in chronological order and not overlap
      const blocks = response.body.timeBlocks;
      for (let i = 1; i < blocks.length; i++) {
        const prevEnd = new Date(blocks[i-1].endISO).getTime();
        const currStart = new Date(blocks[i].startISO).getTime();
        expect(prevEnd).toBeLessThanOrEqual(currStart);
      }
    });
  });
  
  describe('ML Priority Scoring', () => {
    let testTaskId: number;
    
    beforeAll(async () => {
      // Create a test task specifically for ML testing
      const task = await createTestTask(testUserId, {
        title: 'ML Priority Score Test Task',
        description: 'This task is used to test priority scoring',
        priority: 'medium',
        due_date: new Date(Date.now() + 5 * 86400000).toISOString().split('T')[0] // 5 days from now
      });
      
      testTaskId = task.id;
    });
    
    it('should calculate priority score for a single task', async () => {
      const response = await request(app)
        .get(`/api/ml/priorityScore/${testTaskId}`)
        .set('Cookie', cookies);
      
      // We may not be able to test for 200 if ML model is not yet set up
      if (response.status === 200) {
        expect(response.body).toHaveProperty('score');
        expect(typeof response.body.score).toBe('number');
        expect(response.body.score).toBeGreaterThanOrEqual(0);
        expect(response.body.score).toBeLessThanOrEqual(100);
        
        expect(response.body).toHaveProperty('minutesSaved');
        expect(typeof response.body.minutesSaved).toBe('number');
      } else if (response.status === 500) {
        // If ML is not set up, check for appropriate error message
        expect(response.body).toHaveProperty('error');
        console.log(`ML test skipped - reason: ${response.body.error}`);
      }
    });
    
    it('should attempt to calculate batch priority scores', async () => {
      // Create a few more tasks for batch testing
      const task1 = await createTestTask(testUserId, {
        title: 'Batch Priority Task 1',
        priority: 'high',
        due_date: new Date(Date.now() + 2 * 86400000).toISOString().split('T')[0] // 2 days from now
      });
      
      const task2 = await createTestTask(testUserId, {
        title: 'Batch Priority Task 2',
        priority: 'low',
        due_date: new Date(Date.now() + 10 * 86400000).toISOString().split('T')[0] // 10 days from now
      });
      
      // Get debugging information about the tasks
      console.log('Test tasks for batch priority processing:');
      console.log(JSON.stringify([testTaskId, task1.id, task2.id], null, 2));
      
      const response = await request(app)
        .post('/api/ml/batchPriorityScore')
        .set('Cookie', cookies)
        .send({
          taskIds: [testTaskId, task1.id, task2.id]
        });
      
      // Log response for debugging
      console.log(`Batch priority score response (${response.status}):`, response.body);
      
      // We may not be able to test for 200 if ML model is not yet set up
      if (response.status === 200) {
        expect(Array.isArray(response.body)).toBe(true);
        expect(response.body.length).toBeGreaterThan(0);
        
        // Each item should have taskId, score, and minutesSaved
        response.body.forEach((item: any) => {
          expect(item).toHaveProperty('taskId');
          expect(item).toHaveProperty('score');
          expect(item).toHaveProperty('minutesSaved');
        });
      } else if (response.status === 500) {
        // If ML is not set up, check for appropriate error message
        expect(response.body).toHaveProperty('error');
        console.log(`ML batch test skipped - reason: ${response.body.error}`);
      }
    });
    
    it('should handle missing or invalid tasks gracefully', async () => {
      const nonExistentId = 99999; // Assuming this ID doesn't exist
      
      const response = await request(app)
        .get(`/api/ml/priorityScore/${nonExistentId}`)
        .set('Cookie', cookies);
      
      expect(response.status).toBe(404);
    });
  });
});