import request from 'supertest';
import { createTestApp, createTestUser, createTestTask, deleteTestUser, loginTestUser } from '../utils/utils';

describe('ROI Tracking API', () => {
  let app: any;
  let server: any;
  let testUserId: number;
  let cookies: string[];
  
  beforeAll(async () => {
    // Create test application
    const testApp = await createTestApp();
    app = testApp.app;
    server = testApp.server;
    
    // Create a test user with a higher hourly rate for better ROI visibility
    const testUsername = `test_roi_${Date.now()}`;
    const testPassword = 'ROIPassword123!';
    const user = await createTestUser(testUsername, testPassword);
    testUserId = user.id;
    
    // Login to get session cookies
    const response = await loginTestUser(app, testUsername, testPassword);
    cookies = response.headers['set-cookie'];
  });
  
  afterAll(async () => {
    // Clean up test user and associated data
    await deleteTestUser(testUserId);
    
    // Close server
    if (server) {
      await new Promise((resolve) => server.close(resolve));
    }
  });
  
  describe('ROI Calculation for Completed Tasks', () => {
    let highPriorityTaskId: number;
    let mediumPriorityTaskId: number;
    let lowPriorityTaskId: number;
    
    beforeAll(async () => {
      // Create tasks with different priorities
      const highPriorityTask = await createTestTask(testUserId, { 
        title: 'High Priority ROI Test Task', 
        priority: 'high'
      });
      
      const mediumPriorityTask = await createTestTask(testUserId, { 
        title: 'Medium Priority ROI Test Task', 
        priority: 'medium'
      });
      
      const lowPriorityTask = await createTestTask(testUserId, { 
        title: 'Low Priority ROI Test Task', 
        priority: 'low'
      });
      
      highPriorityTaskId = highPriorityTask.id;
      mediumPriorityTaskId = mediumPriorityTask.id;
      lowPriorityTaskId = lowPriorityTask.id;
    });
    
    it('should calculate ROI for a high priority task', async () => {
      // Complete the high priority task
      await request(app)
        .post(`/api/tasks/${highPriorityTaskId}/complete`)
        .set('Cookie', cookies);
      
      // Check ROI
      const response = await request(app)
        .get('/api/roi')
        .set('Cookie', cookies);
      
      expect(response.status).toBe(200);
      expect(response.body).toHaveProperty('hoursSaved');
      expect(response.body).toHaveProperty('moneySaved');
      
      // High priority tasks save 45 minutes (0.75 hours)
      expect(response.body.hoursSaved).toBeGreaterThanOrEqual(0.75);
      
      // At $60/hour default rate, should save at least $45
      expect(response.body.moneySaved).toBeGreaterThanOrEqual(45);
    });
    
    it('should calculate ROI for a medium priority task', async () => {
      // Capture the current ROI values
      const beforeResponse = await request(app)
        .get('/api/roi')
        .set('Cookie', cookies);
      
      const hoursSavedBefore = beforeResponse.body.hoursSaved;
      const moneySavedBefore = beforeResponse.body.moneySaved;
      
      // Complete the medium priority task
      await request(app)
        .post(`/api/tasks/${mediumPriorityTaskId}/complete`)
        .set('Cookie', cookies);
      
      // Check updated ROI
      const afterResponse = await request(app)
        .get('/api/roi')
        .set('Cookie', cookies);
      
      expect(afterResponse.status).toBe(200);
      
      // Medium priority tasks save 30 minutes (0.5 hours)
      expect(afterResponse.body.hoursSaved).toBeGreaterThanOrEqual(hoursSavedBefore + 0.5);
      
      // At $60/hour default rate, should save at least $30 more
      expect(afterResponse.body.moneySaved).toBeGreaterThanOrEqual(moneySavedBefore + 30);
    });
    
    it('should calculate ROI for a low priority task', async () => {
      // Capture the current ROI values
      const beforeResponse = await request(app)
        .get('/api/roi')
        .set('Cookie', cookies);
      
      const hoursSavedBefore = beforeResponse.body.hoursSaved;
      const moneySavedBefore = beforeResponse.body.moneySaved;
      
      // Complete the low priority task
      await request(app)
        .post(`/api/tasks/${lowPriorityTaskId}/complete`)
        .set('Cookie', cookies);
      
      // Check updated ROI
      const afterResponse = await request(app)
        .get('/api/roi')
        .set('Cookie', cookies);
      
      expect(afterResponse.status).toBe(200);
      
      // Low priority tasks save 15 minutes (0.25 hours)
      expect(afterResponse.body.hoursSaved).toBeGreaterThanOrEqual(hoursSavedBefore + 0.25);
      
      // At $60/hour default rate, should save at least $15 more
      expect(afterResponse.body.moneySaved).toBeGreaterThanOrEqual(moneySavedBefore + 15);
    });
  });
  
  describe('ROI Dashboard API', () => {
    it('should return all required ROI metrics', async () => {
      const response = await request(app)
        .get('/api/roi')
        .set('Cookie', cookies);
      
      expect(response.status).toBe(200);
      
      // Basic ROI metrics
      expect(response.body).toHaveProperty('hoursSaved');
      expect(response.body).toHaveProperty('moneySaved');
      
      // Action count for user activity
      expect(response.body).toHaveProperty('actionCount');
      expect(response.body.actionCount).toBeGreaterThan(0);
    });
  });
});