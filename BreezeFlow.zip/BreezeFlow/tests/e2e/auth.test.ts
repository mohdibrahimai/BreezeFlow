import request from 'supertest';
import { createTestApp, deleteTestUser } from '../utils/utils';
import { db } from '../../server/db';
import { users } from '../../shared/schema';
import { sql } from 'drizzle-orm';

describe('Authentication API', () => {
  let app: any;
  let server: any;
  
  beforeAll(async () => {
    // Create test application
    const testApp = await createTestApp();
    app = testApp.app;
    server = testApp.server;
  });
  
  afterAll(async () => {
    // Close server
    if (server) {
      await new Promise((resolve) => server.close(resolve));
    }
  });
  
  describe('User Registration', () => {
    const testUsername = `test_auth_${Date.now()}`;
    const testPassword = 'TestPassword123!';
    let userId: number;
    
    afterAll(async () => {
      // Clean up created user
      if (userId) {
        await deleteTestUser(userId);
      }
    });
    
    it('should register a new user', async () => {
      const response = await request(app)
        .post('/api/register')
        .send({
          username: testUsername,
          password: testPassword,
          name: 'Test Auth User',
          email: `${testUsername}@test.com`,
          plan: 'free'
        });
      
      expect(response.status).toBe(201);
      expect(response.body).toHaveProperty('id');
      expect(response.body.username).toBe(testUsername);
      
      // Save the user ID for cleanup
      userId = response.body.id;
    });
    
    it('should not register a user with an existing username', async () => {
      const response = await request(app)
        .post('/api/register')
        .send({
          username: testUsername,
          password: 'AnotherPassword123!',
          name: 'Duplicate User',
          email: 'duplicate@test.com',
          plan: 'free'
        });
      
      expect(response.status).toBe(400);
    });
  });
  
  describe('User Login', () => {
    const testUsername = `test_login_${Date.now()}`;
    const testPassword = 'LoginPassword123!';
    let userId: number;
    
    beforeAll(async () => {
      // Create a test user for login tests with proper password hashing
      const hashedPassword = await (async (password: string) => {
        const bcrypt = require('bcrypt');
        return bcrypt.hash(password, 10);
      })(testPassword);
      
      const user = await db.insert(users).values({
        username: testUsername,
        password: hashedPassword,
        name: 'Login Test User',
        email: `${testUsername}@test.com`,
        plan: 'free',
        plan_active: true,
        plan_expiry: null,
        flow_score: 0,
        streak_days: 0,
        hourly_rate: 60,
        currency: 'USD',
        razorpay_customer_id: null,
        razorpay_subscription_id: null,
        pref_reduce_motion: false,
        google_refresh_token: null,
        outlook_refresh_token: null,
        created_at: new Date()
      }).returning();
      
      userId = user[0].id;
    });
    
    afterAll(async () => {
      // Clean up created user
      if (userId) {
        await deleteTestUser(userId);
      }
    });
    
    it('should login with valid credentials', async () => {
      const response = await request(app)
        .post('/api/login')
        .send({
          username: testUsername,
          password: testPassword
        });
      
      expect(response.status).toBe(200);
      expect(response.body).toHaveProperty('id');
      expect(response.body.username).toBe(testUsername);
      
      // Check for auth cookie
      expect(response.headers['set-cookie']).toBeDefined();
    });
    
    it('should reject login with invalid password', async () => {
      const response = await request(app)
        .post('/api/login')
        .send({
          username: testUsername,
          password: 'WrongPassword123!'
        });
      
      expect(response.status).toBe(401);
    });
    
    it('should reject login with non-existent username', async () => {
      const response = await request(app)
        .post('/api/login')
        .send({
          username: 'nonexistent_user',
          password: 'AnyPassword123!'
        });
      
      expect(response.status).toBe(401);
    });
  });
  
  describe('User Logout', () => {
    const testUsername = `test_logout_${Date.now()}`;
    const testPassword = 'LogoutPassword123!';
    let userId: number;
    let authCookies: string[];
    
    beforeAll(async () => {
      // Create a test user
      const hashedPassword = await (async (password: string) => {
        const bcrypt = require('bcrypt');
        return bcrypt.hash(password, 10);
      })(testPassword);
      
      const user = await db.insert(users).values({
        username: testUsername,
        password: hashedPassword,
        name: 'Logout Test User',
        email: `${testUsername}@test.com`,
        plan: 'free',
        plan_active: true,
        plan_expiry: null,
        flow_score: 0,
        streak_days: 0,
        hourly_rate: 60,
        currency: 'USD',
        razorpay_customer_id: null,
        razorpay_subscription_id: null,
        pref_reduce_motion: false,
        google_refresh_token: null,
        outlook_refresh_token: null,
        created_at: new Date()
      }).returning();
      
      userId = user[0].id;
      
      // Login to get auth cookies
      const loginResponse = await request(app)
        .post('/api/login')
        .send({
          username: testUsername,
          password: testPassword
        });
      
      authCookies = loginResponse.headers['set-cookie'];
    });
    
    afterAll(async () => {
      // Clean up created user
      if (userId) {
        await deleteTestUser(userId);
      }
    });
    
    it('should logout a logged-in user', async () => {
      const response = await request(app)
        .post('/api/logout')
        .set('Cookie', authCookies);
      
      expect(response.status).toBe(200);
    });
    
    it('should not provide user data after logout', async () => {
      // Try to access protected route with old cookies after logout
      const response = await request(app)
        .get('/api/user')
        .set('Cookie', authCookies);
      
      expect(response.status).toBe(401);
    });
  });
  
  describe('User Profile', () => {
    const testUsername = `test_profile_${Date.now()}`;
    const testPassword = 'ProfilePassword123!';
    let userId: number;
    let authCookies: string[];
    
    beforeAll(async () => {
      // Create a test user
      const hashedPassword = await (async (password: string) => {
        const bcrypt = require('bcrypt');
        return bcrypt.hash(password, 10);
      })(testPassword);
      
      const user = await db.insert(users).values({
        username: testUsername,
        password: hashedPassword,
        name: 'Profile Test User',
        email: `${testUsername}@test.com`,
        plan: 'free',
        plan_active: true,
        plan_expiry: null,
        flow_score: 0,
        streak_days: 0,
        hourly_rate: 60,
        currency: 'USD',
        razorpay_customer_id: null,
        razorpay_subscription_id: null,
        pref_reduce_motion: false,
        google_refresh_token: null,
        outlook_refresh_token: null,
        created_at: new Date()
      }).returning();
      
      userId = user[0].id;
      
      // Login to get auth cookies
      const loginResponse = await request(app)
        .post('/api/login')
        .send({
          username: testUsername,
          password: testPassword
        });
      
      authCookies = loginResponse.headers['set-cookie'];
    });
    
    afterAll(async () => {
      // Clean up created user
      if (userId) {
        await deleteTestUser(userId);
      }
    });
    
    it('should get user profile for authenticated user', async () => {
      const response = await request(app)
        .get('/api/user')
        .set('Cookie', authCookies);
      
      expect(response.status).toBe(200);
      expect(response.body).toHaveProperty('id');
      expect(response.body.username).toBe(testUsername);
      expect(response.body.email).toBe(`${testUsername}@test.com`);
      
      // Password should not be returned
      expect(response.body.password).toBeUndefined();
    });
    
    it('should reject unauthenticated access to user profile', async () => {
      const response = await request(app)
        .get('/api/user');
      
      expect(response.status).toBe(401);
    });
  });
});