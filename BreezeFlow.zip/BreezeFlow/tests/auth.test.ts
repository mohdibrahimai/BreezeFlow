import { describe, it, expect, beforeEach, afterEach, vi } from 'vitest';
import bcrypt from 'bcrypt';
import jwt from 'jsonwebtoken';
import { Request, Response } from 'express';
import { storage } from '../server/storage';
import { setupAuth } from '../server/auth';
import { User } from '../shared/schema';

// Mock storage
vi.mock('../server/storage', () => ({
  storage: {
    getUserByUsername: vi.fn(),
    createUser: vi.fn(),
    getUser: vi.fn()
  }
}));

// Mock bcrypt - using ESM default export syntax
vi.mock('bcrypt', async () => {
  const actual = await vi.importActual('bcrypt');
  return {
    ...actual,
    default: {
      hash: vi.fn().mockResolvedValue('hashed_password'),
      compare: vi.fn()
    },
    hash: vi.fn().mockResolvedValue('hashed_password'),
    compare: vi.fn()
  };
});

// Mock jsonwebtoken - using ESM default export syntax
vi.mock('jsonwebtoken', async () => {
  const actual = await vi.importActual('jsonwebtoken');
  return {
    ...actual,
    default: {
      sign: vi.fn().mockReturnValue('mock_token'),
      verify: vi.fn()
    },
    sign: vi.fn().mockReturnValue('mock_token'),
    verify: vi.fn()
  };
});

describe('Authentication System', () => {
  let req: Partial<Request>;
  let res: Partial<Response>;
  let next: vi.Mock;
  let app: any;
  let authMiddleware: any;

  beforeEach(() => {
    // Reset mocks
    vi.clearAllMocks();
    
    // Mock app
    app = {
      post: vi.fn((path, handler) => {
        if (path === '/api/register') {
          app.registerHandler = handler;
        } else if (path === '/api/login') {
          app.loginHandler = handler;
        } else if (path === '/api/logout') {
          app.logoutHandler = handler;
        }
      }),
      get: vi.fn((path, middleware, handler) => {
        if (path === '/api/user') {
          authMiddleware = middleware;
          app.userHandler = handler;
        }
      })
    };
    
    // Mock request and response
    req = {
      body: {},
      cookies: {},
      userId: undefined
    };
    
    res = {
      status: vi.fn().mockReturnThis(),
      json: vi.fn().mockReturnThis(),
      cookie: vi.fn().mockReturnThis(),
      clearCookie: vi.fn().mockReturnThis(),
      sendStatus: vi.fn().mockReturnThis()
    };
    
    next = vi.fn();
    
    // Setup auth routes
    setupAuth(app);
  });

  describe('Registration', () => {
    it('should register a new user successfully', async () => {
      // Mock data
      const mockUser = {
        id: 1,
        username: 'testuser',
        email: 'test@example.com',
        password: 'hashed_password',
        flow_score: 0,
        streak_days: 0
      } as User;
      
      // Setup mocks
      storage.getUserByUsername = vi.fn().mockResolvedValue(undefined);
      storage.createUser = vi.fn().mockResolvedValue(mockUser);
      
      // Setup request
      req.body = {
        username: 'testuser',
        email: 'test@example.com',
        password: 'password123'
      };
      
      // Call handler
      await app.registerHandler(req, res, next);
      
      // Assertions
      expect(storage.getUserByUsername).toHaveBeenCalledWith('testuser');
      expect(bcrypt.hash).toHaveBeenCalledWith('password123', 10);
      expect(storage.createUser).toHaveBeenCalledWith({
        username: 'testuser',
        email: 'test@example.com',
        password: 'hashed_password'
      });
      expect(jwt.sign).toHaveBeenCalled();
      expect(res.cookie).toHaveBeenCalledWith('jwt', 'mock_token', expect.any(Object));
      expect(res.status).toHaveBeenCalledWith(201);
      expect(res.json).toHaveBeenCalledWith(expect.objectContaining({
        id: 1,
        username: 'testuser',
        email: 'test@example.com'
      }));
      // Password should not be in the response
      expect(res.json).not.toHaveBeenCalledWith(expect.objectContaining({
        password: expect.anything()
      }));
    });

    it('should reject registration if username already exists', async () => {
      // Mock existing user
      const existingUser = {
        id: 1,
        username: 'testuser',
        email: 'existing@example.com',
        password: 'hashed_password'
      } as User;
      
      // Setup mocks
      storage.getUserByUsername = vi.fn().mockResolvedValue(existingUser);
      
      // Setup request
      req.body = {
        username: 'testuser',
        email: 'test@example.com',
        password: 'password123'
      };
      
      // Call handler
      await app.registerHandler(req, res, next);
      
      // Assertions
      expect(storage.getUserByUsername).toHaveBeenCalledWith('testuser');
      expect(storage.createUser).not.toHaveBeenCalled();
      expect(res.status).toHaveBeenCalledWith(400);
      expect(res.json).toHaveBeenCalledWith(expect.objectContaining({
        message: 'Username already exists'
      }));
    });
  });

  describe('Login', () => {
    it('should login successfully with correct credentials', async () => {
      // Mock user
      const mockUser = {
        id: 1,
        username: 'testuser',
        email: 'test@example.com',
        password: 'hashed_password',
        flow_score: 0,
        streak_days: 0
      } as User;
      
      // Setup mocks
      storage.getUserByUsername = vi.fn().mockResolvedValue(mockUser);
      bcrypt.compare = vi.fn().mockResolvedValue(true);
      
      // Setup request
      req.body = {
        username: 'testuser',
        password: 'password123'
      };
      
      // Call handler
      await app.loginHandler(req, res, next);
      
      // Assertions
      expect(storage.getUserByUsername).toHaveBeenCalledWith('testuser');
      expect(bcrypt.compare).toHaveBeenCalledWith('password123', 'hashed_password');
      expect(jwt.sign).toHaveBeenCalled();
      expect(res.cookie).toHaveBeenCalledWith('jwt', 'mock_token', expect.any(Object));
      expect(res.status).toHaveBeenCalledWith(200);
      expect(res.json).toHaveBeenCalledWith(expect.objectContaining({
        id: 1,
        username: 'testuser',
        email: 'test@example.com'
      }));
      // Password should not be in the response
      expect(res.json).not.toHaveBeenCalledWith(expect.objectContaining({
        password: expect.anything()
      }));
    });

    it('should reject login with incorrect password', async () => {
      // Mock user
      const mockUser = {
        id: 1,
        username: 'testuser',
        email: 'test@example.com',
        password: 'hashed_password'
      } as User;
      
      // Setup mocks
      storage.getUserByUsername = vi.fn().mockResolvedValue(mockUser);
      bcrypt.compare = vi.fn().mockResolvedValue(false);
      
      // Setup request
      req.body = {
        username: 'testuser',
        password: 'wrong_password'
      };
      
      // Call handler
      await app.loginHandler(req, res, next);
      
      // Assertions
      expect(storage.getUserByUsername).toHaveBeenCalledWith('testuser');
      expect(bcrypt.compare).toHaveBeenCalledWith('wrong_password', 'hashed_password');
      expect(jwt.sign).not.toHaveBeenCalled();
      expect(res.cookie).not.toHaveBeenCalled();
      expect(res.status).toHaveBeenCalledWith(401);
      expect(res.json).toHaveBeenCalledWith(expect.objectContaining({
        message: 'Invalid username or password'
      }));
    });

    it('should reject login with non-existent username', async () => {
      // Setup mocks
      storage.getUserByUsername = vi.fn().mockResolvedValue(undefined);
      
      // Setup request
      req.body = {
        username: 'nonexistent',
        password: 'password123'
      };
      
      // Call handler
      await app.loginHandler(req, res, next);
      
      // Assertions
      expect(storage.getUserByUsername).toHaveBeenCalledWith('nonexistent');
      expect(bcrypt.compare).not.toHaveBeenCalled();
      expect(jwt.sign).not.toHaveBeenCalled();
      expect(res.cookie).not.toHaveBeenCalled();
      expect(res.status).toHaveBeenCalledWith(401);
      expect(res.json).toHaveBeenCalledWith(expect.objectContaining({
        message: 'Invalid username or password'
      }));
    });
  });

  describe('Logout', () => {
    it('should clear the JWT cookie on logout', async () => {
      // Call handler
      await app.logoutHandler(req, res);
      
      // Assertions
      expect(res.clearCookie).toHaveBeenCalledWith('jwt');
      expect(res.sendStatus).toHaveBeenCalledWith(200);
    });
  });

  describe('Auth Middleware', () => {
    it('should allow access to protected routes with valid JWT', async () => {
      // Mock JWT verification
      jwt.verify = vi.fn().mockReturnValue({ userId: 1, username: 'testuser' });
      
      // Setup request with JWT cookie
      req.cookies = { jwt: 'valid_token' };
      
      // Call middleware
      authMiddleware(req, res, next);
      
      // Assertions
      expect(jwt.verify).toHaveBeenCalledWith('valid_token', expect.any(String));
      expect(req.userId).toBe(1);
      expect(next).toHaveBeenCalled();
    });

    it('should reject access to protected routes without JWT', async () => {
      // Setup request without JWT cookie
      req.cookies = {};
      
      // Call middleware
      authMiddleware(req, res, next);
      
      // Assertions
      expect(jwt.verify).not.toHaveBeenCalled();
      expect(next).not.toHaveBeenCalled();
      expect(res.status).toHaveBeenCalledWith(401);
      expect(res.json).toHaveBeenCalledWith(expect.objectContaining({
        message: 'Not authenticated'
      }));
    });

    it('should reject access with invalid JWT', async () => {
      // Mock JWT verification to throw error
      jwt.verify = vi.fn().mockImplementation(() => {
        throw new Error('Invalid token');
      });
      
      // Setup request with invalid JWT cookie
      req.cookies = { jwt: 'invalid_token' };
      
      // Call middleware
      authMiddleware(req, res, next);
      
      // Assertions
      expect(jwt.verify).toHaveBeenCalledWith('invalid_token', expect.any(String));
      expect(next).not.toHaveBeenCalled();
      expect(res.status).toHaveBeenCalledWith(401);
      expect(res.json).toHaveBeenCalledWith(expect.objectContaining({
        message: 'Invalid or expired token'
      }));
    });
  });

  describe('Get Current User', () => {
    it('should return user data for authenticated user', async () => {
      // Mock user
      const mockUser = {
        id: 1,
        username: 'testuser',
        email: 'test@example.com',
        password: 'hashed_password',
        flow_score: 0,
        streak_days: 0
      } as User;
      
      // Setup mocks
      storage.getUser = vi.fn().mockResolvedValue(mockUser);
      
      // Setup request
      req.userId = 1;
      
      // Call handler
      await app.userHandler(req, res, next);
      
      // Assertions
      expect(storage.getUser).toHaveBeenCalledWith(1);
      expect(res.json).toHaveBeenCalledWith(expect.objectContaining({
        id: 1,
        username: 'testuser',
        email: 'test@example.com'
      }));
      // Password should not be in the response
      expect(res.json).not.toHaveBeenCalledWith(expect.objectContaining({
        password: expect.anything()
      }));
    });

    it('should return 404 if user is not found', async () => {
      // Setup mocks
      storage.getUser = vi.fn().mockResolvedValue(undefined);
      
      // Setup request
      req.userId = 999;
      
      // Call handler
      await app.userHandler(req, res, next);
      
      // Assertions
      expect(storage.getUser).toHaveBeenCalledWith(999);
      expect(res.status).toHaveBeenCalledWith(404);
      expect(res.json).toHaveBeenCalledWith(expect.objectContaining({
        message: 'User not found'
      }));
    });
  });
});