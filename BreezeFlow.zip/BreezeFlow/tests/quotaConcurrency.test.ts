import { describe, it, expect, beforeEach, afterEach, vi, beforeAll, afterAll } from 'vitest';
import { pool } from '../server/db';
import { DatabaseStorage } from '../server/database-storage';
import { Request, Response, NextFunction } from 'express';
import { checkQuota } from '../server/middleware/checkQuota';

// Mock express objects
const mockRequest = (userId: number): Partial<Request> => ({
  userId
});

const mockResponse = (): Partial<Response> => {
  const res: Partial<Response> = {
    status: vi.fn().mockReturnThis(),
    json: vi.fn().mockReturnThis(),
    setHeader: vi.fn().mockReturnThis(),
    sendStatus: vi.fn().mockReturnThis()
  };
  return res;
};

const mockNext = (): NextFunction => vi.fn();

describe('Quota Concurrency Tests', () => {
  // Create an isolated storage and test user
  let testUserId: number;
  let storage: DatabaseStorage;
  
  beforeAll(async () => {
    storage = new DatabaseStorage();
    
    // Create a test user
    const testUser = await storage.createUser({
      username: `test_quota_${Date.now()}`,
      password: 'password123', // This would be hashed in real usage
      name: 'Test Quota User',
      email: `test_quota_${Date.now()}@example.com`,
      plan: 'free' // Free plan has a limit of 50 actions
    });
    
    testUserId = testUser.id;
  });
  
  afterAll(async () => {
    // Clean up: ideally we would delete the test user, but for this test we'll leave it
    await pool.end();
  });
  
  beforeEach(async () => {
    // Reset quota usage by removing all usage events
    await pool.query('DELETE FROM usage_events WHERE user_id = $1', [testUserId]);
  });
  
  it('should handle concurrent quota checks correctly', async () => {
    // Set a very small quota for testing
    const LIMIT = 3;
    
    // Mock the user plan check to always return the test limit
    vi.spyOn(storage, 'getUser').mockImplementation(async () => {
      return {
        id: testUserId,
        plan: 'free',
        // Add other required user fields
        username: 'test_user',
        password: 'hashed_password',
        name: 'Test User',
        email: 'test@example.com',
        plan_active: true,
        plan_expiry: null,
        paypal_customer_id: null,
        paypal_subscription_id: null,
        last_payment_date: null,
        flow_score: 0,
        streak_days: 0,
        hourly_rate: 60,
        currency: 'USD',
        pref_reduce_motion: false
      };
    });
    
    // Create multiple promises that will run concurrently
    const promises = [];
    for (let i = 0; i < LIMIT + 2; i++) {
      const req = mockRequest(testUserId);
      const res = mockResponse();
      const next = mockNext();
      
      promises.push(checkQuota(req as Request, res as Response, next));
    }
    
    // Run all promises concurrently
    await Promise.all(promises);
    
    // Check final action count
    const finalCount = await storage.getUserActionCount(testUserId);
    
    // We should have exactly LIMIT actions recorded
    // Any more than that would indicate a race condition
    expect(finalCount).toEqual(LIMIT);
    
    // Verify that quota enforcement is working
    const { quotaExceeded } = await storage.checkAndIncrementQuota(testUserId, LIMIT);
    expect(quotaExceeded).toBe(true);
  });
});