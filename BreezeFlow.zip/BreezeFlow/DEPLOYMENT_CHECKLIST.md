# BreezeFlow Production Launch Checklist

This checklist covers the necessary steps to prepare BreezeFlow's new pricing and quota system and BreezeMind-Lite feature for production deployment.

## Pre-Deployment Tasks

### Database Migration
- [ ] Run migration script to add 'starter' plan tier to the database enum
  ```
  npx tsx migrations/addStarterPlan.ts
  ```
- [ ] Run migration script to add 'role' column to users table
  ```
  npx tsx migrations/addUserRole.ts
  ```
- [ ] Set at least one admin user for platform management
  ```sql
  UPDATE users SET role = 'admin' WHERE username = 'your_admin_username';
  ```
- [ ] Verify migrations completed successfully by checking logs
- [ ] Confirm plan_enum includes 'free', 'starter', 'pro', and 'team' values
- [ ] Confirm 'role' column exists in users table with 'user' and 'admin' options

### Environment Configuration
- [ ] Create and configure production .env file
- [ ] Set up production Razorpay plan IDs for all plans and billing periods:
  - RAZORPAY_PLAN_FREE_ID
  - RAZORPAY_PLAN_STARTER_M (monthly)
  - RAZORPAY_PLAN_STARTER_Y (annual)
  - RAZORPAY_PLAN_PRO_M (monthly)
  - RAZORPAY_PLAN_PRO_Y (annual)
  - RAZORPAY_PLAN_TEAM_M (monthly)
  - RAZORPAY_PLAN_TEAM_Y (annual)
- [ ] Verify all plan IDs are correctly configured in Razorpay dashboard
- [ ] Set Razorpay production keys
  - RAZORPAY_KEY_ID
  - RAZORPAY_KEY_SECRET
  - VITE_RAZORPAY_KEY_ID (for frontend)
  - RAZORPAY_WEBHOOK_SECRET

### Razorpay Configuration
- [ ] Configure production webhook URLs in Razorpay dashboard:
  - Add webhook endpoint: `https://your-production-domain.com/api/razorpay/webhook`
  - Set "Active" status to Enabled
  - Select webhook events to monitor:
    - Payment Events: payment.authorized, payment.captured, payment.failed
    - Subscription Events: subscription.charged, subscription.cancelled, subscription.updated
- [ ] Generate webhook secret and save as RAZORPAY_WEBHOOK_SECRET
- [ ] Enable and configure all desired payment methods:
  - Cards (Credit/Debit cards)
  - UPI (Google Pay, PhonePe, others)
  - Netbanking
  - Wallets (Paytm, Amazon Pay, etc.)
- [ ] Verify merchant branding information is correct for UPI payments:
  - Logo (should be a square image with transparent background)
  - Merchant name (clear and recognizable)
  - Merchant category (properly set for correct UPI categorization)
- [ ] Test webhook delivery using Razorpay dashboard's "Ping webhook URL" feature

### Security Checks
- [ ] Run security audit on dependencies
  ```
  npm audit --production
  ```
- [ ] Ensure JWT refresh token rotation is working correctly
- [ ] Verify rate limiting is properly configured
- [ ] Confirm session cookie security settings (httpOnly, secure)

### Testing
- [ ] Run comprehensive test suite 
  ```
  npm test
  ```
- [ ] Test quota limits and enforcement on all plan tiers
- [ ] Test billing period toggle (monthly and annual)
- [ ] Test upgrade and downgrade flows between all plans
- [ ] Verify concurrency protection with multiple simultaneous requests
- [ ] Test Razorpay checkout flow with all payment methods
- [ ] Verify webhook handling for subscription events

## Deployment Process

### Build and Deploy
- [ ] Create production build
  ```
  npm run build
  ```
- [ ] Deploy to production environment
- [ ] Verify environment variables are correctly loaded
- [ ] Check server logs for any startup errors

### Post-Deployment Verification
- [ ] Verify database connection is working
- [ ] Confirm all API endpoints are accessible
- [ ] Run payment integration diagnostic:
  ```
  curl -H "Authorization: Bearer YOUR_ACCESS_TOKEN" https://your-production-domain.com/api/payment/status
  ```
- [ ] Test user authentication flow
- [ ] Test quota enforcement in production
- [ ] Verify pricing page displays correct plans and pricing
- [ ] Make test purchase with Razorpay in production mode
- [ ] Test UPI payments via Google Pay or other UPI apps
- [ ] Verify subscription management workflow

### Monitoring and Alerts
- [ ] Set up monitoring for API performance and errors
- [ ] Configure alerts for payment failures
- [ ] Set up quota usage monitoring
- [ ] Configure database performance monitoring

## Rollback Plan

In case of critical issues after deployment:

1. Identify the specific issue and its severity
2. For minor issues: Deploy targeted fixes while keeping the system online
3. For major issues: Roll back to the previous stable version:
   ```
   git checkout [previous-stable-tag]
   npm install
   npm run build
   npm start
   ```
4. Document the issue and add to the known issues list
5. Communicate with users if service was disrupted