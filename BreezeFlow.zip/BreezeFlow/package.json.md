# Package.json Configuration Updates

Add the following script to package.json:

```json
{
  "scripts": {
    "test:e2e": "NODE_ENV=test jest tests/e2e --runInBand"
  }
}
```

## Instructions

To add this script to package.json, please run the following commands:

```bash
npx json -I -f package.json -e 'this.scripts["test:e2e"] = "NODE_ENV=test jest tests/e2e --runInBand"'
```

Or manually add the "test:e2e" entry in the scripts section.

## Purpose

This script runs the end-to-end tests for BreezeFlow with proper environment configuration:

- Sets NODE_ENV to 'test' to avoid modifying production data
- Uses Jest as the test runner
- Specifies the e2e test directory
- Uses `--runInBand` to ensure tests run sequentially, which is important for database tests