import { storage } from '../storage';
import { Bill } from '@shared/schema';
import { differenceInDays } from 'date-fns';

interface ReminderCandidate {
  bill: Bill;
  daysUntilDue: number;
}

/**
 * Checks for bills that need reminders based on user preferences
 * Returns a list of bills that should trigger reminders today
 */
export async function checkForDueReminders(): Promise<ReminderCandidate[]> {
  try {
    // Get all upcoming bills
    const upcomingBills = await storage.getAllUpcomingBills();
    const today = new Date();
    const reminderCandidates: ReminderCandidate[] = [];
    
    // Check each bill to see if it needs a reminder
    upcomingBills.forEach((bill: Bill) => {
      // Skip if due date is not set
      if (!bill.due_date) return;
      
      // Skip if reminder days is not set (user doesn't want reminders)
      if (!bill.reminder_days || bill.reminder_days <= 0) return;
      
      const dueDate = new Date(bill.due_date);
      const daysUntilDue = differenceInDays(dueDate, today);
      
      // Check if we should send a reminder based on reminder_days setting
      if (daysUntilDue === bill.reminder_days) {
        // Skip if we already sent a reminder today
        if (bill.last_reminded_at) {
          const lastRemindedAt = new Date(bill.last_reminded_at);
          if (differenceInDays(today, lastRemindedAt) < 1) {
            return; // Already reminded today
          }
        }
        
        reminderCandidates.push({
          bill,
          daysUntilDue
        });
      }
    });
    
    return reminderCandidates;
    
  } catch (error) {
    console.error('Error checking for due reminders:', error);
    return [];
  }
}

/**
 * Sends reminder notifications for bills that are approaching due date
 * Updates the last_reminded_at timestamp for each bill that gets a reminder
 */
export async function processBillReminders(): Promise<number> {
  try {
    const reminderCandidates = await checkForDueReminders();
    
    // For each candidate, send a notification and update the reminder timestamp
    for (const candidate of reminderCandidates) {
      // In a real application, we would send an email or push notification here
      console.log(`Sending reminder for bill: ${candidate.bill.provider} - Due in ${candidate.daysUntilDue} days`);
      
      // Update the last reminded timestamp
      await storage.updateBillReminderTimestamp(candidate.bill.id);
    }
    
    return reminderCandidates.length;
    
  } catch (error) {
    console.error('Error processing bill reminders:', error);
    return 0;
  }
}

/**
 * Gets a list of upcoming reminders for a specific user
 * Used to display in the UI
 */
export async function getUpcomingReminders(userId: number): Promise<{
  bills: Array<Bill & { daysUntilDue: number }>
}> {
  try {
    // Get all bills for this user
    const userBills = await storage.getBills(userId);
    const today = new Date();
    const upcomingReminders: Array<Bill & { daysUntilDue: number }> = [];
    
    // Filter for bills with upcoming due dates
    userBills.forEach((bill: Bill) => {
      // Skip if due date is not set
      if (!bill.due_date) return;
      
      // Skip if bill is not upcoming
      if (bill.status !== 'upcoming') return;
      
      const dueDate = new Date(bill.due_date);
      const daysUntilDue = differenceInDays(dueDate, today);
      
      // Only include bills due within the next 14 days
      if (daysUntilDue >= 0 && daysUntilDue <= 14) {
        upcomingReminders.push({
          ...bill,
          daysUntilDue
        });
      }
    });
    
    // Sort by days remaining (soonest first)
    upcomingReminders.sort((a, b) => a.daysUntilDue - b.daysUntilDue);
    
    return { bills: upcomingReminders };
    
  } catch (error) {
    console.error('Error getting upcoming reminders:', error);
    return { bills: [] };
  }
}