import { MailService } from '@sendgrid/mail';
import { User } from '@shared/schema';

// Initialize SendGrid with API key
const sendgrid = new MailService();

// Only set up SendGrid if API key exists to avoid errors
if (process.env.SENDGRID_API_KEY) {
  sendgrid.setApiKey(process.env.SENDGRID_API_KEY);
}

interface EmailConfig {
  to: string;
  subject: string;
  html: string;
  text?: string;
  from?: string;
}

/**
 * Email service to handle all application emails
 */
export class EmailService {
  private from: string;
  private enabled: boolean;

  constructor() {
    this.from = process.env.EMAIL_FROM || 'noreply@breezeflow.app';
    this.enabled = !!process.env.SENDGRID_API_KEY;
    
    if (!this.enabled && process.env.NODE_ENV === 'production') {
      console.warn('Warning: SendGrid API key not configured. Email service disabled.');
    }
  }

  /**
   * Send a password reset email
   * @param user The user object
   * @param resetToken The reset token
   * @param resetUrl The URL for resetting the password
   * @returns Promise<boolean> Success status
   */
  async sendPasswordResetEmail(user: User, resetToken: string, resetUrl: string): Promise<boolean> {
    const subject = 'BreezeFlow: Password Reset Request';
    
    const html = `
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
        <div style="background-color: #4f46e5; padding: 20px; text-align: center;">
          <h1 style="color: white; margin: 0;">BreezeFlow</h1>
        </div>
        <div style="padding: 20px; border: 1px solid #e5e7eb; border-top: none;">
          <h2>Password Reset Request</h2>
          <p>Hello ${user.name},</p>
          <p>We received a request to reset your password. Click the button below to set a new password:</p>
          <div style="text-align: center; margin: 30px 0;">
            <a href="${resetUrl}" style="background-color: #4f46e5; color: white; padding: 12px 24px; text-decoration: none; border-radius: 4px; font-weight: bold;">Reset My Password</a>
          </div>
          <p>The link is valid for 1 hour. If you didn't request a password reset, you can safely ignore this email.</p>
          <p>Best regards,<br>The BreezeFlow Team</p>
        </div>
        <div style="background-color: #f3f4f6; padding: 15px; text-align: center; font-size: 12px; color: #6b7280;">
          <p>This is an automated message. Please do not reply to this email.</p>
        </div>
      </div>
    `;
    
    const text = `
      Hello ${user.name},
      
      We received a request to reset your password for your BreezeFlow account.
      
      To reset your password, please visit the following link:
      ${resetUrl}
      
      The link is valid for 1 hour. If you didn't request a password reset, you can safely ignore this email.
      
      Best regards,
      The BreezeFlow Team
    `;
    
    return this.sendEmail({
      to: user.email,
      subject,
      html,
      text
    });
  }

  /**
   * Generic method to send an email
   * @param config Email configuration object
   * @returns Promise<boolean> Success status
   */
  async sendEmail(config: EmailConfig): Promise<boolean> {
    // Don't attempt to send if email service is not enabled
    if (!this.enabled) {
      console.log('Email service disabled. Would have sent email to:', config.to);
      console.log('Subject:', config.subject);
      return false;
    }
    
    try {
      await sendgrid.send({
        to: config.to,
        from: config.from || this.from,
        subject: config.subject,
        html: config.html,
        text: config.text || '',
      });
      return true;
    } catch (error) {
      console.error('Failed to send email:', error);
      return false;
    }
  }
}

// Export singleton instance
export const emailService = new EmailService();