import OpenAI from "openai";
import { storage } from "../storage";

// Initialize OpenAI client
const openai = new OpenAI({
  apiKey: process.env.OPENAI_API_KEY,
});

// Type definitions for function calling
interface CreateTaskArgs {
  title: string;
  dueDate?: string; // ISO date string
  priority: "low" | "medium" | "high";
}

interface OptimizeScheduleResponse {
  timeBlocks: {
    title: string;
    startISO: string;
    endISO: string;
  }[];
}

/**
 * Calls OpenAI chat completions API with function calling capabilities
 * @param userId User ID for quota checking and context
 * @param message User's message to the assistant
 * @param responseFormat Optional parameter to specify response format
 * @returns Stream of OpenAI responses
 */
export async function createChatCompletion(
  userId: number,
  message: string,
  responseStream: any // This will be the Express response object
) {
  // Define available functions
  const functions = [
    {
      name: "create_task",
      description: "Create a new task for the user",
      parameters: {
        type: "object",
        properties: {
          title: {
            type: "string",
            description: "The title or description of the task",
          },
          dueDate: {
            type: "string",
            description:
              "The due date for the task in ISO format (YYYY-MM-DD). If not specified, defaults to today.",
          },
          priority: {
            type: "string",
            enum: ["low", "medium", "high"],
            description: "The priority level of the task",
          },
        },
        required: ["title", "priority"],
      },
    },
    {
      name: "get_today_plan",
      description: "Get the user's plan for today, including tasks and events",
      parameters: {
        type: "object",
        properties: {},
      },
    },
    {
      name: "optimize_schedule",
      description:
        "Optimize the user's schedule by arranging tasks into available time slots",
      parameters: {
        type: "object",
        properties: {},
      },
    },
  ];

  try {
    // Create streaming chat completion
    const stream = await openai.chat.completions.create({
      model: "gpt-4o", // the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
      messages: [
        {
          role: "system",
          content:
            "You are BreezeMind, an AI assistant for BreezeFlow productivity app. You help users manage tasks, events, and optimize their schedules. When users ask you to create tasks, get their plan, or optimize their schedule, use the appropriate functions.",
        },
        { role: "user", content: message },
      ],
      functions: functions,
      function_call: "auto",
      stream: true,
    });

    // Setup SSE headers
    responseStream.writeHead(200, {
      "Content-Type": "text/event-stream",
      "Cache-Control": "no-cache",
      Connection: "keep-alive",
    });

    let functionToCall: string | null = null;
    let functionArgs = "";

    // Stream the response
    for await (const chunk of stream) {
      // Check if there's a function call in this chunk
      if (chunk.choices[0]?.delta?.function_call) {
        const fnCall = chunk.choices[0].delta.function_call;
        
        if (fnCall.name) {
          functionToCall = fnCall.name;
        }
        
        if (fnCall.arguments) {
          functionArgs += fnCall.arguments;
        }
        
        // Don't send function calls to the client
        continue;
      }
      
      // Send regular content to the client
      if (chunk.choices[0]?.delta?.content) {
        responseStream.write(`data: ${JSON.stringify({ 
          type: 'content',
          content: chunk.choices[0].delta.content 
        })}\n\n`);
      }
    }

    // If a function was called, execute it
    if (functionToCall) {
      try {
        const args = JSON.parse(functionArgs);
        
        switch (functionToCall) {
          case "create_task":
            await handleCreateTask(userId, args, responseStream);
            break;
          case "get_today_plan":
            await handleGetTodayPlan(userId, responseStream);
            break;
          case "optimize_schedule":
            await handleOptimizeSchedule(userId, responseStream);
            break;
        }
      } catch (error) {
        console.error("Error executing function:", error);
        responseStream.write(`data: ${JSON.stringify({
          type: 'error',
          content: `I encountered an error executing your request: ${error instanceof Error ? error.message : String(error)}`
        })}\n\n`);
      }
    }

    // End the stream
    responseStream.write(`data: ${JSON.stringify({ type: 'done' })}\n\n`);
    responseStream.end();

  } catch (error) {
    console.error("OpenAI API error:", error);
    responseStream.writeHead(500, { "Content-Type": "application/json" });
    responseStream.end(JSON.stringify({ error: "Failed to generate response" }));
  }
}

/**
 * Handle the create_task function call
 */
async function handleCreateTask(
  userId: number,
  args: CreateTaskArgs,
  responseStream: any
) {
  try {
    // Create task using storage
    const task = await storage.createTask({
      user_id: userId,
      title: args.title,
      priority: args.priority,
      due_date: args.dueDate || new Date().toISOString().split('T')[0],
      status: "backlog",
      description: null,
      points: 0
      // removed completed_at as it's not part of the insertTaskSchema
    });

    // Send confirmation to client
    responseStream.write(`data: ${JSON.stringify({
      type: 'function_result',
      function: 'create_task',
      result: {
        success: true,
        taskId: task.id,
        task: task
      }
    })}\n\n`);

    // Also send a natural language confirmation
    responseStream.write(`data: ${JSON.stringify({
      type: 'content',
      content: `I've created a new ${args.priority} priority task: "${args.title}" due on ${args.dueDate || 'today'}.`
    })}\n\n`);

  } catch (error) {
    console.error("Error creating task:", error);
    responseStream.write(`data: ${JSON.stringify({
      type: 'error',
      content: `I couldn't create that task: ${error instanceof Error ? error.message : String(error)}`
    })}\n\n`);
  }
}

/**
 * Handle the get_today_plan function call
 */
async function handleGetTodayPlan(userId: number, responseStream: any) {
  try {
    // Get today's tasks
    const tasks = await storage.getTasks(userId);
    const today = new Date().toISOString().split('T')[0];
    const todaysTasks = tasks.filter(
      task => task.due_date === today && task.completed_at === null
    );

    // Get today's events
    const events = await storage.getEvents(userId);
    const todaysEvents = events.filter(event => {
      const eventDate = new Date(event.start).toISOString().split('T')[0];
      return eventDate === today;
    });

    // Send the plan to the client
    responseStream.write(`data: ${JSON.stringify({
      type: 'function_result',
      function: 'get_today_plan',
      result: {
        tasks: todaysTasks,
        events: todaysEvents,
        date: today
      }
    })}\n\n`);

    // Generate a summary message
    let summaryMessage = `Here's your plan for today:\n\n`;
    
    if (todaysEvents.length > 0) {
      summaryMessage += `**Events:**\n`;
      todaysEvents.forEach(event => {
        const start = new Date(event.start).toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'});
        const end = new Date(event.end).toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'});
        summaryMessage += `- ${start} - ${end}: ${event.title}\n`;
      });
      summaryMessage += `\n`;
    }
    
    if (todaysTasks.length > 0) {
      summaryMessage += `**Tasks:**\n`;
      const priorityOrder = { high: 0, medium: 1, low: 2 };
      const sortedTasks = [...todaysTasks].sort((a, b) => 
        priorityOrder[a.priority as keyof typeof priorityOrder] - 
        priorityOrder[b.priority as keyof typeof priorityOrder]
      );
      
      sortedTasks.forEach(task => {
        const priorityMarker = 
          task.priority === 'high' ? '🔴' : 
          task.priority === 'medium' ? '🟠' : '🟢';
        summaryMessage += `- ${priorityMarker} ${task.title}\n`;
      });
    } else {
      summaryMessage += `You have no tasks scheduled for today.`;
    }

    // Send the summary to the client
    responseStream.write(`data: ${JSON.stringify({
      type: 'content',
      content: summaryMessage
    })}\n\n`);

  } catch (error) {
    console.error("Error getting today's plan:", error);
    responseStream.write(`data: ${JSON.stringify({
      type: 'error',
      content: `I couldn't retrieve your plan for today: ${error instanceof Error ? error.message : String(error)}`
    })}\n\n`);
  }
}

/**
 * Handle the optimize_schedule function call
 */
async function handleOptimizeSchedule(userId: number, responseStream: any) {
  try {
    // Get necessary data for optimization
    const tasks = await storage.getTasks(userId);
    const events = await storage.getEvents(userId);
    
    const today = new Date().toISOString().split('T')[0];
    const todaysTasks = tasks.filter(
      task => task.due_date === today && task.completed_at === null
    );
    const todaysEvents = events.filter(event => {
      const eventDate = new Date(event.start).toISOString().split('T')[0];
      return eventDate === today;
    });

    // Call optimizer service (will be implemented)
    const scheduleResult = await optimizeSchedule(todaysTasks, todaysEvents);

    // Send the optimized schedule to the client
    responseStream.write(`data: ${JSON.stringify({
      type: 'function_result',
      function: 'optimize_schedule',
      result: scheduleResult
    })}\n\n`);

    // Send a natural language summary
    let summaryMessage = `I've optimized your schedule for today. Here's the plan:\n\n`;
    
    // Add fixed events first
    if (todaysEvents.length > 0) {
      summaryMessage += `**Fixed Events:**\n`;
      todaysEvents.forEach(event => {
        const start = new Date(event.start).toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'});
        const end = new Date(event.end).toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'});
        summaryMessage += `- ${start} - ${end}: ${event.title}\n`;
      });
      summaryMessage += `\n`;
    }
    
    // Add scheduled tasks
    if (scheduleResult.timeBlocks.length > 0) {
      summaryMessage += `**Scheduled Tasks:**\n`;
      scheduleResult.timeBlocks.forEach(block => {
        const start = new Date(block.startISO).toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'});
        const end = new Date(block.endISO).toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'});
        summaryMessage += `- ${start} - ${end}: ${block.title}\n`;
      });
    } else {
      summaryMessage += `No tasks were scheduled.`;
    }

    // Send the summary
    responseStream.write(`data: ${JSON.stringify({
      type: 'content',
      content: summaryMessage
    })}\n\n`);

  } catch (error) {
    console.error("Error optimizing schedule:", error);
    responseStream.write(`data: ${JSON.stringify({
      type: 'error',
      content: `I couldn't optimize your schedule: ${error instanceof Error ? error.message : String(error)}`
    })}\n\n`);
  }
}

/**
 * Placeholder for schedule optimization (to be implemented with a proper algorithm)
 */
async function optimizeSchedule(tasks: any[], events: any[]): Promise<OptimizeScheduleResponse> {
  // Sort tasks by priority (high first)
  const priorityMap = { 'high': 3, 'medium': 2, 'low': 1 };
  const sortedTasks = [...tasks].sort((a, b) => {
    return (priorityMap[b.priority as keyof typeof priorityMap] || 0) - 
           (priorityMap[a.priority as keyof typeof priorityMap] || 0);
  });

  // Find free time slots
  const busySlots = events.map(event => ({
    start: new Date(event.start),
    end: new Date(event.end)
  }));
  
  // Sort busy slots by start time
  busySlots.sort((a, b) => a.start.getTime() - b.start.getTime());
  
  // Define the working day (9 AM to 5 PM)
  const today = new Date();
  today.setHours(0, 0, 0, 0);
  
  const dayStart = new Date(today);
  dayStart.setHours(9, 0, 0, 0);
  
  const dayEnd = new Date(today);
  dayEnd.setHours(17, 0, 0, 0);
  
  // Find free slots
  const freeSlots = [];
  let currentTime = dayStart;
  
  for (const busy of busySlots) {
    if (busy.start > currentTime) {
      freeSlots.push({
        start: new Date(currentTime),
        end: new Date(busy.start)
      });
    }
    currentTime = new Date(Math.max(currentTime.getTime(), busy.end.getTime()));
  }
  
  if (currentTime < dayEnd) {
    freeSlots.push({
      start: new Date(currentTime),
      end: new Date(dayEnd)
    });
  }
  
  // Assign tasks to free slots
  const timeBlocks = [];
  let taskIndex = 0;
  
  for (const slot of freeSlots) {
    let slotDuration = (slot.end.getTime() - slot.start.getTime()) / (1000 * 60); // in minutes
    let currentStartTime = new Date(slot.start);
    
    // Try to fit tasks in this slot
    while (taskIndex < sortedTasks.length) {
      const task = sortedTasks[taskIndex];
      
      // Estimate task duration based on priority
      const taskDuration = task.priority === 'high' ? 60 :
                           task.priority === 'medium' ? 45 : 30; // in minutes
      
      if (taskDuration <= slotDuration) {
        // This task fits in the remaining slot
        const taskEndTime = new Date(currentStartTime.getTime() + taskDuration * 60 * 1000);
        
        timeBlocks.push({
          title: task.title,
          startISO: currentStartTime.toISOString(),
          endISO: taskEndTime.toISOString()
        });
        
        // Update for next task
        currentStartTime = taskEndTime;
        slotDuration -= taskDuration;
        taskIndex++;
      } else {
        // No more tasks fit in this slot
        break;
      }
    }
  }
  
  return { timeBlocks };
}