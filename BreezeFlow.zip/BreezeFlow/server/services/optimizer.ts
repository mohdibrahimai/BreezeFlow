import { Task, Event } from "@shared/schema";

/**
 * Interface for time blocks in the optimized schedule
 */
export interface TimeBlock {
  title: string;
  startISO: string;
  endISO: string;
  taskId?: number;
  isFixed?: boolean;
}

/**
 * Interface for schedule optimization results
 */
export interface OptimizedSchedule {
  timeBlocks: TimeBlock[];
  unscheduledTasks?: Task[];
}

/**
 * Optimizes a schedule by packing tasks into free calendar slots
 * Uses a greedy algorithm to minimize end-of-day task lateness
 * 
 * @param tasks List of incomplete tasks for today
 * @param events List of events (fixed appointments) for today
 * @returns Optimized schedule with time blocks for tasks and events
 */
export async function optimizeSchedule(tasks: Task[], events: Event[]): Promise<OptimizedSchedule> {
  // Sort tasks by priority (high first) and then by points (if available)
  const priorityMap = { 'high': 3, 'medium': 2, 'low': 1 };
  const sortedTasks = [...tasks].sort((a, b) => {
    const priorityDiff = (priorityMap[b.priority as keyof typeof priorityMap] || 0) - 
                         (priorityMap[a.priority as keyof typeof priorityMap] || 0);
    
    // If priority is the same, sort by points (if available)
    if (priorityDiff === 0 && a.points && b.points) {
      return b.points - a.points;
    }
    
    return priorityDiff;
  });

  // Find free time slots
  const busySlots = events.map(event => ({
    id: event.id,
    title: event.title,
    start: new Date(event.start),
    end: new Date(event.end)
  }));
  
  // Sort busy slots by start time
  busySlots.sort((a, b) => a.start.getTime() - b.start.getTime());
  
  // Define the working day (9 AM to 5 PM)
  const now = new Date();
  const today = new Date(now.getFullYear(), now.getMonth(), now.getDate());
  
  const dayStart = new Date(today);
  // If current time is after 9 AM, use current time as day start
  if (now.getHours() >= 9) {
    dayStart.setHours(now.getHours(), now.getMinutes(), 0, 0);
  } else {
    dayStart.setHours(9, 0, 0, 0);
  }
  
  const dayEnd = new Date(today);
  dayEnd.setHours(17, 0, 0, 0);
  
  // Find free slots
  const freeSlots: { start: Date; end: Date }[] = [];
  let currentTime = dayStart;
  
  for (const busy of busySlots) {
    if (busy.start > currentTime) {
      freeSlots.push({
        start: new Date(currentTime),
        end: new Date(busy.start)
      });
    }
    currentTime = new Date(Math.max(currentTime.getTime(), busy.end.getTime()));
  }
  
  if (currentTime < dayEnd) {
    freeSlots.push({
      start: new Date(currentTime),
      end: new Date(dayEnd)
    });
  }
  
  // Assign tasks to free slots
  const timeBlocks: TimeBlock[] = [];
  const scheduledTaskIds: Set<number> = new Set();
  let taskIndex = 0;
  
  for (const slot of freeSlots) {
    const slotDuration = (slot.end.getTime() - slot.start.getTime()) / (1000 * 60); // in minutes
    let currentStartTime = new Date(slot.start);
    
    // Try to fit tasks in this slot
    while (taskIndex < sortedTasks.length) {
      const task = sortedTasks[taskIndex];
      
      // Estimate task duration based on priority
      const taskDuration = getEstimatedTaskDuration(task);
      
      // Check if we have enough time left in this slot
      const remainingMinutes = (slot.end.getTime() - currentStartTime.getTime()) / (1000 * 60);
      
      if (taskDuration <= remainingMinutes) {
        // This task fits in the remaining slot
        const taskEndTime = new Date(currentStartTime.getTime() + taskDuration * 60 * 1000);
        
        timeBlocks.push({
          title: task.title,
          startISO: currentStartTime.toISOString(),
          endISO: taskEndTime.toISOString(),
          taskId: task.id,
          isFixed: false
        });
        
        // Update for next task
        currentStartTime = taskEndTime;
        scheduledTaskIds.add(task.id);
        taskIndex++;
      } else {
        // No more tasks fit in this slot
        break;
      }
    }
  }
  
  // Add events as fixed time blocks
  busySlots.forEach(event => {
    timeBlocks.push({
      title: event.title,
      startISO: event.start.toISOString(),
      endISO: event.end.toISOString(),
      isFixed: true
    });
  });
  
  // Sort all time blocks by start time for the final schedule
  timeBlocks.sort((a, b) => {
    return new Date(a.startISO).getTime() - new Date(b.startISO).getTime();
  });
  
  // Identify any unscheduled tasks
  const unscheduledTasks = sortedTasks.filter(task => !scheduledTaskIds.has(task.id));
  
  return { 
    timeBlocks,
    unscheduledTasks: unscheduledTasks.length > 0 ? unscheduledTasks : undefined
  };
}

/**
 * Estimates task duration based on priority and points
 * @param task The task to estimate duration for
 * @returns Estimated duration in minutes
 */
function getEstimatedTaskDuration(task: Task): number {
  // Base duration by priority
  const baseDuration = task.priority === 'high' ? 60 :
                      task.priority === 'medium' ? 45 : 30;
  
  // Adjust by points if available (each point adds 5 minutes)
  const pointsAdjustment = task.points ? Math.min(task.points * 5, 60) : 0;
  
  // Ensure minimum of 15 minutes, maximum of 120 minutes
  return Math.min(Math.max(baseDuration + pointsAdjustment, 15), 120);
}

/**
 * Creates an array of time blocks suitable for calendar rendering
 * @param timeBlocks Array of time blocks from the optimizer
 * @returns Array of time blocks with additional UI-specific properties
 */
export function prepareCalendarBlocks(timeBlocks: TimeBlock[]) {
  return timeBlocks.map(block => ({
    ...block,
    title: block.title,
    start: block.startISO,
    end: block.endISO,
    backgroundColor: block.isFixed ? '#3788d8' : '#28a745',
    borderColor: block.isFixed ? '#2c6aa8' : '#1f8838',
    textColor: '#ffffff',
    editable: !block.isFixed
  }));
}