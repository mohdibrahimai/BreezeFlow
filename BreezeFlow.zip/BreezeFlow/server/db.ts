import { Pool, neonConfig } from '@neondatabase/serverless';
import { drizzle } from 'drizzle-orm/neon-serverless';
import ws from "ws";
import * as schema from "@shared/schema";

neonConfig.webSocketConstructor = ws;

if (!process.env.DATABASE_URL) {
  throw new Error(
    "DATABASE_URL must be set. Did you forget to provision a database?",
  );
}

// Configure the connection pool with resilience settings
export const pool = new Pool({ 
  connectionString: process.env.DATABASE_URL,
  max: 20, // Maximum number of clients in the pool
  idleTimeoutMillis: 30000, // Close idle clients after 30 seconds
  connectionTimeoutMillis: 5000, // Return an error after 5 seconds if connection not established
  maxUses: 7500, // Close and replace a connection after it's been used 7500 times
  
  // Error handling on idle clients
  verify: (client, callback) => {
    client.query('SELECT 1', (err) => {
      if (err) {
        console.error('Database connection verification failed:', err);
        // This client is not working
        callback(err, false);
      } else {
        // This client is good
        callback(null, true);
      }
    });
  }
});

// Log database connection events for monitoring
pool.on('connect', (client) => {
  console.log('New client connected to database');
});

pool.on('error', (err, client) => {
  console.error('Database connection error:', err);
});

// Initialize Drizzle ORM with the pool
export const db = drizzle(pool, { schema });