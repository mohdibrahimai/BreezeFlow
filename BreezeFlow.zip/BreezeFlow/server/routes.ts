import type { Express, Request, Response, NextFunction } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { setupAuth, hashPassword, comparePasswords } from "./auth";
import { db, pool } from "./db";
import { z } from "zod";
import crypto from "crypto";
import { addMinutes } from "date-fns";
import { 
  insertTaskSchema, 
  insertEventSchema,
  insertErrandSchema,
  insertBillSchema,
  insertRewardSchema,
  insertInviteSchema,
  users as usersTable,
  Bill
} from "@shared/schema";
import jwt from "jsonwebtoken";
import { createRazorpayOrder, verifyRazorpayPayment } from "./razorpay";
import { createPaypalOrder, capturePaypalOrder, loadPaypalDefault } from "./paypal";
import Razorpay from 'razorpay';
import { checkQuota, requirePlan } from "./middleware/checkQuota";
import copilotRoutes from "./routes/copilot";
import mlRoutes from "./routes/ml";
import { calendarRouter } from "./routes/calendar";
import { icalendarRouter } from "./routes/icalendar";
import reminderRoutes from "./routes/reminders";
import paymentAssistantRoutes from "./routes/payment-assistant";

// JWT Secret - must match the one in auth.ts
const JWT_SECRET = process.env.ACCESS_TOKEN_SECRET || "breeze-flow-access-token-secret-key";

// Initialize Razorpay for webhook handling (matches the one in razorpay.ts)
let razorpay: Razorpay | null = null;
if (process.env.RAZORPAY_KEY_ID && process.env.RAZORPAY_KEY_SECRET) {
  try {
    razorpay = new Razorpay({
      key_id: process.env.RAZORPAY_KEY_ID,
      key_secret: process.env.RAZORPAY_KEY_SECRET,
    });
  } catch (error) {
    console.error('Failed to initialize Razorpay in routes.ts:', error);
  }
}

// Type for JWT payload
interface JwtPayload {
  userId: number;
  username: string;
  exp?: number;
  tokenType?: 'access' | 'refresh';
}

export async function registerRoutes(app: Express): Promise<Server> {
  // Health check endpoint for monitoring
  app.get("/api/health", async (req, res) => {
    try {
      // Check database connection
      const dbCheck = await db.execute('SELECT 1');
      const isDbConnected = dbCheck.rows && dbCheck.rows.length > 0;
      
      // Basic system information
      const systemInfo = {
        version: process.env.npm_package_version || '1.0.0',
        nodeEnv: process.env.NODE_ENV || 'development',
        timestamp: new Date().toISOString()
      };
      
      // Return health status
      res.json({
        status: 'ok',
        database: isDbConnected ? 'connected' : 'error',
        system: systemInfo,
        uptime: process.uptime()
      });
    } catch (error) {
      console.error('Health check failed:', error);
      res.status(500).json({
        status: 'error',
        message: 'Health check failed',
        timestamp: new Date().toISOString()
      });
    }
  });
  
  // API documentation endpoint
  app.get("/api", (req, res) => {
    res.json({
      name: "BreezeFlow API",
      version: "1.0.0",
      description: "All-in-one productivity management API",
      endpoints: {
        auth: ["/api/register", "/api/login", "/api/logout", "/api/user"],
        tasks: ["/api/tasks", "/api/tasks/:id"],
        events: ["/api/events", "/api/events/:id"],
        errands: ["/api/errands", "/api/errands/:id"],
        bills: ["/api/bills", "/api/bills/:id"],
        payment: [
          "/api/create-razorpay-order", 
          "/api/verify-razorpay-payment",
          "/paypal/setup",
          "/paypal/order",
          "/paypal/order/:orderID/capture"
        ],
        subscription: ["/api/subscription/change-plan", "/api/subscription/cancel"],
        quota: ["/api/user/quota"],
        system: ["/api/health"],
        copilot: ["/api/copilot", "/api/copilot/schedule/optimize"],
        ml: [
          "/api/ml/priorityScore/:taskId", 
          "/api/ml/batchPriorityScore", 
          "/api/ml/retrain",
          "/api/ml/productivity-insights"
        ],
        icalendar: ["/api/icalendar/export", "/api/icalendar/import", "/api/icalendar/event/:eventId", "/api/icalendar/task/:taskId"],
        paymentAssistant: ["/api/payment-assistant/analyze", "/api/payment-assistant/recommendations"]
      },
      docs: "/api/docs"
    });
  });
  
  // Set up authentication routes
  setupAuth(app);
  
  // Forgot password endpoints
  
  // Step 1: Look up user by username and return security question
  app.post("/api/forgot-password/lookup", async (req, res) => {
    const { username } = req.body;
    
    if (!username) {
      return res.status(400).json({ message: "Username is required" });
    }
    
    try {
      const user = await storage.getUserByUsername(username);
      
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }
      
      if (!user.security_question) {
        return res.status(400).json({ 
          message: "No security question set for this account. Please contact support." 
        });
      }
      
      // Return the security question but not the answer
      return res.status(200).json({
        securityQuestion: user.security_question
      });
    } catch (error) {
      console.error("Error in forgot password lookup:", error);
      return res.status(500).json({ message: "Server error" });
    }
  });
  
  // Step 2: Verify security answer
  app.post("/api/forgot-password/verify-answer", async (req, res) => {
    const { username, answer } = req.body;
    
    if (!username || !answer) {
      return res.status(400).json({ message: "Username and answer are required" });
    }
    
    try {
      const user = await storage.getUserByUsername(username);
      
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }
      
      if (!user.security_answer) {
        return res.status(400).json({ message: "No security answer set for this account" });
      }
      
      // Compare the provided answer with the stored hashed answer
      const isCorrect = await comparePasswords(answer, user.security_answer);
      
      if (!isCorrect) {
        return res.status(401).json({ message: "Incorrect security answer" });
      }
      
      // Generate a reset token that will be valid for 15 minutes
      const resetToken = crypto.randomUUID().replace(/-/g, '');
      const resetTokenExpires = addMinutes(new Date(), 15);
      
      // Save the reset token to the user
      await storage.setResetToken(user.id, resetToken, resetTokenExpires);
      
      return res.status(200).json({ 
        message: "Security answer verified successfully"
      });
    } catch (error) {
      console.error("Error in verify security answer:", error);
      return res.status(500).json({ message: "Server error" });
    }
  });
  
  // Step 3: Reset password
  app.post("/api/forgot-password/reset", async (req, res) => {
    const { username, password } = req.body;
    
    if (!username || !password) {
      return res.status(400).json({ message: "Username and password are required" });
    }
    
    try {
      const user = await storage.getUserByUsername(username);
      
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }
      
      // Hash the new password
      const hashedPassword = await hashPassword(password);
      
      // Update the user's password and clear the reset token
      const updatedUser = await storage.updatePassword(user.id, hashedPassword);
      
      if (!updatedUser) {
        return res.status(500).json({ message: "Failed to update password" });
      }
      
      return res.status(200).json({ message: "Password reset successfully" });
    } catch (error) {
      console.error("Error in reset password:", error);
      return res.status(500).json({ message: "Server error" });
    }
  });
  
  // Token-based password reset endpoints for the reset-password page
  
  // Validate reset token
  app.get("/api/validate-reset-token/:token", async (req, res) => {
    const { token } = req.params;
    
    if (!token) {
      return res.status(400).json({ valid: false, message: "Token is required" });
    }
    
    try {
      const isValid = await storage.validateResetToken(token);
      
      if (!isValid) {
        return res.status(200).json({ valid: false, message: "Invalid or expired token" });
      }
      
      return res.status(200).json({ valid: true, message: "Token is valid" });
    } catch (error) {
      console.error("Error validating reset token:", error);
      return res.status(500).json({ valid: false, message: "Server error" });
    }
  });
  
  // Reset password with token
  app.post("/api/reset-password", async (req, res) => {
    const { token, password } = req.body;
    
    if (!token || !password) {
      return res.status(400).json({ message: "Token and password are required" });
    }
    
    try {
      // Validate the token first
      const isValid = await storage.validateResetToken(token);
      
      if (!isValid) {
        return res.status(400).json({ message: "Invalid or expired token" });
      }
      
      // Get the user associated with this token
      const user = await storage.getUserByResetToken(token);
      
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }
      
      // Hash the new password
      const hashedPassword = await hashPassword(password);
      
      // Update the password and clear the reset token
      const updatedUser = await storage.updatePassword(user.id, hashedPassword);
      
      if (!updatedUser) {
        return res.status(500).json({ message: "Failed to update password" });
      }
      
      return res.status(200).json({ message: "Password reset successfully" });
    } catch (error) {
      console.error("Error resetting password with token:", error);
      return res.status(500).json({ message: "Server error" });
    }
  });
  
  // Middleware to check authentication with JWT
  const requireAuth = (req: Request, res: Response, next: NextFunction) => {
    const token = req.cookies.accessToken;
    
    if (!token) {
      return res.status(401).json({ message: "Not authenticated" });
    }
    
    try {
      const decoded = jwt.verify(token, JWT_SECRET) as JwtPayload;
      // Verify this is an access token
      if (decoded.tokenType !== 'access') {
        return res.status(401).json({ message: "Invalid token type" });
      }
      req.userId = decoded.userId;
      next();
    } catch (err) {
      return res.status(401).json({ message: "Invalid or expired token" });
    }
  };
  
  // Register copilot routes with authentication
  app.use("/api/copilot", requireAuth, copilotRoutes);
  
  // Register ML routes with authentication
  app.use("/api/ml", requireAuth, mlRoutes);
  
  // Register calendar integration routes with authentication
  app.use("/api/calendar", requireAuth, calendarRouter);
  
  // Register iCalendar routes with authentication
  app.use("/api/icalendar", requireAuth, icalendarRouter);
  
  // Register bill reminder routes with authentication
  app.use("/api/reminders", requireAuth, reminderRoutes);
  
  // Payment Assistant routes with authentication
  app.use("/api/payment-assistant", requireAuth, requirePlan(['starter', 'pro', 'team']), paymentAssistantRoutes);
  
  // Tasks API
  app.get("/api/tasks", requireAuth, checkQuota('tasks'), async (req, res) => {
    try {
      const tasks = await storage.getTasks(req.userId as number);
      res.json(tasks);
    } catch (err) {
      res.status(500).json({ message: "Failed to fetch tasks" });
    }
  });
  
  app.post("/api/tasks", requireAuth, checkQuota('tasks'), async (req, res) => {
    try {
      const taskData = insertTaskSchema.parse({ ...req.body, user_id: req.userId });
      const task = await storage.createTask(taskData);
      res.status(201).json(task);
    } catch (err) {
      if (err instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid task data", errors: err.errors });
      }
      res.status(500).json({ message: "Failed to create task" });
    }
  });
  
  app.put("/api/tasks/:id", requireAuth, checkQuota('tasks'), async (req, res) => {
    try {
      const taskId = parseInt(req.params.id);
      const task = await storage.getTask(taskId);
      
      if (!task) {
        return res.status(404).json({ message: "Task not found" });
      }
      
      if (task.user_id !== req.userId) {
        return res.status(403).json({ message: "You don't have permission to update this task" });
      }
      
      // If task is being marked as done, update completed_at
      if (req.body.status === "done" && task.status !== "done") {
        req.body.completed_at = new Date().toISOString();
        
        // Award points to the user
        const user = await storage.getUser(req.userId as number);
        if (user) {
          await storage.updateUser(user.id, {
            flow_score: user.flow_score + (task.points || 10)
          });
        }
      }
      
      const updatedTask = await storage.updateTask(taskId, req.body);
      res.json(updatedTask);
    } catch (err) {
      res.status(500).json({ message: "Failed to update task" });
    }
  });
  
  app.delete("/api/tasks/:id", requireAuth, async (req, res) => {
    try {
      const taskId = parseInt(req.params.id);
      const task = await storage.getTask(taskId);
      
      if (!task) {
        return res.status(404).json({ message: "Task not found" });
      }
      
      if (task.user_id !== req.userId) {
        return res.status(403).json({ message: "You don't have permission to delete this task" });
      }
      
      await storage.deleteTask(taskId);
      res.status(204).send();
    } catch (err) {
      res.status(500).json({ message: "Failed to delete task" });
    }
  });
  
  // Events API
  app.get("/api/events", requireAuth, checkQuota('events'), async (req, res) => {
    try {
      const events = await storage.getEvents(req.userId as number);
      res.json(events);
    } catch (err) {
      res.status(500).json({ message: "Failed to fetch events" });
    }
  });
  
  app.post("/api/events", requireAuth, checkQuota('events'), async (req, res) => {
    try {
      const eventData = insertEventSchema.parse({ ...req.body, user_id: req.userId });
      const event = await storage.createEvent(eventData);
      res.status(201).json(event);
    } catch (err) {
      if (err instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid event data", errors: err.errors });
      }
      res.status(500).json({ message: "Failed to create event" });
    }
  });
  
  app.put("/api/events/:id", requireAuth, checkQuota('events'), async (req, res) => {
    try {
      const eventId = parseInt(req.params.id);
      const event = await storage.getEvent(eventId);
      
      if (!event) {
        return res.status(404).json({ message: "Event not found" });
      }
      
      if (event.user_id !== req.userId) {
        return res.status(403).json({ message: "You don't have permission to update this event" });
      }
      
      const updatedEvent = await storage.updateEvent(eventId, req.body);
      res.json(updatedEvent);
    } catch (err) {
      res.status(500).json({ message: "Failed to update event" });
    }
  });
  
  app.delete("/api/events/:id", requireAuth, async (req, res) => {
    try {
      const eventId = parseInt(req.params.id);
      const event = await storage.getEvent(eventId);
      
      if (!event) {
        return res.status(404).json({ message: "Event not found" });
      }
      
      if (event.user_id !== req.userId) {
        return res.status(403).json({ message: "You don't have permission to delete this event" });
      }
      
      await storage.deleteEvent(eventId);
      res.status(204).send();
    } catch (err) {
      res.status(500).json({ message: "Failed to delete event" });
    }
  });
  
  // Errands API
  app.get("/api/errands", requireAuth, checkQuota('errands'), async (req, res) => {
    try {
      const errands = await storage.getErrands(req.userId as number);
      res.json(errands);
    } catch (err) {
      res.status(500).json({ message: "Failed to fetch errands" });
    }
  });
  
  app.post("/api/errands", requireAuth, checkQuota('errands'), async (req, res) => {
    try {
      const errandData = insertErrandSchema.parse({ ...req.body, user_id: req.userId });
      const errand = await storage.createErrand(errandData);
      res.status(201).json(errand);
    } catch (err) {
      if (err instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid errand data", errors: err.errors });
      }
      res.status(500).json({ message: "Failed to create errand" });
    }
  });
  
  app.put("/api/errands/:id", requireAuth, checkQuota('errands'), async (req, res) => {
    try {
      const errandId = parseInt(req.params.id);
      const errand = await storage.getErrand(errandId);
      
      if (!errand) {
        return res.status(404).json({ message: "Errand not found" });
      }
      
      if (errand.user_id !== req.userId) {
        return res.status(403).json({ message: "You don't have permission to update this errand" });
      }
      
      const updatedErrand = await storage.updateErrand(errandId, req.body);
      res.json(updatedErrand);
    } catch (err) {
      res.status(500).json({ message: "Failed to update errand" });
    }
  });
  
  // Bills API
  app.get("/api/bills", requireAuth, checkQuota('bills'), async (req, res) => {
    try {
      const bills = await storage.getBills(req.userId as number);
      res.json(bills);
    } catch (err) {
      res.status(500).json({ message: "Failed to fetch bills" });
    }
  });
  
  app.post("/api/bills", requireAuth, checkQuota('bills'), async (req, res) => {
    try {
      // Validate required fields according to specs
      // Schema: title, amount, dueDate, recurring, frequency(optional)
      const { title, amount, dueDate, recurring, frequency } = req.body;
      
      if (!title) {
        return res.status(400).json({ message: "Title is required" });
      }
      
      // Map the API request to our schema fields
      const billData = insertBillSchema.parse({ 
        user_id: req.userId,
        name: title, // properly set name field
        provider: title, // mapping title to provider as well for backward compatibility
        amount: typeof amount === 'number' ? amount : parseInt(amount || '0'),
        due_date: dueDate,
        status: 'upcoming',
        recurring: !!recurring,
        recurring_interval: recurring && frequency ? frequency : (recurring ? 'monthly' : undefined),
        autopay: req.body.autopay || false,
        category: req.body.category || 'uncategorized'
      });
      
      const bill = await storage.createBill(billData);
      res.status(201).json(bill);
    } catch (err) {
      if (err instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid bill data", errors: err.errors });
      }
      res.status(500).json({ message: "Failed to create bill" });
    }
  });
  
  app.put("/api/bills/:id", requireAuth, async (req, res) => {
    try {
      const billId = parseInt(req.params.id);
      const bill = await storage.getBill(billId);
      
      if (!bill) {
        return res.status(404).json({ message: "Bill not found" });
      }
      
      if (bill.user_id !== req.userId) {
        return res.status(403).json({ message: "You don't have permission to update this bill" });
      }
      
      // Map API fields to schema
      const { title, amount, dueDate, recurring, frequency, ...otherFields } = req.body;
      const updateData: Partial<Bill> = {
        ...(title && { provider: title }),
        ...(amount !== undefined && { amount: typeof amount === 'number' ? amount : parseInt(amount) }),
        ...(dueDate && { due_date: dueDate }),
        ...(recurring !== undefined && { recurring: !!recurring }),
        ...(frequency && { recurring_interval: frequency }),
        ...otherFields
      };
      
      const updatedBill = await storage.updateBill(billId, updateData);
      res.json(updatedBill);
    } catch (err) {
      res.status(500).json({ message: "Failed to update bill" });
    }
  });
  
  // Add DELETE endpoint for bills
  app.delete("/api/bills/:id", requireAuth, async (req, res) => {
    try {
      const billId = parseInt(req.params.id);
      const bill = await storage.getBill(billId);
      
      if (!bill) {
        return res.status(404).json({ message: "Bill not found" });
      }
      
      if (bill.user_id !== req.userId) {
        return res.status(403).json({ message: "You don't have permission to delete this bill" });
      }
      
      const success = await storage.deleteBill(billId);
      
      if (success) {
        res.status(200).json({ message: "Bill deleted successfully" });
      } else {
        res.status(500).json({ message: "Failed to delete bill" });
      }
    } catch (err) {
      res.status(500).json({ message: "Failed to delete bill" });
    }
  });
  
  // Rewards API
  app.get("/api/rewards", requireAuth, async (req, res) => {
    try {
      const rewards = await storage.getRewards(req.userId as number);
      res.json(rewards);
    } catch (err) {
      res.status(500).json({ message: "Failed to fetch rewards" });
    }
  });
  
  app.post("/api/rewards", requireAuth, async (req, res) => {
    try {
      const rewardData = insertRewardSchema.parse({ ...req.body, user_id: req.userId });
      const reward = await storage.createReward(rewardData);
      res.status(201).json(reward);
    } catch (err) {
      if (err instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid reward data", errors: err.errors });
      }
      res.status(500).json({ message: "Failed to create reward" });
    }
  });
  
  // Admin API - Get all users (for admin dashboard)
  app.get("/api/admin/users", requireAuth, requirePlan(['team']), async (req, res) => {
    // Check if user is admin (for demo, we're considering the first user as admin)
    if (req.userId !== 1) {
      return res.status(403).json({ message: "Admin access required" });
    }
    
    try {
      // For database storage, we need a different approach to get all users
      const usersList = await db.select({
        id: usersTable.id,
        username: usersTable.username,
        email: usersTable.email,
        flow_score: usersTable.flow_score,
        streak_days: usersTable.streak_days
      }).from(usersTable);
      
      res.json(usersList);
    } catch (err) {
      res.status(500).json({ message: "Failed to fetch users" });
    }
  });
  
  // Payment API routes - Razorpay is our only payment provider
  
  // Get payment history for the logged-in user
  app.get("/api/payments", requireAuth, async (req, res) => {
    try {
      // Get all payments for the user, ordered by most recent first
      // Use pool to execute a raw SQL query since we don't have prepared schema query
      const { rows } = await pool.query(
        'SELECT * FROM payments WHERE user_id = $1 ORDER BY created_at DESC LIMIT 10',
        [req.userId]
      );
      
      res.json(rows || []);
    } catch (error) {
      console.error('Error fetching payment history:', error);
      res.status(500).json({ 
        error: "Failed to fetch payment history",
        message: "There was a problem retrieving your payment history. Please try again later."
      });
    }
  });
  
  // Razorpay API routes
  app.post("/api/razorpay/create-order", requireAuth, async (req, res) => {
    await createRazorpayOrder(req, res);
  });

  app.post("/api/razorpay/verify-payment", requireAuth, async (req, res) => {
    await verifyRazorpayPayment(req, res);
  });
  
  // Payment integration status check (admin only or dev environment)
  app.get("/api/payment/status", requireAuth, async (req, res) => {
    // Only allow in development or for admin users (if user has an admin role)
    if (process.env.NODE_ENV !== 'development') {
      // First check for PAYMENT_STATUS_SECRET in query string for direct access
      const secretKey = req.query.secret;
      const adminSecret = process.env.PAYMENT_STATUS_SECRET;
      
      if (adminSecret && secretKey === adminSecret) {
        // Allow access with secret key
      } else {
        // Without the secret, only admin users can access this endpoint
        const user = await storage.getUser(req.userId as number);
        
        // Check if user has role property and it equals 'admin'
        // This is a safe check even if role column doesn't exist yet
        if (!user || (user as any).role !== 'admin') {
          return res.status(403).json({ status: 'error', message: 'Unauthorized' });
        }
      }
    }
    
    try {
      // Check Razorpay configuration
      const razorpayStatus = {
        initialized: !!razorpay,
        keyIdConfigured: !!process.env.RAZORPAY_KEY_ID,
        keySecretConfigured: !!process.env.RAZORPAY_KEY_SECRET,
        webhookSecretConfigured: !!process.env.RAZORPAY_WEBHOOK_SECRET,
        frontendKeyConfigured: !!process.env.VITE_RAZORPAY_KEY_ID
      };
      
      // Test Razorpay API connection if initialized
      let razorpayConnection = false;
      if (razorpay) {
        try {
          // Simple API call that should work with any valid API key
          await razorpay.customers.all({ count: 1 });
          razorpayConnection = true;
        } catch (error) {
          console.error('Failed to connect to Razorpay API:', error);
        }
      }
      
      // Check plans configuration
      const plansConfigured = {
        free: !!process.env.RAZORPAY_PLAN_FREE_ID,
        starterMonthly: !!process.env.RAZORPAY_PLAN_STARTER_M,
        starterAnnual: !!process.env.RAZORPAY_PLAN_STARTER_Y,
        proMonthly: !!process.env.RAZORPAY_PLAN_PRO_M,
        proAnnual: !!process.env.RAZORPAY_PLAN_PRO_Y,
        teamMonthly: !!process.env.RAZORPAY_PLAN_TEAM_M,
        teamAnnual: !!process.env.RAZORPAY_PLAN_TEAM_Y
      };
      
      res.json({
        status: 'success',
        provider: 'razorpay',
        razorpay: {
          ...razorpayStatus,
          connection: razorpayConnection
        },
        plans: plansConfigured,
        environment: process.env.NODE_ENV
      });
    } catch (error) {
      console.error('Error checking payment status:', error);
      res.status(500).json({ status: 'error', message: 'Failed to check payment integration status' });
    }
  });
  
  // Razorpay Webhook handler for automated notifications from Razorpay
  app.post("/api/razorpay/webhook", async (req, res) => {
    try {
      // Validate webhook signature if available
      const webhookSignature = req.headers['x-razorpay-signature'];
      const webhookSecret = process.env.RAZORPAY_WEBHOOK_SECRET;
      
      // Skip signature validation if webhook secret is not configured
      if (webhookSignature && webhookSecret) {
        const hmac = crypto.createHmac('sha256', webhookSecret);
        hmac.update(JSON.stringify(req.body));
        const generatedSignature = hmac.digest('hex');
        
        if (generatedSignature !== webhookSignature) {
          return res.status(400).json({
            status: 'error',
            message: 'Invalid webhook signature'
          });
        }
      }
      
      // Process different webhook events
      const { event, payload } = req.body;
      console.log(`Received Razorpay webhook: ${event}`);
      
      switch (event) {
        case 'payment.authorized':
          // Payment has been authorized but not yet captured
          console.log('Payment authorized, waiting for capture');
          break;
          
        case 'payment.captured':
          // Payment has been captured - update user subscription if needed
          await handlePaymentCaptured(payload);
          break;
          
        case 'payment.failed':
          // Payment has failed - might want to notify the user
          console.log('Payment failed', payload?.payment?.entity?.order_id);
          break;
          
        case 'subscription.charged':
          // Recurring subscription payment was successful
          console.log('Subscription charged successfully');
          break;
          
        default:
          // Handle other events
          console.log(`Unhandled webhook event: ${event}`);
          break;
      }
      
      // Always return 200 OK to acknowledge receipt of webhook
      res.status(200).json({ status: 'success' });
    } catch (error) {
      console.error('Razorpay webhook error:', error);
      // Always return 200 even on error to prevent Razorpay from retrying
      res.status(200).json({ status: 'received_with_error' });
    }
  });
  
  // Helper function to handle payment captured events
  async function handlePaymentCaptured(payload: any) {
    const { payment } = payload;
    if (!payment?.entity?.order_id) return;
    
    const orderId = payment.entity.order_id;
    console.log(`Processing captured payment for order ${orderId}`);
    
    try {
      // Skip if razorpay isn't initialized
      if (!razorpay) {
        console.log('Razorpay not initialized, skipping order fetch');
        return;
      }
      
      // Fetch the order details
      const orderDetails = await razorpay.orders.fetch(orderId);
      if (!orderDetails?.notes) {
        console.log('Order has no notes, cannot process subscription update');
        return;
      }
      
      // Extract user info from order notes
      const userId = Number(orderDetails.notes.userId) || null;
      const planId = orderDetails.notes.planId || 'starter';
      const billingPeriod = orderDetails.notes.billingPeriod || 'Monthly';
      
      if (!userId) {
        console.log('No userId in order notes, skipping subscription update');
        return;
      }
      
      console.log(`Updating subscription for user ${userId} to plan ${planId}`);
      
      // Calculate expiry date
      const expiryDate = new Date();
      if (billingPeriod === 'Annual') {
        expiryDate.setFullYear(expiryDate.getFullYear() + 1);
      } else {
        expiryDate.setMonth(expiryDate.getMonth() + 1);
      }
      
      // Update user plan in the database
      await storage.updateUser(userId, {
        plan: planId as 'starter' | 'pro' | 'team',
        plan_active: true,
        plan_expiry: expiryDate
      });
      
      console.log(`Successfully updated subscription for user ${userId}`);
    } catch (error) {
      console.error('Error processing payment.captured webhook:', error);
    }
  }
  
  // ROI Dashboard Endpoints
  app.get("/api/roi", requireAuth, requirePlan(['starter', 'pro', 'team']), async (req, res) => {
    try {
      const days = req.query.days ? parseInt(req.query.days as string) : 30;
      const roi = await storage.getUserROI(req.userId as number, days);
      const actionCount = await storage.getUserActionCount(req.userId as number, days);
      
      res.json({
        ...roi,
        actionCount,
        days
      });
    } catch (err) {
      res.status(500).json({ message: "Failed to fetch ROI data" });
    }
  });
  
  // Track a usage event (time or money saved)
  app.post("/api/roi/usage-event", requireAuth, requirePlan(['starter', 'pro', 'team']), async (req, res) => {
    try {
      const { eventType, timeSavedMinutes, moneySavedCents } = req.body;
      
      const usageEvent = await storage.createUsageEvent({
        user_id: req.userId as number,
        action: eventType,
        estimated_minutes_saved: timeSavedMinutes || 0,
        estimated_money_saved: moneySavedCents || 0,
        timestamp: new Date(),
        metadata: {}
      });
      
      res.status(201).json(usageEvent);
    } catch (err) {
      res.status(500).json({ message: "Failed to record usage event" });
    }
  });

  // User quota API endpoint
  app.get("/api/user/quota", requireAuth, async (req, res) => {
    try {
      const userId = req.userId as number;
      
      // Get user info to determine plan
      const user = await storage.getUser(userId);
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }
      
      // Get usage count
      const actionCount = await storage.getUserActionCount(userId, 30); // Last 30 days
      
      // Define usage limits for each plan
      const USAGE_LIMITS = {
        free: 75,
        starter: 750,
        pro: Infinity,
        team: Infinity
      };
      
      // Get the limit for the user's plan
      const limit = USAGE_LIMITS[user.plan as keyof typeof USAGE_LIMITS] || USAGE_LIMITS.free;
      
      // Calculate remaining quota
      const remaining = limit === Infinity ? Infinity : Math.max(0, limit - actionCount);
      const percentUsed = limit === Infinity ? 0 : Math.min(100, Math.round((actionCount / limit) * 100));
      
      // For cleaner response formatting
      const formatInfinity = (val: number | typeof Infinity) => val === Infinity ? "unlimited" : val;
      
      // Return quota information
      res.json({
        plan: user.plan,
        actionCount,
        limit: formatInfinity(limit),
        remaining: formatInfinity(remaining),
        percentUsed: limit === Infinity ? 0 : percentUsed,
        isExceeded: actionCount >= limit,
        refreshDate: new Date(new Date().setDate(new Date().getDate() + 30)) // 30 days from now
      });
    } catch (err) {
      console.error("Error fetching quota:", err);
      res.status(500).json({ message: "Failed to fetch quota information" });
    }
  });

  // Return next plan for each current plan
  app.get("/api/plans/upgrade-path", requireAuth, async (req, res) => {
    try {
      const userId = req.userId as number;
      
      // Get user info to determine current plan
      const user = await storage.getUser(userId);
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }
      
      // Define next upgrade path for each plan
      const NEXT_PLAN = {
        free: 'starter',
        starter: 'pro',
        pro: 'team',
        team: 'team' // Already at highest tier
      };
      
      const nextPlan = NEXT_PLAN[user.plan as keyof typeof NEXT_PLAN] || 'starter';
      
      // Return upgrade path information
      res.json({
        currentPlan: user.plan,
        nextPlan,
        upgradeUrl: `/pricing?highlight=${nextPlan}`
      });
    } catch (err) {
      console.error("Error fetching upgrade path:", err);
      res.status(500).json({ message: "Failed to fetch upgrade information" });
    }
  });

  // PayPal integration routes
  app.get("/paypal/setup", async (req, res) => {
    await loadPaypalDefault(req, res);
  });

  app.post("/paypal/order", async (req, res) => {
    // Request body should contain: { intent, amount, currency }
    await createPaypalOrder(req, res);
  });

  app.post("/paypal/order/:orderID/capture", async (req, res) => {
    await capturePaypalOrder(req, res);
  });

  const httpServer = createServer(app);

  return httpServer;
}
