import { Client } from '@microsoft/microsoft-graph-client';
import { AuthenticationResult, ConfidentialClientApplication } from '@azure/msal-node';

// Microsoft OAuth configuration
const msalConfig = {
  auth: {
    clientId: process.env.OUTLOOK_CLIENT_ID || '',
    clientSecret: process.env.OUTLOOK_CLIENT_SECRET || '',
    authority: 'https://login.microsoftonline.com/common'
  }
};

const msalClient = new ConfidentialClientApplication(msalConfig);

// Define the scopes needed for Calendar access
const scopes = ['Calendars.Read', 'offline_access'];

/**
 * Generate authorization URL for Outlook Calendar
 */
export async function getAuthUrl(): Promise<string> {
  const redirectUri = `${process.env.APP_URL || 'http://localhost:5000'}/api/calendar/outlook/callback`;
  
  const authCodeUrlParameters = {
    scopes,
    redirectUri,
    prompt: 'consent', // Force consent to get refresh token
    state: 'userId_placeholder' // This should be replaced with the actual user ID in the client
  };

  return await msalClient.getAuthCodeUrl(authCodeUrlParameters);
}

/**
 * Exchange authorization code for tokens
 */
export async function getTokenFromCode(code: string): Promise<string> {
  try {
    const redirectUri = `${process.env.APP_URL || 'http://localhost:5000'}/api/calendar/outlook/callback`;

    const tokenRequest = {
      code,
      scopes,
      redirectUri
    };

    const response = await msalClient.acquireTokenByCode(tokenRequest);
    
    // Return the refresh token
    // Note: Microsoft's type definitions might not be up to date
    // The refresh token is actually in the response
    return (response as any).refreshToken || '';
  } catch (error) {
    console.error('Error getting token from code:', error);
    throw error;
  }
}

/**
 * Refresh access token using refresh token
 */
export async function getAccessToken(refreshToken: string): Promise<string> {
  try {
    const tokenRequest = {
      refreshToken,
      scopes
    };

    const tokenResponse = await msalClient.acquireTokenByRefreshToken(tokenRequest);
    if (!tokenResponse) {
      throw new Error('Failed to refresh token');
    }
    return tokenResponse.accessToken;
  } catch (error) {
    console.error('Error refreshing access token:', error);
    throw error;
  }
}

/**
 * Revoke a token (Microsoft doesn't have an explicit token revocation endpoint,
 * but we can indicate that tokens for this user shouldn't be used anymore)
 */
export async function revokeToken(token: string): Promise<void> {
  // Microsoft doesn't have a proper revocation endpoint
  // The best we can do is invalidate the token locally
  // We don't need to do anything here as disconnecting in the database is sufficient
}

/**
 * Create Microsoft Graph client
 */
function createGraphClient(accessToken: string): Client {
  // Create authentication provider
  // Use MS Graph client's own AuthenticationProvider type
  return Client.init({
    authProvider: (done: any) => {
      done(null, accessToken);
    }
  });
}

/**
 * Get events from Outlook Calendar
 */
export async function getEvents(refreshToken: string, start: Date, end: Date): Promise<any[]> {
  try {
    // Get access token
    const accessToken = await getAccessToken(refreshToken);
    
    // Create MS Graph client
    const graphClient = createGraphClient(accessToken);
    
    // Format date range for query
    const startIso = start.toISOString();
    const endIso = end.toISOString();
    
    // Get events from Microsoft Graph API
    const response = await graphClient
      .api('/me/calendar/events')
      .filter(`start/dateTime ge '${startIso}' and end/dateTime le '${endIso}'`)
      .select('id,subject,start,end,location')
      .orderby('start/dateTime')
      .get();
    
    const events = response.value || [];
    
    // Transform Outlook events to our format
    return events.map((event: any) => ({
      id: event.id,
      title: event.subject,
      start: event.start.dateTime,
      end: event.end.dateTime,
      location: event.location?.displayName || null,
      source: 'outlook',
      sourceEvent: event // Keep original for reference
    }));
  } catch (error) {
    console.error('Error getting Outlook Calendar events:', error);
    return [];
  }
}