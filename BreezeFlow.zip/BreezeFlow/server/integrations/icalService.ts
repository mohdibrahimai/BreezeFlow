import ical, { ICalCalendar } from 'ical-generator';
import parser from 'ical-parser';
import { Event, Task } from '@shared/schema';
import { storage } from '../storage';
import { promisify } from 'util';

/**
 * Service for handling iCalendar (ICS) import and export
 */
export class ICalService {
  /**
   * Generate an ICS file from a user's events
   * @param userId The user ID
   * @returns ICS formatted string
   */
  static async generateICS(userId: number): Promise<string> {
    try {
      // Get user's events from database
      const events = await storage.getEvents(userId);
      
      // Create a new calendar
      const calendar = ical({ name: 'BreezeFlow Calendar' });
      
      // Add events to the calendar
      events.forEach(event => {
        calendar.createEvent({
          start: new Date(event.start),
          end: new Date(event.end),
          summary: event.title,
          description: `Event from BreezeFlow`,
          location: event.location,
        });
      });
      
      // Also add tasks with due dates as events
      const tasks = await storage.getTasks(userId);
      const tasksWithDueDates = tasks.filter(task => task.due_date);
      
      tasksWithDueDates.forEach(task => {
        const taskDate = new Date(task.due_date);
        calendar.createEvent({
          start: taskDate,
          end: new Date(taskDate.getTime() + 60 * 60 * 1000), // 1 hour duration
          summary: `Task: ${task.title}`,
          description: task.description || `Priority: ${task.priority}`,
          // Use a different color or category for tasks
        });
      });
      
      // Return the calendar as a string
      return calendar.toString();
    } catch (error) {
      console.error('Error generating ICS file:', error);
      throw error;
    }
  }
  
  /**
   * Import events from an ICS file
   * @param userId The user ID
   * @param icsData The ICS file content
   * @returns Number of imported events
   */
  static async importICS(userId: number, icsData: string): Promise<number> {
    try {
      // Convert callback-based parser to Promise
      const parseICS = promisify(parser.convert);
      
      // Parse the ICS data
      const parsedData = await parseICS(icsData);
      
      if (!parsedData || !parsedData.VCALENDAR || !parsedData.VCALENDAR.length) {
        return 0;
      }
      
      let importedCount = 0;
      
      // Process each calendar in the ICS file
      for (const calendar of parsedData.VCALENDAR) {
        // Check if the calendar has events
        if (!calendar.VEVENT || !Array.isArray(calendar.VEVENT)) {
          continue;
        }
        
        // Process each event
        for (const icsEvent of calendar.VEVENT) {
          try {
            // Extract event data
            let startStr: string | undefined;
            let endStr: string | undefined;
            let summary: string | undefined;
            let location: string | undefined;
            
            // Extract start date/time
            if (icsEvent['DTSTART;VALUE=DATE']) {
              const date = icsEvent['DTSTART;VALUE=DATE'];
              // Format: YYYYMMDD
              startStr = `${date.slice(0, 4)}-${date.slice(4, 6)}-${date.slice(6, 8)}T00:00:00.000Z`;
            } else if (icsEvent.DTSTART) {
              startStr = icsEvent.DTSTART;
            }
            
            // Extract end date/time
            if (icsEvent['DTEND;VALUE=DATE']) {
              const date = icsEvent['DTEND;VALUE=DATE'];
              // Format: YYYYMMDD
              endStr = `${date.slice(0, 4)}-${date.slice(4, 6)}-${date.slice(6, 8)}T00:00:00.000Z`;
            } else if (icsEvent.DTEND) {
              endStr = icsEvent.DTEND;
            }
            
            // Extract summary and location
            summary = icsEvent.SUMMARY;
            location = icsEvent.LOCATION;
            
            if (startStr && endStr && summary) {
              // Create a new event in the database
              await storage.createEvent({
                user_id: userId,
                title: summary,
                start: new Date(startStr).toISOString(),
                end: new Date(endStr).toISOString(),
                location: location || null,
                auto_scheduled: false,
              });
              
              importedCount++;
            }
          } catch (error) {
            console.error('Error importing event:', error);
            // Continue with other events even if one fails
          }
        }
      }
      
      return importedCount;
    } catch (error) {
      console.error('Error importing ICS file:', error);
      throw error;
    }
  }
}