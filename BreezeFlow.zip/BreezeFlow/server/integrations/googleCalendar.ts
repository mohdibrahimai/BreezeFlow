import { google } from 'googleapis';

// Google OAuth configuration
const oauth2Client = new google.auth.OAuth2(
  process.env.GOOGLE_CLIENT_ID,
  process.env.GOOGLE_CLIENT_SECRET,
  `${process.env.APP_URL || 'http://localhost:5000'}/api/calendar/google/callback`
);

// Create Calendar API instance
const calendar = google.calendar({ version: 'v3', auth: oauth2Client });

/**
 * Generate authorization URL for Google Calendar
 */
export function getAuthUrl(): string {
  const scopes = [
    'https://www.googleapis.com/auth/calendar.readonly',
    'https://www.googleapis.com/auth/calendar.events.readonly'
  ];

  return oauth2Client.generateAuthUrl({
    access_type: 'offline',
    scope: scopes,
    prompt: 'consent', // Force showing the consent screen to get refresh token
    // State will be passed back to the callback and contains the user ID
    state: 'userId_placeholder' // This should be replaced with the actual user ID in the client
  });
}

/**
 * Exchange authorization code for tokens
 */
export async function getTokenFromCode(code: string): Promise<any> {
  try {
    const { tokens } = await oauth2Client.getToken(code);
    return tokens;
  } catch (error) {
    console.error('Error getting token from code:', error);
    throw error;
  }
}

/**
 * Refresh access token using refresh token
 */
export async function getAccessToken(refreshToken: string): Promise<string> {
  try {
    oauth2Client.setCredentials({
      refresh_token: refreshToken
    });
    
    // This refreshes the token if necessary
    const accessToken = await oauth2Client.getAccessToken();
    return accessToken.token || '';
  } catch (error) {
    console.error('Error refreshing access token:', error);
    throw error;
  }
}

/**
 * Revoke a token
 */
export async function revokeToken(token: string): Promise<void> {
  try {
    await oauth2Client.revokeToken(token);
  } catch (error) {
    console.error('Error revoking token:', error);
    throw error;
  }
}

/**
 * Get events from Google Calendar
 */
export async function getEvents(refreshToken: string, start: Date, end: Date): Promise<any[]> {
  try {
    oauth2Client.setCredentials({
      refresh_token: refreshToken
    });
    
    const response = await calendar.events.list({
      calendarId: 'primary',
      timeMin: start.toISOString(),
      timeMax: end.toISOString(),
      singleEvents: true,
      orderBy: 'startTime',
    });
    
    const events = response.data.items || [];
    
    // Transform Google events to our format
    return events.map((event: any) => ({
      id: event.id,
      title: event.summary,
      start: event.start.dateTime || event.start.date,
      end: event.end.dateTime || event.end.date,
      location: event.location || null,
      source: 'google',
      sourceEvent: event // Keep original for reference
    }));
  } catch (error) {
    console.error('Error getting Google Calendar events:', error);
    return [];
  }
}