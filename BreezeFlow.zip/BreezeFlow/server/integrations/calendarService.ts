import { storage } from '../storage';
import * as googleCalendar from './googleCalendar';

/**
 * Calendar service to handle integrations with external calendar providers
 */
export class CalendarService {
  /**
   * Get authorization URL for connecting to Google Calendar
   */
  static getGoogleAuthUrl(): string {
    return googleCalendar.getAuthUrl();
  }

  /**
   * Handle Google Calendar OAuth callback
   */
  static async handleGoogleCallback(userId: number, code: string): Promise<boolean> {
    try {
      const tokenResponse = await googleCalendar.getTokenFromCode(code);
      if (!tokenResponse || !tokenResponse.refresh_token) {
        console.error('No refresh token received from Google');
        return false;
      }

      await storage.updateGoogleCalendarToken(userId, tokenResponse.refresh_token);
      return true;
    } catch (error) {
      console.error('Error handling Google callback:', error);
      return false;
    }
  }

  // Outlook Calendar integration has been removed

  /**
   * Disconnect Google Calendar integration
   */
  static async disconnectGoogleCalendar(userId: number): Promise<boolean> {
    try {
      const user = await storage.getUser(userId);
      if (!user || !user.google_refresh_token) {
        return false;
      }

      try {
        // Try to revoke the token on Google's end
        await googleCalendar.revokeToken(user.google_refresh_token);
      } catch (error) {
        // Even if token revocation fails, we still want to disconnect locally
        console.warn('Could not revoke Google token:', error);
      }

      await storage.disconnectGoogleCalendar(userId);
      return true;
    } catch (error) {
      console.error('Error disconnecting Google Calendar:', error);
      return false;
    }
  }

  // Outlook Calendar integration has been removed

  /**
   * Get all calendar events from all connected providers for a date range
   */
  static async getAllExternalEvents(
    userId: number, 
    start: Date, 
    end: Date
  ): Promise<any[]> {
    const user = await storage.getUser(userId);
    if (!user) return [];

    const events = [];

    // Get Google Calendar events if connected
    if (user.google_calendar_connected && user.google_refresh_token) {
      try {
        const googleEvents = await googleCalendar.getEvents(
          user.google_refresh_token,
          start,
          end
        );
        events.push(...googleEvents);
      } catch (error) {
        console.error('Error fetching Google Calendar events:', error);
      }
    }

    // Outlook Calendar integration has been removed

    return events;
  }

  /**
   * Synchronize events from all connected calendar providers
   */
  static async syncAllCalendars(userId: number): Promise<number> {
    // This is a placeholder that would actually sync calendar events in a real implementation
    // For now just return 0 events synced
    return 0;
  }

  /**
   * Check if user has any calendar integration connected
   */
  static async hasCalendarIntegration(userId: number): Promise<boolean> {
    const user = await storage.getUser(userId);
    if (!user) return false;
    
    // Only check Google Calendar since Outlook integration is removed
    return Boolean(user.google_calendar_connected);
  }

  /**
   * Get user's calendar integration status
   */
  static async getCalendarIntegrationStatus(userId: number): Promise<{
    googleCalendarConnected: boolean;
    outlookCalendarConnected: boolean; // Kept for API compatibility
  }> {
    const user = await storage.getUser(userId);
    if (!user) {
      return {
        googleCalendarConnected: false,
        outlookCalendarConnected: false
      };
    }

    return {
      googleCalendarConnected: Boolean(user.google_calendar_connected),
      outlookCalendarConnected: false // Outlook integration is disabled
    };
  }
}