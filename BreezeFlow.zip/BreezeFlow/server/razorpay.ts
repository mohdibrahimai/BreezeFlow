import Razorpay from 'razorpay';
import crypto from 'crypto';
import { Request, Response } from 'express';
import { storage } from './storage';

if (!process.env.RAZORPAY_KEY_ID || !process.env.RAZORPAY_KEY_SECRET) {
  console.warn('RAZORPAY_KEY_ID and RAZORPAY_KEY_SECRET must be set for Razorpay payments to work');
}

// Initialize Razorpay if API keys are available
let razorpay: Razorpay | null = null;

try {
  if (process.env.RAZORPAY_KEY_ID && process.env.RAZORPAY_KEY_SECRET) {
    razorpay = new Razorpay({
      key_id: process.env.RAZORPAY_KEY_ID,
      key_secret: process.env.RAZORPAY_KEY_SECRET,
    });
  }
} catch (error) {
  console.error('Failed to initialize Razorpay:', error);
}

export async function createRazorpayOrder(req: Request, res: Response) {
  try {
    // Check if Razorpay is initialized
    if (!razorpay) {
      return res.status(503).json({
        success: false,
        error: 'Razorpay payment gateway is not configured',
        message: 'The administrator needs to set up the Razorpay API keys'
      });
    }

    const { amount, currency, planName, planId, billingPeriod, quota } = req.body;

    // Validate amount
    if (!amount || amount <= 0) {
      return res.status(400).json({
        success: false,
        error: 'Invalid amount',
      });
    }

    // Convert USD to INR if needed (approx exchange rate)
    const EXCHANGE_RATE_USD_TO_INR = 83; // Approximate exchange rate
    
    // If currency is USD, convert to INR since Razorpay primarily works with INR
    let finalAmount = amount;
    let finalCurrency = currency || 'INR';
    
    if (finalCurrency === 'USD') {
      // Convert USD to INR with the exchange rate
      finalAmount = amount * EXCHANGE_RATE_USD_TO_INR;
      finalCurrency = 'INR'; // Set to INR for Razorpay
    }
    
    // Create Razorpay order with enhanced UPI metadata for better compatibility
    const options = {
      amount: Math.round(finalAmount * 100), // Amount in smallest currency unit (paise for INR)
      currency: finalCurrency,
      receipt: `receipt_${Date.now()}`,
      notes: {
        planName,
        planId,
        billingPeriod,
        quota,
        originalCurrency: currency,
        originalAmount: amount,
        description: `BreezeFlow ${planName} Plan - ${billingPeriod} Subscription`,
        merchant_name: "BreezeFlow",
        merchant_id: "BREEZEFLOW2025",
        upi_purpose: "subscription",
        invoice_id: `INV-${Date.now()}`
      }
    };

    // We already checked if razorpay is null above, so this is safe
    const order = await razorpay!.orders.create(options);

    res.status(200).json({
      success: true,
      id: order.id,
      amount: order.amount,
      currency: order.currency,
      key_id: process.env.RAZORPAY_KEY_ID // Send the key ID to the client
    });
  } catch (error) {
    console.error('Razorpay order creation error:', error);
    res.status(500).json({
      success: false,
      error: 'Failed to create order'
    });
  }
}

export async function verifyRazorpayPayment(req: Request, res: Response) {
  try {
    // Check if Razorpay is initialized
    if (!process.env.RAZORPAY_KEY_SECRET) {
      return res.status(503).json({
        success: false,
        error: 'Razorpay payment gateway is not configured',
        message: 'The administrator needs to set up the Razorpay API keys'
      });
    }

    const { razorpay_order_id, razorpay_payment_id, razorpay_signature } = req.body;

    // Verify signature
    const generatedSignature = crypto
      .createHmac('sha256', process.env.RAZORPAY_KEY_SECRET)
      .update(`${razorpay_order_id}|${razorpay_payment_id}`)
      .digest('hex');

    if (generatedSignature === razorpay_signature) {
      // Payment is successful
      // Here you can update your database, assign the subscription to the user, etc.
      
      // Update user subscription based on the payment
      try {
        if (req.userId) {
          const user = await storage.getUser(req.userId);
          if (user) {
            // Retrieve the order details to get plan information
            const order = await razorpay!.orders.fetch(razorpay_order_id);
            const planId = order.notes?.planId || 'starter';
            const billingPeriod = order.notes?.billingPeriod || 'Monthly';
            
            // Calculate expiry date based on billing period
            const expiryDate = new Date();
            if (billingPeriod === 'Annual') {
              expiryDate.setFullYear(expiryDate.getFullYear() + 1); // Add 1 year
            } else {
              expiryDate.setMonth(expiryDate.getMonth() + 1); // Add 1 month
            }
            
            // Validate the plan ID against valid plans
            const validPlans = ['starter', 'pro', 'team'] as const;
            const finalPlanId = validPlans.includes(planId as any) 
              ? (planId as 'starter' | 'pro' | 'team') 
              : 'starter';
            
            await storage.updateUser(user.id, {
              plan: finalPlanId,
              plan_active: true,
              plan_expiry: expiryDate
            });
            
            // Record the payment in the database
            await storage.createPayment({
              user_id: user.id,
              transaction_id: razorpay_payment_id,
              subscription_id: `sub_${Date.now()}`, // Generate a subscription ID
              amount: Math.round(Number(order.amount) / 100), // Convert from paise to currency unit
              currency: order.currency,
              status: 'completed',
              payment_method: 'razorpay',
              created_at: new Date(),
              metadata: { 
                planId: finalPlanId,
                billingPeriod,
                order_id: razorpay_order_id,
                signature: razorpay_signature
              }
            });
          }
        }
      } catch (err) {
        console.error('Error updating user subscription:', err);
        // Still return success even if updating user fails - we'll handle this separately
      }
      
      res.status(200).json({
        success: true,
        message: 'Payment verified successfully',
      });
    } else {
      res.status(400).json({
        success: false,
        error: 'Payment verification failed',
      });
    }
  } catch (error) {
    console.error('Razorpay payment verification error:', error);
    res.status(500).json({
      success: false,
      error: 'Failed to verify payment',
    });
  }
}