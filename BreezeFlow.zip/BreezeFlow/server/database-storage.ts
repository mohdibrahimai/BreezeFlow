import { 
  users, tasks, events, errands, bills, rewards, invites, usage_events, payments,
  type User, type InsertUser,
  type Task, type InsertTask,
  type Event, type InsertEvent,
  type Errand, type InsertErrand,
  type Bill, type InsertBill,
  type Reward, type InsertReward,
  type Invite, type InsertInvite,
  type UsageEvent, type InsertUsageEvent
} from "@shared/schema";
import { db, pool } from "./db";
import { eq, sql, and, gte, count, desc } from "drizzle-orm";
import session from "express-session";
import { Store as SessionStore } from "express-session";
import connectPg from "connect-pg-simple";
import { IStorage } from "./storage";

const PostgresSessionStore = connectPg(session);

export class DatabaseStorage implements IStorage {
  sessionStore: SessionStore;
  
  constructor() {
    this.sessionStore = new PostgresSessionStore({ 
      pool, 
      createTableIfMissing: true 
    });
  }
  
  // User methods
  async getUser(id: number): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }
  
  async getUserByUsername(username: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.username, username));
    return user;
  }
  
  async getUserByEmail(email: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.email, email));
    return user;
  }
  
  async setResetToken(userId: number, token: string, expiresAt: Date): Promise<User | undefined> {
    const [updatedUser] = await db
      .update(users)
      .set({
        reset_token: token,
        reset_token_expires: expiresAt
      })
      .where(eq(users.id, userId))
      .returning();
    
    return updatedUser;
  }
  
  async validateResetToken(token: string): Promise<boolean> {
    const user = await this.getUserByResetToken(token);
    if (!user) return false;
    
    // Check if token is expired
    const now = new Date();
    if (!user.reset_token_expires || new Date(user.reset_token_expires) < now) {
      return false;
    }
    
    return true;
  }
  
  async getUserByResetToken(token: string): Promise<User | undefined> {
    const [user] = await db
      .select()
      .from(users)
      .where(eq(users.reset_token, token));
    
    return user;
  }
  
  async updatePassword(userId: number, newPassword: string): Promise<User | undefined> {
    const [updatedUser] = await db
      .update(users)
      .set({
        password: newPassword,
        reset_token: null,
        reset_token_expires: null
      })
      .where(eq(users.id, userId))
      .returning();
    
    return updatedUser;
  }
  
  async createUser(insertUser: InsertUser): Promise<User> {
    const userData = { 
      ...insertUser, 
      flow_score: 0, 
      streak_days: 0 
    };
    
    const [user] = await db.insert(users).values(userData).returning();
    return user;
  }
  
  async updateUser(id: number, userData: Partial<User>): Promise<User | undefined> {
    const [updatedUser] = await db
      .update(users)
      .set(userData)
      .where(eq(users.id, id))
      .returning();
      
    return updatedUser;
  }
  
  // Task methods
  async getTasks(userId: number): Promise<Task[]> {
    return db.select().from(tasks).where(eq(tasks.user_id, userId));
  }
  
  async getTask(id: number): Promise<Task | undefined> {
    const [task] = await db.select().from(tasks).where(eq(tasks.id, id));
    return task;
  }
  
  async createTask(task: InsertTask): Promise<Task> {
    const [newTask] = await db.insert(tasks).values(task).returning();
    return newTask;
  }
  
  async updateTask(id: number, taskData: Partial<Task>): Promise<Task | undefined> {
    const [updatedTask] = await db
      .update(tasks)
      .set(taskData)
      .where(eq(tasks.id, id))
      .returning();
      
    return updatedTask;
  }
  
  async deleteTask(id: number): Promise<boolean> {
    const result = await db.delete(tasks).where(eq(tasks.id, id));
    return !!result;
  }
  
  // Event methods
  async getEvents(userId: number): Promise<Event[]> {
    return db.select().from(events).where(eq(events.user_id, userId));
  }
  
  async getEvent(id: number): Promise<Event | undefined> {
    const [event] = await db.select().from(events).where(eq(events.id, id));
    return event;
  }
  
  async createEvent(event: InsertEvent): Promise<Event> {
    const [newEvent] = await db.insert(events).values(event).returning();
    return newEvent;
  }
  
  async updateEvent(id: number, eventData: Partial<Event>): Promise<Event | undefined> {
    const [updatedEvent] = await db
      .update(events)
      .set(eventData)
      .where(eq(events.id, id))
      .returning();
      
    return updatedEvent;
  }
  
  async deleteEvent(id: number): Promise<boolean> {
    const result = await db.delete(events).where(eq(events.id, id));
    return !!result;
  }
  
  // Errand methods
  async getErrands(userId: number): Promise<Errand[]> {
    return db.select().from(errands).where(eq(errands.user_id, userId));
  }
  
  async getErrand(id: number): Promise<Errand | undefined> {
    const [errand] = await db.select().from(errands).where(eq(errands.id, id));
    return errand;
  }
  
  async createErrand(errand: InsertErrand): Promise<Errand> {
    const [newErrand] = await db.insert(errands).values(errand).returning();
    return newErrand;
  }
  
  async updateErrand(id: number, errandData: Partial<Errand>): Promise<Errand | undefined> {
    const [updatedErrand] = await db
      .update(errands)
      .set(errandData)
      .where(eq(errands.id, id))
      .returning();
      
    return updatedErrand;
  }
  
  async deleteErrand(id: number): Promise<boolean> {
    const result = await db.delete(errands).where(eq(errands.id, id));
    return !!result;
  }
  
  // Bill methods
  async getBills(userId: number): Promise<Bill[]> {
    return db.select().from(bills).where(eq(bills.user_id, userId));
  }
  
  async getBill(id: number): Promise<Bill | undefined> {
    const [bill] = await db.select().from(bills).where(eq(bills.id, id));
    return bill;
  }
  
  async createBill(bill: InsertBill): Promise<Bill> {
    const [newBill] = await db.insert(bills).values(bill).returning();
    return newBill;
  }
  
  async updateBill(id: number, billData: Partial<Bill>): Promise<Bill | undefined> {
    const [updatedBill] = await db
      .update(bills)
      .set(billData)
      .where(eq(bills.id, id))
      .returning();
      
    return updatedBill;
  }
  
  async deleteBill(id: number): Promise<boolean> {
    const result = await db.delete(bills).where(eq(bills.id, id));
    return !!result;
  }
  
  async getAllUpcomingBills(): Promise<Bill[]> {
    return db
      .select()
      .from(bills)
      .where(eq(bills.status, 'upcoming'));
  }
  
  async updateBillReminderTimestamp(id: number): Promise<Bill | undefined> {
    const [updatedBill] = await db
      .update(bills)
      .set({
        last_reminded_at: new Date()
      })
      .where(eq(bills.id, id))
      .returning();
      
    return updatedBill;
  }
  
  // Reward methods
  async getRewards(userId: number): Promise<Reward[]> {
    return db.select().from(rewards).where(eq(rewards.user_id, userId));
  }
  
  async getReward(id: number): Promise<Reward | undefined> {
    const [reward] = await db.select().from(rewards).where(eq(rewards.id, id));
    return reward;
  }
  
  async createReward(reward: InsertReward): Promise<Reward> {
    const [newReward] = await db.insert(rewards).values(reward).returning();
    return newReward;
  }
  
  // Invite methods
  async getInvites(userId: number): Promise<Invite[]> {
    return db.select().from(invites).where(eq(invites.inviter_id, userId));
  }
  
  async createInvite(invite: InsertInvite): Promise<Invite> {
    const [newInvite] = await db.insert(invites).values(invite).returning();
    return newInvite;
  }
  
  async updateInvite(id: number, inviteData: Partial<Invite>): Promise<Invite | undefined> {
    const [updatedInvite] = await db
      .update(invites)
      .set(inviteData)
      .where(eq(invites.id, id))
      .returning();
      
    return updatedInvite;
  }
  
  // Usage Events and ROI methods
  async createUsageEvent(event: InsertUsageEvent): Promise<UsageEvent> {
    const [newEvent] = await db
      .insert(usage_events)
      .values(event)
      .returning();
    
    return newEvent;
  }
  
  async getUserROI(userId: number, days: number = 30): Promise<{ hoursSaved: number, moneySaved: number }> {
    const thirtyDaysAgo = new Date();
    thirtyDaysAgo.setDate(thirtyDaysAgo.getDate() - days);
    
    const userEvents = await db
      .select()
      .from(usage_events)
      .where(
        and(
          eq(usage_events.user_id, userId),
          gte(usage_events.timestamp, thirtyDaysAgo)
        )
      );
    
    // Sum up time and money saved
    const hoursSaved = userEvents.reduce((total, event) => total + (event.estimated_minutes_saved || 0) / 60, 0);
    const moneySaved = userEvents.reduce((total, event) => total + (event.estimated_money_saved || 0) / 0.01, 0); // Convert cents to dollars
    
    return {
      hoursSaved: parseFloat(hoursSaved.toFixed(2)),
      moneySaved: parseFloat((moneySaved / 100).toFixed(2)) // Convert cents to dollars
    };
  }
  
  async getUserActionCount(userId: number, days: number = 30): Promise<number> {
    const thirtyDaysAgo = new Date();
    thirtyDaysAgo.setDate(thirtyDaysAgo.getDate() - days);
    
    const result = await db
      .select({ count: sql<number>`count(*)` })
      .from(usage_events)
      .where(
        and(
          eq(usage_events.user_id, userId),
          gte(usage_events.timestamp, thirtyDaysAgo)
        )
      );
    
    return result[0]?.count || 0;
  }
  
  /**
   * Check and increment user quota with protection against race conditions
   * Uses a transaction with SELECT FOR UPDATE to lock the rows being counted
   * This ensures accurate quota enforcement even under high concurrency
   */
  async checkAndIncrementQuota(userId: number, limit: number): Promise<{ 
    actionCount: number;
    quotaExceeded: boolean;
  }> {
    let client;
    try {
      // Acquire a client from the pool
      client = await pool.connect();
      
      // Start transaction
      await client.query('BEGIN');
      
      const thirtyDaysAgo = new Date();
      thirtyDaysAgo.setDate(thirtyDaysAgo.getDate() - 30);
      
      // First lock the rows, then count them
      // We need to separate these operations because FOR UPDATE cannot be used with COUNT(*)
      await client.query(`
        SELECT 1 FROM usage_events 
        WHERE user_id = $1 AND timestamp >= $2
        FOR UPDATE
      `, [userId, thirtyDaysAgo]);
      
      // Now count the locked rows
      const countResult = await client.query(`
        SELECT COUNT(*) 
        FROM usage_events 
        WHERE user_id = $1 AND timestamp >= $2
      `, [userId, thirtyDaysAgo]);
      
      const currentCount = parseInt(countResult.rows[0].count, 10);
      
      // Check if quota is exceeded
      const quotaExceeded = currentCount >= limit;
      
      if (!quotaExceeded) {
        // Create a new usage event to track this action
        // Only if quota is not exceeded
        await client.query(`
          INSERT INTO usage_events 
          (user_id, action, timestamp, estimated_minutes_saved, estimated_money_saved)
          VALUES ($1, $2, $3, $4, $5)
        `, [userId, 'api_request', new Date(), 0, 0]);
      }
      
      // Commit the transaction
      await client.query('COMMIT');
      
      return {
        actionCount: quotaExceeded ? currentCount : currentCount + 1,
        quotaExceeded
      };
    } catch (error) {
      // Rollback in case of any errors
      if (client) {
        try {
          await client.query('ROLLBACK');
        } catch (rollbackError) {
          console.error('Error rolling back transaction:', rollbackError);
        }
      }
      console.error('Error in checkAndIncrementQuota:', error);
      // Return a safe default to prevent the app from crashing
      return {
        actionCount: 0,
        quotaExceeded: false
      };
    } finally {
      // Release the client back to the pool
      if (client) {
        client.release();
      }
    }
  }
  
  /**
   * Create a payment record
   */
  async createPayment(payment: any): Promise<any> {
    try {
      // For now, just recording the payment details
      const result = await db
        .insert(payments)
        .values({
          ...payment,
          created_at: new Date()
        })
        .returning();
      
      return result[0];
    } catch (error) {
      console.error('Error creating payment record:', error);
      throw error;
    }
  }
  
  /**
   * Calendar integration methods
   */
  
  async updateGoogleCalendarToken(userId: number, refreshToken: string): Promise<User | undefined> {
    try {
      const [updatedUser] = await db
        .update(users)
        .set({
          google_calendar_connected: true,
          google_refresh_token: refreshToken
        })
        .where(eq(users.id, userId))
        .returning();
        
      return updatedUser;
    } catch (error) {
      console.error('Error updating Google Calendar token:', error);
      return undefined;
    }
  }
  
  async updateOutlookCalendarToken(userId: number, refreshToken: string): Promise<User | undefined> {
    try {
      const [updatedUser] = await db
        .update(users)
        .set({
          outlook_calendar_connected: true,
          outlook_refresh_token: refreshToken
        })
        .where(eq(users.id, userId))
        .returning();
        
      return updatedUser;
    } catch (error) {
      console.error('Error updating Outlook Calendar token:', error);
      return undefined;
    }
  }
  
  async disconnectGoogleCalendar(userId: number): Promise<User | undefined> {
    try {
      const [updatedUser] = await db
        .update(users)
        .set({
          google_calendar_connected: false,
          google_refresh_token: null
        })
        .where(eq(users.id, userId))
        .returning();
        
      return updatedUser;
    } catch (error) {
      console.error('Error disconnecting Google Calendar:', error);
      return undefined;
    }
  }
  
  async disconnectOutlookCalendar(userId: number): Promise<User | undefined> {
    try {
      const [updatedUser] = await db
        .update(users)
        .set({
          outlook_calendar_connected: false,
          outlook_refresh_token: null
        })
        .where(eq(users.id, userId))
        .returning();
        
      return updatedUser;
    } catch (error) {
      console.error('Error disconnecting Outlook Calendar:', error);
      return undefined;
    }
  }
  
  async getExternalCalendarEvents(userId: number, start: Date, end: Date): Promise<any[]> {
    // This method should be implemented with real API calls to Google/Microsoft 
    // in the service layer. This is just a placeholder that returns an empty array.
    return [];
  }
  
  async syncCalendarEvents(userId: number): Promise<number> {
    // This method should be implemented with real sync logic in the service layer.
    // This is just a placeholder that returns 0 for number of events synced.
    return 0;
  }
  
  async getAllTasks(): Promise<Task[]> {
    // Used for ML training
    return db.select().from(tasks);
  }
}