import { Express, Request, Response, NextFunction } from "express";
import bcrypt from "bcrypt";
import jwt from "jsonwebtoken";
import rateLimit from "express-rate-limit";
import { storage } from "./storage";
import { User as SelectUser, insertUserSchema } from "@shared/schema";

// JWT Secrets
const ACCESS_TOKEN_SECRET = process.env.ACCESS_TOKEN_SECRET || "breeze-flow-access-token-secret-key";
const REFRESH_TOKEN_SECRET = process.env.REFRESH_TOKEN_SECRET || "breeze-flow-refresh-token-secret-key";

// Token expiry settings
const ACCESS_TOKEN_EXPIRY = '15m'; // 15 minutes
const REFRESH_TOKEN_EXPIRY = '7d';  // 7 days

// Make sure JWT secrets are set and strong in production
if (process.env.NODE_ENV === 'production') {
  if (!process.env.ACCESS_TOKEN_SECRET || process.env.ACCESS_TOKEN_SECRET === 'breeze-flow-access-token-secret-key') {
    console.warn('Warning: Using a default ACCESS_TOKEN_SECRET in production is not secure!');
  }
  if (!process.env.REFRESH_TOKEN_SECRET || process.env.REFRESH_TOKEN_SECRET === 'breeze-flow-refresh-token-secret-key') {
    console.warn('Warning: Using a default REFRESH_TOKEN_SECRET in production is not secure!');
  }
}

// Bcrypt salt rounds
const SALT_ROUNDS = 10;

// Type for JWT payload
interface JwtPayload {
  userId: number;
  username: string;
  exp?: number;
  tokenType?: 'access' | 'refresh';
}

// Hash password with bcrypt
export async function hashPassword(password: string): Promise<string> {
  return bcrypt.hash(password, SALT_ROUNDS);
}

// Compare password with bcrypt
export async function comparePasswords(supplied: string, stored: string): Promise<boolean> {
  return bcrypt.compare(supplied, stored);
}

// Generate access token (short-lived)
function generateAccessToken(user: SelectUser): string {
  const payload: JwtPayload = {
    userId: user.id,
    username: user.username,
    tokenType: 'access'
  };
  
  return jwt.sign(payload, ACCESS_TOKEN_SECRET, { 
    expiresIn: ACCESS_TOKEN_EXPIRY 
  });
}

// Generate refresh token (long-lived)
function generateRefreshToken(user: SelectUser): string {
  const payload: JwtPayload = {
    userId: user.id,
    username: user.username,
    tokenType: 'refresh'
  };
  
  return jwt.sign(payload, REFRESH_TOKEN_SECRET, { 
    expiresIn: REFRESH_TOKEN_EXPIRY 
  });
}

// Generate both tokens
interface TokenPair {
  accessToken: string;
  refreshToken: string;
}

function generateTokens(user: SelectUser): TokenPair {
  return {
    accessToken: generateAccessToken(user),
    refreshToken: generateRefreshToken(user)
  };
}

// Auth middleware to protect routes using access token
function authMiddleware(req: Request, res: Response, next: NextFunction) {
  const token = req.cookies.accessToken;

  if (!token) {
    return res.status(401).json({ message: "Not authenticated" });
  }

  try {
    const decoded = jwt.verify(token, ACCESS_TOKEN_SECRET) as JwtPayload;
    
    // Verify this is an access token
    if (decoded.tokenType !== 'access') {
      return res.status(401).json({ message: "Invalid token type" });
    }
    
    req.userId = decoded.userId;
    next();
  } catch (err) {
    return res.status(401).json({ message: "Invalid or expired token" });
  }
}

// Validate refresh token
function validateRefreshToken(token: string): JwtPayload | null {
  try {
    const decoded = jwt.verify(token, REFRESH_TOKEN_SECRET) as JwtPayload;
    
    // Verify this is a refresh token
    if (decoded.tokenType !== 'refresh') {
      return null;
    }
    
    return decoded;
  } catch (err) {
    return null;
  }
}

// Extend Request type
declare global {
  namespace Express {
    interface Request {
      userId?: number;
    }
  }
}

import { randomBytes } from 'crypto';
import { emailService } from './services/email-service';

export function setupAuth(app: Express) {
  // Rate limiting middleware for auth endpoints
  const authLimiter = rateLimit({
    windowMs: 15 * 60 * 1000, // 15 minutes
    max: 5, // 5 requests per IP per windowMs for login attempts
    message: { message: "Too many login attempts, please try again later" },
    standardHeaders: true, // Return rate limit info in the `RateLimit-*` headers
    legacyHeaders: false, // Disable the `X-RateLimit-*` headers
  });

  // Apply rate limiting to sensitive auth endpoints
  const loginLimiter = authLimiter;
  const refreshLimiter = rateLimit({
    windowMs: 60 * 60 * 1000, // 1 hour
    max: 20, // 20 refresh attempts per hour
    message: { message: "Too many token refresh attempts, please try again later" },
    standardHeaders: true,
    legacyHeaders: false,
  });
  
  // Password reset rate limiter (more lenient)
  const resetLimiter = rateLimit({
    windowMs: 60 * 60 * 1000, // 1 hour
    max: 3, // 3 reset requests per hour per IP
    message: { message: "Too many password reset attempts, please try again later" },
    standardHeaders: true,
    legacyHeaders: false,
  });
  // Registration endpoint
  app.post("/api/register", async (req, res, next) => {
    try {
      const validation = insertUserSchema.safeParse(req.body);
      
      if (!validation.success) {
        return res.status(400).json({ 
          message: "Invalid user data", 
          errors: validation.error.errors 
        });
      }
      
      const existingUser = await storage.getUserByUsername(req.body.username);
      if (existingUser) {
        return res.status(400).json({ message: "Username already exists" });
      }

      // Make sure to hash both the password and security answer
      const userData = {
        ...req.body,
        password: await hashPassword(req.body.password),
      };
      
      // If security answer is provided, hash it too
      if (userData.security_answer) {
        userData.security_answer = await hashPassword(userData.security_answer);
      }
      
      const user = await storage.createUser(userData);

      // Generate both tokens
      const { accessToken, refreshToken } = generateTokens(user);

      // Set cookies
      // Access token - short lived
      res.cookie('accessToken', accessToken, {
        httpOnly: true,
        secure: process.env.NODE_ENV === 'production',
        sameSite: 'strict',
        maxAge: 15 * 60 * 1000 // 15 minutes
      });
      
      // Refresh token - long lived
      res.cookie('refreshToken', refreshToken, {
        httpOnly: true,
        secure: process.env.NODE_ENV === 'production',
        sameSite: 'strict',
        maxAge: 7 * 24 * 60 * 60 * 1000 // 7 days
      });
      
      // Don't send the password back to the client
      const { password, ...userWithoutPassword } = user;
      res.status(201).json(userWithoutPassword);
    } catch (err) {
      next(err);
    }
  });

  // Login endpoint
  app.post("/api/login", loginLimiter, async (req, res, next) => {
    try {
      const { username, password } = req.body;
      
      if (!username || !password) {
        return res.status(400).json({ message: "Username and password are required" });
      }
      
      const user = await storage.getUserByUsername(username);
      
      if (!user || !(await comparePasswords(password, user.password))) {
        return res.status(401).json({ message: "Invalid username or password" });
      }
      
      // Generate both tokens
      const { accessToken, refreshToken } = generateTokens(user);

      // Set cookies
      // Access token - short lived
      res.cookie('accessToken', accessToken, {
        httpOnly: true,
        secure: process.env.NODE_ENV === 'production',
        sameSite: 'strict',
        maxAge: 15 * 60 * 1000 // 15 minutes
      });
      
      // Refresh token - long lived
      res.cookie('refreshToken', refreshToken, {
        httpOnly: true,
        secure: process.env.NODE_ENV === 'production',
        sameSite: 'strict',
        maxAge: 7 * 24 * 60 * 60 * 1000 // 7 days
      });
      
      // Don't send the password back to the client
      const { password: _, ...userWithoutPassword } = user;
      res.status(200).json(userWithoutPassword);
    } catch (err) {
      next(err);
    }
  });

  // Token refresh endpoint
  app.post("/api/refresh-token", refreshLimiter, async (req, res, next) => {
    try {
      const refreshToken = req.cookies.refreshToken;
      
      if (!refreshToken) {
        return res.status(401).json({ message: "Refresh token not provided" });
      }
      
      // Validate the refresh token
      const decoded = validateRefreshToken(refreshToken);
      
      if (!decoded) {
        return res.status(401).json({ message: "Invalid refresh token" });
      }
      
      // Get the user from the decoded token
      const user = await storage.getUser(decoded.userId);
      
      if (!user) {
        return res.status(401).json({ message: "User not found" });
      }
      
      // Generate a new access token
      const newAccessToken = generateAccessToken(user);
      
      // Set the new access token in a cookie
      res.cookie('accessToken', newAccessToken, {
        httpOnly: true,
        secure: process.env.NODE_ENV === 'production',
        sameSite: 'strict',
        maxAge: 15 * 60 * 1000 // 15 minutes
      });
      
      // Return success
      res.status(200).json({ message: "Token refreshed successfully" });
    } catch (err) {
      next(err);
    }
  });

  // Logout endpoint
  app.post("/api/logout", (req, res) => {
    // Clear both access and refresh token cookies
    res.clearCookie('accessToken');
    res.clearCookie('refreshToken');
    res.sendStatus(200);
  });

  // Get current user endpoint
  app.get("/api/user", authMiddleware, async (req, res, next) => {
    try {
      const user = await storage.getUser(req.userId as number);
      
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }
      
      // Don't send the password back to the client
      const { password, ...userWithoutPassword } = user;
      res.json(userWithoutPassword);
    } catch (err) {
      next(err);
    }
  });

  // Password reset request (forgot password) endpoint
  app.post("/api/forgot-password", resetLimiter, async (req, res, next) => {
    try {
      const { email } = req.body;
      
      if (!email) {
        return res.status(400).json({ message: "Email is required" });
      }
      
      // Find user by email
      const user = await storage.getUserByEmail(email);
      
      // Always return success, even if user is not found
      // This prevents user enumeration attacks
      if (!user) {
        return res.status(200).json({ 
          message: "If a user with that email exists, a password reset link has been sent" 
        });
      }
      
      // Generate a secure random token
      const resetToken = randomBytes(32).toString('hex');
      const now = new Date();
      const expiresAt = new Date(now.getTime() + 60 * 60 * 1000); // 1 hour from now
      
      // Save token to database
      await storage.setResetToken(user.id, resetToken, expiresAt);
      
      // Generate reset URL
      const baseUrl = process.env.APP_URL || 
        (process.env.NODE_ENV === 'production' 
          ? 'https://breezeflow.app'
          : 'http://localhost:5000');
      
      const resetUrl = `${baseUrl}/reset-password?token=${resetToken}`;
      
      // Send email
      const emailSent = await emailService.sendPasswordResetEmail(user, resetToken, resetUrl);
      
      if (!emailSent && process.env.NODE_ENV === 'production') {
        console.error('Failed to send password reset email to:', email);
      }
      
      res.status(200).json({ 
        message: "If a user with that email exists, a password reset link has been sent" 
      });
    } catch (err) {
      next(err);
    }
  });
  
  // Validate reset token endpoint
  app.get("/api/validate-reset-token/:token", async (req, res, next) => {
    try {
      const { token } = req.params;
      
      if (!token) {
        return res.status(400).json({ valid: false, message: "Token is required" });
      }
      
      // Check if token exists and is valid
      const isValid = await storage.validateResetToken(token);
      
      res.json({ 
        valid: isValid,
        message: isValid ? "Token is valid" : "Token is invalid or expired"
      });
    } catch (err) {
      next(err);
    }
  });
  
  // Reset password endpoint
  app.post("/api/reset-password", async (req, res, next) => {
    try {
      const { token, password } = req.body;
      
      if (!token || !password) {
        return res.status(400).json({ 
          message: "Token and password are required" 
        });
      }
      
      // Password validation
      if (password.length < 6) {
        return res.status(400).json({ 
          message: "Password must be at least 6 characters long" 
        });
      }
      
      // Check if token exists and is valid
      const user = await storage.getUserByResetToken(token);
      
      if (!user) {
        return res.status(400).json({ 
          message: "Token is invalid or expired" 
        });
      }
      
      // Hash the new password
      const hashedPassword = await hashPassword(password);
      
      // Update password and clear reset token
      await storage.updatePassword(user.id, hashedPassword);
      
      // Return success response
      res.status(200).json({ 
        message: "Password has been reset successfully" 
      });
    } catch (err) {
      next(err);
    }
  });
}
