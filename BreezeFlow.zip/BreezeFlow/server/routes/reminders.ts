import express, { Request, Response } from "express";
import { storage } from "../storage";

const router = express.Router();

/**
 * Extends Express Request to include userId
 */
interface AuthenticatedRequest extends Request {
  userId?: number;
}

/**
 * GET /api/reminders
 * Get all upcoming reminders for bills and tasks
 */
router.get("/", async (req: AuthenticatedRequest, res: Response) => {
  try {
    const userId = req.userId;
    if (!userId) {
      return res.status(401).json({ message: "Not authenticated" });
    }

    // Get upcoming bills with reminders
    const bills = await storage.getBills(userId);
    const upcomingBills = bills.filter(bill => {
      return bill.status === 'upcoming' && (bill.reminder_days || bill.reminder_days_before);
    });

    // Get tasks with reminder times
    const tasks = await storage.getTasks(userId);
    const tasksWithReminders = tasks.filter(task => {
      return task.status !== 'done' && task.reminder_time;
    });

    // Format reminders
    const billReminders = upcomingBills
      .filter(bill => bill.due_date != null) // Filter out bills without due dates
      .map(bill => {
        // We've filtered out nulls, but TypeScript needs reassurance
        const dueDate = bill.due_date ? new Date(bill.due_date) : new Date();
        const reminderDate = new Date(dueDate);
        // Use reminder_days_before if available, otherwise fallback to reminder_days
        const reminderDays = bill.reminder_days_before || bill.reminder_days || 0;
        reminderDate.setDate(dueDate.getDate() - reminderDays);
        
        return {
          id: `bill-${bill.id}`,
          type: 'bill',
          title: `Bill payment: ${bill.name || bill.provider}`,
          amount: bill.amount,
          dueDate: bill.due_date as string, // We've filtered nulls out
          reminderDate: reminderDate.toISOString(),
          sourceId: bill.id
        };
      });

    const taskReminders = tasksWithReminders
      .filter(task => task.reminder_time != null) // Filter out tasks without reminder times
      .map(task => {
        // We've filtered out nulls, but TypeScript needs reassurance
        const reminderTimeStr = task.reminder_time ? 
          (task.reminder_time instanceof Date ? 
            task.reminder_time.toISOString() : 
            String(task.reminder_time)) : 
          '';
          
        return {
          id: `task-${task.id}`,
          type: 'task',
          title: task.title,
          priority: task.priority,
          dueDate: task.due_date,
          reminderDate: reminderTimeStr,
          sourceId: task.id
        };
      }) as Array<{
      id: string;
      type: string;
      title: string;
      priority: string;
      dueDate: string | null;
      reminderDate: string;
      sourceId: number;
    }>;

    // Combine and sort reminders by date
    const allReminders = [...billReminders, ...taskReminders].sort((a, b) => {
      return new Date(a.reminderDate).getTime() - new Date(b.reminderDate).getTime();
    });

    res.json(allReminders);
  } catch (error) {
    console.error("Error fetching reminders:", error);
    res.status(500).json({ message: "Failed to fetch reminders" });
  }
});

export default router;