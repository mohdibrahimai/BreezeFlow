import { Router, Request, Response, NextFunction } from 'express';
import { storage } from '../storage';
import { CalendarService } from '../integrations/calendarService';

export const calendarRouter = Router();

// Middleware to check authentication
const requireAuth = (req: Request, res: Response, next: NextFunction) => {
  if (!req.userId) {
    return res.status(401).json({ message: 'Not authenticated' });
  }
  next();
};

// All routes in this file already have /api/calendar prefix

/**
 * Get calendar integration status
 */
calendarRouter.get('/status', requireAuth, async (req, res) => {
  try {
    const user = await storage.getUser(req.userId!);
    if (!user) {
      return res.status(404).json({ message: 'User not found' });
    }

    res.json({
      googleCalendarConnected: user.google_calendar_connected || false,
      outlookCalendarConnected: false // Outlook Calendar integration is removed
    });
  } catch (error) {
    console.error('Error getting calendar status:', error);
    res.status(500).json({ message: 'Failed to get calendar status' });
  }
});

/**
 * Get authorization URL for Google Calendar
 */
calendarRouter.get('/google/auth-url', requireAuth, async (req, res) => {
  try {
    const authUrl = CalendarService.getGoogleAuthUrl();
    res.json({ url: authUrl });
  } catch (error) {
    console.error('Error getting Google auth URL:', error);
    res.status(500).json({ message: 'Failed to get Google auth URL' });
  }
});

/**
 * Handle Google Calendar OAuth callback
 */
calendarRouter.get('/google/callback', async (req, res) => {
  try {
    const { code, state } = req.query;
    const userId = parseInt(state as string, 10);
    
    if (!code || !userId) {
      return res.redirect('/settings?googleCalendarError=true');
    }
    
    const success = await CalendarService.handleGoogleCallback(
      userId,
      code as string
    );
    
    if (success) {
      res.redirect('/settings?googleCalendarConnected=true');
    } else {
      res.redirect('/settings?googleCalendarError=true');
    }
  } catch (error) {
    console.error('Error in Google callback:', error);
    res.redirect('/settings?googleCalendarError=true');
  }
});

/**
 * Outlook Calendar integration has been removed
 */

/**
 * Disconnect Google Calendar
 */
calendarRouter.post('/google/disconnect', requireAuth, async (req, res) => {
  try {
    const success = await CalendarService.disconnectGoogleCalendar(req.userId!);
    
    if (success) {
      res.json({ success: true });
    } else {
      res.status(500).json({ message: 'Failed to disconnect Google Calendar' });
    }
  } catch (error) {
    console.error('Error disconnecting Google Calendar:', error);
    res.status(500).json({ message: 'Failed to disconnect Google Calendar' });
  }
});

/**
 * Outlook Calendar integration has been removed
 */

/**
 * Sync Google Calendar events
 */
calendarRouter.post('/google/sync', requireAuth, async (req, res) => {
  try {
    // For now, just report that we synced 0 events
    // In a real implementation, this would call the Google Calendar API 
    // to fetch events and store them in the database
    
    res.json({ success: true, eventsCount: 0 });
  } catch (error) {
    console.error('Error syncing Google Calendar:', error);
    res.status(500).json({ message: 'Failed to sync Google Calendar' });
  }
});

/**
 * Outlook Calendar integration has been removed
 */

/**
 * Sync all calendars
 */
calendarRouter.post('/sync-all', requireAuth, async (req, res) => {
  try {
    const eventsCount = await CalendarService.syncAllCalendars(req.userId!);
    res.json({ success: true, eventsCount });
  } catch (error) {
    console.error('Error syncing all calendars:', error);
    res.status(500).json({ message: 'Failed to sync calendars' });
  }
});

/**
 * Get external calendar events
 */
calendarRouter.get('/events', requireAuth, async (req, res) => {
  try {
    const start = new Date(req.query.start as string || Date.now());
    const end = new Date(req.query.end as string || Date.now() + 30 * 24 * 60 * 60 * 1000); // Default to 30 days
    
    const events = await CalendarService.getAllExternalEvents(req.userId!, start, end);
    res.json(events);
  } catch (error) {
    console.error('Error getting external calendar events:', error);
    res.status(500).json({ message: 'Failed to get external calendar events' });
  }
});