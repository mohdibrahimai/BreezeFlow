import { Router, Request, Response, NextFunction } from 'express';
import { ICalService } from '../integrations/icalService';
import multer from 'multer';
import { storage } from '../storage';

export const icalendarRouter = Router();

// Setup multer for file uploads (in-memory storage)
const upload = multer({ 
  storage: multer.memoryStorage(),
  limits: {
    fileSize: 5 * 1024 * 1024, // 5MB limit
  },
});

// Middleware to check authentication
const requireAuth = (req: Request, res: Response, next: NextFunction) => {
  if (!req.userId) {
    return res.status(401).json({ message: 'Not authenticated' });
  }
  next();
};

/**
 * Export calendar as ICS file
 */
icalendarRouter.get('/export', requireAuth, async (req, res) => {
  try {
    const icsData = await ICalService.generateICS(req.userId!);
    
    // Set headers for file download
    res.setHeader('Content-Type', 'text/calendar');
    res.setHeader('Content-Disposition', 'attachment; filename=breezeflow-calendar.ics');
    
    res.send(icsData);
  } catch (error) {
    console.error('Error exporting calendar:', error);
    res.status(500).json({ message: 'Failed to export calendar' });
  }
});

/**
 * Import events from ICS file
 */
icalendarRouter.post('/import', requireAuth, upload.single('calendar'), async (req, res) => {
  try {
    if (!req.file) {
      return res.status(400).json({ message: 'No file provided' });
    }
    
    // Get file content
    const icsData = req.file.buffer.toString('utf-8');
    
    // Import events
    const importedCount = await ICalService.importICS(req.userId!, icsData);
    
    res.json({ 
      success: true, 
      importedCount,
      message: `Successfully imported ${importedCount} events` 
    });
  } catch (error) {
    console.error('Error importing calendar:', error);
    res.status(500).json({ message: 'Failed to import calendar' });
  }
});

/**
 * Generate ICS for a single event
 */
icalendarRouter.get('/event/:eventId', requireAuth, async (req, res) => {
  try {
    const eventId = parseInt(req.params.eventId, 10);
    if (isNaN(eventId)) {
      return res.status(400).json({ message: 'Invalid event ID' });
    }
    
    // Verify the event belongs to the user
    const event = await storage.getEvent(eventId);
    if (!event || event.user_id !== req.userId) {
      return res.status(404).json({ message: 'Event not found' });
    }
    
    // Create a calendar with a single event
    const calendar = ical({ name: 'BreezeFlow Event' });
    calendar.createEvent({
      start: new Date(event.start),
      end: new Date(event.end),
      summary: event.title,
      description: `Event from BreezeFlow`,
      location: event.location,
    });
    
    // Set headers for file download
    res.setHeader('Content-Type', 'text/calendar');
    res.setHeader('Content-Disposition', `attachment; filename=${event.title.replace(/[^a-z0-9]/gi, '_').toLowerCase()}.ics`);
    
    res.send(calendar.toString());
  } catch (error) {
    console.error('Error exporting event:', error);
    res.status(500).json({ message: 'Failed to export event' });
  }
});

/**
 * Generate ICS for a single task
 */
icalendarRouter.get('/task/:taskId', requireAuth, async (req, res) => {
  try {
    const taskId = parseInt(req.params.taskId, 10);
    if (isNaN(taskId)) {
      return res.status(400).json({ message: 'Invalid task ID' });
    }
    
    // Verify the task belongs to the user
    const task = await storage.getTask(taskId);
    if (!task || task.user_id !== req.userId || !task.due_date) {
      return res.status(404).json({ message: 'Task not found or has no due date' });
    }
    
    // Create a calendar with a single task as an event
    const calendar = ical({ name: 'BreezeFlow Task' });
    const taskDate = new Date(task.due_date);
    
    calendar.createEvent({
      start: taskDate,
      end: new Date(taskDate.getTime() + 60 * 60 * 1000), // 1 hour duration
      summary: `Task: ${task.title}`,
      description: task.description || `Priority: ${task.priority}`,
    });
    
    // Set headers for file download
    res.setHeader('Content-Type', 'text/calendar');
    res.setHeader('Content-Disposition', `attachment; filename=${task.title.replace(/[^a-z0-9]/gi, '_').toLowerCase()}.ics`);
    
    res.send(calendar.toString());
  } catch (error) {
    console.error('Error exporting task:', error);
    res.status(500).json({ message: 'Failed to export task' });
  }
});