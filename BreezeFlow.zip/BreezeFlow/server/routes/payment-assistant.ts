/**
 * Payment Assistant Module
 * 
 * Provides AI-powered insights and recommendations for bill management
 * Available to Starter, Pro, and Team plan users
 */

import { Router, Request, Response } from "express";
import { storage } from "../storage";
import { db } from "../db";
import { bills } from "@shared/schema";
import { eq, and, gte, lte } from "drizzle-orm";
import { addMonths, format, startOfMonth, endOfMonth, isAfter, isBefore } from "date-fns";

// Extends Express Request to include userId
interface AuthenticatedRequest extends Request {
  userId?: number;
  user?: { id: number };
}

const router = Router();

/**
 * GET /api/payment-assistant/analyze
 * Analyzes user's bill payment patterns and spending trends
 */
router.get("/analyze", async (req: AuthenticatedRequest, res: Response) => {
  try {
    const userId = req.userId || (req.user?.id as number);
    if (!userId) {
      return res.status(401).json({ error: "Unauthorized" });
    }
    
    // Get all user bills
    const userBills = await storage.getBills(userId);
    
    if (userBills.length === 0) {
      return res.json({
        message: "No bills found for analysis",
        spending_trends: [],
        payment_patterns: { on_time: 0, late: 0, rate: 0 },
        category_breakdown: {},
        forecast: {
          next_month: 0,
          three_month: 0
        },
        suggestions: [
          "Start adding your recurring bills to get payment insights",
          "Add bill categories to track spending by category",
          "Set up bill reminders to avoid late payments"
        ]
      });
    }
    
    // Filter paid bills with payment dates
    const paidBills = userBills.filter(bill => 
      bill.status === "paid" && bill.payment_date !== null
    );
    
    // Calculate on-time vs late payments
    const onTimeBills = paidBills.filter(bill => {
      if (!bill.due_date || !bill.payment_date) return false;
      const dueDate = new Date(bill.due_date);
      const paymentDate = new Date(bill.payment_date);
      return !isAfter(paymentDate, dueDate);
    });
    
    const lateBills = paidBills.filter(bill => {
      if (!bill.due_date || !bill.payment_date) return false;
      const dueDate = new Date(bill.due_date);
      const paymentDate = new Date(bill.payment_date);
      return isAfter(paymentDate, dueDate);
    });
    
    const paymentRate = paidBills.length > 0 
      ? (onTimeBills.length / paidBills.length) * 100 
      : 0;
    
    // Calculate spending by category
    const categoryTotals: Record<string, number> = {};
    userBills.forEach(bill => {
      const category = bill.category || "Uncategorized";
      const billAmount = bill.amount || 0;
      categoryTotals[category] = (categoryTotals[category] || 0) + billAmount;
    });
    
    // Calculate monthly spending trends (last 6 months)
    const today = new Date();
    const sixMonthsAgo = addMonths(today, -6);
    
    const monthlyTotals: Array<{month: string, total: number}> = [];
    
    for (let i = 0; i <= 6; i++) {
      const targetMonth = addMonths(sixMonthsAgo, i);
      const monthStart = startOfMonth(targetMonth);
      const monthEnd = endOfMonth(targetMonth);
      const monthLabel = format(targetMonth, "MMM yyyy");
      
      // Filter bills paid in this month
      const monthBills = userBills.filter(bill => {
        if (!bill.payment_date) return false;
        const paymentDate = new Date(bill.payment_date);
        return (
          isAfter(paymentDate, monthStart) && 
          isBefore(paymentDate, monthEnd)
        );
      });
      
      // Sum the amounts
      const monthTotal = monthBills.reduce((sum, bill) => sum + (bill.amount || 0), 0);
      
      monthlyTotals.push({
        month: monthLabel,
        total: monthTotal
      });
    }
    
    // Forecast next month's bills
    const recurringBills = userBills.filter(bill => bill.recurring);
    const nextMonthTotal = recurringBills.reduce((sum, bill) => sum + (bill.amount || 0), 0);
    
    // Generate recommendation insights based on the analysis
    const insights = [];
    
    if (paymentRate < 80) {
      insights.push("Consider setting up automatic payments for bills you frequently pay late");
    }
    
    if (Object.keys(categoryTotals).length <= 1) {
      insights.push("Categorize your bills to get better spending insights");
    }
    
    const highestCategory = Object.entries(categoryTotals)
      .sort((a, b) => b[1] - a[1])
      .shift();
    
    if (highestCategory) {
      insights.push(`Your highest spending category is ${highestCategory[0]} at $${highestCategory[1].toFixed(2)}`);
    }
    
    if (insights.length === 0) {
      insights.push("Your bill payment patterns look good");
      insights.push("Consider reviewing recurring subscriptions for potential savings");
    }
    
    res.json({
      message: "Bill analysis completed",
      spending_trends: monthlyTotals,
      payment_patterns: {
        on_time: onTimeBills.length,
        late: lateBills.length,
        rate: paymentRate.toFixed(2)
      },
      category_breakdown: categoryTotals,
      forecast: {
        next_month: nextMonthTotal,
        three_month: nextMonthTotal * 3
      },
      suggestions: insights
    });
    
  } catch (error) {
    console.error("Error analyzing bill patterns:", error);
    res.status(500).json({ error: "Failed to analyze bill patterns" });
  }
});

/**
 * GET /api/payment-assistant/recommendations
 * Provides personalized recommendations for improving payment habits
 */
router.get("/recommendations", async (req: AuthenticatedRequest, res: Response) => {
  try {
    const userId = req.userId || (req.user?.id as number);
    if (!userId) {
      return res.status(401).json({ error: "Unauthorized" });
    }
    
    // Get all user bills
    const userBills = await storage.getBills(userId);
    
    // Default recommendations for users with few or no bills
    if (userBills.length < 3) {
      return res.json({
        automatic_payment_candidates: [],
        consolidation_opportunities: [],
        reminder_recommendations: [],
        general_recommendations: [
          "Add more bills to get personalized recommendations",
          "Set up recurring bills to track monthly expenses",
          "Add reminders for important bills to avoid late fees"
        ]
      });
    }
    
    // Find bills that are frequently paid late (good candidates for automatic payments)
    const lateBills = userBills.filter(bill => {
      if (!bill.due_date || !bill.payment_date) return false;
      const dueDate = new Date(bill.due_date);
      const paymentDate = new Date(bill.payment_date);
      return isAfter(paymentDate, dueDate);
    });
    
    // Find bills with the same payee that could be consolidated
    const payeeBills: Record<string, Array<typeof userBills[0]>> = {};
    userBills.forEach(bill => {
      if (bill.payee) {
        if (!payeeBills[bill.payee]) {
          payeeBills[bill.payee] = [];
        }
        payeeBills[bill.payee].push(bill);
      }
    });
    
    const consolidationOpportunities = Object.entries(payeeBills)
      .filter(([_, bills]) => bills.length > 1)
      .map(([payee, bills]) => ({
        payee,
        bill_count: bills.length,
        total_amount: bills.reduce((sum, bill) => sum + (bill.amount || 0), 0)
      }));
    
    // Find bills without reminders that should have them
    const highValueBills = userBills.filter(bill => 
      (bill.amount || 0) > 100 && !bill.reminder_days_before
    );
    
    // Generate smart recommendations based on the analysis
    const autoBillCandidates = lateBills.map(bill => ({
      id: bill.id,
      name: bill.name || bill.provider,
      amount: bill.amount || 0,
      reason: "Frequently paid after due date"
    }));
    
    const reminderRecommendations = highValueBills.map(bill => {
      const billAmount = bill.amount || 0;
      return {
        id: bill.id,
        name: bill.name || bill.provider,
        amount: billAmount,
        suggested_days_before: Math.min(7, Math.ceil(billAmount / 100)) // Higher amount = more advance notice
      };
    });
    
    // Generate general recommendations
    const generalRecommendations = [];
    
    if (lateBills.length > 0) {
      generalRecommendations.push("Consider setting up automatic payments for bills frequently paid late");
    }
    
    if (consolidationOpportunities.length > 0) {
      generalRecommendations.push("You have multiple bills from the same payee that could potentially be consolidated");
    }
    
    if (highValueBills.length > 0) {
      generalRecommendations.push("Set up reminders for high-value bills to avoid missing important payments");
    }
    
    // Find seasonal patterns
    const seasonalBills = userBills.filter(bill => !bill.recurring && (bill.amount || 0) > 50);
    if (seasonalBills.length > 0) {
      generalRecommendations.push("Consider budgeting for seasonal expenses that occur throughout the year");
    }
    
    // Add default recommendations if not enough specific ones
    if (generalRecommendations.length < 2) {
      generalRecommendations.push("Review your subscriptions regularly to identify services you no longer use");
      generalRecommendations.push("Set up bill payment due date alerts to your calendar or email");
    }
    
    res.json({
      automatic_payment_candidates: autoBillCandidates,
      consolidation_opportunities: consolidationOpportunities,
      reminder_recommendations: reminderRecommendations,
      general_recommendations: generalRecommendations
    });
    
  } catch (error) {
    console.error("Error generating payment recommendations:", error);
    res.status(500).json({ error: "Failed to generate payment recommendations" });
  }
});

export default router;