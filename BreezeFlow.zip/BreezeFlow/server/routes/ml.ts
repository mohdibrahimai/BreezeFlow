import { Request, Response, Router } from 'express';
import { eq, and, gte, lte, isNotNull, isNull } from 'drizzle-orm';
import path from 'path';
import { exec } from 'child_process';
import util from 'util';
import fs from 'fs';
import os from 'os';
import { db } from '../db';
import { tasks, users } from '@shared/schema';
import { requireAuth } from '../middleware/auth';
import { storage } from '../storage';

const execPromise = util.promisify(exec);
const router = Router();

// Helper function to create temp JSON files for ML scripts
async function createTempJsonFile(data: any): Promise<string> {
  const tempFilePath = path.join(os.tmpdir(), `breezeflow_${Date.now()}.json`);
  await fs.promises.writeFile(tempFilePath, JSON.stringify(data));
  return tempFilePath;
}

// Helper function to run ML scripts
async function runMLScript(scriptPath: string, inputFilePath: string): Promise<any> {
  const mlDir = path.join(__dirname, '../../ml');
  const fullScriptPath = path.join(mlDir, scriptPath);
  
  try {
    const { stdout, stderr } = await execPromise(`python ${fullScriptPath} ${inputFilePath}`);
    
    if (stderr) {
      console.error(`ML script error: ${stderr}`);
    }
    
    return JSON.parse(stdout);
  } catch (error) {
    console.error('Error running ML script:', error);
    throw new Error('Failed to run ML analysis');
  } finally {
    // Clean up temp file
    try {
      await fs.promises.unlink(inputFilePath);
    } catch (err) {
      console.error('Error deleting temp file:', err);
    }
  }
}

// Get productivity insights for a user
router.get('/productivity-insights', requireAuth, async (req: Request, res: Response) => {
  try {
    const userId = parseInt(req.query.userId as string) || req.userId;
    
    if (!userId) {
      return res.status(400).json({ error: 'User ID is required' });
    }
    
    // Ensure the user is only accessing their own data or is an admin
    if (userId !== req.userId && req.userRole !== 'admin') {
      return res.status(403).json({ error: 'Unauthorized access to user data' });
    }
    
    // Get all tasks for the user
    const userTasks = await db.select().from(tasks).where(eq(tasks.user_id, userId));
    
    // Calculate task stats
    const completedTasks = userTasks.filter(task => task.status === 'done');
    const overdueTasks = userTasks.filter(task => {
      if (!task.due_date || task.status === 'done') return false;
      const dueDate = new Date(task.due_date);
      return dueDate < new Date() && task.status !== 'done';
    });
    
    const tasksWithScores = userTasks.filter(task => task.priority_score !== null);
    
    // Calculate completion rate
    const completionRate = userTasks.length > 0 
      ? (completedTasks.length / userTasks.length) * 100 
      : 0;
    
    // Calculate average priority score
    const averagePriorityScore = tasksWithScores.length > 0
      ? tasksWithScores.reduce((sum, task) => sum + (task.priority_score || 0), 0) / tasksWithScores.length
      : null;
    
    // Determine most productive hour (mock data for now - would use real completion timestamps in production)
    const mostProductiveHour = completedTasks.length >= 5 ? (new Date().getHours() % 12 || 12) : null;
    
    // Calculate high priority completion rate
    const highPriorityTasks = userTasks.filter(task => task.priority === 'high');
    const completedHighPriorityTasks = highPriorityTasks.filter(task => task.status === 'done');
    const highPriorityCompletionRate = highPriorityTasks.length > 0
      ? (completedHighPriorityTasks.length / highPriorityTasks.length) * 100
      : null;
    
    // Analyze tag usage
    const tagCounts: Record<string, number> = {};
    userTasks.forEach(task => {
      if (task.tags) {
        const taskTags = Array.isArray(task.tags) 
          ? task.tags 
          : typeof task.tags === 'string' 
            ? task.tags.split(',').map(t => t.trim()) 
            : [];
            
        taskTags.forEach(tag => {
          tagCounts[tag] = (tagCounts[tag] || 0) + 1;
        });
      }
    });
    
    const tagUsage = Object.entries(tagCounts)
      .map(([tag, count]) => ({ tag, count }))
      .sort((a, b) => b.count - a.count);
    
    // Generate personalized tips based on task data
    const personalizedTips = [];
    
    if (overdueTasks.length > 0) {
      personalizedTips.push(`You have ${overdueTasks.length} overdue tasks. Consider rescheduling or breaking them down into smaller steps.`);
    }
    
    if (completionRate < 50 && userTasks.length >= 5) {
      personalizedTips.push("Your task completion rate is below 50%. Try focusing on fewer tasks at a time to improve completion.");
    }
    
    if (userTasks.filter(task => !task.estimated_minutes).length > userTasks.length * 0.5) {
      personalizedTips.push("Adding time estimates to your tasks will help with scheduling and priority assignment.");
    }
    
    if (tagUsage.length === 0 && userTasks.length >= 5) {
      personalizedTips.push("Using tags can help you organize and prioritize your tasks more effectively.");
    }
    
    if (userTasks.filter(task => task.description && task.description.length > 10).length < userTasks.length * 0.3) {
      personalizedTips.push("Adding detailed descriptions to tasks can improve clarity and completion rates.");
    }
    
    // If we don't have enough personalized tips, add general ones
    const generalTips = [
      "Schedule your most important tasks during your peak energy hours.",
      "Take short breaks between tasks to maintain productivity and focus.",
      "Group similar tasks together to reduce context switching.",
      "Consider the 2-minute rule: if a task takes less than 2 minutes, do it immediately.",
      "Review your completed tasks weekly to identify patterns and improvements."
    ];
    
    while (personalizedTips.length < 3 && generalTips.length > 0) {
      personalizedTips.push(generalTips.shift() as string);
    }
    
    // Prepare the response
    const productivityData = {
      task_stats: {
        total: userTasks.length,
        completed: completedTasks.length,
        completion_rate: completionRate,
        overdue: overdueTasks.length,
        with_priority_scores: tasksWithScores.length
      },
      productivity_metrics: {
        average_priority_score: averagePriorityScore,
        most_productive_hour: mostProductiveHour,
        high_priority_completion_rate: highPriorityCompletionRate
      },
      tag_usage: tagUsage,
      personalized_tips: personalizedTips
    };
    
    res.json(productivityData);
  } catch (error) {
    console.error('Error getting productivity insights:', error);
    res.status(500).json({ error: 'Failed to get productivity insights' });
  }
});

// Batch process task scores
router.post('/batch-process-scores', requireAuth, async (req: Request, res: Response) => {
  try {
    const userId = req.body.userId || req.userId;
    
    if (!userId) {
      return res.status(400).json({ error: 'User ID is required' });
    }
    
    // Ensure the user is only accessing their own data or is an admin
    if (userId !== req.userId && req.userRole !== 'admin') {
      return res.status(403).json({ error: 'Unauthorized access to user data' });
    }
    
    // Get incomplete tasks for the user
    const userTasks = await db.select().from(tasks)
      .where(and(
        eq(tasks.user_id, userId),
        eq(tasks.status, 'todo')
      ));
    
    if (userTasks.length === 0) {
      return res.status(404).json({ error: 'No incomplete tasks found for batch processing' });
    }
    
    // Create temp file for ML script
    const inputFilePath = await createTempJsonFile(userTasks);
    
    // Run the ML script
    const results = await runMLScript('calculate_batch_scores.py', inputFilePath);
    
    // Update tasks with priority scores in the database
    const updates = [];
    for (const task of results.tasks) {
      if (task.id) {
        updates.push(
          db.update(tasks)
            .set({ 
              priority_score: task.score,
              estimated_minutes: task.estimated_completion_minutes || tasks.estimated_minutes
            })
            .where(eq(tasks.id, task.id))
        );
      }
    }
    
    await Promise.all(updates);
    
    // Track usage event
    await storage.createUsageEvent({
      user_id: userId,
      event_type: 'ml_batch_process',
      event_data: JSON.stringify({
        task_count: userTasks.length,
        avg_score: results.stats.average_score
      }),
      timestamp: new Date().toISOString()
    });
    
    res.json(results);
  } catch (error) {
    console.error('Error processing batch scores:', error);
    res.status(500).json({ error: 'Failed to process task scores' });
  }
});

// Calculate priority score for a single task
router.post('/calculate-score', requireAuth, async (req: Request, res: Response) => {
  try {
    const { taskId } = req.body;
    
    if (!taskId) {
      return res.status(400).json({ error: 'Task ID is required' });
    }
    
    // Get the task
    const [task] = await db.select().from(tasks).where(eq(tasks.id, taskId));
    
    if (!task) {
      return res.status(404).json({ error: 'Task not found' });
    }
    
    // Ensure the user is only accessing their own data or is an admin
    if (task.user_id !== req.userId && req.userRole !== 'admin') {
      return res.status(403).json({ error: 'Unauthorized access to task data' });
    }
    
    // Create temp file for ML script
    const inputFilePath = await createTempJsonFile(task);
    
    // Run the ML script
    const result = await runMLScript('calculate_score.py', inputFilePath);
    
    // Update task with priority score in the database
    await db.update(tasks)
      .set({ 
        priority_score: result.score,
        estimated_minutes: result.estimated_minutes || task.estimated_minutes
      })
      .where(eq(tasks.id, taskId));
    
    // Track usage event
    await storage.createUsageEvent({
      user_id: task.user_id,
      event_type: 'ml_score_calculation',
      event_data: JSON.stringify({
        task_id: taskId,
        score: result.score
      }),
      timestamp: new Date().toISOString()
    });
    
    res.json(result);
  } catch (error) {
    console.error('Error calculating priority score:', error);
    res.status(500).json({ error: 'Failed to calculate priority score' });
  }
});

// Generate optimized schedule
router.post('/generate-schedule', requireAuth, async (req: Request, res: Response) => {
  try {
    const { userId, date } = req.body;
    
    if (!userId || !date) {
      return res.status(400).json({ error: 'User ID and date are required' });
    }
    
    // Ensure the user is only accessing their own data or is an admin
    if (userId !== req.userId && req.userRole !== 'admin') {
      return res.status(403).json({ error: 'Unauthorized access to user data' });
    }
    
    // Parse the date and get the date range (start and end of day)
    const selectedDate = new Date(date);
    const startDate = new Date(selectedDate);
    startDate.setHours(0, 0, 0, 0);
    
    const endDate = new Date(selectedDate);
    endDate.setHours(23, 59, 59, 999);
    
    // Get user's tasks for the day
    const userTasks = await db.select().from(tasks)
      .where(and(
        eq(tasks.user_id, userId),
        eq(tasks.status, 'todo'),
        isNotNull(tasks.priority_score)
      ));
    
    // Get user's events for the day
    const userEvents = await db.select()
      .from(storage.events)
      .where(and(
        eq(storage.events.user_id, userId),
        gte(storage.events.start_time, startDate.toISOString()),
        lte(storage.events.end_time, endDate.toISOString())
      ));
    
    // Prepare input data for the optimization algorithm
    const optimizationData = {
      tasks: userTasks,
      events: userEvents,
      date: date
    };
    
    // Ideally, we'd use a real optimization engine here
    // For now, we'll use a simpler approach:
    
    // Convert events to time blocks
    const fixedBlocks = userEvents.map(event => ({
      title: event.title,
      startISO: event.start_time,
      endISO: event.end_time,
      isFixed: true
    }));
    
    // Sort tasks by priority score (highest first)
    const sortedTasks = [...userTasks].sort((a, b) => {
      return (b.priority_score || 0) - (a.priority_score || 0);
    });
    
    // Define working hours (9 AM to 5 PM)
    const workStart = new Date(selectedDate);
    workStart.setHours(9, 0, 0, 0);
    
    const workEnd = new Date(selectedDate);
    workEnd.setHours(17, 0, 0, 0);
    
    // Add start and end boundaries
    const timeBlocks = [
      ...fixedBlocks,
    ];
    
    // Find available time slots
    const busyTimes = fixedBlocks.map(block => ({
      start: new Date(block.startISO),
      end: new Date(block.endISO)
    })).sort((a, b) => a.start.getTime() - b.start.getTime());
    
    const freeSlots: { start: Date; end: Date }[] = [];
    let currentTime = new Date(workStart);
    
    // Add slots between fixed events
    busyTimes.forEach(busy => {
      if (busy.start > currentTime) {
        freeSlots.push({
          start: new Date(currentTime),
          end: new Date(busy.start)
        });
      }
      currentTime = busy.end > currentTime ? busy.end : currentTime;
    });
    
    // Add final slot if needed
    if (currentTime < workEnd) {
      freeSlots.push({
        start: new Date(currentTime),
        end: new Date(workEnd)
      });
    }
    
    // Schedule tasks in free slots
    const scheduledTasks: any[] = [];
    const unscheduledTasks: any[] = [];
    
    sortedTasks.forEach(task => {
      const taskDuration = (task.estimated_minutes || 30) * 60 * 1000; // Convert to milliseconds
      
      // Find a slot that fits this task
      const slotIndex = freeSlots.findIndex(slot => {
        return (slot.end.getTime() - slot.start.getTime()) >= taskDuration;
      });
      
      if (slotIndex !== -1) {
        const slot = freeSlots[slotIndex];
        
        // Create a new time block for this task
        const taskBlock = {
          title: task.title,
          startISO: slot.start.toISOString(),
          endISO: new Date(slot.start.getTime() + taskDuration).toISOString(),
          taskId: task.id
        };
        
        scheduledTasks.push(taskBlock);
        
        // Update the slot's start time
        slot.start = new Date(slot.start.getTime() + taskDuration);
        
        // Remove the slot if it's now too small
        if (slot.end.getTime() - slot.start.getTime() < 15 * 60 * 1000) { // Less than 15 minutes
          freeSlots.splice(slotIndex, 1);
        }
      } else {
        unscheduledTasks.push({
          id: task.id,
          title: task.title
        });
      }
    });
    
    // Combine fixed blocks and scheduled tasks
    const allTimeBlocks = [
      ...fixedBlocks,
      ...scheduledTasks
    ].sort((a, b) => {
      return new Date(a.startISO).getTime() - new Date(b.startISO).getTime();
    });
    
    const schedule = {
      timeBlocks: allTimeBlocks,
      unscheduledTasks: unscheduledTasks
    };
    
    // Track usage event
    await storage.createUsageEvent({
      user_id: userId,
      event_type: 'schedule_optimization',
      event_data: JSON.stringify({
        date: date,
        scheduled_tasks: scheduledTasks.length,
        unscheduled_tasks: unscheduledTasks.length
      }),
      timestamp: new Date().toISOString()
    });
    
    res.json(schedule);
  } catch (error) {
    console.error('Error generating schedule:', error);
    res.status(500).json({ error: 'Failed to generate optimized schedule' });
  }
});

// Get optimized schedule
router.get('/optimized-schedule', requireAuth, async (req: Request, res: Response) => {
  try {
    const userId = parseInt(req.query.userId as string) || req.userId;
    const date = req.query.date as string;
    
    if (!userId || !date) {
      return res.status(400).json({ error: 'User ID and date are required' });
    }
    
    // Ensure the user is only accessing their own data or is an admin
    if (userId !== req.userId && req.userRole !== 'admin') {
      return res.status(403).json({ error: 'Unauthorized access to user data' });
    }
    
    // For this endpoint, we'll return a 404 to indicate no schedule exists yet
    // The client should then call the POST endpoint to generate a schedule
    res.status(404).json({ error: 'No optimized schedule found for this date' });
  } catch (error) {
    console.error('Error retrieving optimized schedule:', error);
    res.status(500).json({ error: 'Failed to retrieve optimized schedule' });
  }
});

export default router;