import express, { Request, Response } from "express";
import { storage } from "../storage";
import { optimizeSchedule } from "../../scripts/optimizer";
import { requirePlan } from "../middleware/checkQuota";
import { queryLlm, createTaskWithLlm, createBatchTasksWithLlm, ensureLlmRunning } from "../../scripts/llm_client";

const router = express.Router();

/**
 * Extends Express Request to include userId
 */
interface AuthenticatedRequest extends Request {
  userId?: number;
}

/**
 * GET /api/copilot
 * This endpoint returns a personalized greeting and status
 */
router.get("/", async (req: AuthenticatedRequest, res: Response) => {
  try {
    const userId = req.userId as number;
    const user = await storage.getUser(userId);
    
    if (!user) {
      return res.status(404).json({ message: "User not found" });
    }
    
    // Get incomplete tasks count
    const tasks = await storage.getTasks(userId);
    const incompleteTasks = tasks.filter(task => task.status !== "done");
    
    // Get upcoming events count
    const now = new Date();
    const events = await storage.getEvents(userId);
    const upcomingEvents = events.filter(event => {
      const eventStart = new Date(event.start);
      return eventStart > now;
    });
    
    // Get user productivity stats
    const roi = await storage.getUserROI(userId, 30);
    
    // Format greeting based on time of day
    const hour = new Date().getHours();
    let greeting = "Hello";
    if (hour < 12) {
      greeting = "Good morning";
    } else if (hour < 18) {
      greeting = "Good afternoon";
    } else {
      greeting = "Good evening";
    }
    
    res.json({
      greeting: `${greeting}, ${user.name}!`,
      taskCount: incompleteTasks.length,
      eventCount: upcomingEvents.length,
      productivityStats: {
        hoursSaved: roi.hoursSaved,
        moneySaved: roi.moneySaved
      },
      streakDays: user.streak_days
    });
  } catch (error) {
    console.error("Error in copilot greeting:", error);
    res.status(500).json({ message: "Failed to generate copilot greeting" });
  }
});

/**
 * POST /api/copilot/schedule/optimize
 * This endpoint uses the optimizer to create a smart schedule
 */
router.post("/schedule/optimize", requirePlan(['starter', 'pro', 'team']), async (req: AuthenticatedRequest, res: Response) => {
  try {
    const userId = req.userId as number;
    
    // Get user tasks and events
    const tasks = await storage.getTasks(userId);
    const events = await storage.getEvents(userId);
    
    // Filter for active tasks (not completed)
    const activeTasks = tasks.filter(task => task.status !== "done");
    
    // Generate optimized schedule
    const optimizedSchedule = optimizeSchedule(activeTasks, events);
    
    res.json(optimizedSchedule);
  } catch (error) {
    console.error("Error optimizing schedule:", error);
    res.status(500).json({ message: "Failed to optimize schedule" });
  }
});

/**
 * POST /api/copilot
 * This endpoint processes user messages through the LLM and returns streaming responses
 */
router.post("/", async (req: AuthenticatedRequest, res: Response) => {
  try {
    // Check if user provided a message
    const { message } = req.body;
    if (!message || typeof message !== 'string') {
      return res.status(400).json({ message: "Message is required" });
    }

    // Get user information for personalization
    const userId = req.userId as number;
    const user = await storage.getUser(userId);
    
    if (!user) {
      return res.status(404).json({ message: "User not found" });
    }

    // Set response headers for streaming
    res.setHeader('Content-Type', 'text/event-stream');
    res.setHeader('Cache-Control', 'no-cache');
    res.setHeader('Connection', 'keep-alive');
    
    // Ensure LLM is running
    await ensureLlmRunning();
    
    // Get user's tasks and events for context
    const tasks = await storage.getTasks(userId);
    const events = await storage.getEvents(userId);
    const bills = await storage.getBills(userId);
    
    // Format tasks and events for context
    const tasksSummary = tasks
      .filter(task => task.status !== 'done')
      .map(task => `- ${task.title} (priority: ${task.priority}, due: ${task.due_date || 'not set'})`)
      .slice(0, 5)
      .join('\n');
    
    const eventsSummary = events
      .filter(event => new Date(event.start) > new Date())
      .map(event => `- ${event.title} (${event.start})`)
      .slice(0, 3)
      .join('\n');
      
    const billsSummary = bills
      .filter(bill => bill.status === 'upcoming')
      .map(bill => `- ${bill.provider}: $${bill.amount/100} (due: ${bill.due_date})`)
      .slice(0, 3)
      .join('\n');
    
    // Prepare the prompt with enhanced user context
    const userContext = `
You are BreezeMind, a personal productivity assistant for BreezeFlow app.
Current user: ${user.name} (Plan: ${user.plan || 'free'})
Current time: ${new Date().toLocaleString()}

USER CONTEXT:
${tasks.filter(t => t.status !== 'done').length} pending tasks, ${events.filter(e => new Date(e.start) > new Date()).length} upcoming events, ${bills.filter(b => b.status === 'upcoming').length} upcoming bills

Top tasks:
${tasksSummary || '(No pending tasks)'}

Upcoming events:
${eventsSummary || '(No upcoming events)'}

Upcoming bills:
${billsSummary || '(No upcoming bills)'}

Help the user with their request in a helpful, concise way. For task-related requests,
you can create tasks for the user by extracting task details. If they ask about their tasks,
events or bills, reference the actual data above.

User's message: ${message}
`;

    let functionResult = null;
    
    // Check if this is a batch task creation request
    if (message.toLowerCase().includes('create tasks') || 
        message.toLowerCase().includes('add tasks') ||
        message.toLowerCase().includes('to-do list') ||
        message.toLowerCase().includes('todo list')) {
      try {
        // Extract multiple tasks using batch processing
        const tasksData = await createBatchTasksWithLlm(message);
        
        const createdTaskIds: number[] = [];
        
        // Create each task in the database
        for (const taskData of tasksData) {
          const createdTask = await storage.createTask({
            title: taskData.title,
            priority: taskData.priority,
            status: 'todo',
            user_id: userId,
            due_date: taskData.dueDate || null,
            description: taskData.description || null,
            points: taskData.points || 1
          });
          
          createdTaskIds.push(createdTask.id);
        }
        
        // Save the created tasks info for the response
        functionResult = { 
          batchTaskIds: createdTaskIds,
          count: createdTaskIds.length
        };
        
        // Send a usage event for ROI tracking
        await storage.createUsageEvent({
          user_id: userId,
          action: 'create_batch_tasks_via_ai',
          timestamp: new Date(),
          metadata: { taskCount: createdTaskIds.length },
          estimated_minutes_saved: createdTaskIds.length * 3, // 3 minutes saved per task
          estimated_money_saved: Math.round((createdTaskIds.length * 3/60) * 60) // Default hourly rate
        });
      } catch (error) {
        console.error('Error creating batch tasks from AI:', error);
      }
    }
    // Check if this is a single task creation request
    else if (message.toLowerCase().includes('create task') || 
        message.toLowerCase().includes('add task') ||
        message.toLowerCase().includes('remind me to')) {
      try {
        // Extract task information using LLM
        const taskData = await createTaskWithLlm(message);
        
        // Prepare tags if they exist
        let tagStr = null;
        if (taskData.tags && taskData.tags.length > 0) {
          tagStr = taskData.tags.join(',');
        }
        
        // Parse reminder time if it's a string to convert to Date
        let reminderTimeDate = null;
        if (taskData.reminderTime) {
          reminderTimeDate = new Date(taskData.reminderTime);
        }
        
        // Create the task in the database
        const createdTask = await storage.createTask({
          title: taskData.title,
          priority: taskData.priority,
          status: 'todo',
          user_id: userId,
          due_date: taskData.dueDate || null,
          description: taskData.description || null,
          points: taskData.points || 1,
          tags: tagStr,
          estimated_minutes: taskData.estimatedTime,
          reminder_time: reminderTimeDate
        });
        
        // Save the created task info for the response
        functionResult = { taskId: createdTask.id };
        
        // Send a usage event for ROI tracking
        await storage.createUsageEvent({
          user_id: userId,
          action: 'create_task_via_ai',
          timestamp: new Date(),
          metadata: { taskId: createdTask.id, title: createdTask.title },
          estimated_minutes_saved: 5,
          estimated_money_saved: Math.round((5/60) * 60) // Default hourly rate
        });
      } catch (error) {
        console.error('Error creating task from AI:', error);
      }
    }
    
    // Process the message with LLM
    const llmPromise = queryLlm(userContext);
    
    // Stream initial data packet
    res.write('data: ' + JSON.stringify({ type: 'content', content: '' }) + '\n\n');
    
    // Get LLM response
    let llmResponse = await llmPromise;
    
    // Customize response based on function result
    if (functionResult) {
      // Add task creation confirmation to the response
      if (functionResult.taskId) {
        llmResponse += "\n\nI've created that task for you! You can find it in your tasks list.";
      } else if (functionResult.batchTaskIds && functionResult.count) {
        llmResponse += `\n\nI've created ${functionResult.count} tasks for you! You can find them in your tasks list.`;
      }
    }
    
    // Format and stream the response in chunks for a more natural typing effect
    const words = llmResponse.split(' ');
    const chunkSize = 5; // Send 5 words at a time
    
    // Send response in chunks
    for (let i = 0; i < words.length; i += chunkSize) {
      const chunk = words.slice(i, i + chunkSize).join(' ') + ' ';
      res.write('data: ' + JSON.stringify({ type: 'content', content: chunk }) + '\n\n');
      
      // Add a small delay between chunks for a more natural effect
      await new Promise(resolve => setTimeout(resolve, 100));
    }
    
    // If we have function results, send them
    if (functionResult) {
      res.write('data: ' + JSON.stringify({ type: 'function_result', result: functionResult }) + '\n\n');
    }
    
    // Send done message
    res.write('data: ' + JSON.stringify({ type: 'done' }) + '\n\n');
    res.end();
    
  } catch (error) {
    console.error('Error in copilot chat:', error);
    
    // If headers not sent yet, send error as JSON
    if (!res.headersSent) {
      return res.status(500).json({ 
        message: "Failed to process chat message",
        error: error instanceof Error ? error.message : String(error)
      });
    }
    
    // Otherwise stream the error
    res.write('data: ' + JSON.stringify({ 
      type: 'error',
      content: "Sorry, I encountered an error processing your message."
    }) + '\n\n');
    res.end();
  }
});

export default router;