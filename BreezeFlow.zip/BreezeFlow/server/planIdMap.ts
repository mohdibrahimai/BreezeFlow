// Map plan names to their respective IDs in payment gateways

interface PlanMap {
  free: string;
  starter: {
    monthly: string;
    annual: string;
  };
  pro: {
    monthly: string;
    annual: string;
  };
  team: {
    monthly: string;
    annual: string;
  };
}

// Plan IDs for Razorpay
export const razorpayPlanIds: PlanMap = {
  free: process.env.RAZORPAY_PLAN_FREE_ID || 'free_sandbox',
  starter: {
    monthly: process.env.RAZORPAY_PLAN_STARTER_M || 'starter_m_sandbox',
    annual: process.env.RAZORPAY_PLAN_STARTER_Y || 'starter_y_sandbox',
  },
  pro: {
    monthly: process.env.RAZORPAY_PLAN_PRO_M || 'pro_m_sandbox',
    annual: process.env.RAZORPAY_PLAN_PRO_Y || 'pro_y_sandbox',
  },
  team: {
    monthly: process.env.RAZORPAY_PLAN_TEAM_M || 'team_m_sandbox',
    annual: process.env.RAZORPAY_PLAN_TEAM_Y || 'team_y_sandbox',
  }
};

// Plan prices in INR (₹)
export const planPricesINR = {
  free: 0,
  starter: {
    monthly: 499, // ₹499 ≈ $6 USD (reduced from ₹580)
    annual: 4990, // ₹4990 ≈ $60 USD (2 months free)
  },
  pro: {
    monthly: 1399, // ₹1399 ≈ $16.85 USD (reduced from ₹1575)
    annual: 13990, // ₹13990 ≈ $168.5 USD (2 months free)
  },
  team: {
    monthly: 899, // ₹899 ≈ $10.85 USD per user (reduced from ₹995)
    annual: 8990, // ₹8990 ≈ $108.5 USD per user (2 months free)
  }
};

// Plan prices in USD ($)
export const planPricesUSD = {
  free: 0,
  starter: {
    monthly: 6, // Reduced from $7
    annual: 60, // $60/year (2 months free)
  },
  pro: {
    monthly: 16.85, // Reduced from $19
    annual: 168.5, // $168.5/year (2 months free)
  },
  team: {
    monthly: 10.85, // per user (reduced from $12)
    annual: 108.5, // per user (2 months free)
  }
};

// Calculate features available at each tier
export const planFeatures = {
  free: {
    monthlyActions: 75, // Increased from 50
    unlimitedTasks: true,
    basicReporting: true,
    automatedScheduling: false,
    customIntegrations: false,
    prioritySupport: false,
    teamCollaboration: false,
    whiteLabeling: false,
    advancedAnalytics: false,
    aiAssistant: false,
    smartPrioritization: false,
    recurringBills: false,
    backupAndExport: false,
    calendarSync: false,
    darkMode: true,
    offlineMode: false,
    mobileAccess: true,
  },
  starter: {
    monthlyActions: 750, // Increased from 500
    unlimitedTasks: true,
    basicReporting: true,
    automatedScheduling: true,
    customIntegrations: false,
    prioritySupport: false,
    teamCollaboration: false,
    whiteLabeling: false,
    advancedAnalytics: true, // Added
    aiAssistant: true, // Added 
    smartPrioritization: true, // Added
    recurringBills: true, // Added
    backupAndExport: true, // Added
    calendarSync: true, // Added
    darkMode: true,
    offlineMode: true, // Added
    mobileAccess: true,
  },
  pro: {
    monthlyActions: Infinity,
    unlimitedTasks: true,
    basicReporting: true,
    automatedScheduling: true,
    customIntegrations: true,
    prioritySupport: true,
    teamCollaboration: false,
    whiteLabeling: false,
    advancedAnalytics: true,
    aiAssistant: true,
    smartPrioritization: true,
    recurringBills: true,
    backupAndExport: true,
    calendarSync: true,
    darkMode: true,
    offlineMode: true,
    mobileAccess: true,
    automatedReminders: true, // Added
    batchScheduling: true, // Added
    apiAccess: true, // Added
    customCategories: true, // Added
  },
  team: {
    monthlyActions: Infinity,
    unlimitedTasks: true,
    basicReporting: true,
    automatedScheduling: true,
    customIntegrations: true,
    prioritySupport: true,
    teamCollaboration: true,
    whiteLabeling: true,
    advancedAnalytics: true,
    aiAssistant: true,
    smartPrioritization: true,
    recurringBills: true,
    backupAndExport: true,
    calendarSync: true,
    darkMode: true,
    offlineMode: true,
    mobileAccess: true,
    automatedReminders: true,
    batchScheduling: true,
    apiAccess: true,
    customCategories: true,
    userRoles: true, // Added
    activityLogs: true, // Added
    ssoIntegration: true, // Added
    bulkOperations: true, // Added
  }
};

// Get plan ID for a specific gateway, plan, and billing period
export function getPlanId(planName: string, billingPeriod: 'monthly' | 'annual' = 'monthly'): string {
  if (planName === 'free') {
    return razorpayPlanIds.free;
  }
  
  const plan = razorpayPlanIds[planName as keyof typeof razorpayPlanIds];
  
  if (typeof plan === 'object') {
    return plan[billingPeriod];
  }
  
  // Fallback to starter monthly if something goes wrong
  return razorpayPlanIds.starter.monthly;
}