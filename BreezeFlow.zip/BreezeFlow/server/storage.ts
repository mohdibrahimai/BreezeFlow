import { 
  users, type User, type InsertUser,
  tasks, type Task, type InsertTask,
  events, type Event, type InsertEvent,
  errands, type Errand, type InsertErrand,
  bills, type Bill, type InsertBill,
  rewards, type Reward, type InsertReward,
  invites, type Invite, type InsertInvite,
  usage_events, type UsageEvent, type InsertUsageEvent,
  payments
} from "@shared/schema";
import createMemoryStore from "memorystore";
import session from "express-session";
import { Store as SessionStore } from "express-session";
import { DatabaseStorage } from "./database-storage";

const MemoryStore = createMemoryStore(session);

export interface IStorage {
  // Users
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  getUserByEmail(email: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUser(id: number, userData: Partial<User>): Promise<User | undefined>;
  
  // Password Reset
  setResetToken(userId: number, token: string, expiresAt: Date): Promise<User | undefined>;
  validateResetToken(token: string): Promise<boolean>;
  getUserByResetToken(token: string): Promise<User | undefined>;
  updatePassword(userId: number, newPassword: string): Promise<User | undefined>;
  
  // Tasks
  getTasks(userId: number): Promise<Task[]>;
  getAllTasks(): Promise<Task[]>;  // Add this method to get all tasks for ML training
  getTask(id: number): Promise<Task | undefined>;
  createTask(task: InsertTask): Promise<Task>;
  updateTask(id: number, taskData: Partial<Task>): Promise<Task | undefined>;
  deleteTask(id: number): Promise<boolean>;
  
  // Events
  getEvents(userId: number): Promise<Event[]>;
  getEvent(id: number): Promise<Event | undefined>;
  createEvent(event: InsertEvent): Promise<Event>;
  updateEvent(id: number, eventData: Partial<Event>): Promise<Event | undefined>;
  deleteEvent(id: number): Promise<boolean>;
  
  // Errands
  getErrands(userId: number): Promise<Errand[]>;
  getErrand(id: number): Promise<Errand | undefined>;
  createErrand(errand: InsertErrand): Promise<Errand>;
  updateErrand(id: number, errandData: Partial<Errand>): Promise<Errand | undefined>;
  deleteErrand(id: number): Promise<boolean>;
  
  // Bills
  getBills(userId: number): Promise<Bill[]>;
  getBill(id: number): Promise<Bill | undefined>;
  createBill(bill: InsertBill): Promise<Bill>;
  updateBill(id: number, billData: Partial<Bill>): Promise<Bill | undefined>;
  deleteBill(id: number): Promise<boolean>;
  getAllUpcomingBills(): Promise<Bill[]>; // For reminder processing
  updateBillReminderTimestamp(id: number): Promise<Bill | undefined>; // For tracking reminders
  
  // Rewards
  getRewards(userId: number): Promise<Reward[]>;
  getReward(id: number): Promise<Reward | undefined>;
  createReward(reward: InsertReward): Promise<Reward>;
  
  // Invites
  getInvites(userId: number): Promise<Invite[]>;
  createInvite(invite: InsertInvite): Promise<Invite>;
  updateInvite(id: number, inviteData: Partial<Invite>): Promise<Invite | undefined>;
  
  // Calendar Integrations
  updateGoogleCalendarToken(userId: number, refreshToken: string): Promise<User | undefined>;
  updateOutlookCalendarToken(userId: number, refreshToken: string): Promise<User | undefined>;
  disconnectGoogleCalendar(userId: number): Promise<User | undefined>;
  disconnectOutlookCalendar(userId: number): Promise<User | undefined>;
  getExternalCalendarEvents(userId: number, start: Date, end: Date): Promise<any[]>;
  syncCalendarEvents(userId: number): Promise<number>; // Returns count of synced events
  
  // Usage Events and ROI
  createUsageEvent(event: InsertUsageEvent): Promise<UsageEvent>;
  getUserROI(userId: number, days?: number): Promise<{ hoursSaved: number, moneySaved: number }>;
  getUserActionCount(userId: number, days?: number): Promise<number>;
  
  // Quota Management with Concurrency Protection
  checkAndIncrementQuota(userId: number, limit: number): Promise<{ 
    actionCount: number;
    quotaExceeded: boolean;
  }>;
  
  // Payments
  createPayment(payment: any): Promise<any>;
  
  // Session store
  sessionStore: SessionStore;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private tasks: Map<number, Task>;
  private events: Map<number, Event>;
  private errands: Map<number, Errand>;
  private bills: Map<number, Bill>;
  private rewards: Map<number, Reward>;
  private invites: Map<number, Invite>;
  private usageEvents: Map<number, UsageEvent>;
  private externalCalendarEvents: Map<number, any[]>; // Store synchronized calendar events
  
  userCurrentId: number;
  taskCurrentId: number;
  eventCurrentId: number;
  errandCurrentId: number;
  billCurrentId: number;
  rewardCurrentId: number;
  inviteCurrentId: number;
  usageEventCurrentId: number;
  sessionStore: SessionStore;

  constructor() {
    this.users = new Map();
    this.tasks = new Map();
    this.events = new Map();
    this.errands = new Map();
    this.bills = new Map();
    this.rewards = new Map();
    this.invites = new Map();
    this.usageEvents = new Map();
    this.externalCalendarEvents = new Map();
    
    this.userCurrentId = 1;
    this.taskCurrentId = 1;
    this.usageEventCurrentId = 1;
    this.eventCurrentId = 1;
    this.errandCurrentId = 1;
    this.billCurrentId = 1;
    this.rewardCurrentId = 1;
    this.inviteCurrentId = 1;
    
    this.sessionStore = new MemoryStore({
      checkPeriod: 86400000 // Clear expired sessions every day
    });
  }

  // User methods
  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }
  
  async getUserByEmail(email: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.email === email,
    );
  }
  
  async setResetToken(userId: number, token: string, expiresAt: Date): Promise<User | undefined> {
    const user = this.users.get(userId);
    if (!user) return undefined;
    
    const updatedUser = { 
      ...user, 
      reset_token: token,
      reset_token_expires: expiresAt
    };
    this.users.set(userId, updatedUser);
    return updatedUser;
  }
  
  async validateResetToken(token: string): Promise<boolean> {
    const user = await this.getUserByResetToken(token);
    if (!user) return false;
    
    // Check if token is expired
    const now = new Date();
    if (!user.reset_token_expires || new Date(user.reset_token_expires) < now) {
      return false;
    }
    
    return true;
  }
  
  async getUserByResetToken(token: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.reset_token === token
    );
  }
  
  async updatePassword(userId: number, newPassword: string): Promise<User | undefined> {
    const user = this.users.get(userId);
    if (!user) return undefined;
    
    const updatedUser = { 
      ...user, 
      password: newPassword,
      reset_token: null, // Clear reset token after password update
      reset_token_expires: null
    };
    this.users.set(userId, updatedUser);
    return updatedUser;
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.userCurrentId++;
    const user: User = { 
      ...insertUser, 
      id, 
      flow_score: 0, 
      streak_days: 0,
      plan: insertUser.plan || "free",
      plan_active: false,
      plan_expiry: null,
      paypal_customer_id: null,
      paypal_subscription_id: null,
      last_payment_date: null,
      hourly_rate: "60",
      currency: "USD",
      pref_reduce_motion: false,
      google_calendar_connected: false,
      google_refresh_token: null,
      outlook_calendar_connected: false,
      outlook_refresh_token: null,
      reset_token: null,
      reset_token_expires: null,
      // Ensure security question/answer are included with default values if not provided
      security_question: insertUser.security_question || null,
      security_answer: insertUser.security_answer || null
    };
    this.users.set(id, user);
    return user;
  }
  
  async updateUser(id: number, userData: Partial<User>): Promise<User | undefined> {
    const user = this.users.get(id);
    if (!user) return undefined;
    
    const updatedUser = { ...user, ...userData };
    this.users.set(id, updatedUser);
    return updatedUser;
  }

  // Task methods
  async getTasks(userId: number): Promise<Task[]> {
    return Array.from(this.tasks.values()).filter(task => task.user_id === userId);
  }
  
  async getAllTasks(): Promise<Task[]> {
    return Array.from(this.tasks.values());
  }
  
  async getTask(id: number): Promise<Task | undefined> {
    return this.tasks.get(id);
  }
  
  async createTask(task: InsertTask): Promise<Task> {
    const id = this.taskCurrentId++;
    const newTask: Task = { 
      ...task, 
      id, 
      description: task.description || null,
      due_date: task.due_date || null,
      points: task.points || 10,
      completed_at: null,
      created_at: new Date(),
      priority_score: null
    };
    this.tasks.set(id, newTask);
    return newTask;
  }
  
  async updateTask(id: number, taskData: Partial<Task>): Promise<Task | undefined> {
    const task = this.tasks.get(id);
    if (!task) return undefined;
    
    const updatedTask = { ...task, ...taskData };
    this.tasks.set(id, updatedTask);
    return updatedTask;
  }
  
  async deleteTask(id: number): Promise<boolean> {
    return this.tasks.delete(id);
  }

  // Event methods
  async getEvents(userId: number): Promise<Event[]> {
    return Array.from(this.events.values()).filter(event => event.user_id === userId);
  }
  
  async getEvent(id: number): Promise<Event | undefined> {
    return this.events.get(id);
  }
  
  async createEvent(event: InsertEvent): Promise<Event> {
    const id = this.eventCurrentId++;
    const newEvent: Event = { 
      ...event, 
      id,
      location: event.location || null,
      auto_scheduled: event.auto_scheduled || false
    };
    this.events.set(id, newEvent);
    return newEvent;
  }
  
  async updateEvent(id: number, eventData: Partial<Event>): Promise<Event | undefined> {
    const event = this.events.get(id);
    if (!event) return undefined;
    
    const updatedEvent = { ...event, ...eventData };
    this.events.set(id, updatedEvent);
    return updatedEvent;
  }
  
  async deleteEvent(id: number): Promise<boolean> {
    return this.events.delete(id);
  }

  // Errand methods
  async getErrands(userId: number): Promise<Errand[]> {
    return Array.from(this.errands.values()).filter(errand => errand.user_id === userId);
  }
  
  async getErrand(id: number): Promise<Errand | undefined> {
    return this.errands.get(id);
  }
  
  async createErrand(errand: InsertErrand): Promise<Errand> {
    const id = this.errandCurrentId++;
    const newErrand: Errand = { 
      ...errand, 
      id,
      due_date: errand.due_date || null,
      amount: errand.amount || null,
      autopay: errand.autopay || false
    };
    this.errands.set(id, newErrand);
    return newErrand;
  }
  
  async updateErrand(id: number, errandData: Partial<Errand>): Promise<Errand | undefined> {
    const errand = this.errands.get(id);
    if (!errand) return undefined;
    
    const updatedErrand = { ...errand, ...errandData };
    this.errands.set(id, updatedErrand);
    return updatedErrand;
  }
  
  async deleteErrand(id: number): Promise<boolean> {
    return this.errands.delete(id);
  }

  // Bill methods
  async getBills(userId: number): Promise<Bill[]> {
    return Array.from(this.bills.values()).filter(bill => bill.user_id === userId);
  }
  
  async getBill(id: number): Promise<Bill | undefined> {
    return this.bills.get(id);
  }
  
  async createBill(bill: InsertBill): Promise<Bill> {
    const id = this.billCurrentId++;
    const newBill: Bill = { 
      ...bill, 
      id,
      due_date: bill.due_date || null,
      amount: bill.amount || null,
      autopay: bill.autopay || false, 
      category: bill.category || null,
      recurring: bill.recurring || false,
      recurring_interval: bill.recurring_interval || null,
      reminder_days: bill.reminder_days || null,
      notes: bill.notes || null,
      created_at: new Date(),
      paid_at: null,
      last_reminded_at: null
    };
    this.bills.set(id, newBill);
    return newBill;
  }
  
  async updateBill(id: number, billData: Partial<Bill>): Promise<Bill | undefined> {
    const bill = this.bills.get(id);
    if (!bill) return undefined;
    
    const updatedBill = { ...bill, ...billData };
    this.bills.set(id, updatedBill);
    return updatedBill;
  }
  
  async deleteBill(id: number): Promise<boolean> {
    return this.bills.delete(id);
  }
  
  async getAllUpcomingBills(): Promise<Bill[]> {
    // Return all upcoming bills across all users
    return Array.from(this.bills.values()).filter(bill => bill.status === 'upcoming');
  }
  
  async updateBillReminderTimestamp(id: number): Promise<Bill | undefined> {
    const bill = this.bills.get(id);
    if (!bill) return undefined;
    
    const updatedBill = { 
      ...bill, 
      last_reminded_at: new Date() 
    };
    this.bills.set(id, updatedBill);
    return updatedBill;
  }

  // Reward methods
  async getRewards(userId: number): Promise<Reward[]> {
    return Array.from(this.rewards.values()).filter(reward => reward.user_id === userId);
  }
  
  async getReward(id: number): Promise<Reward | undefined> {
    return this.rewards.get(id);
  }
  
  async createReward(reward: InsertReward): Promise<Reward> {
    const id = this.rewardCurrentId++;
    const newReward: Reward = { ...reward, id };
    this.rewards.set(id, newReward);
    return newReward;
  }

  // Invite methods
  async getInvites(userId: number): Promise<Invite[]> {
    return Array.from(this.invites.values()).filter(invite => invite.inviter_id === userId);
  }
  
  async createInvite(invite: InsertInvite): Promise<Invite> {
    const id = this.inviteCurrentId++;
    const newInvite: Invite = { ...invite, id };
    this.invites.set(id, newInvite);
    return newInvite;
  }
  
  async updateInvite(id: number, inviteData: Partial<Invite>): Promise<Invite | undefined> {
    const invite = this.invites.get(id);
    if (!invite) return undefined;
    
    const updatedInvite = { ...invite, ...inviteData };
    this.invites.set(id, updatedInvite);
    return updatedInvite;
  }
  
  async createUsageEvent(event: InsertUsageEvent): Promise<UsageEvent> {
    const id = this.usageEventCurrentId++;
    const newEvent: UsageEvent = { 
      ...event, 
      id,
      timestamp: event.timestamp || new Date(),
      metadata: event.metadata || {},
      estimated_minutes_saved: event.estimated_minutes_saved || 0,
      estimated_money_saved: event.estimated_money_saved || 0
    };
    this.usageEvents.set(id, newEvent);
    return newEvent;
  }
  
  async getUserROI(userId: number, days: number = 30): Promise<{ hoursSaved: number, moneySaved: number }> {
    const thirtyDaysAgo = new Date();
    thirtyDaysAgo.setDate(thirtyDaysAgo.getDate() - days);
    
    // Filter usage events for this user in the specified time period
    const userEvents = Array.from(this.usageEvents.values()).filter(event => 
      event.user_id === userId && 
      new Date(event.timestamp) >= thirtyDaysAgo
    );
    
    // Sum up time and money saved
    const hoursSaved = userEvents.reduce((total, event) => total + (event.estimated_minutes_saved || 0) / 60, 0);
    const moneySaved = userEvents.reduce((total, event) => total + (event.estimated_money_saved || 0), 0);
    
    return {
      hoursSaved: parseFloat(hoursSaved.toFixed(2)),
      moneySaved: parseFloat(moneySaved.toFixed(2))
    };
  }
  
  async getUserActionCount(userId: number, days: number = 30): Promise<number> {
    const thirtyDaysAgo = new Date();
    thirtyDaysAgo.setDate(thirtyDaysAgo.getDate() - days);
    
    // Count total actions (tasks completed, bills paid, events attended, etc.)
    const userEvents = Array.from(this.usageEvents.values()).filter(event => 
      event.user_id === userId && 
      new Date(event.timestamp) >= thirtyDaysAgo
    );
    
    return userEvents.length;
  }

  /**
   * Check and increment user quota with protection against race conditions
   */
  async checkAndIncrementQuota(userId: number, limit: number): Promise<{ 
    actionCount: number;
    quotaExceeded: boolean;
  }> {
    const thirtyDaysAgo = new Date();
    thirtyDaysAgo.setDate(thirtyDaysAgo.getDate() - 30);
    
    // Count current actions
    const userEvents = Array.from(this.usageEvents.values()).filter(event => 
      event.user_id === userId && 
      new Date(event.timestamp) >= thirtyDaysAgo
    );
    
    const currentCount = userEvents.length;
    const quotaExceeded = currentCount >= limit;
    
    // Only increment if not exceeded
    if (!quotaExceeded) {
      await this.createUsageEvent({
        user_id: userId,
        action: 'api_request',
        timestamp: new Date(),
        estimated_minutes_saved: 0,
        estimated_money_saved: 0,
        metadata: {}
      } as InsertUsageEvent);
    }
    
    return {
      actionCount: quotaExceeded ? currentCount : currentCount + 1,
      quotaExceeded
    };
  }

  /**
   * Create a payment record
   */
  async createPayment(payment: any): Promise<any> {
    // Since this is MemStorage and we don't have a payments map,
    // we'll just return the payment data as is
    return payment;
  }
  
  // Calendar integration methods
  async updateGoogleCalendarToken(userId: number, refreshToken: string): Promise<User | undefined> {
    const user = this.users.get(userId);
    if (!user) return undefined;
    
    const updatedUser = { 
      ...user, 
      google_calendar_connected: true, 
      google_refresh_token: refreshToken 
    };
    this.users.set(userId, updatedUser);
    return updatedUser;
  }
  
  async updateOutlookCalendarToken(userId: number, refreshToken: string): Promise<User | undefined> {
    const user = this.users.get(userId);
    if (!user) return undefined;
    
    const updatedUser = { 
      ...user, 
      outlook_calendar_connected: true, 
      outlook_refresh_token: refreshToken 
    };
    this.users.set(userId, updatedUser);
    return updatedUser;
  }
  
  async disconnectGoogleCalendar(userId: number): Promise<User | undefined> {
    const user = this.users.get(userId);
    if (!user) return undefined;
    
    const updatedUser = { 
      ...user, 
      google_calendar_connected: false, 
      google_refresh_token: null 
    };
    this.users.set(userId, updatedUser);
    return updatedUser;
  }
  
  async disconnectOutlookCalendar(userId: number): Promise<User | undefined> {
    const user = this.users.get(userId);
    if (!user) return undefined;
    
    const updatedUser = { 
      ...user, 
      outlook_calendar_connected: false, 
      outlook_refresh_token: null 
    };
    this.users.set(userId, updatedUser);
    return updatedUser;
  }
  
  async getExternalCalendarEvents(userId: number, start: Date, end: Date): Promise<any[]> {
    // In a real implementation, this would fetch events from Google/Outlook APIs
    // For now, return any stored external events for this user
    return this.externalCalendarEvents.get(userId) || [];
  }
  
  async syncCalendarEvents(userId: number): Promise<number> {
    // In a real implementation, this would synchronize events between
    // external calendars and our local storage
    // For now, return 0 as no events were synced
    return 0;
  }
}

// Use DatabaseStorage for persistent storage with PostgreSQL
export const storage = new DatabaseStorage();
