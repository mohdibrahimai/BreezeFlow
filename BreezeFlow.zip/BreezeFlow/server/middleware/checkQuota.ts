import { Request, Response, NextFunction } from "express";
import { storage } from "../storage";

interface AuthenticatedRequest extends Request {
  userId?: number;
  user?: { id: number };
}

/**
 * A simple checkQuota middleware - creates a middleware that checks quota
 * Usage: app.get('/api/resource', checkQuota('api'), async (req, res) => {...})
 * 
 * @param featureType The feature type to check quota for (for logging)
 * @returns Express middleware function
 */
export function checkQuota(featureType: string = 'action') {
  const limits = {
    free: 75,
    starter: 750,
    pro: Infinity,
    team: Infinity
  };
  
  return async (req: AuthenticatedRequest, res: Response, next: NextFunction) => {
    try {
      const userId = req.userId || (req.user?.id as number);
      if (!userId) {
        return res.status(401).json({ error: "Unauthorized" });
      }

      const user = await storage.getUser(userId);
      if (!user) {
        return res.status(404).json({ error: "User not found" });
      }

      // Get the limit based on user's plan
      const limit = limits[user.plan as keyof typeof limits] || limits.free;

      // Check and increment quota with transaction-based protection
      const { quotaExceeded, actionCount } = await storage.checkAndIncrementQuota(userId, limit);

      if (quotaExceeded) {
        return res.status(429).json({
          error: "Quota exceeded",
          message: `You've reached your ${limit} ${featureType} limit. Please upgrade your plan for higher limits.`,
          plan: user.plan,
          usage: { current: actionCount, limit },
        });
      }

      // Add usage info to request for logging or response
      res.locals.usageInfo = {
        current: actionCount,
        limit,
        remaining: Math.max(0, limit - actionCount),
      };

      next();
    } catch (error) {
      console.error(`Error in quota check for ${featureType}:`, error);
      res.status(500).json({ error: "Internal server error during quota check" });
    }
  };
}

/**
 * Middleware to restrict access to features based on user's plan
 * Allows access only if user is on one of the specified plans
 * 
 * @param allowedPlans List of plan names that have access to the feature
 */
export function requirePlan(allowedPlans: string[]) {
  return async (req: AuthenticatedRequest, res: Response, next: NextFunction) => {
    try {
      const userId = req.userId || (req.user?.id as number);
      if (!userId) {
        return res.status(401).json({ error: "Unauthorized" });
      }

      const user = await storage.getUser(userId);
      if (!user) {
        return res.status(404).json({ error: "User not found" });
      }

      if (!allowedPlans.includes(user.plan)) {
        return res.status(403).json({
          error: "Plan restriction",
          message: `This feature requires ${allowedPlans.join(' or ')} plan. Please upgrade to access.`,
          currentPlan: user.plan,
          requiredPlans: allowedPlans
        });
      }

      next();
    } catch (error) {
      console.error("Error in plan check:", error);
      res.status(500).json({ error: "Internal server error during plan check" });
    }
  };
}