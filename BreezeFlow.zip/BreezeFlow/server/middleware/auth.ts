import { Request, Response, NextFunction } from 'express';
import jwt from 'jsonwebtoken';
import { storage } from '../storage';

// Type for JWT payload
export interface JwtPayload {
  userId: number;
  username: string;
  exp?: number;
  tokenType?: 'access' | 'refresh';
  role?: string;
}

// Declare a custom property on the Express Request interface to store user and role
declare global {
  namespace Express {
    interface Request {
      userId?: number;
      userRole?: string;
    }
  }
}

// JWT Secret - must match the one in auth.ts
const JWT_SECRET = process.env.ACCESS_TOKEN_SECRET || "breeze-flow-access-token-secret-key";

// Middleware to require authentication
export const requireAuth = async (req: Request, res: Response, next: NextFunction) => {
  const token = req.cookies?.accessToken;
  
  if (!token) {
    return res.status(401).json({ message: "Not authenticated" });
  }
  
  try {
    const decoded = jwt.verify(token, JWT_SECRET) as JwtPayload;
    
    // Verify this is an access token
    if (decoded.tokenType !== 'access') {
      return res.status(401).json({ message: "Invalid token type" });
    }
    
    // Set the user ID on the request
    req.userId = decoded.userId;
    
    // Get user's role if needed
    const user = await storage.getUser(decoded.userId);
    if (user) {
      req.userRole = user.role || 'user';
    } else {
      // If user doesn't exist in DB anymore, invalidate token
      return res.status(401).json({ message: "User not found" });
    }
    
    next();
  } catch (err) {
    return res.status(401).json({ message: "Invalid or expired token" });
  }
};

// Middleware to require specific role
export const requireRole = (roles: string[]) => {
  return (req: Request, res: Response, next: NextFunction) => {
    if (!req.userRole) {
      return res.status(401).json({ message: "Not authenticated" });
    }
    
    if (!roles.includes(req.userRole)) {
      return res.status(403).json({ message: "Insufficient permissions" });
    }
    
    next();
  };
};