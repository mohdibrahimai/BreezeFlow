import numpy as np
import pickle
import os
import datetime
import re
from typing import Dict, List, Tuple, Any, Optional, Union
import json
import sys

# Check if nltk is available and install if needed
try:
    import nltk
    from nltk.tokenize import word_tokenize
    from nltk.corpus import stopwords
    
    # Download required NLTK data
    nltk_data_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'nltk_data')
    os.makedirs(nltk_data_path, exist_ok=True)
    nltk.data.path.append(nltk_data_path)
    
    try:
        nltk.data.find('tokenizers/punkt')
    except LookupError:
        nltk.download('punkt', download_dir=nltk_data_path)
    
    try:
        nltk.data.find('corpora/stopwords')
    except LookupError:
        nltk.download('stopwords', download_dir=nltk_data_path)
    
    NLTK_AVAILABLE = True
except ImportError:
    NLTK_AVAILABLE = False
    print("NLTK not available. Text analysis features will be limited.", file=sys.stderr)

def preprocess_text(text):
    """Preprocess text for NLP analysis"""
    if not text or not isinstance(text, str):
        return ""
        
    if NLTK_AVAILABLE:
        # Tokenize and remove stop words
        stop_words = set(stopwords.words('english'))
        tokens = word_tokenize(text.lower())
        tokens = [t for t in tokens if t.isalpha() and t not in stop_words]
        return ' '.join(tokens)
    else:
        # Basic preprocessing without NLTK
        text = text.lower()
        text = re.sub(r'[^\w\s]', '', text)  # Remove punctuation
        text = re.sub(r'\s+', ' ', text).strip()  # Normalize whitespace
        return text

class TextVectorizer:
    """Simple text vectorizer that counts word occurrences"""
    def __init__(self, max_features=100):
        self.max_features = max_features
        self.vocabulary_ = {}
        self.fitted = False
        
    def fit(self, texts):
        """Build vocabulary from a list of texts"""
        word_freq = {}
        
        for text in texts:
            if not text:
                continue
                
            words = text.split()
            for word in words:
                word_freq[word] = word_freq.get(word, 0) + 1
        
        # Keep only the top max_features words
        sorted_words = sorted(word_freq.items(), key=lambda x: x[1], reverse=True)
        self.vocabulary_ = {word: idx for idx, (word, _) in enumerate(sorted_words[:self.max_features])}
        self.fitted = True
        return self
        
    def transform(self, texts):
        """Transform texts to a matrix of token counts"""
        if not self.fitted:
            raise ValueError("Vectorizer needs to be fitted before transform")
            
        result = np.zeros((len(texts), len(self.vocabulary_)))
        
        for i, text in enumerate(texts):
            if not text:
                continue
                
            words = text.split()
            for word in words:
                if word in self.vocabulary_:
                    result[i, self.vocabulary_[word]] += 1
                    
        return result
        
    def fit_transform(self, texts):
        """Fit and transform in one step"""
        self.fit(texts)
        return self.transform(texts)

def extract_features_from_task(task, text_vectorizer=None):
    """
    Extract features from a task for ML model
    
    Parameters:
    task (dict): Task data
    text_vectorizer: Optional pre-fitted CountVectorizer for text features
    
    Returns:
    dict: Dictionary of features
    """
    features = {}
    
    # Calculate days until due
    try:
        if task.get('due_date'):
            due_date = datetime.datetime.fromisoformat(task['due_date'].replace('Z', '+00:00'))
            now = datetime.datetime.now()
            days_until_due = (due_date - now).total_seconds() / 86400  # Convert seconds to days
            features['days_until_due'] = max(-30, min(days_until_due, 30))  # Cap between -30 and 30 days
        else:
            features['days_until_due'] = 7  # Default to one week if no due date
    except (ValueError, TypeError):
        features['days_until_due'] = 7  # Default if date can't be parsed
    
    # Priority encoding
    priority_map = {'low': 0, 'medium': 1, 'high': 2}
    features['priority'] = priority_map.get(task.get('priority'), 1)  # Default to medium
    
    # User streak - more consecutive days of activity may indicate higher engagement
    features['streak_days'] = min(task.get('streak_days', 0), 100)  # Cap at 100 days
    
    # Task age in days (older tasks might be more stale or forgotten)
    try:
        if task.get('created_at'):
            created_at = datetime.datetime.fromisoformat(task['created_at'].replace('Z', '+00:00'))
            now = datetime.datetime.now()
            task_age_days = (now - created_at).total_seconds() / 86400
            features['task_age_days'] = min(task_age_days, 365)  # Cap at 1 year
        else:
            features['task_age_days'] = 0
    except (ValueError, TypeError):
        features['task_age_days'] = 0
    
    # Task complexity indicators
    title = task.get('title', '')
    description = task.get('description', '')
    
    # Extract estimated minutes if available
    features['estimated_minutes'] = task.get('estimated_minutes', 0)
    if features['estimated_minutes'] is None:
        features['estimated_minutes'] = 0
    
    # Compute text length features
    features['title_length'] = len(title) if title else 0
    features['description_length'] = len(description) if description else 0
    
    # Tag count (if tags exist)
    tags = task.get('tags', [])
    if isinstance(tags, str):
        # If tags is a comma-separated string, split it
        tags = [tag.strip() for tag in tags.split(',') if tag.strip()]
    features['tag_count'] = len(tags) if isinstance(tags, list) else 0
    
    # Analyze text content using NLP (when available)
    combined_text = f"{title} {description}".strip()
    
    if text_vectorizer and combined_text:
        # Preprocess the text
        processed_text = preprocess_text(combined_text)
        
        # Vectorize the text
        if text_vectorizer.fitted:
            text_features = text_vectorizer.transform([processed_text])
            
            # Add text features with prefix 'text_'
            for i in range(text_features.shape[1]):
                features[f'text_{i}'] = text_features[0, i]
    
    # Additional indicators
    features['has_reminder'] = 1 if task.get('reminder_time') else 0
    
    # Return the feature dictionary and values list
    feature_list = list(features.values())
    
    return features, feature_list

class SimpleScaler:
    """Simple scaler that standardizes features to zero mean and unit variance"""
    def __init__(self):
        self.mean_ = None
        self.scale_ = None
        self.fitted = False
        
    def fit(self, X):
        """Compute the mean and standard deviation of X for scaling"""
        X = np.array(X)
        self.mean_ = np.mean(X, axis=0)
        self.scale_ = np.std(X, axis=0)
        self.scale_[self.scale_ == 0] = 1.0  # Avoid division by zero
        self.fitted = True
        return self
        
    def transform(self, X):
        """Scale features according to learned parameters"""
        if not self.fitted:
            raise ValueError("Scaler needs to be fitted before transform")
            
        X = np.array(X)
        return (X - self.mean_) / self.scale_
        
    def fit_transform(self, X):
        """Fit and transform in one step"""
        self.fit(X)
        return self.transform(X)

def random_forest_predict(X, trees):
    """Predict using a random forest model"""
    predictions = np.zeros(len(X))
    
    for tree in trees:
        node = 0
        while tree[node]['type'] != 'leaf':
            feature = tree[node]['feature']
            threshold = tree[node]['threshold']
            
            if X[feature] <= threshold:
                node = tree[node]['left']
            else:
                node = tree[node]['right']
        
        predictions += tree[node]['value']
    
    return predictions / len(trees)

def gradient_boosting_predict(X, trees, learning_rate=0.1, initial_value=0.5):
    """Predict using a gradient boosting model"""
    prediction = initial_value
    
    for tree in trees:
        node = 0
        while tree[node]['type'] != 'leaf':
            feature = tree[node]['feature']
            threshold = tree[node]['threshold']
            
            if X[feature] <= threshold:
                node = tree[node]['left']
            else:
                node = tree[node]['right']
        
        prediction += learning_rate * tree[node]['value']
    
    return prediction

def ensemble_predict(X, models):
    """Predict using an ensemble of models"""
    predictions = []
    
    for model in models:
        model_type = model['type']
        
        if model_type == 'random_forest':
            pred = random_forest_predict(X, model['trees'])
            predictions.append(pred)
        elif model_type == 'gradient_boosting':
            pred = gradient_boosting_predict(X, model['trees'], model['learning_rate'], model['initial_value'])
            predictions.append(pred)
    
    # Weighted average of predictions
    weights = [model['weight'] for model in models]
    return np.average(predictions, weights=weights)

def generate_synthetic_training_data(num_examples=30):
    """Generate synthetic training examples for demonstration purposes"""
    np.random.seed(42)  # For reproducibility
    
    # Generate time span for task creation dates
    now = datetime.datetime.now()
    
    data = []
    
    for i in range(num_examples):
        # Create a synthetic task
        task = {}
        
        # Randomly determine priority
        priority_options = ['low', 'medium', 'high']
        priority_idx = np.random.choice([0, 1, 2], p=[0.2, 0.5, 0.3])
        task['priority'] = priority_options[priority_idx]
        
        # Random task age (0-60 days)
        task_age = np.random.randint(0, 60)
        created_date = now - datetime.timedelta(days=task_age)
        task['created_at'] = created_date.isoformat()
        
        # Random days until due (-14 to 30 days)
        days_until_due = np.random.randint(-14, 31)
        due_date = now + datetime.timedelta(days=days_until_due)
        task['due_date'] = due_date.isoformat()
        
        # Streak days (0-30)
        task['streak_days'] = np.random.randint(0, 31)
        
        # Estimated minutes (varies by priority)
        if task['priority'] == 'low':
            task['estimated_minutes'] = np.random.randint(5, 30)
        elif task['priority'] == 'medium':
            task['estimated_minutes'] = np.random.randint(15, 60)
        else:  # high
            task['estimated_minutes'] = np.random.randint(30, 120)
            
        # Title and description based on template
        templates = [
            {"title": "Review document", "desc": "Go through the document and provide feedback"},
            {"title": "Send email update", "desc": "Update team on project progress"},
            {"title": "Prepare presentation", "desc": "Create slides for the upcoming meeting"},
            {"title": "Fix bug in code", "desc": "Debug and fix the reported issue in the application"},
            {"title": "Schedule meeting", "desc": "Set up time for team discussion"},
            {"title": "Write documentation", "desc": "Document the new feature implementation"},
            {"title": "Research solution", "desc": "Look into possible solutions for the problem"},
            {"title": "Call client", "desc": "Follow up with client about their request"},
            {"title": "Update website", "desc": "Make the requested changes to the website"},
            {"title": "Submit report", "desc": "Complete and submit the monthly report"}
        ]
        
        template = templates[np.random.randint(0, len(templates))]
        task['title'] = template["title"]
        task['description'] = template["desc"]
        
        # Randomly assign tags
        all_tags = ["work", "personal", "urgent", "family", "finance", "health", "home", "project"]
        num_tags = np.random.randint(0, 3)
        selected_tags = np.random.choice(all_tags, size=num_tags, replace=False)
        task['tags'] = ",".join(selected_tags)
        
        # Random reminder (30% chance)
        if np.random.random() < 0.3:
            reminder_date = due_date - datetime.timedelta(days=1)
            task['reminder_time'] = reminder_date.isoformat()
        else:
            task['reminder_time'] = None
            
        # Generate a priority score that correlates with the features
        # Higher score = more likely to be completed on time
        
        # Base score influenced by priority
        if task['priority'] == 'high':
            base_score = np.random.normal(75, 10)
        elif task['priority'] == 'medium':
            base_score = np.random.normal(60, 15)
        else:  # low
            base_score = np.random.normal(40, 15)
            
        # Adjust based on days until due
        if days_until_due < 0:  # Overdue
            base_score -= abs(days_until_due) * 3
        elif days_until_due < 2:  # Due very soon
            base_score -= 5
        elif 2 <= days_until_due <= 7:  # Due in reasonable time
            base_score += 10
        else:  # Due in more than a week
            base_score -= (days_until_due - 7) * 2
            
        # Adjust based on estimated time
        if task['estimated_minutes'] > 90:
            base_score -= 15
        elif task['estimated_minutes'] > 45:
            base_score -= 5
            
        # Adjust based on streak days (active users tend to complete more)
        base_score += task['streak_days'] * 0.5
        
        # Reminder bonus
        if task['reminder_time']:
            base_score += 8
            
        # Add some noise
        final_score = max(5, min(95, base_score + np.random.normal(0, 5)))
        task['priority_score'] = int(round(final_score))
        
        data.append(task)
        
    return data

def train_priority_model(task_data):
    """
    Train an advanced ensemble model for task priority prediction using multiple algorithms
    
    Parameters:
    task_data (list): List of task dictionaries with relevant features
    
    Returns:
    dict: Dictionary containing model components (ensemble, scaler, text_vectorizer)
    """
    # If we don't have enough real data, supplement with synthetic data
    if len(task_data) < 10:
        synthetic_data = generate_synthetic_training_data(30)
        task_data.extend(synthetic_data)
        print(f"Added {len(synthetic_data)} synthetic training examples", file=sys.stderr)
    
    # Preprocess text from titles and descriptions
    texts = []
    for task in task_data:
        title = task.get('title', '')
        description = task.get('description', '')
        combined_text = f"{title} {description}".strip()
        texts.append(preprocess_text(combined_text) if combined_text else "")
    
    # Create and fit text vectorizer
    text_vectorizer = TextVectorizer(max_features=20)
    text_vectorizer.fit(texts)
    
    # Extract features from tasks
    feature_sets = []
    feature_lists = []
    target_values = []
    
    for task in task_data:
        # Skip tasks without priority scores
        if 'priority_score' not in task or task['priority_score'] is None:
            continue
            
        features, feature_list = extract_features_from_task(task, text_vectorizer)
        feature_sets.append(features)
        feature_lists.append(feature_list)
        target_values.append(task['priority_score'])
    
    X = np.array(feature_lists)
    y = np.array(target_values)
    
    # Create and fit scaler
    scaler = SimpleScaler()
    X_scaled = scaler.fit_transform(X)
    
    # Create a simple random forest model
    rf_trees = []
    for _ in range(5):  # Create 5 trees
        tree = create_simple_decision_tree(X_scaled, y, max_depth=3)
        rf_trees.append(tree)
    
    # Create a simple gradient boosting model
    gb_trees = []
    residuals = y - np.mean(y)
    initial_value = np.mean(y)
    
    for _ in range(3):  # Create 3 trees
        tree = create_simple_decision_tree(X_scaled, residuals, max_depth=2)
        gb_trees.append(tree)
        
        # Update residuals
        predictions = np.zeros_like(residuals)
        for i, x in enumerate(X_scaled):
            node = 0
            while tree[node]['type'] != 'leaf':
                feature = tree[node]['feature']
                threshold = tree[node]['threshold']
                
                if x[feature] <= threshold:
                    node = tree[node]['left']
                else:
                    node = tree[node]['right']
            
            predictions[i] = tree[node]['value']
        
        learning_rate = 0.1
        residuals -= learning_rate * predictions
    
    # Create ensemble model
    ensemble = [
        {
            'type': 'random_forest',
            'trees': rf_trees,
            'weight': 0.6
        },
        {
            'type': 'gradient_boosting',
            'trees': gb_trees,
            'learning_rate': 0.1,
            'initial_value': float(initial_value),
            'weight': 0.4
        }
    ]
    
    # Store feature names for interpretability
    feature_names = []
    for task_features in feature_sets:
        for name in task_features.keys():
            if name not in feature_names:
                feature_names.append(name)
    
    # Return all model components
    model_components = {
        'ensemble': ensemble,
        'scaler': scaler,
        'text_vectorizer': text_vectorizer,
        'feature_names': feature_names
    }
    
    return model_components

def create_simple_decision_tree(X, y, max_depth=3, min_samples=2):
    """Create a simple decision tree for demonstration"""
    if len(X) == 0:
        return [{'type': 'leaf', 'value': 0}]
    
    def mse(y_vals):
        if len(y_vals) == 0:
            return 0
        return np.mean((y_vals - np.mean(y_vals)) ** 2)
    
    def find_best_split(X, y):
        best_feature = 0
        best_threshold = 0
        best_score = float('inf')
        
        n_features = X.shape[1]
        
        for feature in range(n_features):
            thresholds = np.unique(X[:, feature])
            
            for threshold in thresholds:
                left_mask = X[:, feature] <= threshold
                right_mask = ~left_mask
                
                if np.sum(left_mask) < min_samples or np.sum(right_mask) < min_samples:
                    continue
                
                left_y = y[left_mask]
                right_y = y[right_mask]
                
                score = (len(left_y) / len(y)) * mse(left_y) + (len(right_y) / len(y)) * mse(right_y)
                
                if score < best_score:
                    best_score = score
                    best_feature = feature
                    best_threshold = threshold
        
        return best_feature, best_threshold
    
    def build_tree(X, y, depth=0):
        if depth >= max_depth or len(X) < min_samples * 2 or len(np.unique(y)) == 1:
            return {'type': 'leaf', 'value': float(np.mean(y))}
        
        feature, threshold = find_best_split(X, y)
        
        left_mask = X[:, feature] <= threshold
        right_mask = ~left_mask
        
        if np.sum(left_mask) < min_samples or np.sum(right_mask) < min_samples:
            return {'type': 'leaf', 'value': float(np.mean(y))}
        
        tree = {
            'type': 'split',
            'feature': feature,
            'threshold': threshold,
            'left': None,
            'right': None
        }
        
        tree_nodes = [tree]
        left_node = build_tree(X[left_mask], y[left_mask], depth + 1)
        right_node = build_tree(X[right_mask], y[right_mask], depth + 1)
        
        tree['left'] = len(tree_nodes)
        tree_nodes.append(left_node)
        
        tree['right'] = len(tree_nodes)
        tree_nodes.append(right_node)
        
        return tree_nodes
    
    return build_tree(X, y)

def calculate_priority_score(model_components, task):
    """
    Calculate priority score for a given task using the ensemble model
    
    Parameters:
    model_components (dict): Dictionary containing model, scaler, and text_vectorizer
    task (dict): Task data with relevant features
    
    Returns:
    score (float): Priority score between 0-100, higher means more likely to be completed on time
    insights (dict): Additional insights and explanations
    """
    ensemble = model_components['ensemble']
    scaler = model_components['scaler']
    text_vectorizer = model_components['text_vectorizer']
    
    # Extract features from the task
    features, feature_list = extract_features_from_task(task, text_vectorizer)
    
    # Scale features
    X_scaled = scaler.transform([feature_list])[0]
    
    # Make prediction with ensemble
    raw_prediction = ensemble_predict(X_scaled, ensemble)
    
    # Scale prediction to 0-100 range
    score = max(0, min(100, raw_prediction))
    
    # Generate insights based on the features and prediction
    insights = generate_insights(features, score)
    
    return int(round(score)), insights

def generate_insights(features, score):
    """Generate insights based on task features and prediction score"""
    insights = {
        "message": "",
        "risk_factors": [],
        "suggestions": [],
        "estimated_completion_minutes": features.get('estimated_minutes', 30)
    }
    
    # Determine overall message based on score
    if score >= 80:
        insights["message"] = "This task has high completion potential"
    elif score >= 60:
        insights["message"] = "This task has good completion potential"
    elif score >= 40:
        insights["message"] = "This task has moderate completion potential"
    elif score >= 20:
        insights["message"] = "This task has low completion potential"
    else:
        insights["message"] = "This task has very low completion potential"
    
    # Analyze days until due
    days_until_due = features.get('days_until_due', 0)
    if days_until_due < 0:
        insights["risk_factors"].append("Task is overdue")
        insights["suggestions"].append("Reprioritize or reschedule this task immediately")
    elif days_until_due < 1:
        insights["risk_factors"].append("Task is due very soon")
        insights["suggestions"].append("Consider addressing this task immediately")
    elif days_until_due > 14:
        insights["risk_factors"].append("Task is due far in the future")
        insights["suggestions"].append("Break down this task into smaller steps with closer due dates")
    
    # Analyze estimated minutes
    estimated_minutes = features.get('estimated_minutes', 0)
    if estimated_minutes > 120:
        insights["risk_factors"].append("Task requires significant time investment")
        insights["suggestions"].append("Break this task down into smaller sub-tasks")
    elif estimated_minutes > 60:
        insights["suggestions"].append("Consider scheduling a dedicated time block for this task")
    elif estimated_minutes == 0:
        insights["risk_factors"].append("Task has no time estimate")
        insights["suggestions"].append("Add a time estimate to improve planning")
    
    # Analyze task age
    task_age_days = features.get('task_age_days', 0)
    if task_age_days > 14:
        insights["risk_factors"].append("Task has been pending for a while")
        insights["suggestions"].append("Consider whether this task is still relevant")
    
    # Analyze text content
    if features.get('title_length', 0) < 5:
        insights["risk_factors"].append("Task title is too short/vague")
        insights["suggestions"].append("Give the task a clearer, more specific title")
    
    if features.get('description_length', 0) < 10:
        insights["risk_factors"].append("Task description is minimal")
        insights["suggestions"].append("Add more details to clarify what needs to be done")
    
    # Analyze tags
    if features.get('tag_count', 0) == 0:
        insights["risk_factors"].append("Task has no tags")
        insights["suggestions"].append("Add relevant tags to categorize and prioritize better")
    
    # Analyze reminders
    if features.get('has_reminder', 0) == 0:
        insights["suggestions"].append("Set a reminder for this task to avoid missing it")
    
    # If there are no risk factors but the score is low, add a generic one
    if len(insights["risk_factors"]) == 0 and score < 50:
        insights["risk_factors"].append("Task has general completion risk factors")
    
    # If there are no suggestions, add generic ones based on priority
    if len(insights["suggestions"]) == 0:
        priority = features.get('priority', 1)
        if priority == 2:  # high
            insights["suggestions"].append("Focus on completing this high-priority task soon")
        elif priority == 0:  # low
            insights["suggestions"].append("Consider batching this with other low-priority tasks")
    
    return insights

def save_model(model_components, model_path='priority_model.pkl'):
    """
    Save all model components to disk
    
    Parameters:
    model_components (dict): Dictionary containing model components
    model_path (str): Path to save the model
    """
    with open(model_path, 'wb') as f:
        pickle.dump(model_components, f)

def load_model(model_path='priority_model.pkl'):
    """
    Load model components from disk
    
    Parameters:
    model_path (str): Path to the saved model
    
    Returns:
    dict: Dictionary containing model components
    """
    with open(model_path, 'rb') as f:
        model_components = pickle.load(f)
    return model_components

# For testing/development
if __name__ == "__main__":
    # Generate synthetic data for testing
    test_data = generate_synthetic_training_data(20)
    
    # Train model
    model_components = train_priority_model(test_data)
    
    # Test prediction on a new task
    test_task = {
        'title': 'Complete project report',
        'description': 'Finalize the quarterly project report with all metrics and analysis',
        'priority': 'high',
        'due_date': (datetime.datetime.now() + datetime.timedelta(days=2)).isoformat(),
        'created_at': (datetime.datetime.now() - datetime.timedelta(days=5)).isoformat(),
        'streak_days': 10,
        'estimated_minutes': 90,
        'tags': 'work,report,quarterly',
        'reminder_time': (datetime.datetime.now() + datetime.timedelta(days=1)).isoformat()
    }
    
    score, insights = calculate_priority_score(model_components, test_task)
    
    print(f"Priority Score: {score}")
    print(f"Message: {insights['message']}")
    print("Risk Factors:")
    for factor in insights['risk_factors']:
        print(f"- {factor}")
    print("Suggestions:")
    for suggestion in insights['suggestions']:
        print(f"- {suggestion}")
    print(f"Estimated Time: {insights['estimated_completion_minutes']} minutes")
    
    # Save model for future use
    save_model(model_components)