import sys
import json
import os
import traceback
import datetime
from typing import Dict, List, Any
from priority_model import train_priority_model, save_model, generate_synthetic_training_data

def main():
    # Check if input file is provided
    if len(sys.argv) < 2:
        print(json.dumps({"error": "No input file provided"}))
        sys.exit(1)
    
    # Load the task data
    input_file = sys.argv[1]
    try:
        with open(input_file, 'r') as f:
            task_data = json.load(f)
    except Exception as e:
        print(json.dumps({"error": f"Failed to load task data: {str(e)}"}))
        sys.exit(1)
    
    # Validate training data
    if not isinstance(task_data, list):
        print(json.dumps({"error": "Training data must be a list of tasks"}))
        sys.exit(1)
    
    # Add synthetic data if needed
    if len(task_data) < 20:
        synthetic_data_count = 30  # Generate 30 synthetic examples
        try:
            synthetic_data = generate_synthetic_training_data(synthetic_data_count)
            task_data.extend(synthetic_data)
            print(f"Added {synthetic_data_count} synthetic tasks to supplement training data", file=sys.stderr)
        except Exception as e:
            print(f"Warning: Failed to generate synthetic data: {str(e)}", file=sys.stderr)
    
    # Train the model
    try:
        print(f"Training model with {len(task_data)} tasks...", file=sys.stderr)
        model_components = train_priority_model(task_data)
        
        # Save the model
        script_dir = os.path.dirname(os.path.abspath(__file__))
        model_path = os.path.join(script_dir, 'priority_model.pkl')
        
        save_model(model_components, model_path)
        print(f"Model successfully trained and saved to {model_path}", file=sys.stderr)
        
        # Return success response
        response = {
            "success": True,
            "message": "Model successfully trained",
            "model_path": model_path,
            "stats": {
                "training_examples": len(task_data),
                "timestamp": datetime.datetime.now().isoformat()
            }
        }
        
        print(json.dumps(response))
    except Exception as e:
        print(json.dumps({"error": f"Failed to train model: {str(e)}"}))
        traceback.print_exc(file=sys.stderr)
        sys.exit(1)

if __name__ == "__main__":
    try:
        main()
    except Exception as e:
        print(json.dumps({"error": f"Unexpected error: {str(e)}"}))
        traceback.print_exc(file=sys.stderr)
        sys.exit(1)