import sys
import json
import os
import traceback
import datetime
import numpy as np
from priority_model import load_model, calculate_priority_score

def sanitize_task(task):
    """
    Sanitize task data to prevent common errors when calculating priority scores.
    """
    # Make a copy to avoid modifying the original
    clean_task = dict(task)
    
    # Ensure created_at is present and valid
    if 'created_at' not in clean_task or not clean_task['created_at']:
        clean_task['created_at'] = datetime.datetime.now().isoformat()
    
    # If due_date is missing, set it to 7 days from created_at
    if 'due_date' not in clean_task or not clean_task['due_date']:
        if isinstance(clean_task['created_at'], str):
            try:
                created_date = datetime.datetime.fromisoformat(clean_task['created_at'].replace('Z', '+00:00'))
                due_date = created_date + datetime.timedelta(days=7)
                clean_task['due_date'] = due_date.isoformat()
            except:
                # If we can't parse the created_at date, use current date + 7 days
                due_date = datetime.datetime.now() + datetime.timedelta(days=7)
                clean_task['due_date'] = due_date.isoformat()
        else:
            # If created_at is not a string, use current date + 7 days
            due_date = datetime.datetime.now() + datetime.timedelta(days=7)
            clean_task['due_date'] = due_date.isoformat()
    
    # Ensure streak_days is present
    if 'streak_days' not in clean_task or clean_task['streak_days'] is None:
        clean_task['streak_days'] = 0
    
    # Ensure priority is valid
    if 'priority' not in clean_task or clean_task['priority'] not in ['low', 'medium', 'high']:
        clean_task['priority'] = 'medium'
    
    # Ensure title is a string
    if 'title' not in clean_task or not isinstance(clean_task['title'], str):
        clean_task['title'] = 'Untitled Task'
    
    return clean_task

def main():
    # Check if input file is provided
    if len(sys.argv) < 2:
        print(json.dumps({"error": "No input file provided"}))
        sys.exit(1)
    
    # Load the task data
    input_file = sys.argv[1]
    try:
        with open(input_file, 'r') as f:
            task_data = json.load(f)
    except Exception as e:
        print(json.dumps({"error": f"Failed to load task data: {str(e)}"}))
        sys.exit(1)
    
    # Load the model components
    try:
        script_dir = os.path.dirname(os.path.abspath(__file__))
        model_path = os.path.join(script_dir, 'priority_model.pkl')
        
        # Ensure the model exists
        if not os.path.exists(model_path):
            print(json.dumps({"error": "ML model not found. Model needs to be trained first."}))
            sys.exit(1)
        
        model_components = load_model(model_path)
    except Exception as e:
        print(json.dumps({"error": f"Failed to load model: {str(e)}"}))
        sys.exit(1)
    
    # Calculate the priority score
    try:
        # Sanitize the task to prevent errors
        clean_task = sanitize_task(task_data)
        
        # Calculate score and get insights
        score, insights = calculate_priority_score(model_components, clean_task)
        
        # Prepare response with score and insights
        response = {
            "score": score,
            "message": insights["message"],
            "risk_factors": insights["risk_factors"],
            "suggestions": insights["suggestions"],
            "estimated_minutes": insights["estimated_completion_minutes"]
        }
        
        print(json.dumps(response))
    except Exception as e:
        print(json.dumps({"error": f"Failed to calculate score: {str(e)}"}))
        traceback.print_exc(file=sys.stderr)
        sys.exit(1)

if __name__ == "__main__":
    try:
        main()
    except Exception as e:
        print(json.dumps({"error": f"Unexpected error: {str(e)}"}))
        traceback.print_exc(file=sys.stderr)
        sys.exit(1)