import sys
import json
import os
import traceback
import datetime
from priority_model import load_model, calculate_priority_score

def sanitize_task(task):
    """
    Sanitize task data to prevent common errors when calculating priority scores.
    """
    # Make a copy to avoid modifying the original
    clean_task = dict(task)
    
    # Ensure created_at is present and valid
    if 'created_at' not in clean_task or not clean_task['created_at']:
        clean_task['created_at'] = datetime.datetime.now().isoformat()
    
    # If due_date is missing, set it to 7 days from created_at
    if 'due_date' not in clean_task or not clean_task['due_date']:
        if isinstance(clean_task['created_at'], str):
            try:
                created_date = datetime.datetime.fromisoformat(clean_task['created_at'].replace('Z', '+00:00'))
                due_date = created_date + datetime.timedelta(days=7)
                clean_task['due_date'] = due_date.isoformat()
            except:
                # If we can't parse the created_at date, use current date + 7 days
                due_date = datetime.datetime.now() + datetime.timedelta(days=7)
                clean_task['due_date'] = due_date.isoformat()
        else:
            # If created_at is not a string, use current date + 7 days
            due_date = datetime.datetime.now() + datetime.timedelta(days=7)
            clean_task['due_date'] = due_date.isoformat()
    
    # Ensure streak_days is present
    if 'streak_days' not in clean_task or clean_task['streak_days'] is None:
        clean_task['streak_days'] = 0
    
    # Ensure priority is valid
    if 'priority' not in clean_task or clean_task['priority'] not in ['low', 'medium', 'high']:
        clean_task['priority'] = 'medium'
    
    # Ensure title is a string
    if 'title' not in clean_task or not isinstance(clean_task['title'], str):
        clean_task['title'] = 'Untitled Task'
    
    return clean_task

def get_task_insights(task_data, score, insights):
    """
    Enrich task data with score and insights
    """
    return {
        "id": task_data.get("id"),
        "title": task_data.get("title"),
        "score": score,
        "message": insights["message"],
        "risk_factors": insights["risk_factors"],
        "suggestions": insights["suggestions"],
        "estimated_completion_minutes": insights["estimated_completion_minutes"]
    }

def main():
    # Check if input file is provided
    if len(sys.argv) < 2:
        print(json.dumps({"error": "No input file provided"}))
        sys.exit(1)
    
    # Load the tasks data
    input_file = sys.argv[1]
    try:
        with open(input_file, 'r') as f:
            tasks_data = json.load(f)
    except Exception as e:
        print(json.dumps({"error": f"Failed to load tasks data: {str(e)}"}))
        sys.exit(1)
    
    # Ensure tasks_data is a list
    if not isinstance(tasks_data, list):
        print(json.dumps({"error": "Input data must be a list of tasks"}))
        sys.exit(1)
    
    # Load the model components
    try:
        script_dir = os.path.dirname(os.path.abspath(__file__))
        model_path = os.path.join(script_dir, 'priority_model.pkl')
        
        # Ensure the model exists
        if not os.path.exists(model_path):
            print(json.dumps({"error": "ML model not found. Model needs to be trained first."}))
            sys.exit(1)
        
        model_components = load_model(model_path)
    except Exception as e:
        print(json.dumps({"error": f"Failed to load model: {str(e)}"}))
        sys.exit(1)
    
    # Calculate the priority scores for each task
    try:
        task_scores = []
        
        for task in tasks_data:
            # Skip invalid tasks
            if not isinstance(task, dict):
                continue
                
            # Sanitize the task to prevent errors
            clean_task = sanitize_task(task)
            
            # Calculate score and get insights
            score, insights = calculate_priority_score(model_components, clean_task)
            
            # Add task with score and insights to results
            task_scores.append(get_task_insights(task, score, insights))
        
        # Sort tasks by score (descending)
        task_scores.sort(key=lambda x: x["score"], reverse=True)
        
        # Group tasks into categories
        high_priority = [t for t in task_scores if t["score"] >= 75]
        medium_priority = [t for t in task_scores if 40 <= t["score"] < 75]
        low_priority = [t for t in task_scores if t["score"] < 40]
        
        # Calculate stats
        total_tasks = len(task_scores)
        avg_score = sum(t["score"] for t in task_scores) / total_tasks if total_tasks > 0 else 0
        total_estimated_minutes = sum(t["estimated_completion_minutes"] for t in task_scores)
        
        # Common risk factors and suggestions across tasks
        all_risk_factors = [factor for t in task_scores for factor in t["risk_factors"]]
        all_suggestions = [suggestion for t in task_scores for suggestion in t["suggestions"]]
        
        risk_factor_counts = {}
        for factor in all_risk_factors:
            risk_factor_counts[factor] = risk_factor_counts.get(factor, 0) + 1
            
        suggestion_counts = {}
        for suggestion in all_suggestions:
            suggestion_counts[suggestion] = suggestion_counts.get(suggestion, 0) + 1
        
        # Sort by frequency
        common_risk_factors = sorted(risk_factor_counts.items(), key=lambda x: x[1], reverse=True)
        common_suggestions = sorted(suggestion_counts.items(), key=lambda x: x[1], reverse=True)
        
        # Prepare response with scores and batch insights
        response = {
            "tasks": task_scores,
            "categories": {
                "high_priority": high_priority,
                "medium_priority": medium_priority,
                "low_priority": low_priority
            },
            "stats": {
                "total_tasks": total_tasks,
                "average_score": round(avg_score, 1),
                "total_estimated_minutes": total_estimated_minutes,
                "high_priority_count": len(high_priority),
                "medium_priority_count": len(medium_priority),
                "low_priority_count": len(low_priority)
            },
            "insights": {
                "common_risk_factors": [{"factor": factor, "count": count} 
                                      for factor, count in common_risk_factors[:5]],
                "common_suggestions": [{"suggestion": suggestion, "count": count} 
                                     for suggestion, count in common_suggestions[:5]]
            },
            "time_management": {
                "estimated_hours": round(total_estimated_minutes / 60, 1),
                "recommended_daily_tasks": min(3, len(high_priority)) + min(2, len(medium_priority)),
                "focus_areas": [factor for factor, _ in common_risk_factors[:3]]
            }
        }
        
        print(json.dumps(response))
    except Exception as e:
        print(json.dumps({"error": f"Failed to calculate scores: {str(e)}"}))
        traceback.print_exc(file=sys.stderr)
        sys.exit(1)

if __name__ == "__main__":
    try:
        main()
    except Exception as e:
        print(json.dumps({"error": f"Unexpected error: {str(e)}"}))
        traceback.print_exc(file=sys.stderr)
        sys.exit(1)