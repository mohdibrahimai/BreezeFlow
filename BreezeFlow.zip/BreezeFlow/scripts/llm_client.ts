import { spawn, ChildProcessWithoutNullStreams } from 'child_process';
import * as fs from 'fs';
import * as path from 'path';
import { fileURLToPath } from 'url';

// Get current file path in ESM
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// Define interface for LLM instance
interface LlmInstance {
  process: ChildProcessWithoutNullStreams;
  lastUsed: Date;
}

// Track active instance of the LLM
let activeInstance: LlmInstance | null = null;

// Read config from file
let config: {
  model: string;
  maxTokens: number;
  temperature: number;
  idleTimeoutMinutes: number;
} = {
  model: 'breezemind',
  maxTokens: 512,
  temperature: 0.7,
  idleTimeoutMinutes: 10
};

try {
  const configPath = path.join(__dirname, '..', 'config', 'llm_config.json');
  if (fs.existsSync(configPath)) {
    config = JSON.parse(fs.readFileSync(configPath, 'utf8'));
  }
} catch (error) {
  console.error('Error loading LLM config:', error);
  // Use default config if file cannot be read
}

// Set up automatic unload timer
let unloadTimer: NodeJS.Timeout | null = null;

/**
 * Ensure the LLM is running and available
 * 
 * NOTE: For testing purposes in Replit environment, this is a mock implementation
 * that doesn't actually start Ollama since it's not installed.
 */
export async function ensureLlmRunning() {
  // Clear any existing unload timer
  if (unloadTimer) {
    clearTimeout(unloadTimer);
    unloadTimer = null;
  }
  
  // For testing purposes, we'll just log that we would start the LLM
  console.log('[MOCK] Starting LLM instance...');
  
  // In a real environment, we would start the Ollama process here
  // Since we're in a test environment, we'll just return a mock successful response
  return { 
    process: null as any, 
    lastUsed: new Date() 
  };
}

/**
 * Query the LLM with a given prompt
 * 
 * NOTE: For testing purposes in Replit environment, this is a mock implementation
 * that returns predefined responses instead of using Ollama.
 */
export async function queryLlm(prompt: string, options: { format?: 'text' | 'json', temperature?: number } = {}) {
  // Simulate startup delay
  await new Promise(resolve => setTimeout(resolve, 500));
  
  console.log('[MOCK] Received prompt:', prompt.substring(0, 100) + '...');
  
  const format = options.format || 'text';
  
  // Check if this is a task creation request
  if (prompt.toLowerCase().includes('create task') || 
      prompt.toLowerCase().includes('add task') ||
      prompt.toLowerCase().includes('remind me to')) {
    if (format === 'json') {
      // Return a mock task JSON response
      return JSON.stringify({
        title: "Mock Task from AI",
        priority: "medium",
        dueDate: new Date(Date.now() + 86400000).toISOString().split('T')[0], // Tomorrow
        description: "This is a mock task created by the AI assistant"
      });
    }
  }
  
  // Generate a friendly response based on the prompt content
  if (prompt.toLowerCase().includes('help me manage my tasks')) {
    return "I'd be happy to help you manage your tasks! With BreezeFlow, you can create tasks, set priorities, and organize your schedule. Would you like me to create a task for you, or would you prefer to see your current tasks?";
  } else if (prompt.toLowerCase().includes('hello') || prompt.toLowerCase().includes('hi')) {
    return "Hello! I'm BreezeMind, your productivity assistant. How can I help you today? I can help create tasks, optimize your schedule, or answer questions about productivity.";
  } else if (prompt.toLowerCase().includes('schedule')) {
    return "I can help optimize your schedule by analyzing your tasks and commitments. Would you like me to help prioritize your tasks based on deadlines and importance?";
  } else if (prompt.toLowerCase().includes('productivity tip') || prompt.toLowerCase().includes('advice')) {
    const productivityTips = [
      "Try the Pomodoro Technique: work for 25 minutes, then take a 5-minute break to maintain focus and energy.",
      "Consider time-blocking your calendar to dedicate specific hours to specific types of tasks.",
      "The 'two-minute rule' suggests that if a task takes less than two minutes, do it immediately rather than scheduling it for later.",
      "Start your day by completing your most challenging task first (also known as 'eating the frog').",
      "Review your goals weekly to ensure your daily tasks align with your larger objectives.",
      "Use the 'Eisenhower Box' to categorize tasks by urgency and importance to focus on what truly matters.",
      "Try batching similar tasks together to reduce context switching and improve efficiency.",
      "Set clear boundaries for checking email and messages to prevent continuous interruptions.",
      "For complex projects, break them down into smaller, manageable tasks with specific outcomes.",
      "Remember to schedule breaks and downtime - research shows it actually improves overall productivity."
    ];
    
    // Select a random productivity tip
    const randomTip = productivityTips[Math.floor(Math.random() * productivityTips.length)];
    return `Here's a productivity tip that might help: ${randomTip} Would you like me to help you implement this in your workflow?`;
  } else if (prompt.toLowerCase().includes('recommend task') || prompt.toLowerCase().includes('suggest task')) {
    const recommendedTasks = [
      {
        title: "Review and update your task priorities",
        benefit: "to ensure you're focusing on what matters most",
        estimatedTime: "15 minutes"
      },
      {
        title: "Plan your schedule for tomorrow",
        benefit: "to start your day with clarity and purpose",
        estimatedTime: "10 minutes"
      },
      {
        title: "Take a break and go for a short walk",
        benefit: "to refresh your mind and improve focus",
        estimatedTime: "15 minutes"
      },
      {
        title: "Clear your email inbox",
        benefit: "to reduce mental clutter and ensure you haven't missed anything important",
        estimatedTime: "30 minutes"
      },
      {
        title: "Review your progress on current projects",
        benefit: "to identify any blockers or next steps",
        estimatedTime: "20 minutes"
      }
    ];
    
    // Select a random recommended task
    const recommendation = recommendedTasks[Math.floor(Math.random() * recommendedTasks.length)];
    
    return `I recommend creating a task to "${recommendation.title}" ${recommendation.benefit}. This should take about ${recommendation.estimatedTime}. Would you like me to add this to your tasks?`;
  } else {
    // Default response for any other prompt
    return "I'm here to help with your productivity needs. You can ask me to create tasks, optimize your schedule, recommend tasks, provide productivity tips, or assist with batch task creation. What would you like assistance with today?";
  }
}

/**
 * Function to get a task creation response from the LLM
 * 
 * NOTE: For testing purposes in Replit environment, this is a mock implementation
 * that returns predefined task data instead of using Ollama.
 */
export async function createTaskWithLlm(userRequest: string): Promise<{
  title: string;
  priority: 'low' | 'medium' | 'high';
  dueDate?: string;
  description?: string;
  points?: number;
  tags?: string[];
  reminderTime?: string;
  estimatedTime?: number;
}> {
  console.log('[MOCK] Creating task from request:', userRequest);
  
  // Extract some key information from the user request to make the response more natural
  let title = userRequest;
  let priority: 'low' | 'medium' | 'high' = 'medium';
  let description: string | undefined = undefined;
  let tags: string[] = [];
  let reminderTime: string | undefined = undefined;
  let estimatedTime: number | undefined = undefined;
  
  // Try to extract a task title
  if (userRequest.toLowerCase().includes('create task') || userRequest.toLowerCase().includes('add task')) {
    title = userRequest
      .replace(/^(create|add) (a )?task( to)?/i, '')
      .trim();
  } else if (userRequest.toLowerCase().includes('remind me to')) {
    title = userRequest
      .replace(/^remind me to/i, '')
      .trim();
  }
  
  // Set priority based on keywords
  if (userRequest.toLowerCase().includes('urgent') || 
      userRequest.toLowerCase().includes('important') || 
      userRequest.toLowerCase().includes('critical') ||
      userRequest.toLowerCase().includes('asap')) {
    priority = 'high';
  } else if (userRequest.toLowerCase().includes('sometime') || 
             userRequest.toLowerCase().includes('when you can') ||
             userRequest.toLowerCase().includes('low priority')) {
    priority = 'low';
  }
  
  // Extract due date with more advanced parsing
  let dueDate: string;
  
  // Check for specific date mentions
  if (userRequest.toLowerCase().includes('today')) {
    const today = new Date();
    dueDate = today.toISOString().split('T')[0];
  } else if (userRequest.toLowerCase().includes('tomorrow')) {
    const tomorrow = new Date();
    tomorrow.setDate(tomorrow.getDate() + 1);
    dueDate = tomorrow.toISOString().split('T')[0];
  } else if (userRequest.toLowerCase().includes('next week')) {
    const nextWeek = new Date();
    nextWeek.setDate(nextWeek.getDate() + 7);
    dueDate = nextWeek.toISOString().split('T')[0];
  } else if (userRequest.toLowerCase().includes('this weekend') || userRequest.toLowerCase().includes('weekend')) {
    // Set to next Saturday
    const today = new Date();
    const daysUntilSaturday = (6 - today.getDay() + 7) % 7;
    const saturday = new Date();
    saturday.setDate(today.getDate() + daysUntilSaturday);
    dueDate = saturday.toISOString().split('T')[0];
  } else if (userRequest.match(/by (monday|tuesday|wednesday|thursday|friday|saturday|sunday)/i)) {
    const dayMatch = userRequest.match(/by (monday|tuesday|wednesday|thursday|friday|saturday|sunday)/i);
    const day = dayMatch ? dayMatch[1].toLowerCase() : '';
    const dayMapping: {[key: string]: number} = {
      'monday': 1, 'tuesday': 2, 'wednesday': 3, 'thursday': 4, 'friday': 5, 'saturday': 6, 'sunday': 0
    };
    
    if (day && dayMapping[day] !== undefined) {
      const today = new Date();
      const targetDay = dayMapping[day];
      const daysUntilTarget = (targetDay - today.getDay() + 7) % 7;
      const targetDate = new Date();
      targetDate.setDate(today.getDate() + (daysUntilTarget || 7)); // Use next week if today
      dueDate = targetDate.toISOString().split('T')[0];
    } else {
      // Default to tomorrow
      const tomorrow = new Date();
      tomorrow.setDate(tomorrow.getDate() + 1);
      dueDate = tomorrow.toISOString().split('T')[0];
    }
  } else {
    // Default to tomorrow
    const tomorrow = new Date();
    tomorrow.setDate(tomorrow.getDate() + 1);
    dueDate = tomorrow.toISOString().split('T')[0];
  }
  
  // Extract time estimates
  const timeEstimateMatch = userRequest.match(/(\d+)\s*(hour|hr|minute|min)s?/i);
  if (timeEstimateMatch) {
    const amount = parseInt(timeEstimateMatch[1]);
    const unit = timeEstimateMatch[2].toLowerCase();
    
    if (unit === 'hour' || unit === 'hr') {
      estimatedTime = amount * 60; // Convert to minutes
    } else {
      estimatedTime = amount;
    }
  }
  
  // Extract description if present
  if (userRequest.toLowerCase().includes('description:')) {
    const descParts = userRequest.split(/description:/i);
    if (descParts.length > 1) {
      // Get everything after "description:" until the next keyword or end
      description = descParts[1].trim();
    }
  }
  
  // Extract tags
  const tagMatches = userRequest.match(/#\w+/g);
  if (tagMatches) {
    tags = tagMatches.map(tag => tag.substring(1));
  }
  
  // Extract reminder time if present
  if (userRequest.toLowerCase().includes('remind me')) {
    if (userRequest.toLowerCase().includes('at ')) {
      const timeMatch = userRequest.match(/at\s+(\d{1,2})(:\d{2})?\s*(am|pm)?/i);
      if (timeMatch) {
        let hour = parseInt(timeMatch[1]);
        const minute = timeMatch[2] ? parseInt(timeMatch[2].substring(1)) : 0;
        const period = timeMatch[3] ? timeMatch[3].toLowerCase() : null;
        
        // Adjust hour for 12-hour format with am/pm
        if (period === 'pm' && hour < 12) {
          hour += 12;
        } else if (period === 'am' && hour === 12) {
          hour = 0;
        }
        
        const reminderDate = new Date(dueDate);
        reminderDate.setHours(hour, minute, 0, 0);
        reminderTime = reminderDate.toISOString();
      }
    }
  }
  
  // Calculate task points based on priority and estimated time
  let points = 5; // Default points
  
  if (priority === 'high') {
    points = 10;
  } else if (priority === 'low') {
    points = 3;
  }
  
  // Adjust points based on estimated time if available
  if (estimatedTime) {
    // Add 1 point for every 20 minutes of estimated work
    points += Math.floor(estimatedTime / 20);
  }
  
  // Create enhanced task data
  return {
    title: title || "Task from AI assistant",
    priority,
    dueDate,
    description: description || "Task created by BreezeMind AI assistant.",
    points,
    tags: tags.length > 0 ? tags : undefined,
    reminderTime,
    estimatedTime
  };
}

/**
 * Function to process multiple tasks from a single request
 * Useful for to-do lists or batch task creation
 * 
 * NOTE: For testing purposes in Replit environment, this is a mock implementation
 */
export async function createBatchTasksWithLlm(userRequest: string): Promise<Array<{
  title: string;
  priority: 'low' | 'medium' | 'high';
  dueDate?: string;
  description?: string;
  points?: number;
}>> {
  console.log('[MOCK] Creating batch tasks from request:', userRequest);
  
  // Try to identify separate tasks by common list patterns
  const tasks: Array<{
    title: string;
    priority: 'low' | 'medium' | 'high';
    dueDate?: string;
    description?: string;
    points?: number;
  }> = [];
  
  // Clean the user request
  let cleanedRequest = userRequest;
  
  // Remove initial prompt text like "create tasks for" 
  if (cleanedRequest.toLowerCase().match(/^(create|add)( a list of| multiple| batch)? tasks( for| to)?:/i)) {
    cleanedRequest = cleanedRequest.replace(/^(create|add)( a list of| multiple| batch)? tasks( for| to)?:/i, '').trim();
  }
  
  // Process the tasks based on common list delimiters
  let taskList: string[] = [];
  
  // First check for numbered lists (1. Task 2. Another task)
  if (cleanedRequest.match(/\d+\.\s+.+/)) {
    taskList = cleanedRequest.split(/\d+\.\s+/).filter(t => t.trim().length > 0);
  } 
  // Then check for bullet points
  else if (cleanedRequest.match(/[-•*]\s+.+/)) {
    taskList = cleanedRequest.split(/[-•*]\s+/).filter(t => t.trim().length > 0);
  } 
  // Look for newlines
  else if (cleanedRequest.includes('\n')) {
    taskList = cleanedRequest.split('\n').filter(t => t.trim().length > 0);
  }
  // Default - try to split by comma or semicolon if other methods didn't work
  else if (taskList.length === 0) {
    taskList = cleanedRequest.split(/[,;]\s+/).filter(t => t.trim().length > 0);
  }
  
  // Process each identified task
  for (const taskText of taskList) {
    // Basic information
    let title = taskText.trim();
    let priority: 'low' | 'medium' | 'high' = 'medium';
    
    // Try to determine priority
    if (taskText.toLowerCase().includes('urgent') || 
        taskText.toLowerCase().includes('important') || 
        taskText.toLowerCase().includes('asap')) {
      priority = 'high';
    } else if (taskText.toLowerCase().includes('sometime') || 
              taskText.toLowerCase().includes('when you can') ||
              taskText.toLowerCase().includes('low priority')) {
      priority = 'low';
    }
    
    // Try to extract dates
    let dueDate: string | undefined = undefined;
    
    // Simple date check
    if (taskText.toLowerCase().includes('today')) {
      const today = new Date();
      dueDate = today.toISOString().split('T')[0];
    } else if (taskText.toLowerCase().includes('tomorrow')) {
      const tomorrow = new Date();
      tomorrow.setDate(tomorrow.getDate() + 1);
      dueDate = tomorrow.toISOString().split('T')[0];
    } else if (taskText.toLowerCase().includes('next week')) {
      const nextWeek = new Date();
      nextWeek.setDate(nextWeek.getDate() + 7);
      dueDate = nextWeek.toISOString().split('T')[0];
    }
    
    // Calculate points based on priority
    let points = 5;
    if (priority === 'high') {
      points = 8;
    } else if (priority === 'low') {
      points = 3;
    }
    
    tasks.push({
      title,
      priority,
      dueDate,
      points
    });
  }
  
  // If we couldn't identify any tasks, create at least one default task
  if (tasks.length === 0) {
    tasks.push({
      title: cleanedRequest || "Task from AI assistant",
      priority: 'medium',
      points: 5
    });
  }
  
  return tasks;
}

/**
 * Check if the LLM should be unloaded due to inactivity
 * This function should be called periodically
 * 
 * NOTE: For testing purposes in Replit environment, this is a mock implementation
 */
export function checkAndUnloadLlm() {
  if (!activeInstance) return;
  
  const now = new Date();
  const idleTime = now.getTime() - activeInstance.lastUsed.getTime();
  const idleTimeoutMs = config.idleTimeoutMinutes * 60 * 1000;
  
  if (idleTime > idleTimeoutMs) {
    console.log(`[MOCK] LLM instance idle for ${idleTime / 1000} seconds, unloading...`);
    unloadLlm();
  }
}

/**
 * Unload the LLM to free up resources
 * 
 * NOTE: For testing purposes in Replit environment, this is a mock implementation
 */
function unloadLlm() {
  console.log('[MOCK] Unloading LLM instance');
  activeInstance = null;
  
  if (unloadTimer) {
    clearTimeout(unloadTimer);
    unloadTimer = null;
  }
}

/**
 * Setup auto-unload timer
 * 
 * NOTE: For testing purposes in Replit environment, this is a mock implementation
 */
function setupUnloadTimer() {
  // Check every minute if the LLM should be unloaded
  if (unloadTimer) {
    clearTimeout(unloadTimer);
  }
  
  unloadTimer = setInterval(() => {
    checkAndUnloadLlm();
  }, 60 * 1000); // Check every minute
}