/**
 * Script to create Razorpay plans and set up environment variables
 * Run with: npx tsx scripts/setupPlans.ts
 */

import fs from 'fs';
import path from 'path';
import dotenv from 'dotenv';
import Razorpay from 'razorpay';
import { planPricesINR } from '../server/planIdMap';

// Load environment variables
dotenv.config();

// Verify API keys are present
if (!process.env.RAZORPAY_KEY_ID || !process.env.RAZORPAY_KEY_SECRET) {
  console.error('Error: Razorpay API keys not found in environment variables.');
  console.error('Please set RAZORPAY_KEY_ID and RAZORPAY_KEY_SECRET in your .env file.');
  process.exit(1);
}

// Initialize Razorpay client
const razorpay = new Razorpay({
  key_id: process.env.RAZORPAY_KEY_ID,
  key_secret: process.env.RAZORPAY_KEY_SECRET
});

// Plan details
const plans = [
  {
    name: 'FREE',
    description: 'Free tier with basic features',
    envKey: 'RAZORPAY_PLAN_FREE_ID',
    interval: 'monthly',
    amount: 0,
    currency: 'INR'
  },
  {
    name: 'STARTER MONTHLY',
    description: 'Starter tier with enhanced features (monthly billing)',
    envKey: 'RAZORPAY_PLAN_STARTER_M',
    interval: 'monthly',
    amount: planPricesINR.starter.monthly,
    currency: 'INR'
  },
  {
    name: 'STARTER ANNUAL',
    description: 'Starter tier with enhanced features (annual billing)',
    envKey: 'RAZORPAY_PLAN_STARTER_Y',
    interval: 'yearly',
    amount: planPricesINR.starter.annual,
    currency: 'INR'
  },
  {
    name: 'PRO MONTHLY',
    description: 'Professional tier with advanced features (monthly billing)',
    envKey: 'RAZORPAY_PLAN_PRO_M',
    interval: 'monthly',
    amount: planPricesINR.pro.monthly,
    currency: 'INR'
  },
  {
    name: 'PRO ANNUAL',
    description: 'Professional tier with advanced features (annual billing)',
    envKey: 'RAZORPAY_PLAN_PRO_Y',
    interval: 'yearly',
    amount: planPricesINR.pro.annual,
    currency: 'INR'
  },
  {
    name: 'TEAM MONTHLY',
    description: 'Team tier with collaboration features (monthly billing, per user)',
    envKey: 'RAZORPAY_PLAN_TEAM_M',
    interval: 'monthly',
    amount: planPricesINR.team.monthly,
    currency: 'INR'
  },
  {
    name: 'TEAM ANNUAL',
    description: 'Team tier with collaboration features (annual billing, per user)',
    envKey: 'RAZORPAY_PLAN_TEAM_Y',
    interval: 'yearly',
    amount: planPricesINR.team.annual,
    currency: 'INR'
  }
];

// Function to create plans
async function createPlans() {
  console.log('Creating plans in Razorpay...');
  
  const envUpdates = {};
  
  for (const plan of plans) {
    try {
      console.log(`Creating plan: ${plan.name}`);
      
      // Skip free plan creation in Razorpay since it's not a paid plan
      if (plan.name === 'FREE') {
        envUpdates[plan.envKey] = 'free_plan';
        console.log(`Free plan (not created in Razorpay) - using ID: free_plan`);
        continue;
      }
      
      // Create plan
      const razorpayPlan = await razorpay.plans.create({
        period: plan.interval,
        interval: 1,
        item: {
          name: plan.name,
          description: plan.description,
          amount: plan.amount * 100, // Razorpay uses smaller units (paise)
          currency: plan.currency
        }
      });
      
      console.log(`Created plan: ${plan.name} with ID: ${razorpayPlan.id}`);
      
      // Store plan ID for .env
      envUpdates[plan.envKey] = razorpayPlan.id;
    } catch (error) {
      console.error(`Error creating plan ${plan.name}:`, error);
    }
  }
  
  // Update .env file with plan IDs
  try {
    const envPath = path.resolve(process.cwd(), '.env');
    let envContent = '';
    
    if (fs.existsSync(envPath)) {
      envContent = fs.readFileSync(envPath, 'utf8');
    }
    
    for (const [key, value] of Object.entries(envUpdates)) {
      const regex = new RegExp(`^${key}=.*$`, 'm');
      
      if (regex.test(envContent)) {
        // Update existing variable
        envContent = envContent.replace(regex, `${key}=${value}`);
      } else {
        // Add new variable
        envContent += `\n${key}=${value}`;
      }
    }
    
    fs.writeFileSync(envPath, envContent.trim());
    console.log('Updated .env file with plan IDs');
  } catch (error) {
    console.error('Error updating .env file:', error);
  }
}

// Execute the function
createPlans()
  .then(() => {
    console.log('Plan setup completed successfully');
    process.exit(0);
  })
  .catch((error) => {
    console.error('Plan setup failed:', error);
    process.exit(1);
  });