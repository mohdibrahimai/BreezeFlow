#!/bin/bash
# Script to prepare the application for production deployment

echo "======== BreezeFlow Production Preparation ========"
echo "Running typescript checks..."
npx tsc --noEmit

echo "Running tests..."
npx vitest run

echo "Migrating database to include starter plan..."
npx tsx migrations/addStarterPlan.ts

echo "Setting up Razorpay plans..."
npx tsx scripts/setupPlans.ts

echo "Building production assets..."
npx vite build && npx esbuild server/index.ts --platform=node --packages=external --bundle --format=esm --outdir=dist

echo "======== Production Preparation Complete ========"
echo "You can now deploy the application to production."
echo "Run 'node dist/index.js' to start the production server."