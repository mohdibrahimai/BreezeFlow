import { Task, Event } from "@shared/schema";

export interface TimeBlock {
  title: string;
  startISO: string;
  endISO: string;
  taskId?: number;
  isFixed?: boolean;
}

export interface OptimizedSchedule {
  timeBlocks: TimeBlock[];
  unscheduledTasks?: Task[];
}

/**
 * A simplified optimizer using greedy algorithm for scheduling tasks
 * This is a placeholder for the OR-Tools scheduler that would be used in production
 */
export function optimizeSchedule(tasks: Task[], events: Event[]): OptimizedSchedule {
  // Sort tasks by priority score (descending) or regular priority if score not available
  const sortedTasks = [...tasks].sort((a, b) => {
    if (a.priority_score && b.priority_score) {
      return b.priority_score - a.priority_score;
    } else if (a.priority === 'high' && b.priority !== 'high') {
      return -1;
    } else if (a.priority !== 'high' && b.priority === 'high') {
      return 1;
    } else if (a.priority === 'medium' && b.priority === 'low') {
      return -1;
    } else if (a.priority === 'low' && b.priority === 'medium') {
      return 1;
    }
    return 0;
  });

  // Create fixed blocks from existing events
  const fixedBlocks: TimeBlock[] = events.map(event => ({
    title: event.title,
    startISO: event.start,
    endISO: event.end,
    isFixed: true
  }));

  // Set the boundary for our schedule (today 8am to 8pm)
  const now = new Date();
  const startDate = new Date(now);
  startDate.setHours(8, 0, 0, 0); // 8am
  const endDate = new Date(now);
  endDate.setHours(20, 0, 0, 0); // 8pm

  // Set boundary blocks to ensure we only schedule within our working hours
  const startBoundary: TimeBlock = {
    title: "Start of Day",
    startISO: new Date(0).toISOString(), // Beginning of time
    endISO: startDate.toISOString(),
    isFixed: true
  };

  const endBoundary: TimeBlock = {
    title: "End of Day",
    startISO: endDate.toISOString(),
    endISO: new Date(8640000000000000).toISOString(), // End of time (max date)
    isFixed: true
  };

  // Combine the fixed blocks with boundary blocks
  const allFixedBlocks = [startBoundary, ...fixedBlocks, endBoundary];
  
  // Sort fixed blocks by start time
  allFixedBlocks.sort((a, b) => new Date(a.startISO).getTime() - new Date(b.startISO).getTime());

  // Find available time slots between fixed blocks
  const freeSlots = findFreeTimeSlots(allFixedBlocks);

  // Assign tasks to slots
  const scheduledBlocks = assignTasksToSlots(sortedTasks, freeSlots);

  // Combine fixed blocks and scheduled blocks and sort them
  const allBlocks = [...fixedBlocks, ...scheduledBlocks].sort(
    (a, b) => new Date(a.startISO).getTime() - new Date(b.startISO).getTime()
  );

  // Find tasks that couldn't be scheduled
  const scheduledTaskIds = new Set(scheduledBlocks.map(block => block.taskId).filter(Boolean));
  const unscheduledTasks = sortedTasks.filter(task => !scheduledTaskIds.has(task.id));

  return {
    timeBlocks: allBlocks,
    unscheduledTasks
  };
}

/**
 * Find available time slots between events
 */
function findFreeTimeSlots(fixedBlocks: TimeBlock[]): { start: Date, end: Date }[] {
  const freeSlots: { start: Date, end: Date }[] = [];
  
  for (let i = 0; i < fixedBlocks.length - 1; i++) {
    const currentEnd = new Date(fixedBlocks[i].endISO);
    const nextStart = new Date(fixedBlocks[i + 1].startISO);
    
    // If there's time between the end of one event and the start of the next
    if (currentEnd < nextStart) {
      freeSlots.push({
        start: currentEnd,
        end: nextStart
      });
    }
  }
  
  return freeSlots;
}

/**
 * Assign tasks to available time slots
 */
function assignTasksToSlots(tasks: Task[], freeSlots: { start: Date, end: Date }[]): TimeBlock[] {
  const scheduledBlocks: TimeBlock[] = [];
  let currentTaskIndex = 0;
  
  for (const slot of freeSlots) {
    if (currentTaskIndex >= tasks.length) break;
    
    const slotDuration = slot.end.getTime() - slot.start.getTime();
    let remainingTime = slotDuration;
    let currentTime = new Date(slot.start);
    
    while (remainingTime > 0 && currentTaskIndex < tasks.length) {
      const task = tasks[currentTaskIndex];
      const taskDuration = estimateTaskDuration(task);
      const taskDurationMs = taskDuration * 60 * 1000; // Convert minutes to ms
      
      // If task can fit in the remaining time
      if (taskDurationMs <= remainingTime) {
        const taskEnd = new Date(currentTime.getTime() + taskDurationMs);
        
        scheduledBlocks.push({
          title: task.title,
          startISO: currentTime.toISOString(),
          endISO: taskEnd.toISOString(),
          taskId: task.id
        });
        
        currentTime = taskEnd;
        remainingTime -= taskDurationMs;
        currentTaskIndex++;
      } else {
        // If the task doesn't fit, add it to the next slot
        break;
      }
    }
  }
  
  return scheduledBlocks;
}

/**
 * Estimate task duration based on priority and other factors
 */
function estimateTaskDuration(task: Task): number {
  // Basic duration estimates based on priority
  const baseDuration = {
    'high': 45,
    'medium': 30,
    'low': 15
  };
  
  // Use AI-generated priority score if available
  if (task.priority_score) {
    // Higher score = higher priority = potentially more complex
    // Map 0-100 score to 15-60 minutes
    return 15 + Math.round((task.priority_score / 100) * 45);
  }
  
  return baseDuration[task.priority as keyof typeof baseDuration] || 30;
}