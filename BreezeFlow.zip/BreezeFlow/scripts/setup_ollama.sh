#!/bin/bash

# setup_ollama.sh
# Script to download and configure Ollama with Llama-3

# Print colored output
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
NC='\033[0m' # No Color

echo -e "${YELLOW}Starting BreezeMind-Lite setup...${NC}"
echo -e "This script will download and configure Ollama with the Llama-3 model."
echo -e "Note: This process may take some time depending on your internet connection and system."

# Check if Ollama is already installed
if command -v ollama >/dev/null 2>&1; then
  echo -e "${GREEN}Ollama is already installed!${NC}"
else
  echo -e "${YELLOW}Installing Ollama...${NC}"
  
  # Download and install Ollama
  curl -fsSL https://ollama.com/install.sh | sh
  
  if [ $? -ne 0 ]; then
    echo -e "${RED}Failed to install Ollama. Please check your internet connection and try again.${NC}"
    exit 1
  fi
  
  echo -e "${GREEN}Ollama installed successfully!${NC}"
fi

# Start Ollama server in the background
echo -e "${YELLOW}Starting Ollama server...${NC}"
ollama serve &
OLLAMA_PID=$!

# Wait for Ollama to start
sleep 5

# Download the model
echo -e "${YELLOW}Downloading Llama-3 model (8B quantized version for memory efficiency)...${NC}"
echo -e "${YELLOW}This may take several minutes...${NC}"

ollama pull llama3:8b-q4_0

if [ $? -ne 0 ]; then
  echo -e "${RED}Failed to download the model. Please check your internet connection and try again.${NC}"
  kill $OLLAMA_PID
  exit 1
fi

echo -e "${GREEN}Model downloaded successfully!${NC}"

# Create a modelfile with appropriate parameters
echo -e "${YELLOW}Configuring model parameters...${NC}"

cat > modelfile << EOL
FROM llama3:8b-q4_0

# Set reasonable temperature for assistant-like behavior
PARAMETER temperature 0.7

# Reduce max tokens to stay within memory constraints
PARAMETER num_predict 512 

# System prompt to prepare the model
SYSTEM You are BreezeMind, a productivity assistant for BreezeFlow users.
SYSTEM You can help create tasks, optimize schedules, and answer productivity questions.
SYSTEM You are designed to be helpful, accurate, and focused on productivity solutions.
SYSTEM Always format your responses clearly and concisely.
EOL

# Build the customized model
echo -e "${YELLOW}Building custom BreezeMind model...${NC}"
ollama create breezemind -f modelfile

if [ $? -ne 0 ]; then
  echo -e "${RED}Failed to create custom model.${NC}"
  kill $OLLAMA_PID
  exit 1
fi

echo -e "${GREEN}Custom BreezeMind model created successfully!${NC}"

# Clean up
rm modelfile
kill $OLLAMA_PID

# Create config file for the llm_client.ts
echo -e "${YELLOW}Creating config file for LLM client...${NC}"

cat > ../config/llm_config.json << EOL
{
  "model": "breezemind",
  "maxTokens": 512,
  "temperature": 0.7,
  "idleTimeoutMinutes": 10
}
EOL

echo -e "${GREEN}Configuration complete!${NC}"
echo -e "${GREEN}BreezeMind-Lite is now ready to use.${NC}"
echo -e "${YELLOW}To use BreezeMind, simply click the 'Open BreezeMind' button in the sidebar.${NC}"
echo ""
echo -e "${YELLOW}Note: The Ollama server will start automatically when needed and will shut down after 10 minutes of inactivity to conserve system resources.${NC}"