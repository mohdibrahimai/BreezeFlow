#!/bin/bash
# Script to test the quota system with multiple simultaneous requests

# Configuration
API_URL="http://localhost:5000"
REQUESTS=60 # Number of requests to make
CONCURRENT=10 # Concurrent requests
AUTH_TOKEN="" # Will be filled after login

# Colors for output
GREEN='\033[0;32m'
RED='\033[0;31m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

echo "=== BreezeFlow Quota System Test ==="
echo "This script will test the quota system by making multiple simultaneous requests"

# Login to get auth token
echo -e "\n${YELLOW}Step 1: Logging in to get authentication token${NC}"
LOGIN_RESPONSE=$(curl -s -c cookies.txt -X POST -H "Content-Type: application/json" \
    -d '{"username": "testuser", "password": "password123"}' \
    $API_URL/api/login)

if [[ $LOGIN_RESPONSE == *"Authentication failed"* ]]; then
    echo -e "${RED}Login failed. Please create a test user first:${NC}"
    echo "curl -X POST -H \"Content-Type: application/json\" \\"
    echo "    -d '{\"username\": \"testuser\", \"password\": \"password123\", \"name\": \"Test User\", \"email\": \"test@example.com\"}' \\"
    echo "    $API_URL/api/register"
    exit 1
fi

echo -e "${GREEN}Login successful${NC}"

# Get user info to check plan
echo -e "\n${YELLOW}Step 2: Getting user info${NC}"
USER_INFO=$(curl -s -b cookies.txt $API_URL/api/user)
PLAN=$(echo $USER_INFO | grep -o '"plan":"[^"]*"' | cut -d'"' -f4)

echo -e "User is on the ${GREEN}$PLAN${NC} plan"

# Get current quota status
echo -e "\n${YELLOW}Step 3: Checking initial quota${NC}"
QUOTA_INFO=$(curl -s -b cookies.txt $API_URL/api/user/quota)
USED=$(echo $QUOTA_INFO | grep -o '"actionCount":[0-9]*' | cut -d':' -f2)
LIMIT=$(echo $QUOTA_INFO | grep -o '"limit":"[^"]*"' | cut -d'"' -f4)

if [[ "$LIMIT" == "unlimited" ]]; then
    echo -e "Current usage: ${GREEN}$USED / unlimited${NC}"
    echo -e "${YELLOW}Note: User has unlimited actions, quota enforcement test will not be meaningful${NC}"
else
    echo -e "Current usage: ${GREEN}$USED / $LIMIT${NC}"
    REMAINING=$((LIMIT - USED))
    if (( REQUESTS > REMAINING )); then
        echo -e "${YELLOW}Warning: You're trying to make $REQUESTS requests but only have $REMAINING remaining.${NC}"
        echo -e "${YELLOW}This will trigger quota exceeded responses.${NC}"
    fi
fi

# Function to make a request and extract headers
make_request() {
    local result=$(curl -s -b cookies.txt -w "\nX-Quota-Remaining: %{http_code}\n" $API_URL/api/tasks)
    local status_code=$(echo "$result" | tail -n1 | cut -d' ' -f2)
    
    if [[ "$status_code" == "402" ]]; then
        echo "QUOTA_EXCEEDED"
    else
        echo "SUCCESS"
    fi
}

# Make multiple concurrent requests to test quota enforcement
echo -e "\n${YELLOW}Step 4: Making $REQUESTS requests ($CONCURRENT concurrent) to test quota${NC}"
echo "This may take a moment..."

SUCCESS_COUNT=0
QUOTA_EXCEEDED_COUNT=0

# Use GNU Parallel if available, otherwise fall back to a simple loop
if command -v parallel &> /dev/null; then
    echo "Using GNU Parallel for concurrent requests"
    RESULTS=$(seq $REQUESTS | parallel -j $CONCURRENT --results - "bash -c 'source $0; make_request'" 2>/dev/null)
    SUCCESS_COUNT=$(echo "$RESULTS" | grep -c "SUCCESS")
    QUOTA_EXCEEDED_COUNT=$(echo "$RESULTS" | grep -c "QUOTA_EXCEEDED")
else
    echo "GNU Parallel not found, using sequential requests"
    for i in $(seq $REQUESTS); do
        RESULT=$(make_request)
        if [[ "$RESULT" == "SUCCESS" ]]; then
            SUCCESS_COUNT=$((SUCCESS_COUNT + 1))
        else
            QUOTA_EXCEEDED_COUNT=$((QUOTA_EXCEEDED_COUNT + 1))
        fi
        echo -ne "Progress: $i/$REQUESTS\r"
    done
    echo
fi

# Get final quota status
echo -e "\n${YELLOW}Step 5: Checking final quota${NC}"
FINAL_QUOTA=$(curl -s -b cookies.txt $API_URL/api/user/quota)
FINAL_USED=$(echo $FINAL_QUOTA | grep -o '"actionCount":[0-9]*' | cut -d':' -f2)

echo -e "\n${GREEN}Test completed!${NC}"
echo "Successful requests: $SUCCESS_COUNT"
echo "Quota exceeded responses: $QUOTA_EXCEEDED_COUNT"
echo -e "Initial action count: ${YELLOW}$USED${NC}"
echo -e "Final action count: ${YELLOW}$FINAL_USED${NC}"
echo -e "Actions recorded: ${GREEN}$((FINAL_USED - USED))${NC}"

if [[ "$LIMIT" != "unlimited" && "$QUOTA_EXCEEDED_COUNT" > 0 ]]; then
    echo -e "\n${GREEN}Quota enforcement is working correctly!${NC}"
    echo "The system prevented additional actions after quota was exceeded."
elif [[ "$LIMIT" == "unlimited" ]]; then
    echo -e "\n${GREEN}Testing completed for unlimited plan.${NC}"
    echo "As expected, no quota limits were enforced."
elif (( REQUESTS <= REMAINING )); then
    echo -e "\n${GREEN}All requests succeeded as expected.${NC}"
    echo "To test quota enforcement, increase the number of requests above your remaining quota."
else
    echo -e "\n${RED}Warning: Quota enforcement may not be working correctly.${NC}"
    echo "All requests succeeded despite exceeding quota limits."
fi

# Clean up
rm -f cookies.txt
echo -e "\n${GREEN}Done!${NC}"