import { Switch, Route } from "wouter";
import { QueryClientProvider } from "@tanstack/react-query";
import { queryClient } from "./lib/queryClient";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/not-found";
import { ProtectedRoute } from "./lib/protected-route";
import LandingPage from "./pages/landing";
import AuthPage from "./pages/auth-page";
import Dashboard from "./pages/dashboard";
import TasksPage from "./pages/tasks";
import CalendarPage from "./pages/calendar";
import ErrandsPage from "./pages/errands";
import BillsPage from "./pages/bills";
import RewardsPage from "./pages/rewards";
import SettingsPage from "./pages/settings";
import AdminPage from "./pages/admin";
import PricingPage from "./pages/pricing";
import Checkout from "./pages/checkout";
import ROIDashboard from "./pages/roi-dashboard";
import AIDashboard from "./pages/ai-dashboard";
import ForgotPasswordPage from "./pages/forgot-password";
import ResetPasswordPage from "./pages/reset-password";
import { ThemeProvider } from "next-themes";
import { AuthProvider } from "./hooks/use-auth";

function Router() {
  return (
    <Switch>
      <Route path="/" component={LandingPage} />
      <Route path="/auth" component={AuthPage} />
      <Route path="/pricing" component={PricingPage} />
      <Route path="/forgot-password" component={ForgotPasswordPage} />
      <Route path="/reset-password" component={ResetPasswordPage} />
      <ProtectedRoute path="/dashboard" component={Dashboard} />
      <ProtectedRoute path="/tasks" component={TasksPage} />
      <ProtectedRoute path="/calendar" component={CalendarPage} />
      <ProtectedRoute path="/errands" component={ErrandsPage} />
      <ProtectedRoute path="/bills" component={BillsPage} />
      <ProtectedRoute path="/rewards" component={RewardsPage} />
      <ProtectedRoute path="/settings" component={SettingsPage} />
      <ProtectedRoute path="/admin" component={AdminPage} />
      <ProtectedRoute path="/checkout" component={Checkout} />
      <ProtectedRoute path="/roi-dashboard" component={ROIDashboard} />
      <ProtectedRoute path="/ai-dashboard" component={AIDashboard} />
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <AuthProvider>
        <ThemeProvider attribute="class" defaultTheme="light">
          <TooltipProvider>
            <Router />
          </TooltipProvider>
        </ThemeProvider>
      </AuthProvider>
    </QueryClientProvider>
  );
}

export default App;
