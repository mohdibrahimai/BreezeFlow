import React from 'react';
import { AppLayout } from '@/components/layout/app-layout';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { useQuery } from '@tanstack/react-query';
import { useAuth } from '@/hooks/use-auth';
import { 
  Users, 
  UserCheck, 
  UserX, 
  CheckSquare, 
  Calendar, 
  ShoppingCart,
  CreditCard,
  Award,
  DollarSign
} from 'lucide-react';
import { 
  LineChart, 
  Line, 
  BarChart, 
  Bar, 
  PieChart, 
  Pie, 
  Cell,
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  Legend, 
  ResponsiveContainer 
} from 'recharts';
import { Badge } from '@/components/ui/badge';
import { Helmet } from 'react-helmet';
import { useLocation } from 'wouter';

// Demo data for charts
const monthlyRevenueData = [
  { month: 'Jan', revenue: 1200 },
  { month: 'Feb', revenue: 1900 },
  { month: 'Mar', revenue: 2400 },
  { month: 'Apr', revenue: 2200 },
  { month: 'May', revenue: 2600 },
  { month: 'Jun', revenue: 3100 },
  { month: 'Jul', revenue: 3800 },
];

const userActivityData = [
  { day: 'Mon', active: 120 },
  { day: 'Tue', active: 132 },
  { day: 'Wed', active: 101 },
  { day: 'Thu', active: 134 },
  { day: 'Fri', active: 90 },
  { day: 'Sat', active: 70 },
  { day: 'Sun', active: 85 },
];

const userPlanData = [
  { name: 'Free', value: 65 },
  { name: 'Pro', value: 25 },
  { name: 'Team', value: 10 },
];

const COLORS = ['#8884d8', '#82ca9d', '#ffc658'];

export default function AdminPage() {
  const { user } = useAuth();
  const [, navigate] = useLocation();
  
  // Admin access check
  React.useEffect(() => {
    // In a real app, you'd check for an admin role
    // For this demo, we're considering user with ID 1 as admin
    if (user?.id !== 1) {
      navigate('/dashboard');
    }
  }, [user, navigate]);
  
  const { data: adminUsers, isLoading: loadingUsers } = useQuery({
    queryKey: ['/api/admin/users'],
  });
  
  // Calculate stats
  const totalUsers = adminUsers?.length || 0;
  const activeUsers = adminUsers?.filter(u => u.streak_days > 0)?.length || 0;
  const inactiveUsers = totalUsers - activeUsers;
  const totalRevenue = adminUsers?.reduce((sum, user) => {
    if (user.plan === 'pro') return sum + 19;
    if (user.plan === 'team') return sum + 29;
    return sum;
  }, 0) || 0;

  return (
    <AppLayout pageTitle="Admin Dashboard">
      <Helmet>
        <title>Admin Dashboard - BreezeFlow</title>
        <meta name="description" content="Admin dashboard for BreezeFlow. View metrics, user data, and system information." />
      </Helmet>
      
      <div className="mb-6">
        <h1 className="text-2xl font-semibold text-gray-900 dark:text-white">Admin Dashboard</h1>
        <p className="text-gray-600 dark:text-gray-400">System overview and management</p>
      </div>
      
      {/* Stats Overview */}
      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-4 mb-6">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium">Total Users</CardTitle>
            <Users className="h-4 w-4 text-primary" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{totalUsers}</div>
            <p className="text-xs text-gray-500 dark:text-gray-400">Registered accounts</p>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium">Active Users</CardTitle>
            <UserCheck className="h-4 w-4 text-green-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{activeUsers}</div>
            <p className="text-xs text-gray-500 dark:text-gray-400">Users with active streaks</p>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium">Inactive Users</CardTitle>
            <UserX className="h-4 w-4 text-red-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{inactiveUsers}</div>
            <p className="text-xs text-gray-500 dark:text-gray-400">Users with no recent activity</p>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium">Monthly Revenue</CardTitle>
            <DollarSign className="h-4 w-4 text-green-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              {new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD' }).format(totalRevenue)}
            </div>
            <p className="text-xs text-gray-500 dark:text-gray-400">From Pro and Team plans</p>
          </CardContent>
        </Card>
      </div>
      
      {/* Chart Section */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
        <Card>
          <CardHeader>
            <CardTitle>Monthly Revenue</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="h-80">
              <ResponsiveContainer width="100%" height="100%">
                <LineChart
                  data={monthlyRevenueData}
                  margin={{ top: 5, right: 30, left: 20, bottom: 5 }}
                >
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="month" />
                  <YAxis />
                  <Tooltip
                    formatter={(value) => [`$${value}`, 'Revenue']}
                    contentStyle={{
                      backgroundColor: 'rgba(255, 255, 255, 0.9)',
                      borderColor: '#e2e8f0',
                    }}
                  />
                  <Legend />
                  <Line
                    type="monotone"
                    dataKey="revenue"
                    stroke="#3B82F6"
                    strokeWidth={2}
                    activeDot={{ r: 8 }}
                  />
                </LineChart>
              </ResponsiveContainer>
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader>
            <CardTitle>Daily Active Users</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="h-80">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart
                  data={userActivityData}
                  margin={{ top: 5, right: 30, left: 20, bottom: 5 }}
                >
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="day" />
                  <YAxis />
                  <Tooltip
                    formatter={(value) => [`${value} users`, 'Active']}
                    contentStyle={{
                      backgroundColor: 'rgba(255, 255, 255, 0.9)',
                      borderColor: '#e2e8f0',
                    }}
                  />
                  <Legend />
                  <Bar dataKey="active" fill="#10B981" />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </CardContent>
        </Card>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
        <Card className="md:col-span-1">
          <CardHeader>
            <CardTitle>Users by Plan</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="h-64">
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie
                    data={userPlanData}
                    cx="50%"
                    cy="50%"
                    labelLine={false}
                    label={({ name, percent }) => `${name}: ${(percent * 100).toFixed(0)}%`}
                    outerRadius={80}
                    fill="#8884d8"
                    dataKey="value"
                  >
                    {userPlanData.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                    ))}
                  </Pie>
                  <Tooltip
                    formatter={(value) => [`${value} users`, 'Count']}
                    contentStyle={{
                      backgroundColor: 'rgba(255, 255, 255, 0.9)',
                      borderColor: '#e2e8f0',
                    }}
                  />
                </PieChart>
              </ResponsiveContainer>
            </div>
          </CardContent>
        </Card>
        
        <Card className="md:col-span-2">
          <CardHeader>
            <CardTitle>System Health</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="flex justify-between items-center">
                <div className="space-y-0.5">
                  <div className="text-sm font-medium">Server Status</div>
                  <div className="text-xs text-gray-500 dark:text-gray-400">API and web services</div>
                </div>
                <Badge variant="success">Operational</Badge>
              </div>
              
              <div className="flex justify-between items-center">
                <div className="space-y-0.5">
                  <div className="text-sm font-medium">Database Status</div>
                  <div className="text-xs text-gray-500 dark:text-gray-400">Primary and replica databases</div>
                </div>
                <Badge variant="success">Operational</Badge>
              </div>
              
              <div className="flex justify-between items-center">
                <div className="space-y-0.5">
                  <div className="text-sm font-medium">Cache Status</div>
                  <div className="text-xs text-gray-500 dark:text-gray-400">Redis caching system</div>
                </div>
                <Badge variant="success">Operational</Badge>
              </div>
              
              <div className="flex justify-between items-center">
                <div className="space-y-0.5">
                  <div className="text-sm font-medium">Storage Status</div>
                  <div className="text-xs text-gray-500 dark:text-gray-400">File and media storage</div>
                </div>
                <Badge variant="success">Operational</Badge>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
      
      {/* Data Tables */}
      <Tabs defaultValue="users" className="space-y-6">
        <TabsList>
          <TabsTrigger value="users">
            <Users className="h-4 w-4 mr-2" /> Users
          </TabsTrigger>
          <TabsTrigger value="tasks">
            <CheckSquare className="h-4 w-4 mr-2" /> Tasks
          </TabsTrigger>
          <TabsTrigger value="events">
            <Calendar className="h-4 w-4 mr-2" /> Events
          </TabsTrigger>
          <TabsTrigger value="errands">
            <ShoppingCart className="h-4 w-4 mr-2" /> Errands
          </TabsTrigger>
          <TabsTrigger value="bills">
            <CreditCard className="h-4 w-4 mr-2" /> Bills
          </TabsTrigger>
          <TabsTrigger value="rewards">
            <Award className="h-4 w-4 mr-2" /> Rewards
          </TabsTrigger>
        </TabsList>
        
        <TabsContent value="users">
          <Card>
            <CardHeader>
              <CardTitle>Users</CardTitle>
            </CardHeader>
            <CardContent>
              {loadingUsers ? (
                <div className="text-center py-8">Loading user data...</div>
              ) : adminUsers?.length > 0 ? (
                <div className="overflow-x-auto">
                  <table className="w-full text-sm text-left">
                    <thead className="text-xs uppercase bg-gray-50 dark:bg-gray-800">
                      <tr>
                        <th className="px-4 py-3">ID</th>
                        <th className="px-4 py-3">Username</th>
                        <th className="px-4 py-3">Name</th>
                        <th className="px-4 py-3">Email</th>
                        <th className="px-4 py-3">Plan</th>
                        <th className="px-4 py-3">Flow Score</th>
                        <th className="px-4 py-3">Streak Days</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-gray-200 dark:divide-gray-700">
                      {adminUsers.map((u) => (
                        <tr key={u.id} className="bg-white dark:bg-gray-900 hover:bg-gray-50 dark:hover:bg-gray-800">
                          <td className="px-4 py-3">{u.id}</td>
                          <td className="px-4 py-3">{u.username}</td>
                          <td className="px-4 py-3">{u.name}</td>
                          <td className="px-4 py-3">{u.email}</td>
                          <td className="px-4 py-3 capitalize">{u.plan}</td>
                          <td className="px-4 py-3">{u.flow_score}</td>
                          <td className="px-4 py-3">{u.streak_days}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              ) : (
                <div className="text-center py-8">No user data available</div>
              )}
            </CardContent>
          </Card>
        </TabsContent>
        
        <TabsContent value="tasks">
          <Card>
            <CardHeader>
              <CardTitle>Tasks</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-center py-8">
                Task data will be available soon
              </div>
            </CardContent>
          </Card>
        </TabsContent>
        
        <TabsContent value="events">
          <Card>
            <CardHeader>
              <CardTitle>Events</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-center py-8">
                Event data will be available soon
              </div>
            </CardContent>
          </Card>
        </TabsContent>
        
        <TabsContent value="errands">
          <Card>
            <CardHeader>
              <CardTitle>Errands</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-center py-8">
                Errand data will be available soon
              </div>
            </CardContent>
          </Card>
        </TabsContent>
        
        <TabsContent value="bills">
          <Card>
            <CardHeader>
              <CardTitle>Bills</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-center py-8">
                Bill data will be available soon
              </div>
            </CardContent>
          </Card>
        </TabsContent>
        
        <TabsContent value="rewards">
          <Card>
            <CardHeader>
              <CardTitle>Rewards</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-center py-8">
                Reward data will be available soon
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </AppLayout>
  );
}
