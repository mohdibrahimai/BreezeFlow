import React from 'react';
import { AppLayout } from '@/components/layout/app-layout';
import { BillList } from '@/components/ui/bill-list';
import { QuickAdd } from '@/components/ui/quick-add';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { useQuery } from '@tanstack/react-query';
import { CreditCard, CheckCircle, AlertTriangle, Clock } from 'lucide-react';
import { format, isBefore, parseISO, addDays } from 'date-fns';
import { Helmet } from 'react-helmet';

export default function BillsPage() {
  const { data: bills, isLoading } = useQuery({
    queryKey: ['/api/bills'],
  });

  // Calculate bill statistics
  const upcomingBills = bills?.filter(bill => bill.status === 'upcoming').length || 0;
  const paidBills = bills?.filter(bill => bill.status === 'paid').length || 0;
  
  // Calculate total amount due
  const totalDue = React.useMemo(() => {
    if (!bills) return 0;
    
    return bills
      .filter(bill => bill.status === 'upcoming' && bill.amount)
      .reduce((sum, bill) => sum + bill.amount, 0);
  }, [bills]);
  
  // Find bills due soon (within next 7 days)
  const dueSoonCount = React.useMemo(() => {
    if (!bills) return 0;
    
    const today = new Date();
    const nextWeek = addDays(today, 7);
    
    return bills.filter(bill => {
      if (!bill.due_date || bill.status !== 'upcoming') return false;
      
      try {
        const dueDate = parseISO(bill.due_date);
        return !isBefore(dueDate, today) && isBefore(dueDate, nextWeek);
      } catch (e) {
        return false;
      }
    }).length;
  }, [bills]);

  return (
    <AppLayout pageTitle="Bills">
      <Helmet>
        <title>Bills - BreezeFlow</title>
        <meta name="description" content="Manage your bills and payments with BreezeFlow's bill management system." />
      </Helmet>
      
      <div className="mb-6">
        <h1 className="text-2xl font-semibold text-gray-900 dark:text-white">Bills</h1>
        <p className="text-gray-600 dark:text-gray-400">Track and manage your bills and payments</p>
      </div>
      
      <div className="mb-6">
        <QuickAdd />
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-6">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium">Upcoming</CardTitle>
            <CreditCard className="h-4 w-4 text-primary" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{upcomingBills}</div>
            <p className="text-xs text-gray-500 dark:text-gray-400">Bills to pay</p>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium">Paid</CardTitle>
            <CheckCircle className="h-4 w-4 text-green-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{paidBills}</div>
            <p className="text-xs text-gray-500 dark:text-gray-400">Bills paid</p>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium">Total Due</CardTitle>
            <AlertTriangle className="h-4 w-4 text-red-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              {new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD' }).format(totalDue)}
            </div>
            <p className="text-xs text-gray-500 dark:text-gray-400">Amount due</p>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium">Due Soon</CardTitle>
            <Clock className="h-4 w-4 text-amber-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{dueSoonCount}</div>
            <p className="text-xs text-gray-500 dark:text-gray-400">Due within 7 days</p>
          </CardContent>
        </Card>
      </div>
      
      <BillList />
    </AppLayout>
  );
}
