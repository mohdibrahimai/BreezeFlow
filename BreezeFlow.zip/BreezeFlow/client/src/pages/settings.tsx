import React, { useState, useEffect } from 'react';
import { AppLayout } from '@/components/layout/app-layout';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Switch } from '@/components/ui/switch';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { useAuth } from '@/hooks/use-auth';
import { useMutation, useQueryClient, useQuery } from '@tanstack/react-query';
import { apiRequest } from '@/lib/queryClient';
import { useToast } from '@/hooks/use-toast';
import { CalendarImportExport } from '@/components/ui/calendar-import-export';
import { SubscriptionStatus } from '@/components/ui/SubscriptionStatus';
import { PaymentHistory } from '@/components/ui/PaymentHistory';
import { 
  User, 
  Bell, 
  Lock, 
  CreditCard, 
  Calendar, 
  Mail, 
  Save,
  LogOut,
  Moon,
  Sun,
  Loader2,
  RefreshCw
} from 'lucide-react';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { useTheme } from 'next-themes';
import { Helmet } from 'react-helmet';
import { useLocation } from 'wouter';

export default function SettingsPage() {
  const { user, logoutMutation } = useAuth();
  const { toast } = useToast();
  const { theme, setTheme } = useTheme();
  const queryClient = useQueryClient();
  const [location, setLocation] = useLocation();
  
  // Check for query parameters that indicate calendar connection status
  const searchParams = typeof window !== 'undefined' ? new URLSearchParams(window.location.search) : new URLSearchParams();
  const googleCalendarConnected = searchParams.get('googleCalendarConnected') === 'true';
  const googleCalendarError = searchParams.get('googleCalendarError') === 'true';
  
  // If we have query parameters, show toast notifications and cleanup the URL
  useEffect(() => {
    if (googleCalendarConnected || googleCalendarError) {
      if (googleCalendarConnected) {
        toast({
          title: 'Google Calendar Connected',
          description: 'Your Google Calendar has been successfully connected.',
        });
      } else if (googleCalendarError) {
        toast({
          title: 'Google Calendar Error',
          description: 'There was an error connecting to Google Calendar. Please try again.',
          variant: 'destructive',
        });
      }
      
      // Clean up URL parameters
      setLocation('/settings');
    }
  }, [googleCalendarConnected, googleCalendarError, toast, setLocation]);
  
  const [profileData, setProfileData] = useState({
    name: user?.name || '',
    email: user?.email || '',
    hourly_rate: user?.hourly_rate || 60,
    currency: user?.currency || 'USD',
    pref_reduce_motion: user?.pref_reduce_motion || false,
  });
  
  const [notificationSettings, setNotificationSettings] = useState({
    emailNotifications: true,
    taskReminders: true,
    billReminders: true,
    achievementNotifications: true,
  });
  
  // Load calendar integration status
  const { data: calendarStatus, isLoading: isLoadingCalendarStatus, error: calendarStatusError } = useQuery({
    queryKey: ['/api/calendar/status'],
    queryFn: async () => {
      const res = await apiRequest('GET', '/api/calendar/status');
      if (!res.ok) throw new Error('Failed to fetch calendar status');
      return res.json();
    },
    enabled: !!user,
  });
  
  const updateProfileMutation = useMutation({
    mutationFn: async (data: any) => {
      const res = await apiRequest('PUT', `/api/user/${user?.id}`, data);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/user'] });
      toast({
        title: 'Profile updated',
        description: 'Your profile information has been updated successfully.',
      });
    },
    onError: (error) => {
      toast({
        title: 'Error updating profile',
        description: error.message,
        variant: 'destructive',
      });
    },
  });
  
  const handleProfileSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    updateProfileMutation.mutate(profileData);
  };
  
  const handleNotificationSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    toast({
      title: 'Notification settings saved',
      description: 'Your notification preferences have been updated.',
    });
  };
  
  const handleIntegrationSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    toast({
      title: 'Integration settings saved',
      description: 'Your integration preferences have been updated.',
    });
  };
  
  const [billingPeriod, setBillingPeriod] = useState<'monthly' | 'annual'>('monthly');
  
  const handlePlanChange = (plan: string) => {
    // If they selected the current plan, do nothing
    if (plan === user?.plan) {
      toast({
        title: 'Current Plan',
        description: `You are already on the ${plan} plan.`,
      });
      return;
    }
    
    // If they're downgrading to free, handle that separately
    if (plan === 'free') {
      toast({
        title: 'Downgrade Initiated',
        description: 'Your plan will be downgraded at the end of your current billing period.',
      });
      // In a real app, we would call the API to cancel the subscription here
      return;
    }
    
    // For upgrades, navigate to checkout page with the selected plan and billing period
    const planParam = encodeURIComponent(plan);
    const periodParam = encodeURIComponent(billingPeriod);
    window.location.href = `/checkout?plan=${planParam}&billingPeriod=${periodParam}`;
  };
  
  const handleThemeChange = (newTheme: string) => {
    setTheme(newTheme);
  };

  return (
    <AppLayout pageTitle="Settings">
      <Helmet>
        <title>Settings - BreezeFlow</title>
        <meta name="description" content="Manage your account settings, integrations, and preferences in BreezeFlow." />
      </Helmet>
      
      <div className="mb-6">
        <h1 className="text-2xl font-semibold text-gray-900 dark:text-white">Settings</h1>
        <p className="text-gray-600 dark:text-gray-400">Manage your account and preferences</p>
      </div>
      
      <Tabs defaultValue="profile" className="space-y-6">
        <TabsList className="w-full justify-start border-b pb-0">
          <TabsTrigger value="profile" className="data-[state=active]:border-b-2 data-[state=active]:border-primary">
            <User className="h-4 w-4 mr-2" /> Profile
          </TabsTrigger>
          <TabsTrigger value="notifications" className="data-[state=active]:border-b-2 data-[state=active]:border-primary">
            <Bell className="h-4 w-4 mr-2" /> Notifications
          </TabsTrigger>
          <TabsTrigger value="integrations" className="data-[state=active]:border-b-2 data-[state=active]:border-primary">
            <Calendar className="h-4 w-4 mr-2" /> Integrations
          </TabsTrigger>
          <TabsTrigger value="billing" className="data-[state=active]:border-b-2 data-[state=active]:border-primary">
            <CreditCard className="h-4 w-4 mr-2" /> Billing
          </TabsTrigger>
          <TabsTrigger value="appearance" className="data-[state=active]:border-b-2 data-[state=active]:border-primary">
            <Sun className="h-4 w-4 mr-2" /> Appearance
          </TabsTrigger>
        </TabsList>
        
        {/* Profile Settings */}
        <TabsContent value="profile">
          <Card>
            <CardHeader>
              <CardTitle>Profile Settings</CardTitle>
              <CardDescription>Manage your personal information</CardDescription>
            </CardHeader>
            <CardContent>
              <form onSubmit={handleProfileSubmit} className="space-y-6">
                <div className="flex items-center space-x-4">
                  <Avatar className="h-16 w-16">
                    <AvatarImage src={`https://api.dicebear.com/7.x/initials/svg?seed=${user?.name}`} />
                    <AvatarFallback>{user?.name?.charAt(0)}</AvatarFallback>
                  </Avatar>
                  <div>
                    <p className="text-sm font-medium text-gray-900 dark:text-white">{user?.name}</p>
                    <p className="text-sm text-gray-500 dark:text-gray-400">{user?.email}</p>
                    <p className="text-xs text-gray-500 dark:text-gray-400 mt-1 capitalize">{user?.plan} Plan</p>
                  </div>
                </div>
                
                <div className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="name">Full Name</Label>
                    <Input 
                      id="name" 
                      value={profileData.name} 
                      onChange={(e) => setProfileData({ ...profileData, name: e.target.value })} 
                    />
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="email">Email Address</Label>
                    <Input 
                      id="email" 
                      type="email" 
                      value={profileData.email} 
                      onChange={(e) => setProfileData({ ...profileData, email: e.target.value })} 
                    />
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="username">Username</Label>
                    <Input 
                      id="username" 
                      value={user?.username} 
                      disabled 
                    />
                    <p className="text-xs text-gray-500 dark:text-gray-400">Username cannot be changed</p>
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="hourly_rate">Your Hourly Rate</Label>
                    <div className="flex">
                      <Select 
                        value={profileData.currency} 
                        onValueChange={(value) => setProfileData({ ...profileData, currency: value })}
                      >
                        <SelectTrigger className="w-24">
                          <SelectValue placeholder="Currency" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="USD">USD ($)</SelectItem>
                          <SelectItem value="EUR">EUR (€)</SelectItem>
                          <SelectItem value="GBP">GBP (£)</SelectItem>
                          <SelectItem value="INR">INR (₹)</SelectItem>
                          <SelectItem value="JPY">JPY (¥)</SelectItem>
                          <SelectItem value="CAD">CAD ($)</SelectItem>
                          <SelectItem value="AUD">AUD ($)</SelectItem>
                        </SelectContent>
                      </Select>
                      <Input 
                        id="hourly_rate" 
                        type="number"
                        min="0"
                        step="0.01"
                        value={profileData.hourly_rate} 
                        onChange={(e) => setProfileData({ ...profileData, hourly_rate: parseFloat(e.target.value) })} 
                        className="flex-1 ml-2"
                      />
                    </div>
                    <p className="text-xs text-gray-500 dark:text-gray-400">
                      Used to calculate how much money BreezeFlow is saving you in the ROI Dashboard
                    </p>
                  </div>
                  
                  <div className="flex items-center justify-between pt-4">
                    <div>
                      <Label htmlFor="reduce_motion" className="mb-2 block">Reduce Motion Effects</Label>
                      <div className="flex items-center">
                        <Switch 
                          id="reduce_motion" 
                          checked={profileData.pref_reduce_motion}
                          onCheckedChange={(checked) => 
                            setProfileData({ ...profileData, pref_reduce_motion: checked })
                          }
                          className="mr-2"
                        />
                        <span className="text-sm text-gray-500 dark:text-gray-400">
                          Replace animations with simpler visual effects
                        </span>
                      </div>
                    </div>
                  </div>
                </div>
                
                <div className="flex justify-between items-center pt-4">
                  <Button 
                    type="button" 
                    variant="destructive" 
                    onClick={() => logoutMutation.mutate()}
                    disabled={logoutMutation.isPending}
                  >
                    <LogOut className="h-4 w-4 mr-2" />
                    {logoutMutation.isPending ? 'Logging out...' : 'Log Out'}
                  </Button>
                  
                  <Button 
                    type="submit"
                    disabled={updateProfileMutation.isPending}
                  >
                    <Save className="h-4 w-4 mr-2" />
                    {updateProfileMutation.isPending ? 'Saving...' : 'Save Changes'}
                  </Button>
                </div>
              </form>
            </CardContent>
          </Card>
        </TabsContent>
        
        {/* Notification Settings */}
        <TabsContent value="notifications">
          <Card>
            <CardHeader>
              <CardTitle>Notification Settings</CardTitle>
              <CardDescription>Configure how and when you receive notifications</CardDescription>
            </CardHeader>
            <CardContent>
              <form onSubmit={handleNotificationSubmit} className="space-y-6">
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <div className="space-y-0.5">
                      <Label htmlFor="email-notifications">Email Notifications</Label>
                      <p className="text-sm text-gray-500 dark:text-gray-400">Receive notifications via email</p>
                    </div>
                    <Switch 
                      id="email-notifications" 
                      checked={notificationSettings.emailNotifications}
                      onCheckedChange={(checked) => 
                        setNotificationSettings({ ...notificationSettings, emailNotifications: checked })
                      }
                    />
                  </div>
                  
                  <div className="flex items-center justify-between">
                    <div className="space-y-0.5">
                      <Label htmlFor="task-reminders">Task Reminders</Label>
                      <p className="text-sm text-gray-500 dark:text-gray-400">Get reminded about upcoming and due tasks</p>
                    </div>
                    <Switch 
                      id="task-reminders" 
                      checked={notificationSettings.taskReminders}
                      onCheckedChange={(checked) => 
                        setNotificationSettings({ ...notificationSettings, taskReminders: checked })
                      }
                    />
                  </div>
                  
                  <div className="flex items-center justify-between">
                    <div className="space-y-0.5">
                      <Label htmlFor="bill-reminders">Bill Reminders</Label>
                      <p className="text-sm text-gray-500 dark:text-gray-400">Get reminded about upcoming bills and payments</p>
                    </div>
                    <Switch 
                      id="bill-reminders" 
                      checked={notificationSettings.billReminders}
                      onCheckedChange={(checked) => 
                        setNotificationSettings({ ...notificationSettings, billReminders: checked })
                      }
                    />
                  </div>
                  
                  <div className="flex items-center justify-between">
                    <div className="space-y-0.5">
                      <Label htmlFor="achievement-notifications">Achievement Notifications</Label>
                      <p className="text-sm text-gray-500 dark:text-gray-400">Get notified when you earn badges and rewards</p>
                    </div>
                    <Switch 
                      id="achievement-notifications" 
                      checked={notificationSettings.achievementNotifications}
                      onCheckedChange={(checked) => 
                        setNotificationSettings({ ...notificationSettings, achievementNotifications: checked })
                      }
                    />
                  </div>
                </div>
                
                <div className="flex justify-end pt-4">
                  <Button type="submit">
                    <Save className="h-4 w-4 mr-2" />
                    Save Notification Settings
                  </Button>
                </div>
              </form>
            </CardContent>
          </Card>
        </TabsContent>
        
        {/* Integration Settings */}
        <TabsContent value="integrations">
          <Card>
            <CardHeader>
              <CardTitle>Integrations</CardTitle>
              <CardDescription>Connect your accounts with third-party services</CardDescription>
            </CardHeader>
            <CardContent>
              <form onSubmit={handleIntegrationSubmit} className="space-y-6">
                <div className="space-y-4">
                  <h3 className="text-sm font-medium text-gray-900 dark:text-white mb-4">Calendar Management</h3>
                  
                  {/* iCalendar Import/Export Component */}
                  <CalendarImportExport />
                  
                  <div className="mt-8 mb-4">
                    <h3 className="text-sm font-medium text-gray-900 dark:text-white">External Calendar Connections</h3>
                    <p className="text-xs text-gray-500 dark:text-gray-400 mt-1 mb-4">
                      Connect to external calendar services (optional)
                    </p>
                  </div>
                  
                  <div className="flex items-center justify-between pl-4 mb-4">
                    <div className="flex items-center">
                      <svg className="h-6 w-6 mr-2" viewBox="0 0 24 24" fill="#4285F4">
                        <path d="M12 0C5.372 0 0 5.372 0 12s5.372 12 12 12 12-5.372 12-12S18.628 0 12 0zm.14 19.018c-3.868 0-7-3.14-7-7.018 0-3.878 3.132-7.018 7-7.018 1.89 0 3.47.697 4.682 1.829l-1.974 1.978v-.004c-.735-.702-1.667-1.062-2.708-1.062-2.31 0-4.187 1.956-4.187 4.273 0 2.315 1.877 4.277 4.187 4.277 2.096 0 3.522-1.202 3.816-2.852H12.14v-2.737h6.585c.088.47.135.96.135 1.474 0 4.01-2.677 6.86-6.72 6.86z"/>
                      </svg>
                      <div>
                        <span>Google Calendar</span>
                        {calendarStatus?.googleCalendarConnected && (
                          <Badge variant="outline" className="ml-2 text-xs bg-green-50 text-green-700 border-green-200">
                            Connected
                          </Badge>
                        )}
                      </div>
                    </div>
                    {isLoadingCalendarStatus ? (
                      <Button type="button" variant="outline" size="sm" disabled>
                        <Loader2 className="h-4 w-4 animate-spin mr-2" />
                        Loading...
                      </Button>
                    ) : calendarStatus?.googleCalendarConnected ? (
                      <div className="flex space-x-2">
                        <Button 
                          type="button" 
                          variant="outline" 
                          size="sm"
                          onClick={async () => {
                            try {
                              const res = await apiRequest('POST', '/api/calendar/google/sync');
                              if (!res.ok) throw new Error('Failed to sync calendar');
                              const data = await res.json();
                              toast({
                                title: 'Calendar Synced',
                                description: `Successfully synced ${data.eventsCount} events.`,
                              });
                            } catch (error) {
                              toast({
                                title: 'Sync Failed',
                                description: error instanceof Error ? error.message : 'Unknown error',
                                variant: 'destructive',
                              });
                            }
                          }}
                        >
                          <RefreshCw className="h-4 w-4 mr-2" />
                          Sync
                        </Button>
                        <Button 
                          type="button" 
                          variant="outline" 
                          size="sm"
                          onClick={async () => {
                            if (window.confirm('Are you sure you want to disconnect Google Calendar?')) {
                              try {
                                const res = await apiRequest('POST', '/api/calendar/google/disconnect');
                                if (!res.ok) throw new Error('Failed to disconnect calendar');
                                queryClient.invalidateQueries({ queryKey: ['/api/calendar/status'] });
                                toast({
                                  title: 'Disconnected',
                                  description: 'Google Calendar has been disconnected.',
                                });
                              } catch (error) {
                                toast({
                                  title: 'Disconnect Failed',
                                  description: error instanceof Error ? error.message : 'Unknown error',
                                  variant: 'destructive',
                                });
                              }
                            }
                          }}
                        >
                          Disconnect
                        </Button>
                      </div>
                    ) : (
                      <Button 
                        type="button" 
                        variant="outline" 
                        size="sm"
                        onClick={async () => {
                          try {
                            const res = await apiRequest('GET', '/api/calendar/google/auth-url');
                            if (!res.ok) throw new Error('Failed to get auth URL');
                            const { url } = await res.json();
                            // Open authorization URL in a new window
                            window.location.href = url;
                          } catch (error) {
                            toast({
                              title: 'Connection Failed',
                              description: error instanceof Error ? error.message : 'Unknown error',
                              variant: 'destructive',
                            });
                          }
                        }}
                      >
                        Connect
                      </Button>
                    )}
                  </div>
                  
                  <h3 className="text-sm font-medium text-gray-900 dark:text-white pt-4">Payment Integrations</h3>
                  
                  <div className="flex items-center justify-between pl-4">
                    <div className="flex items-center">
                      <svg className="h-6 w-6 mr-2" viewBox="0 0 24 24" fill="#635BFF">
                        <path d="M12 0C5.372 0 0 5.372 0 12s5.372 12 12 12 12-5.372 12-12S18.628 0 12 0zm-1.586 15.586c-.84.84-1.965 1.302-3.157 1.302-2.475 0-4.48-2.01-4.48-4.474 0-2.465 2.005-4.47 4.47-4.47 1.196 0 2.316.465 3.162 1.307l-.668.668c-.672-.672-1.565-1.043-2.515-1.043-1.97 0-3.57 1.596-3.57 3.56 0 1.965 1.6 3.56 3.57 3.56.943 0 1.832-.368 2.5-1.036l.67.67-.002-.005zM15.032 11h-2.39V9.5h3.897v.576L13.633 14.5h-1.03l2.43-3.5z"/>
                      </svg>
                      <span>Stripe</span>
                    </div>
                    <Button 
                      type="button" 
                      variant="outline" 
                      size="sm"
                      disabled
                    >
                      Coming Soon
                    </Button>
                  </div>
                  
                  <div className="flex items-center justify-between pl-4">
                    <div className="flex items-center">
                      <svg className="h-6 w-6 mr-2" viewBox="0 0 24 24" fill="#00B8D4">
                        <path d="M12 0C5.372 0 0 5.372 0 12s5.372 12 12 12 12-5.372 12-12S18.628 0 12 0zm5.694 15.727c-.78.78-1.866 1.245-3.075 1.245-2.398 0-4.342-1.946-4.342-4.34 0-2.4 1.944-4.347 4.342-4.347 1.21 0 2.296.465 3.096 1.263L16.52 10.74c-.54-.54-1.27-.84-2.04-.84-1.593 0-2.887 1.29-2.887 2.888 0 1.592 1.294 2.886 2.887 2.886.77 0 1.5-.3 2.042-.843l1.17 1.17.002-.002z"/>
                      </svg>
                      <span>Plaid</span>
                    </div>
                    <Button 
                      type="button" 
                      variant="outline" 
                      size="sm"
                      disabled
                    >
                      Coming Soon
                    </Button>
                  </div>
                  
                  <h3 className="text-sm font-medium text-gray-900 dark:text-white pt-4">Shopping Integrations</h3>
                  
                  <div className="flex items-center justify-between pl-4">
                    <div className="flex items-center">
                      <svg className="h-6 w-6 mr-2" viewBox="0 0 24 24" fill="#FF9900">
                        <path d="M12 0C5.372 0 0 5.372 0 12s5.372 12 12 12 12-5.372 12-12S18.628 0 12 0zm6.324 14.748c-.708.432-1.356.612-2.004.612-1.332 0-2.244-.54-2.244-1.932v-3.972h4.428V7.32h-4.428V3.384L9.852 5.16v2.16H8.256v2.136h1.596v4.296c0 2.676 1.62 4.08 4.428 4.08 1.224 0 2.304-.396 3.228-1.068l-1.356-1.884c.18-.12.03-.12.172-.132z"/>
                      </svg>
                      <span>Amazon</span>
                    </div>
                    <Button 
                      type="button" 
                      variant="outline" 
                      size="sm"
                      disabled
                    >
                      Coming Soon
                    </Button>
                  </div>
                  
                  <div className="flex items-center justify-between pl-4">
                    <div className="flex items-center">
                      <svg className="h-6 w-6 mr-2" viewBox="0 0 24 24" fill="#43B02A">
                        <path d="M12 0C5.372 0 0 5.372 0 12s5.372 12 12 12 12-5.372 12-12S18.628 0 12 0zm0 16.364c-2.402 0-4.364-1.962-4.364-4.364 0-2.402 1.962-4.364 4.364-4.364 2.402 0 4.364 1.962 4.364 4.364 0 2.402-1.962 4.364-4.364 4.364zm0-7.637c-1.807 0-3.272 1.465-3.272 3.272 0 1.807 1.465 3.272 3.272 3.272 1.807 0 3.272-1.465 3.272-3.272 0-1.807-1.465-3.272-3.272-3.272z"/>
                      </svg>
                      <span>Instacart</span>
                    </div>
                    <Button 
                      type="button" 
                      variant="outline" 
                      size="sm"
                      disabled
                    >
                      Coming Soon
                    </Button>
                  </div>
                </div>
                
                <div className="flex justify-end pt-4">
                  <Button type="submit">
                    <Save className="h-4 w-4 mr-2" />
                    Save Integration Settings
                  </Button>
                </div>
              </form>
            </CardContent>
          </Card>
        </TabsContent>
        
        {/* Billing Settings */}
        <TabsContent value="billing">
          <Card>
            <CardHeader>
              <CardTitle>Billing & Subscription</CardTitle>
              <CardDescription>Manage your subscription plan and payment methods</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-6">
                <div className="space-y-4 mb-6">
                  <SubscriptionStatus onUpgrade={() => window.location.href = '/pricing'} />
                </div>
                
                {/* Current Usage Section */}
                <div className="space-y-3">
                  <h3 className="text-sm font-medium text-gray-900 dark:text-white">Current Usage</h3>
                  <div className="p-4 border rounded-md">
                    <div className="flex justify-between mb-2">
                      <span className="text-sm text-gray-600 dark:text-gray-400">Monthly Actions</span>
                      <span className="text-sm font-medium">
                        {user?.plan === 'free' && '23/75'}
                        {user?.plan === 'starter' && '210/750'}
                        {(user?.plan === 'pro' || user?.plan === 'team') && 'Unlimited'}
                      </span>
                    </div>
                    {(user?.plan === 'free' || user?.plan === 'starter') && (
                      <Progress 
                        value={user?.plan === 'free' ? (23/75)*100 : (210/750)*100} 
                        className="h-2" 
                      />
                    )}
                    {(user?.plan === 'free' || user?.plan === 'starter') && (
                      <p className="text-xs mt-1 text-gray-500 dark:text-gray-400">
                        {user?.plan === 'free' ? 'Upgrade to get 10x more actions' : 'Upgrade to get unlimited actions'}
                      </p>
                    )}
                  </div>
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="subscription-plan">Change Plan</Label>
                  <Select 
                    defaultValue={user?.plan} 
                    onValueChange={handlePlanChange}
                  >
                    <SelectTrigger id="subscription-plan">
                      <SelectValue placeholder="Select a plan" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="free">Free Plan</SelectItem>
                      <SelectItem value="starter">
                        Starter Plan ({billingPeriod === 'monthly' ? '$6/month' : '$60/year (2 months free)'})
                      </SelectItem>
                      <SelectItem value="pro">
                        Pro Plan ({billingPeriod === 'monthly' ? '$16.85/month' : '$168.50/year (2 months free)'})
                      </SelectItem>
                      <SelectItem value="team">
                        Team Plan ({billingPeriod === 'monthly' ? '$10.85/user/month' : '$108.50/user/year (2 months free)'})
                      </SelectItem>
                    </SelectContent>
                  </Select>
                  
                  <div className="space-y-4 mt-3">
                    <div className="flex items-center justify-between">
                      <Label htmlFor="billing-period">Billing Period</Label>
                      <div className="flex items-center space-x-2">
                        <span className={`text-sm ${billingPeriod === 'monthly' ? 'font-medium' : 'text-gray-500'}`}>Monthly</span>
                        <Switch 
                          id="billing-period" 
                          checked={billingPeriod === 'annual'}
                          onCheckedChange={(checked) => 
                            setBillingPeriod(checked ? 'annual' : 'monthly')
                          }
                        />
                        <span className={`text-sm ${billingPeriod === 'annual' ? 'font-medium' : 'text-gray-500'}`}>
                          Annual <Badge className="ml-1 bg-green-100 text-green-800 dark:bg-green-900/30 dark:text-green-400">Save 16%</Badge>
                        </span>
                      </div>
                    </div>
                    
                    <div className="flex items-center">
                      <Button 
                        variant="link" 
                        className="p-0 h-auto text-xs underline" 
                        onClick={() => window.location.href = '/pricing'}
                      >
                        View detailed pricing information
                      </Button>
                    </div>
                  </div>
                </div>
                
                <div className="pt-4">
                  <h3 className="text-sm font-medium text-gray-900 dark:text-white mb-2">Payment Methods</h3>
                  {user?.plan === 'free' ? (
                    <div className="text-sm text-gray-500 dark:text-gray-400">
                      No payment methods needed with the Free plan.
                    </div>
                  ) : (
                    <div className="p-4 border rounded-md">
                      <div className="flex justify-between items-center">
                        <div className="flex items-center">
                          <CreditCard className="h-5 w-5 mr-2 text-gray-500" />
                          <div>
                            <p className="text-sm font-medium">•••• •••• •••• 4242</p>
                            <p className="text-xs text-gray-500 dark:text-gray-400">Expires 12/2025</p>
                          </div>
                        </div>
                        <Button variant="outline" size="sm">Edit</Button>
                      </div>
                    </div>
                  )}
                </div>
                
                <div className="pt-4">
                  <PaymentHistory />
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
        
        {/* Appearance Settings */}
        <TabsContent value="appearance">
          <Card>
            <CardHeader>
              <CardTitle>Appearance</CardTitle>
              <CardDescription>Customize how BreezeFlow looks</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-6">
                <div className="space-y-2">
                  <Label htmlFor="theme">Theme</Label>
                  <div className="grid grid-cols-3 gap-4">
                    <div 
                      className={`p-4 border rounded-md cursor-pointer flex flex-col items-center ${theme === 'light' ? 'border-primary bg-primary-50 dark:bg-primary-900/20' : 'border-gray-200 dark:border-gray-700'}`}
                      onClick={() => handleThemeChange('light')}
                    >
                      <Sun className="h-8 w-8 mb-2 text-amber-500" />
                      <span className="text-sm font-medium">Light</span>
                    </div>
                    
                    <div 
                      className={`p-4 border rounded-md cursor-pointer flex flex-col items-center ${theme === 'dark' ? 'border-primary bg-primary-50 dark:bg-primary-900/20' : 'border-gray-200 dark:border-gray-700'}`}
                      onClick={() => handleThemeChange('dark')}
                    >
                      <Moon className="h-8 w-8 mb-2 text-indigo-500" />
                      <span className="text-sm font-medium">Dark</span>
                    </div>
                    
                    <div 
                      className={`p-4 border rounded-md cursor-pointer flex flex-col items-center ${theme === 'system' ? 'border-primary bg-primary-50 dark:bg-primary-900/20' : 'border-gray-200 dark:border-gray-700'}`}
                      onClick={() => handleThemeChange('system')}
                    >
                      <svg className="h-8 w-8 mb-2 text-gray-500" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9.75 17L9 20l-1 1h8l-1-1-.75-3M3 13h18M5 17h14a2 2 0 002-2V5a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z" />
                      </svg>
                      <span className="text-sm font-medium">System</span>
                    </div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </AppLayout>
  );
}
