import React from 'react';
import { AppLayout } from '@/components/layout/app-layout';
import { TaskBoard } from '@/components/ui/task-board';
import { QuickAdd } from '@/components/ui/quick-add';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { useQuery } from '@tanstack/react-query';
import { 
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell
} from 'recharts';
import { Helmet } from 'react-helmet';

export default function TasksPage() {
  const { data: tasks, isLoading } = useQuery({
    queryKey: ['/api/tasks'],
  });

  // Calculate task statistics
  const tasksByStatus = React.useMemo(() => {
    if (!tasks) return [];
    
    const counts = {
      backlog: tasks.filter(t => t.status === 'backlog').length,
      today: tasks.filter(t => t.status === 'today').length,
      done: tasks.filter(t => t.status === 'done').length,
    };
    
    return [
      { name: 'Backlog', value: counts.backlog },
      { name: 'Today', value: counts.today },
      { name: 'Done', value: counts.done },
    ];
  }, [tasks]);
  
  const tasksByPriority = React.useMemo(() => {
    if (!tasks) return [];
    
    const counts = {
      high: tasks.filter(t => t.priority === 'high').length,
      medium: tasks.filter(t => t.priority === 'medium').length,
      low: tasks.filter(t => t.priority === 'low').length,
    };
    
    return [
      { name: 'High', value: counts.high },
      { name: 'Medium', value: counts.medium },
      { name: 'Low', value: counts.low },
    ];
  }, [tasks]);
  
  // Colors for charts
  const statusColors = ['#9CA3AF', '#3B82F6', '#10B981'];
  const priorityColors = ['#EF4444', '#3B82F6', '#10B981'];

  return (
    <AppLayout pageTitle="Tasks">
      <Helmet>
        <title>Tasks - BreezeFlow</title>
        <meta name="description" content="Manage your tasks with BreezeFlow's intuitive kanban board system." />
      </Helmet>
      
      <div className="mb-6">
        <h1 className="text-2xl font-semibold text-gray-900 dark:text-white">Tasks</h1>
        <p className="text-gray-600 dark:text-gray-400">Manage and organize your tasks efficiently</p>
      </div>
      
      <div className="mb-6">
        <QuickAdd />
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-lg font-medium">Tasks by Status</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="h-64">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart
                  data={tasksByStatus}
                  margin={{
                    top: 20,
                    right: 30,
                    left: 20,
                    bottom: 5,
                  }}
                >
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="name" />
                  <YAxis allowDecimals={false} />
                  <Tooltip 
                    formatter={(value) => [`${value} tasks`, 'Count']}
                    contentStyle={{ 
                      backgroundColor: 'rgba(255, 255, 255, 0.9)',
                      borderColor: '#e2e8f0',
                    }}
                  />
                  <Bar dataKey="value" fill="#3B82F6">
                    {tasksByStatus.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={statusColors[index % statusColors.length]} />
                    ))}
                  </Bar>
                </BarChart>
              </ResponsiveContainer>
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-lg font-medium">Tasks by Priority</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="h-64">
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie
                    data={tasksByPriority}
                    cx="50%"
                    cy="50%"
                    labelLine={false}
                    label={({ name, percent }) => `${name}: ${(percent * 100).toFixed(0)}%`}
                    outerRadius={80}
                    fill="#8884d8"
                    dataKey="value"
                  >
                    {tasksByPriority.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={priorityColors[index % priorityColors.length]} />
                    ))}
                  </Pie>
                  <Tooltip 
                    formatter={(value) => [`${value} tasks`, 'Count']}
                    contentStyle={{ 
                      backgroundColor: 'rgba(255, 255, 255,.9)',
                      borderColor: '#e2e8f0',
                    }}
                  />
                </PieChart>
              </ResponsiveContainer>
            </div>
          </CardContent>
        </Card>
      </div>
      
      <TaskBoard />
    </AppLayout>
  );
}
