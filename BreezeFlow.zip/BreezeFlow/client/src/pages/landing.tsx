import React from 'react';
import { Link, useLocation } from 'wouter';
import { AppLogo } from '@/components/ui/app-logo';
import { Button } from '@/components/ui/button';
import { useAuth } from '@/hooks/use-auth';
import { Helmet } from 'react-helmet';

export default function LandingPage() {
  const { user } = useAuth();
  const [, navigate] = useLocation();

  return (
    <>
      <Helmet>
        <title>BreezeFlow - Turn Chaos into Flow</title>
        <meta name="description" content="An all-in-one, fully automated life-manager that merges calendars, to-dos, bill payments, errands, and gamified productivity into one portal." />
      </Helmet>

      {/* Header/Navigation */}
      <header className="bg-white shadow-sm dark:bg-gray-900 dark:border-b dark:border-gray-800">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between h-16">
            <div className="flex items-center">
              <AppLogo />
              <nav className="hidden md:ml-6 md:flex md:space-x-8">
                <a href="#features" className="inline-flex items-center px-1 pt-1 text-sm font-medium text-gray-500 hover:text-gray-900 dark:text-gray-400 dark:hover:text-white">Features</a>
                <a href="#pricing" className="inline-flex items-center px-1 pt-1 text-sm font-medium text-gray-500 hover:text-gray-900 dark:text-gray-400 dark:hover:text-white">Pricing</a>
                <a href="#testimonials" className="inline-flex items-center px-1 pt-1 text-sm font-medium text-gray-500 hover:text-gray-900 dark:text-gray-400 dark:hover:text-white">Testimonials</a>
                <a href="#faq" className="inline-flex items-center px-1 pt-1 text-sm font-medium text-gray-500 hover:text-gray-900 dark:text-gray-400 dark:hover:text-white">FAQ</a>
              </nav>
            </div>
            <div className="flex items-center">
              {user ? (
                <Button onClick={() => navigate('/dashboard')}>Go to Dashboard</Button>
              ) : (
                <>
                  <Button 
                    variant="ghost" 
                    onClick={() => navigate('/auth')}
                    className="text-primary-600 hover:text-primary-800 dark:text-primary-400 dark:hover:text-primary-300"
                  >
                    Log in
                  </Button>
                  <Button 
                    onClick={() => navigate('/auth')}
                    className="ml-3"
                  >
                    Sign up free
                  </Button>
                </>
              )}
            </div>
          </div>
        </div>
      </header>

      {/* Hero Section with Limited Time Offer */}
      <div className="relative bg-white overflow-hidden dark:bg-gray-900">
        {/* Limited-time offer banner */}
        <div className="absolute inset-x-0 top-0 z-20">
          <div className="bg-gradient-to-r from-indigo-600 to-purple-600 text-white py-2 text-center">
            <p className="text-sm font-medium">
              ✨ Limited Time Offer: Up to 15% off all plans until next update ✨ 
              <button 
                onClick={() => document.getElementById('pricing')?.scrollIntoView({behavior: 'smooth'})}
                className="ml-2 underline hover:no-underline"
              >
                View Plans →
              </button>
            </p>
          </div>
        </div>
        
        <div className="max-w-7xl mx-auto pt-6">
          <div className="relative z-10 pb-8 bg-white dark:bg-gray-900 sm:pb-16 md:pb-20 lg:max-w-2xl lg:w-full lg:pb-28 xl:pb-32">
            <main className="mt-10 mx-auto max-w-7xl px-4 sm:mt-12 sm:px-6 md:mt-16 lg:mt-20 lg:px-8 xl:mt-28">
              <div className="sm:text-center lg:text-left">
                <h1 className="text-4xl tracking-tight font-extrabold text-gray-900 dark:text-white sm:text-5xl md:text-6xl">
                  <span className="block">Turn Chaos</span>
                  <span className="block text-primary-600 dark:text-primary-500">into Flow</span>
                </h1>
                <p className="mt-3 text-base text-gray-500 dark:text-gray-400 sm:mt-5 sm:text-lg sm:max-w-xl sm:mx-auto md:mt-5 md:text-xl lg:mx-0">
                  Your AI-powered productivity assistant that turns chaos into organized brilliance. Manage tasks, bills, and events with smart automation.
                </p>
                
                {/* Features highlight */}
                <div className="mt-5 grid grid-cols-2 gap-2 text-sm md:flex md:gap-4">
                  <div className="flex items-center">
                    <svg className="h-5 w-5 text-green-500 mr-2" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor">
                      <path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd" />
                    </svg>
                    <span className="text-gray-600 dark:text-gray-300">Smart AI Assistant</span>
                  </div>
                  <div className="flex items-center">
                    <svg className="h-5 w-5 text-green-500 mr-2" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor">
                      <path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd" />
                    </svg>
                    <span className="text-gray-600 dark:text-gray-300">Calendar Sync</span>
                  </div>
                  <div className="flex items-center">
                    <svg className="h-5 w-5 text-green-500 mr-2" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor">
                      <path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd" />
                    </svg>
                    <span className="text-gray-600 dark:text-gray-300">Bill Tracking</span>
                  </div>
                  <div className="flex items-center">
                    <svg className="h-5 w-5 text-green-500 mr-2" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor">
                      <path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd" />
                    </svg>
                    <span className="text-gray-600 dark:text-gray-300">Gamified Tasks</span>
                  </div>
                </div>
                
                <div className="mt-5 sm:mt-8 sm:flex sm:justify-center lg:justify-start">
                  <div className="rounded-md shadow">
                    <Button 
                      size="lg"
                      onClick={() => navigate('/auth')}
                      className="w-full flex items-center justify-center px-8 py-3"
                    >
                      Start Free
                    </Button>
                  </div>
                  <div className="mt-3 sm:mt-0 sm:ml-3">
                    <Button 
                      size="lg" 
                      className="bg-primary-800 hover:bg-primary-700 text-white border-primary-800 hover:border-primary-700"
                      onClick={() => navigate('/pricing')}
                    >
                      View Plans
                    </Button>
                  </div>
                </div>
                
                <div className="mt-3 text-sm text-gray-500 dark:text-gray-400">
                  No credit card required. Cancel anytime.
                </div>
              </div>
            </main>
          </div>
        </div>
        <div className="lg:absolute lg:inset-y-0 lg:right-0 lg:w-1/2">
          <div className="relative h-56 w-full sm:h-72 md:h-96 lg:w-full lg:h-full">
            <img 
              className="h-full w-full object-cover" 
              src="https://images.unsplash.com/photo-1551288049-bebda4e38f71?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1050&h=700" 
              alt="Productivity dashboard" 
            />
            {/* Overlaid price badge */}
            <div className="absolute bottom-4 right-4 bg-white dark:bg-gray-800 rounded-lg shadow-lg p-3 transform rotate-3">
              <p className="text-xs font-semibold text-gray-500 dark:text-gray-400">Starting at</p>
              <p className="text-2xl font-bold text-primary-600 dark:text-primary-400">$6<span className="text-sm">/mo</span></p>
            </div>
          </div>
        </div>
      </div>

      {/* Features Section with AI Highlight */}
      <div id="features" className="py-16 bg-white dark:bg-gray-900">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="lg:text-center">
            <div className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-primary-100 text-primary-800 dark:bg-primary-800 dark:text-primary-100 mb-2">
              AI-Powered Productivity
            </div>
            <h2 className="mt-2 text-3xl leading-8 font-extrabold tracking-tight text-gray-900 dark:text-white sm:text-4xl">
              Let AI transform your productivity
            </h2>
            <p className="mt-4 max-w-2xl text-xl text-gray-500 dark:text-gray-400 lg:mx-auto">
              BreezeFlow combines AI, machine learning, and automation to revolutionize your work and personal life.
            </p>
          </div>

          <div className="mt-16">
            <div className="space-y-12 md:space-y-0 md:grid md:grid-cols-3 md:gap-x-8 md:gap-y-12">
              {/* Feature 1 */}
              <div className="relative bg-gray-50 dark:bg-gray-800 p-6 rounded-lg shadow-sm transition transform hover:-translate-y-1 hover:shadow-md">
                <div className="absolute -top-4 flex items-center justify-center h-12 w-12 rounded-md bg-gradient-to-br from-primary-500 to-indigo-600 text-white">
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9.663 17h4.673M12 3v1m6.364 1.636l-.707.707M21 12h-1M4 12H3m3.343-5.657l-.707-.707m2.828 9.9a5 5 0 117.072 0l-.548.547A3.374 3.374 0 0014 18.469V19a2 2 0 11-4 0v-.531c0-.895-.356-1.754-.988-2.386l-.548-.547z" />
                  </svg>
                </div>
                <div className="mt-2">
                  <h3 className="text-lg leading-6 font-medium text-gray-900 dark:text-white">Smart Priority Score</h3>
                  <p className="mt-2 text-base text-gray-500 dark:text-gray-400">
                    Our ML algorithm learns your patterns and prioritizes tasks for maximum efficiency and completion likelihood.
                  </p>
                  <span className="mt-3 inline-flex items-center text-sm font-medium text-primary-600 dark:text-primary-400">
                    New in Pro plan
                  </span>
                </div>
              </div>

              {/* Feature 2 */}
              <div className="relative bg-gray-50 dark:bg-gray-800 p-6 rounded-lg shadow-sm transition transform hover:-translate-y-1 hover:shadow-md">
                <div className="absolute -top-4 flex items-center justify-center h-12 w-12 rounded-md bg-gradient-to-br from-primary-500 to-indigo-600 text-white">
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 17h5l-1.405-1.405A2.032 2.032 0 0118 14.158V11a6.002 6.002 0 00-4-5.659V5a2 2 0 10-4 0v.341C7.67 6.165 6 8.388 6 11v3.159c0 .538-.214 1.055-.595 1.436L4 17h5m6 0v1a3 3 0 11-6 0v-1m6 0H9" />
                  </svg>
                </div>
                <div className="mt-2">
                  <h3 className="text-lg leading-6 font-medium text-gray-900 dark:text-white">BreezeMind AI Assistant</h3>
                  <p className="mt-2 text-base text-gray-500 dark:text-gray-400">
                    Our AI chat assistant helps you create tasks, generate schedules, and optimize your workflow with natural language.
                  </p>
                  <span className="mt-3 inline-flex items-center text-sm font-medium text-primary-600 dark:text-primary-400">
                    Available in all plans
                  </span>
                </div>
              </div>

              {/* Feature 3 */}
              <div className="relative bg-gray-50 dark:bg-gray-800 p-6 rounded-lg shadow-sm transition transform hover:-translate-y-1 hover:shadow-md">
                <div className="absolute -top-4 flex items-center justify-center h-12 w-12 rounded-md bg-gradient-to-br from-primary-500 to-indigo-600 text-white">
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z" />
                  </svg>
                </div>
                <div className="mt-2">
                  <h3 className="text-lg leading-6 font-medium text-gray-900 dark:text-white">Calendar Integration</h3>
                  <p className="mt-2 text-base text-gray-500 dark:text-gray-400">
                    Import and export iCal events, sync with your existing calendars, and get a unified view of your schedule.
                  </p>
                  <span className="mt-3 inline-flex items-center text-sm font-medium text-primary-600 dark:text-primary-400">
                    Enhanced in Starter+ plans
                  </span>
                </div>
              </div>

              {/* Feature 4 */}
              <div className="relative bg-gray-50 dark:bg-gray-800 p-6 rounded-lg shadow-sm transition transform hover:-translate-y-1 hover:shadow-md">
                <div className="absolute -top-4 flex items-center justify-center h-12 w-12 rounded-md bg-gradient-to-br from-primary-500 to-indigo-600 text-white">
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 10h18M7 15h1m4 0h1m-7 4h12a3 3 0 003-3V8a3 3 0 00-3-3H6a3 3 0 00-3 3v8a3 3 0 003 3z" />
                  </svg>
                </div>
                <div className="mt-2">
                  <h3 className="text-lg leading-6 font-medium text-gray-900 dark:text-white">Smart Bill Tracking</h3>
                  <p className="mt-2 text-base text-gray-500 dark:text-gray-400">
                    Track recurring bills, receive timely reminders, and get insights on your spending patterns.
                  </p>
                  <span className="mt-3 inline-flex items-center text-sm font-medium text-primary-600 dark:text-primary-400">
                    Pay alerts in Free, full features in Starter+
                  </span>
                </div>
              </div>

              {/* Feature 5 */}
              <div className="relative bg-gray-50 dark:bg-gray-800 p-6 rounded-lg shadow-sm transition transform hover:-translate-y-1 hover:shadow-md">
                <div className="absolute -top-4 flex items-center justify-center h-12 w-12 rounded-md bg-gradient-to-br from-primary-500 to-indigo-600 text-white">
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z" />
                  </svg>
                </div>
                <div className="mt-2">
                  <h3 className="text-lg leading-6 font-medium text-gray-900 dark:text-white">ROI Dashboard</h3>
                  <p className="mt-2 text-base text-gray-500 dark:text-gray-400">
                    See exactly how much time and money BreezeFlow saves you with our data-driven ROI tracking system.
                  </p>
                  <span className="mt-3 inline-flex items-center text-sm font-medium text-primary-600 dark:text-primary-400">
                    Exclusive to Starter+ plans
                  </span>
                </div>
              </div>

              {/* Feature 6 */}
              <div className="relative bg-gray-50 dark:bg-gray-800 p-6 rounded-lg shadow-sm transition transform hover:-translate-y-1 hover:shadow-md">
                <div className="absolute -top-4 flex items-center justify-center h-12 w-12 rounded-md bg-gradient-to-br from-primary-500 to-indigo-600 text-white">
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 3v4M3 5h4M6 17v4m-2-2h4m5-16l2.286 6.857L21 12l-5.714 2.143L13 21l-2.286-6.857L5 12l5.714-2.143L13 3z" />
                  </svg>
                </div>
                <div className="mt-2">
                  <h3 className="text-lg leading-6 font-medium text-gray-900 dark:text-white">Gamified Productivity</h3>
                  <p className="mt-2 text-base text-gray-500 dark:text-gray-400">
                    Stay motivated with points, badges, levels, and rewards as you complete tasks and improve your productivity.
                  </p>
                  <span className="mt-3 inline-flex items-center text-sm font-medium text-primary-600 dark:text-primary-400">
                    Basic in Free, enhanced in paid plans
                  </span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Pricing Section with Limited Time Offer */}
      <div id="pricing" className="bg-gradient-to-b from-gray-50 to-gray-100 dark:from-gray-900 dark:to-gray-800 py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <div className="inline-flex items-center px-3 py-1 rounded-full text-sm font-medium bg-rose-100 text-rose-800 dark:bg-rose-900 dark:text-rose-100 mb-3">
              Limited Time Offer – Special pricing available until next update!
            </div>
            <h2 className="mt-2 text-3xl leading-8 font-extrabold tracking-tight text-gray-900 dark:text-white sm:text-4xl">
              Simple, transparent pricing
            </h2>
            <p className="mt-4 max-w-2xl text-xl text-gray-500 dark:text-gray-400 mx-auto">
              Start for free, no credit card required. Upgrade anytime to unlock premium features.
            </p>
          </div>

          <div className="mt-12 space-y-4 sm:mt-16 sm:space-y-0 sm:grid sm:grid-cols-1 md:grid-cols-2 lg:grid-cols-4 sm:gap-6 lg:max-w-5xl lg:mx-auto xl:max-w-none xl:mx-0">
            {/* Free Plan */}
            <div className="border border-gray-200 dark:border-gray-700 rounded-xl shadow-sm divide-y divide-gray-200 dark:divide-gray-700 bg-white dark:bg-gray-900 flex flex-col overflow-hidden">
              <div className="p-6">
                <div className="flex justify-between items-center">
                  <h2 className="text-xl font-bold text-gray-900 dark:text-white">Free</h2>
                  <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-100">
                    Basic
                  </span>
                </div>
                <p className="mt-4 text-sm text-gray-500 dark:text-gray-400">Perfect for getting started with personal productivity.</p>
                <p className="mt-8">
                  <span className="text-4xl font-extrabold text-gray-900 dark:text-white">$0</span>
                  <span className="text-base font-medium text-gray-500 dark:text-gray-400">/mo</span>
                </p>
                <Button
                  variant="outline"
                  className="mt-8 block w-full"
                  onClick={() => navigate('/auth')}
                >
                  Start Free
                </Button>
              </div>
              <div className="px-6 pt-6 pb-8 flex-grow">
                <h3 className="text-xs font-medium text-gray-900 dark:text-white tracking-wide uppercase">What's included</h3>
                <ul className="mt-6 space-y-4">
                  <li className="flex space-x-3">
                    <svg className="flex-shrink-0 h-5 w-5 text-green-500" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor">
                      <path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd" />
                    </svg>
                    <span className="text-sm text-gray-500 dark:text-gray-400">Basic AI Assistant</span>
                  </li>
                  <li className="flex space-x-3">
                    <svg className="flex-shrink-0 h-5 w-5 text-green-500" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor">
                      <path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd" />
                    </svg>
                    <span className="text-sm text-gray-500 dark:text-gray-400">Up to 75 actions/month</span>
                  </li>
                  <li className="flex space-x-3">
                    <svg className="flex-shrink-0 h-5 w-5 text-green-500" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor">
                      <path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd" />
                    </svg>
                    <span className="text-sm text-gray-500 dark:text-gray-400">Basic task management</span>
                  </li>
                  <li className="flex space-x-3">
                    <svg className="flex-shrink-0 h-5 w-5 text-green-500" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor">
                      <path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd" />
                    </svg>
                    <span className="text-sm text-gray-500 dark:text-gray-400">Basic calendar</span>
                  </li>
                  <li className="flex space-x-3">
                    <svg className="flex-shrink-0 h-5 w-5 text-green-500" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor">
                      <path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd" />
                    </svg>
                    <span className="text-sm text-gray-500 dark:text-gray-400">Bill payment reminders</span>
                  </li>
                </ul>
              </div>
            </div>

            {/* Starter Plan */}
            <div className="border-2 border-primary-500 dark:border-primary-400 rounded-xl shadow-md divide-y divide-gray-200 dark:divide-gray-700 bg-white dark:bg-gray-900 flex flex-col overflow-hidden relative">
              {/* Most popular badge */}
              <div className="absolute top-0 right-0 left-0">
                <div className="bg-primary-500 text-white text-xs font-bold uppercase py-1 text-center transform">
                  Most Popular
                </div>
              </div>
              <div className="p-6 pt-8">
                <div className="flex justify-between items-center">
                  <h2 className="text-xl font-bold text-gray-900 dark:text-white">Starter</h2>
                  <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-100">
                    Great Value
                  </span>
                </div>
                <p className="mt-4 text-sm text-gray-500 dark:text-gray-400">Perfect for individuals looking to boost productivity.</p>
                <p className="mt-8">
                  <span className="text-4xl font-extrabold text-gray-900 dark:text-white">$6</span>
                  <span className="text-base font-medium text-gray-500 dark:text-gray-400">/mo</span>
                </p>
                <div className="mt-1 text-sm text-green-600 dark:text-green-400">
                  <span className="font-medium">$60/year</span> (2 months free!)
                </div>
                <Button
                  className="mt-6 block w-full bg-primary-600 hover:bg-primary-700"
                  onClick={() => navigate('/auth?plan=starter')}
                >
                  Get Started
                </Button>
              </div>
              <div className="px-6 pt-6 pb-8">
                <h3 className="text-xs font-medium text-gray-900 dark:text-white tracking-wide uppercase">What's included</h3>
                <ul className="mt-6 space-y-4">
                  <li className="flex space-x-3">
                    <svg className="flex-shrink-0 h-5 w-5 text-green-500" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor">
                      <path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd" />
                    </svg>
                    <span className="text-sm text-gray-500 dark:text-gray-400">Everything in Free</span>
                  </li>
                  <li className="flex space-x-3">
                    <svg className="flex-shrink-0 h-5 w-5 text-green-500" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor">
                      <path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd" />
                    </svg>
                    <span className="text-sm text-gray-500 dark:text-gray-400">Up to 750 actions/month</span>
                  </li>
                  <li className="flex space-x-3">
                    <svg className="flex-shrink-0 h-5 w-5 text-green-500" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor">
                      <path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd" />
                    </svg>
                    <span className="text-sm text-gray-500 dark:text-gray-400">Enhanced AI features</span>
                  </li>
                  <li className="flex space-x-3">
                    <svg className="flex-shrink-0 h-5 w-5 text-green-500" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor">
                      <path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd" />
                    </svg>
                    <span className="text-sm text-gray-500 dark:text-gray-400">Full calendar integration</span>
                  </li>
                  <li className="flex space-x-3">
                    <svg className="flex-shrink-0 h-5 w-5 text-green-500" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor">
                      <path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd" />
                    </svg>
                    <span className="text-sm text-gray-500 dark:text-gray-400">Advanced bill tracking</span>
                  </li>
                  <li className="flex space-x-3">
                    <svg className="flex-shrink-0 h-5 w-5 text-green-500" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor">
                      <path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd" />
                    </svg>
                    <span className="text-sm text-gray-500 dark:text-gray-400">ROI Dashboard</span>
                  </li>
                </ul>
              </div>
            </div>

            {/* Pro Plan */}
            <div className="border border-gray-200 dark:border-gray-700 rounded-xl shadow-sm divide-y divide-gray-200 dark:divide-gray-700 bg-white dark:bg-gray-900 flex flex-col overflow-hidden">
              <div className="p-6">
                <div className="flex justify-between items-center">
                  <h2 className="text-xl font-bold text-gray-900 dark:text-white">Pro</h2>
                  <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-purple-100 text-purple-800 dark:bg-purple-900 dark:text-purple-100">
                    Advanced
                  </span>
                </div>
                <p className="mt-4 text-sm text-gray-500 dark:text-gray-400">For power users with demanding productivity needs.</p>
                <p className="mt-8">
                  <span className="text-4xl font-extrabold text-gray-900 dark:text-white">$16.85</span>
                  <span className="text-base font-medium text-gray-500 dark:text-gray-400">/mo</span>
                </p>
                <div className="mt-1 text-sm text-green-600 dark:text-green-400">
                  <span className="font-medium">$169/year</span> (2 months free!)
                </div>
                <Button
                  className="mt-6 block w-full"
                  onClick={() => navigate('/auth?plan=pro')}
                >
                  Get Started
                </Button>
              </div>
              <div className="px-6 pt-6 pb-8">
                <h3 className="text-xs font-medium text-gray-900 dark:text-white tracking-wide uppercase">What's included</h3>
                <ul className="mt-6 space-y-4">
                  <li className="flex space-x-3">
                    <svg className="flex-shrink-0 h-5 w-5 text-green-500" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor">
                      <path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd" />
                    </svg>
                    <span className="text-sm text-gray-500 dark:text-gray-400">Everything in Starter</span>
                  </li>
                  <li className="flex space-x-3">
                    <svg className="flex-shrink-0 h-5 w-5 text-green-500" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor">
                      <path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd" />
                    </svg>
                    <span className="text-sm text-gray-500 dark:text-gray-400">Unlimited actions</span>
                  </li>
                  <li className="flex space-x-3">
                    <svg className="flex-shrink-0 h-5 w-5 text-green-500" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor">
                      <path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd" />
                    </svg>
                    <span className="text-sm text-gray-500 dark:text-gray-400">Smart Priority Score</span>
                  </li>
                  <li className="flex space-x-3">
                    <svg className="flex-shrink-0 h-5 w-5 text-green-500" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor">
                      <path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd" />
                    </svg>
                    <span className="text-sm text-gray-500 dark:text-gray-400">Advanced analytics</span>
                  </li>
                  <li className="flex space-x-3">
                    <svg className="flex-shrink-0 h-5 w-5 text-green-500" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor">
                      <path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd" />
                    </svg>
                    <span className="text-sm text-gray-500 dark:text-gray-400">Priority support</span>
                  </li>
                  <li className="flex space-x-3">
                    <svg className="flex-shrink-0 h-5 w-5 text-green-500" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor">
                      <path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd" />
                    </svg>
                    <span className="text-sm text-gray-500 dark:text-gray-400">All future features</span>
                  </li>
                </ul>
              </div>
            </div>

            {/* Team Plan */}
            <div className="border border-gray-200 dark:border-gray-700 rounded-xl shadow-sm divide-y divide-gray-200 dark:divide-gray-700 bg-white dark:bg-gray-900 flex flex-col overflow-hidden">
              <div className="p-6">
                <div className="flex justify-between items-center">
                  <h2 className="text-xl font-bold text-gray-900 dark:text-white">Team</h2>
                  <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-indigo-100 text-indigo-800 dark:bg-indigo-900 dark:text-indigo-100">
                    Collaboration
                  </span>
                </div>
                <p className="mt-4 text-sm text-gray-500 dark:text-gray-400">For teams who work together on projects and tasks.</p>
                <p className="mt-8">
                  <span className="text-4xl font-extrabold text-gray-900 dark:text-white">$10.85</span>
                  <span className="text-base font-medium text-gray-500 dark:text-gray-400">/user/mo</span>
                </p>
                <div className="mt-1 text-sm text-green-600 dark:text-green-400">
                  <span className="font-medium">$109/user/year</span> (2 months free!)
                </div>
                <Button
                  className="mt-6 block w-full"
                  onClick={() => navigate('/auth?plan=team')}
                >
                  Get Started
                </Button>
              </div>
              <div className="px-6 pt-6 pb-8">
                <h3 className="text-xs font-medium text-gray-900 dark:text-white tracking-wide uppercase">What's included</h3>
                <ul className="mt-6 space-y-4">
                  <li className="flex space-x-3">
                    <svg className="flex-shrink-0 h-5 w-5 text-green-500" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor">
                      <path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd" />
                    </svg>
                    <span className="text-sm text-gray-500 dark:text-gray-400">Everything in Pro</span>
                  </li>
                  <li className="flex space-x-3">
                    <svg className="flex-shrink-0 h-5 w-5 text-green-500" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor">
                      <path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd" />
                    </svg>
                    <span className="text-sm text-gray-500 dark:text-gray-400">Shared workspaces</span>
                  </li>
                  <li className="flex space-x-3">
                    <svg className="flex-shrink-0 h-5 w-5 text-green-500" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor">
                      <path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd" />
                    </svg>
                    <span className="text-sm text-gray-500 dark:text-gray-400">Team calendar</span>
                  </li>
                  <li className="flex space-x-3">
                    <svg className="flex-shrink-0 h-5 w-5 text-green-500" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor">
                      <path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd" />
                    </svg>
                    <span className="text-sm text-gray-500 dark:text-gray-400">Team analytics</span>
                  </li>
                  <li className="flex space-x-3">
                    <svg className="flex-shrink-0 h-5 w-5 text-green-500" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor">
                      <path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd" />
                    </svg>
                    <span className="text-sm text-gray-500 dark:text-gray-400">Unlimited team members</span>
                  </li>
                  <li className="flex space-x-3">
                    <svg className="flex-shrink-0 h-5 w-5 text-green-500" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor">
                      <path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd" />
                    </svg>
                    <span className="text-sm text-gray-500 dark:text-gray-400">Team performance tracking</span>
                  </li>
                  <li className="flex space-x-3">
                    <svg className="flex-shrink-0 h-5 w-5 text-green-500" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor">
                      <path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd" />
                    </svg>
                    <span className="text-sm text-gray-500 dark:text-gray-400">Admin controls</span>
                  </li>
                </ul>
              </div>
            </div>
          </div>
          
          {/* Compare Plans button */}
          <div className="mt-10 text-center">
            <p className="text-base text-gray-500 dark:text-gray-400 mb-4">
              Need more details? Compare all plans to find the perfect fit for your needs.
            </p>
            <Button 
              onClick={() => navigate('/pricing')}
              className="inline-flex items-center px-6 py-3"
            >
              Compare All Plans
              <svg className="ml-2 -mr-1 w-5 h-5" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M14 5l7 7m0 0l-7 7m7-7H3" />
              </svg>
            </Button>
          </div>
        </div>
      </div>

      {/* Footer */}
      <footer className="bg-white dark:bg-gray-900">
        <div className="max-w-7xl mx-auto py-12 px-4 sm:px-6 lg:px-8">
          <div className="xl:grid xl:grid-cols-3 xl:gap-8">
            <div className="space-y-8 xl:col-span-1">
              <AppLogo />
              <p className="text-gray-500 dark:text-gray-400 text-base">
                Turn Chaos into Flow with the ultimate life management system.
              </p>
              <div className="mt-4 p-4 border border-green-200 dark:border-green-800 bg-green-50 dark:bg-green-900/30 rounded-lg">
                <p className="text-sm font-medium text-green-800 dark:text-green-400">
                  Limited Time Offer: Lock in our reduced prices before the next update. Save up to 15% on all plans!
                </p>
              </div>
              <div className="flex space-x-6">
                <button type="button" className="text-gray-400 hover:text-gray-500 dark:hover:text-gray-300">
                  <span className="sr-only">Facebook</span>
                  <svg className="h-6 w-6" fill="currentColor" viewBox="0 0 24 24" aria-hidden="true">
                    <path fillRule="evenodd" d="M22 12c0-5.523-4.477-10-10-10S2 6.477 2 12c0 4.991 3.657 9.128 8.438 9.878v-6.987h-2.54V12h2.54V9.797c0-2.506 1.492-3.89 3.777-3.89 1.094 0 2.238.195 2.238.195v2.46h-1.26c-1.243 0-1.63.771-1.63 1.562V12h2.773l-.443 2.89h-2.33v6.988C18.343 21.128 22 16.991 22 12z" clipRule="evenodd" />
                  </svg>
                </button>
                <button type="button" className="text-gray-400 hover:text-gray-500 dark:hover:text-gray-300">
                  <span className="sr-only">Instagram</span>
                  <svg className="h-6 w-6" fill="currentColor" viewBox="0 0 24 24" aria-hidden="true">
                    <path fillRule="evenodd" d="M12.315 2c2.43 0 2.784.013 3.808.06 1.064.049 1.791.218 2.427.465a4.902 4.902 0 011.772 1.153 4.902 4.902 0 011.153 1.772c.247.636.416 1.363.465 2.427.048 1.067.06 1.407.06 4.123v.08c0 2.643-.012 2.987-.06 4.043-.049 1.064-.218 1.791-.465 2.427a4.902 4.902 0 01-1.153 1.772 4.902 4.902 0 01-1.772 1.153c-.636.247-1.363.416-2.427.465-1.067.048-1.407.06-4.123.06h-.08c-2.643 0-2.987-.012-4.043-.06-1.064-.049-1.791-.218-2.427-.465a4.902 4.902 0 01-1.772-1.153 4.902 4.902 0 01-1.153-1.772c-.247-.636-.416-1.363-.465-2.427-.047-1.024-.06-1.379-.06-3.808v-.63c0-2.43.013-2.784.06-3.808.049-1.064.218-1.791.465-2.427a4.902 4.902 0 011.153-1.772A4.902 4.902 0 015.45 2.525c.636-.247 1.363-.416 2.427-.465C8.901 2.013 9.256 2 11.685 2h.63zm-.081 1.802h-.468c-2.456 0-2.784.011-3.807.058-.975.045-1.504.207-1.857.344-.467.182-.8.398-1.15.748-.35.35-.566.683-.748 1.15-.137.353-.3.882-.344 1.857-.047 1.023-.058 1.351-.058 3.807v.468c0 2.456.011 2.784.058 3.807.045.975.207 1.504.344 1.857.182.466.399.8.748 1.15.35.35.683.566 1.15.748.353.137.882.3 1.857.344 1.054.048 1.37.058 4.041.058h.08c2.597 0 2.917-.01 3.96-.058.976-.045 1.505-.207 1.858-.344.466-.182.8-.398 1.15-.748.35-.35.566-.683.748-1.15.137-.353.3-.882.344-1.857.048-1.055.058-1.37.058-4.041v-.08c0-2.597-.01-2.917-.058-3.96-.045-.976-.207-1.505-.344-1.858a3.097 3.097 0 00-.748-1.15 3.098 3.098 0 00-1.15-.748c-.353-.137-.882-.3-1.857-.344-1.023-.047-1.351-.058-3.807-.058zM12 6.865a5.135 5.135 0 110 10.27 5.135 5.135 0 010-10.27zm0 1.802a3.333 3.333 0 100 6.666 3.333 3.333 0 000-6.666zm5.338-3.205a1.2 1.2 0 110 2.4 1.2 1.2 0 010-2.4z" clipRule="evenodd" />
                  </svg>
                </button>
                <button type="button" className="text-gray-400 hover:text-gray-500 dark:hover:text-gray-300">
                  <span className="sr-only">Twitter</span>
                  <svg className="h-6 w-6" fill="currentColor" viewBox="0 0 24 24" aria-hidden="true">
                    <path d="M8.29 20.251c7.547 0 11.675-6.253 11.675-11.675 0-.178 0-.355-.012-.53A8.348 8.348 0 0022 5.92a8.19 8.19 0 01-2.357.646 4.118 4.118 0 001.804-2.27 8.224 8.224 0 01-2.605.996 4.107 4.107 0 00-6.993 3.743 11.65 11.65 0 01-8.457-4.287 4.106 4.106 0 001.27 5.477A4.072 4.072 0 012.8 9.713v.052a4.105 4.105 0 003.292 4.022 4.095 4.095 0 01-1.853.07 4.108 4.108 0 003.834 2.85A8.233 8.233 0 012 18.407a11.616 11.616 0 006.29 1.84" />
                  </svg>
                </button>
                <button type="button" className="text-gray-400 hover:text-gray-500 dark:hover:text-gray-300">
                  <span className="sr-only">LinkedIn</span>
                  <svg className="h-6 w-6" fill="currentColor" viewBox="0 0 24 24" aria-hidden="true">
                    <path fillRule="evenodd" d="M16.338 16.338H13.67V12.16c0-1.005-.02-2.298-1.39-2.298-1.397 0-1.61 1.09-1.61 2.23v4.246h-2.667V8.75h2.56v1.17h.035c.36-.685 1.235-1.41 2.532-1.41 2.712 0 3.213 1.785 3.213 4.11v3.72zM6.75 7.58c-.858 0-1.56-.7-1.56-1.56 0-.862.702-1.562 1.56-1.562.862 0 1.564.7 1.564 1.562 0 .86-.702 1.56-1.564 1.56zm1.335 8.758H5.417V8.75H8.085v7.588zM22.5 0H1.5C.672 0 0 .672 0 1.5v21c0 .828.672 1.5 1.5 1.5h21c.828 0 1.5-.672 1.5-1.5v-21c0-.828-.672-1.5-1.5-1.5z" clipRule="evenodd" />
                  </svg>
                </button>
              </div>
            </div>
            <div className="mt-12 grid grid-cols-2 gap-8 xl:mt-0 xl:col-span-2">
              <div className="md:grid md:grid-cols-2 md:gap-8">
                <div>
                  <h3 className="text-sm font-semibold text-gray-400 tracking-wider uppercase">
                    Product
                  </h3>
                  <ul className="mt-4 space-y-4">
                    <li><button onClick={() => window.location.href='#features'} className="text-base text-gray-500 dark:text-gray-400 hover:text-gray-900 dark:hover:text-white">Features</button></li>
                    <li><button onClick={() => window.location.href='#pricing'} className="text-base text-gray-500 dark:text-gray-400 hover:text-gray-900 dark:hover:text-white">Pricing</button></li>
                    <li><button className="text-base text-gray-500 dark:text-gray-400 hover:text-gray-900 dark:hover:text-white">FAQ</button></li>
                    <li><button className="text-base text-gray-500 dark:text-gray-400 hover:text-gray-900 dark:hover:text-white">Guides</button></li>
                  </ul>
                </div>
                <div className="mt-12 md:mt-0">
                  <h3 className="text-sm font-semibold text-gray-400 tracking-wider uppercase">
                    Company
                  </h3>
                  <ul className="mt-4 space-y-4">
                    <li><button className="text-base text-gray-500 dark:text-gray-400 hover:text-gray-900 dark:hover:text-white">About</button></li>
                    <li><button className="text-base text-gray-500 dark:text-gray-400 hover:text-gray-900 dark:hover:text-white">Blog</button></li>
                    <li><button className="text-base text-gray-500 dark:text-gray-400 hover:text-gray-900 dark:hover:text-white">Jobs</button></li>
                    <li><button className="text-base text-gray-500 dark:text-gray-400 hover:text-gray-900 dark:hover:text-white">Press</button></li>
                  </ul>
                </div>
              </div>
              <div className="md:grid md:grid-cols-2 md:gap-8">
                <div>
                  <h3 className="text-sm font-semibold text-gray-400 tracking-wider uppercase">
                    Legal
                  </h3>
                  <ul className="mt-4 space-y-4">
                    <li><button className="text-base text-gray-500 dark:text-gray-400 hover:text-gray-900 dark:hover:text-white">Privacy</button></li>
                    <li><button className="text-base text-gray-500 dark:text-gray-400 hover:text-gray-900 dark:hover:text-white">Terms</button></li>
                    <li><button className="text-base text-gray-500 dark:text-gray-400 hover:text-gray-900 dark:hover:text-white">Cookie Policy</button></li>
                  </ul>
                </div>
                <div className="mt-12 md:mt-0">
                  <h3 className="text-sm font-semibold text-gray-400 tracking-wider uppercase">
                    Support
                  </h3>
                  <ul className="mt-4 space-y-4">
                    <li><button className="text-base text-gray-500 dark:text-gray-400 hover:text-gray-900 dark:hover:text-white">Help Center</button></li>
                    <li><button className="text-base text-gray-500 dark:text-gray-400 hover:text-gray-900 dark:hover:text-white">Contact Us</button></li>
                    <li><button className="text-base text-gray-500 dark:text-gray-400 hover:text-gray-900 dark:hover:text-white">Status</button></li>
                  </ul>
                </div>
              </div>
            </div>
          </div>
          <div className="mt-12 border-t border-gray-200 dark:border-gray-700 pt-8">
            <p className="text-base text-gray-400 text-center">
              &copy; {new Date().getFullYear()} BreezeFlow. All rights reserved.
            </p>
          </div>
        </div>
      </footer>
    </>
  );
}
