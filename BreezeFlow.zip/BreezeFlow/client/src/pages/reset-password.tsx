import React, { useState, useEffect } from 'react';
import { z } from 'zod';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { Link, useLocation } from 'wouter';
import { 
  Card, 
  CardContent, 
  CardDescription, 
  CardFooter, 
  CardHeader, 
  CardTitle 
} from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Loader2, Lock, ArrowLeft, CheckCircle2, X } from 'lucide-react';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { AppLogo } from '@/components/ui/app-logo';
import { apiRequest } from '@/lib/queryClient';
import { useMutation, useQuery } from '@tanstack/react-query';
import { Helmet } from 'react-helmet';

// Password Reset Form Schema
const resetPasswordSchema = z.object({
  password: z.string()
    .min(6, 'Password must be at least 6 characters')
    .max(100, 'Password is too long'),
  confirmPassword: z.string()
    .min(1, 'Please confirm your password'),
}).refine(data => data.password === data.confirmPassword, {
  message: "Passwords don't match",
  path: ['confirmPassword'],
});

type ResetPasswordFormValues = z.infer<typeof resetPasswordSchema>;

export default function ResetPasswordPage() {
  const [location, navigate] = useLocation();
  const [token, setToken] = useState<string | null>(null);
  const [resetSuccess, setResetSuccess] = useState(false);
  
  // Extract token from URL query parameter
  useEffect(() => {
    const params = new URLSearchParams(location.split('?')[1]);
    const tokenParam = params.get('token');
    setToken(tokenParam);
  }, [location]);
  
  // Setup form for password reset
  const resetForm = useForm<ResetPasswordFormValues>({
    resolver: zodResolver(resetPasswordSchema),
    defaultValues: {
      password: '',
      confirmPassword: '',
    },
  });
  
  // Token validation query
  const { data: tokenData, error: tokenError, isLoading: tokenLoading } = useQuery({
    queryKey: ['/api/validate-reset-token', token],
    queryFn: async () => {
      if (!token) return { valid: false, message: 'No token provided' };
      const res = await apiRequest('GET', `/api/validate-reset-token/${token}`);
      return res.json();
    },
    enabled: !!token,
  });
  
  // Reset password mutation
  const resetMutation = useMutation({
    mutationFn: async (data: { token: string, password: string }) => {
      const res = await apiRequest("POST", "/api/reset-password", data);
      return res.json();
    },
    onSuccess: () => {
      setResetSuccess(true);
    },
  });
  
  // Handle form submission
  const onResetSubmit = (data: ResetPasswordFormValues) => {
    if (!token) return;
    
    resetMutation.mutate({
      token,
      password: data.password,
    });
  };
  
  // Determine current state
  const isTokenInvalid = tokenData && !tokenData.valid;
  const isErrorState = !!tokenError || isTokenInvalid;
  
  return (
    <>
      <Helmet>
        <title>Reset Password - BreezeFlow</title>
        <meta name="description" content="Set a new password for your BreezeFlow account." />
      </Helmet>

      <div className="flex h-screen bg-gray-50 dark:bg-gray-900">
        <div className="w-full max-w-md mx-auto p-8 flex items-center justify-center">
          <div className="w-full">
            <div className="mb-8 text-center">
              <AppLogo className="mx-auto mb-4" />
              <h1 className="text-2xl font-bold text-gray-900 dark:text-white mb-2">Reset Your Password</h1>
              <p className="text-gray-600 dark:text-gray-400">
                {resetSuccess
                  ? "Your password has been updated"
                  : isErrorState
                    ? "There was an issue with your reset link"
                    : "Create a new password for your account"}
              </p>
            </div>
            
            <Card>
              {tokenLoading ? (
                // Loading state
                <CardContent className="pt-6 flex flex-col items-center">
                  <Loader2 className="h-8 w-8 animate-spin text-primary mb-4" />
                  <p>Validating your reset link...</p>
                </CardContent>
              ) : resetSuccess ? (
                // Success state
                <CardContent className="pt-6 flex flex-col items-center">
                  <div className="mb-4 p-3 rounded-full bg-green-100 dark:bg-green-900">
                    <CheckCircle2 className="h-10 w-10 text-green-600 dark:text-green-400" />
                  </div>
                  <h3 className="text-xl font-semibold mb-2">Password Reset Complete</h3>
                  <p className="text-center text-gray-600 dark:text-gray-400 mb-6">
                    Your password has been successfully updated. You can now log in with your new password.
                  </p>
                  <Link to="/auth" className="w-full">
                    <Button className="w-full">
                      Go to Login
                    </Button>
                  </Link>
                </CardContent>
              ) : isErrorState ? (
                // Error state - invalid or expired token
                <CardContent className="pt-6 flex flex-col items-center">
                  <div className="mb-4 p-3 rounded-full bg-red-100 dark:bg-red-900">
                    <X className="h-10 w-10 text-red-600 dark:text-red-400" />
                  </div>
                  <h3 className="text-xl font-semibold mb-2">Invalid or Expired Link</h3>
                  <p className="text-center text-gray-600 dark:text-gray-400 mb-6">
                    This password reset link is invalid or has expired. Please request a new password reset link.
                  </p>
                  <Link to="/forgot-password" className="w-full">
                    <Button className="w-full">
                      Request New Reset Link
                    </Button>
                  </Link>
                  <Link to="/auth">
                    <Button variant="link" className="mt-4">
                      Return to login
                    </Button>
                  </Link>
                </CardContent>
              ) : (
                // Form state - valid token
                <>
                  <CardHeader>
                    <CardTitle>Create New Password</CardTitle>
                    <CardDescription>
                      Choose a new password for your BreezeFlow account.
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <form onSubmit={resetForm.handleSubmit(onResetSubmit)}>
                      <div className="space-y-4">
                        <div className="space-y-2">
                          <Label htmlFor="password">New Password</Label>
                          <div className="relative">
                            <Lock className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
                            <Input 
                              id="password" 
                              type="password" 
                              className="pl-10"
                              {...resetForm.register('password')} 
                            />
                          </div>
                          {resetForm.formState.errors.password && (
                            <p className="text-sm text-red-500">{resetForm.formState.errors.password.message}</p>
                          )}
                        </div>
                        
                        <div className="space-y-2">
                          <Label htmlFor="confirmPassword">Confirm New Password</Label>
                          <div className="relative">
                            <Lock className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
                            <Input 
                              id="confirmPassword" 
                              type="password" 
                              className="pl-10"
                              {...resetForm.register('confirmPassword')} 
                            />
                          </div>
                          {resetForm.formState.errors.confirmPassword && (
                            <p className="text-sm text-red-500">{resetForm.formState.errors.confirmPassword.message}</p>
                          )}
                        </div>
                        
                        {resetMutation.error && (
                          <Alert variant="destructive">
                            <AlertDescription>
                              {resetMutation.error instanceof Error
                                ? resetMutation.error.message
                                : "Something went wrong. Please try again."}
                            </AlertDescription>
                          </Alert>
                        )}
                        
                        <Button 
                          type="submit" 
                          className="w-full" 
                          disabled={resetMutation.isPending}
                        >
                          {resetMutation.isPending ? (
                            <><Loader2 className="mr-2 h-4 w-4 animate-spin" /> Updating password...</>
                          ) : (
                            'Reset Password'
                          )}
                        </Button>
                      </div>
                    </form>
                  </CardContent>
                  <CardFooter className="flex flex-col">
                    <div className="text-sm text-gray-500 dark:text-gray-400">
                      <Link to="/auth">
                        <Button variant="link" className="p-0">
                          <ArrowLeft className="mr-1 h-4 w-4" /> Back to login
                        </Button>
                      </Link>
                    </div>
                  </CardFooter>
                </>
              )}
            </Card>
          </div>
        </div>
      </div>
    </>
  );
}