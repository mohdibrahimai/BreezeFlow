import React, { useState, useEffect } from 'react';
import { Link, useLocation } from 'wouter';
import { z } from 'zod';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { 
  Card, 
  CardContent, 
  CardDescription, 
  CardFooter, 
  CardHeader, 
  CardTitle 
} from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Label } from '@/components/ui/label';
import { AppLogo } from '@/components/ui/app-logo';
import { useAuth } from '@/hooks/use-auth';
import { Loader2 } from 'lucide-react';
import { Helmet } from 'react-helmet';

// Login Form Schema
const loginSchema = z.object({
  username: z.string().min(1, 'Username is required'),
  password: z.string().min(1, 'Password is required'),
});

// Registration Form Schema
const registerSchema = z.object({
  name: z.string().min(1, 'Full name is required'),
  email: z.string().email('Invalid email address'),
  username: z.string().min(3, 'Username must be at least 3 characters').max(50, 'Username must be less than 50 characters'),
  password: z.string().min(6, 'Password must be at least 6 characters'),
  plan: z.enum(['free', 'starter', 'pro', 'team']).default('free'),
  security_question: z.string().min(1, 'Security question is required'),
  security_answer: z.string().min(1, 'Security answer is required'),
});

type LoginFormValues = z.infer<typeof loginSchema>;
type RegisterFormValues = z.infer<typeof registerSchema>;

export default function AuthPage() {
  const [activeTab, setActiveTab] = useState<string>('login');
  const [, navigate] = useLocation();
  const { user, loginMutation, registerMutation } = useAuth();
  const [location] = useLocation();
  
  // Get redirect parameter from URL if it exists
  const params = new URLSearchParams(location.split('?')[1]);
  const redirectPath = params.get('redirect') || '/dashboard';
  
  // Setup form for login
  const loginForm = useForm<LoginFormValues>({
    resolver: zodResolver(loginSchema),
    defaultValues: {
      username: '',
      password: '',
    },
  });
  
  // Setup form for registration
  const registerForm = useForm<RegisterFormValues>({
    resolver: zodResolver(registerSchema),
    defaultValues: {
      name: '',
      email: '',
      username: '',
      password: '',
      plan: 'free',
      security_question: '',
      security_answer: '',
    },
  });
  
  // Redirect if user is already logged in
  useEffect(() => {
    if (user) {
      navigate(redirectPath);
    }
  }, [user, navigate, redirectPath]);
  
  // Handle login submission
  const onLoginSubmit = (data: LoginFormValues) => {
    loginMutation.mutate(data, {
      onSuccess: () => {
        navigate(redirectPath);
      }
    });
  };
  
  // Handle registration submission
  const onRegisterSubmit = (data: RegisterFormValues) => {
    // Ensure plan has a default value
    const userData = {
      ...data,
      plan: data.plan || 'free'
    };
    
    registerMutation.mutate(userData, {
      onSuccess: () => {
        navigate(redirectPath);
      }
    });
  };

  return (
    <>
      <Helmet>
        <title>Sign In or Register - BreezeFlow</title>
        <meta name="description" content="Sign in to your BreezeFlow account or create a new account to start managing your tasks, events, bills, and more." />
      </Helmet>

      <div className="flex h-screen bg-gray-50 dark:bg-gray-900">
        {/* Left side: Auth forms */}
        <div className="w-full lg:w-1/2 p-8 flex items-center justify-center">
          <div className="max-w-md w-full">
            <div className="mb-8 text-center">
              <AppLogo className="mx-auto mb-4" />
              <h1 className="text-2xl font-bold text-gray-900 dark:text-white mb-2">Welcome to BreezeFlow</h1>
              <p className="text-gray-600 dark:text-gray-400">Turn chaos into flow with the ultimate life management system</p>
            </div>

            <Tabs defaultValue="login" value={activeTab} onValueChange={setActiveTab}>
              <TabsList className="grid grid-cols-2 mb-6">
                <TabsTrigger value="login">Login</TabsTrigger>
                <TabsTrigger value="register">Register</TabsTrigger>
              </TabsList>

              {/* Login Form */}
              <TabsContent value="login">
                <Card>
                  <CardHeader>
                    <CardTitle>Login to your account</CardTitle>
                    <CardDescription>Enter your credentials to access your dashboard</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <form onSubmit={loginForm.handleSubmit(onLoginSubmit)}>
                      <div className="space-y-4">
                        <div className="space-y-2">
                          <Label htmlFor="username">Username</Label>
                          <Input 
                            id="username" 
                            type="text" 
                            placeholder="johnsmith" 
                            {...loginForm.register('username')} 
                          />
                          {loginForm.formState.errors.username && (
                            <p className="text-sm text-red-500">{loginForm.formState.errors.username.message}</p>
                          )}
                        </div>
                        <div className="space-y-2">
                          <div className="flex items-center justify-between">
                            <Label htmlFor="password">Password</Label>
                            <Link href="/forgot-password" className="text-sm text-primary-600 hover:text-primary-500 dark:text-primary-400">
                              Forgot password?
                            </Link>
                          </div>
                          <Input 
                            id="password" 
                            type="password" 
                            {...loginForm.register('password')} 
                          />
                          {loginForm.formState.errors.password && (
                            <p className="text-sm text-red-500">{loginForm.formState.errors.password.message}</p>
                          )}
                        </div>
                        
                        {loginMutation.error && (
                          <Alert variant="destructive">
                            <AlertDescription>{loginMutation.error.message}</AlertDescription>
                          </Alert>
                        )}
                        
                        <div className="flex justify-end mb-2">
                          <Link href="/forgot-password" className="text-sm text-muted-foreground hover:text-primary">
                            Forgot password?
                          </Link>
                        </div>
                        
                        <Button 
                          type="submit" 
                          className="w-full" 
                          disabled={loginMutation.isPending}
                        >
                          {loginMutation.isPending ? (
                            <><Loader2 className="mr-2 h-4 w-4 animate-spin" /> Logging in...</>
                          ) : (
                            'Sign in'
                          )}
                        </Button>
                      </div>
                    </form>
                  </CardContent>
                  <CardFooter className="flex flex-col items-center">
                    <div className="text-sm text-gray-500 dark:text-gray-400">
                      Don't have an account?{' '}
                      <button 
                        className="text-primary-600 hover:text-primary-500 dark:text-primary-400 font-medium" 
                        onClick={() => setActiveTab('register')}
                      >
                        Sign up
                      </button>
                    </div>
                  </CardFooter>
                </Card>
              </TabsContent>

              {/* Registration Form */}
              <TabsContent value="register">
                <Card>
                  <CardHeader>
                    <CardTitle>Create your account</CardTitle>
                    <CardDescription>Enter your information to get started</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <form onSubmit={registerForm.handleSubmit(onRegisterSubmit)}>
                      <div className="space-y-4">
                        <div className="space-y-2">
                          <Label htmlFor="name">Full Name</Label>
                          <Input 
                            id="name" 
                            type="text" 
                            placeholder="John Smith" 
                            {...registerForm.register('name')} 
                          />
                          {registerForm.formState.errors.name && (
                            <p className="text-sm text-red-500">{registerForm.formState.errors.name.message}</p>
                          )}
                        </div>
                        <div className="space-y-2">
                          <Label htmlFor="email">Email</Label>
                          <Input 
                            id="email" 
                            type="email" 
                            placeholder="john@example.com" 
                            {...registerForm.register('email')} 
                          />
                          {registerForm.formState.errors.email && (
                            <p className="text-sm text-red-500">{registerForm.formState.errors.email.message}</p>
                          )}
                        </div>
                        <div className="space-y-2">
                          <Label htmlFor="register-username">Username</Label>
                          <Input 
                            id="register-username" 
                            type="text" 
                            placeholder="johnsmith" 
                            {...registerForm.register('username')} 
                          />
                          {registerForm.formState.errors.username && (
                            <p className="text-sm text-red-500">{registerForm.formState.errors.username.message}</p>
                          )}
                        </div>
                        <div className="space-y-2">
                          <Label htmlFor="register-password">Password</Label>
                          <Input 
                            id="register-password" 
                            type="password" 
                            {...registerForm.register('password')} 
                          />
                          {registerForm.formState.errors.password && (
                            <p className="text-sm text-red-500">{registerForm.formState.errors.password.message}</p>
                          )}
                        </div>
                        
                        <div className="space-y-2">
                          <Label htmlFor="security-question">Security Question</Label>
                          <select
                            id="security-question"
                            className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background file:border-0 file:bg-transparent file:text-sm file:font-medium placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50"
                            {...registerForm.register('security_question')}
                          >
                            <option value="">Select a security question</option>
                            <option value="What was the name of your first pet?">What was the name of your first pet?</option>
                            <option value="What was the name of your elementary school?">What was the name of your elementary school?</option>
                            <option value="What is your mother's maiden name?">What is your mother's maiden name?</option>
                            <option value="What city were you born in?">What city were you born in?</option>
                            <option value="What was your childhood nickname?">What was your childhood nickname?</option>
                          </select>
                          {registerForm.formState.errors.security_question && (
                            <p className="text-sm text-red-500">{registerForm.formState.errors.security_question.message}</p>
                          )}
                        </div>
                        
                        <div className="space-y-2">
                          <Label htmlFor="security-answer">Security Answer</Label>
                          <Input 
                            id="security-answer" 
                            type="text" 
                            placeholder="Your answer" 
                            {...registerForm.register('security_answer')} 
                          />
                          {registerForm.formState.errors.security_answer && (
                            <p className="text-sm text-red-500">{registerForm.formState.errors.security_answer.message}</p>
                          )}
                          <p className="text-xs text-gray-500">This will be used to recover your account if you forget your password.</p>
                        </div>
                        
                        {registerMutation.error && (
                          <Alert variant="destructive">
                            <AlertDescription>{registerMutation.error.message}</AlertDescription>
                          </Alert>
                        )}
                        
                        <Button 
                          type="submit" 
                          className="w-full" 
                          disabled={registerMutation.isPending}
                        >
                          {registerMutation.isPending ? (
                            <><Loader2 className="mr-2 h-4 w-4 animate-spin" /> Creating account...</>
                          ) : (
                            'Sign up'
                          )}
                        </Button>
                      </div>
                    </form>
                  </CardContent>
                  <CardFooter className="flex flex-col items-center">
                    <div className="text-sm text-gray-500 dark:text-gray-400">
                      Already have an account?{' '}
                      <button 
                        className="text-primary-600 hover:text-primary-500 dark:text-primary-400 font-medium" 
                        onClick={() => setActiveTab('login')}
                      >
                        Sign in
                      </button>
                    </div>
                  </CardFooter>
                </Card>
              </TabsContent>
            </Tabs>
          </div>
        </div>

        {/* Right side: Hero banner */}
        <div className="hidden lg:block lg:w-1/2 bg-primary-600 dark:bg-primary-900">
          <div className="h-full flex items-center justify-center p-12">
            <div className="max-w-lg text-white">
              <h2 className="text-4xl font-bold mb-6">Turn Chaos into Flow</h2>
              <ul className="space-y-4">
                <li className="flex items-start">
                  <svg className="h-6 w-6 text-primary-300 mr-2" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                  </svg>
                  <span>Combine tasks, calendar, bills, and errands in one unified dashboard</span>
                </li>
                <li className="flex items-start">
                  <svg className="h-6 w-6 text-primary-300 mr-2" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                  </svg>
                  <span>Gamified productivity with badges and rewards to keep you motivated</span>
                </li>
                <li className="flex items-start">
                  <svg className="h-6 w-6 text-primary-300 mr-2" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                  </svg>
                  <span>Smart automation that organizes your day for maximum efficiency</span>
                </li>
                <li className="flex items-start">
                  <svg className="h-6 w-6 text-primary-300 mr-2" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                  </svg>
                  <span>Powerful integrations with the tools you already use</span>
                </li>
              </ul>
              <div className="mt-8">
                <img 
                  src="https://images.unsplash.com/photo-1508780709619-79562169bc64?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=600&h=400&q=80" 
                  alt="Productivity dashboard" 
                  className="rounded-lg shadow-lg"
                />
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
}
