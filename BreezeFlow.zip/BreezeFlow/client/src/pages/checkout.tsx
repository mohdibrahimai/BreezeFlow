import { useState, useEffect } from "react";
import { useToast } from "@/hooks/use-toast";
import { useLocation } from "wouter";
import RazorpayButton from "@/components/ui/RazorpayButton";
import PayPalButton from "@/components/ui/PayPalButton";
import { AppLayout } from "@/components/layout/app-layout";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { CircleDollarSign, CreditCard, ShieldAlert, AlertCircle, IndianRupee, Smartphone } from "lucide-react";
import { Checkbox } from "@/components/ui/checkbox";
// import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";

interface PlanOption {
  id: string;
  name: string;
  description: string;
  price: number;
  annualPrice: number;
  billingPeriod: "Monthly" | "Annual";
  features: string[];
  quota: string;
}

export default function Checkout() {
  const { toast } = useToast();
  const [location, navigate] = useLocation();
  const [showPaymentOptions, setShowPaymentOptions] = useState(false);
  const [currency, setCurrency] = useState("USD");
  const [paymentMethod, setPaymentMethod] = useState<"razorpay" | "paypal">("razorpay");
  const [termsAccepted, setTermsAccepted] = useState(false);
  const [privacyAccepted, setPrivacyAccepted] = useState(false);
  const [subscriptionConsent, setSubscriptionConsent] = useState(false);
  const [billingPeriod, setBillingPeriod] = useState<"Monthly" | "Annual">("Monthly");
  
  // Define plans with new tiers
  const plans: PlanOption[] = [
    {
      id: "starter",
      name: "BreezeFlow Starter",
      description: "Essential features for everyday productivity",
      price: 6.00,
      annualPrice: 60.00,
      billingPeriod: "Monthly",
      quota: "750 actions / month",
      features: [
        "10x monthly action quota",
        "Enhanced ROI analytics",
        "Priority email support",
        "Advanced task automation"
      ]
    },
    {
      id: "pro",
      name: "BreezeFlow Pro",
      description: "Advanced features for power users",
      price: 16.85,
      annualPrice: 168.50,
      billingPeriod: "Monthly",
      quota: "Unlimited actions",
      features: [
        "Unlimited actions",
        "Custom integrations",
        "Advanced ROI dashboard",
        "Premium support"
      ]
    },
    {
      id: "team",
      name: "BreezeFlow Team",
      description: "For families and small teams",
      price: 10.85,
      annualPrice: 108.50,
      billingPeriod: "Monthly",
      quota: "Unlimited actions",
      features: [
        "Everything in Pro",
        "Shared workspace",
        "Team calendar",
        "Team analytics",
        "Admin controls"
      ]
    }
  ];
  
  // Initialize selected plan state after plans are defined
  const [selectedPlan, setSelectedPlan] = useState<PlanOption>(plans[0]);
  
  // Check for plan parameter in URL when component mounts
  useEffect(() => {
    const urlParams = new URLSearchParams(window.location.search);
    const planParam = urlParams.get('plan');
    const billingParam = urlParams.get('billing');
    const billingPeriodParam = urlParams.get('billingPeriod');
    
    // Set billing period if specified - check both potential parameter names
    if (billingParam === 'annual' || billingPeriodParam === 'annual') {
      setBillingPeriod('Annual');
    }
    
    if (planParam) {
      // Get plan by ID
      const plan = plans.find(p => p.id === planParam.toLowerCase());
      if (plan) {
        // Set the billing period on the plan
        plan.billingPeriod = billingPeriod;
        setSelectedPlan(plan);
        toast({
          title: "Plan Selected",
          description: `You're upgrading to the ${plan.name} plan with ${billingPeriod.toLowerCase()} billing.`,
        });
      }
    }
  }, [toast, billingPeriod]);

  const handleProceedToPayment = () => {
    if (!termsAccepted || !privacyAccepted || !subscriptionConsent) {
      toast({
        title: "Consent Required",
        description: "Please accept the terms and conditions to proceed.",
        variant: "destructive",
      });
      return;
    }
    
    setShowPaymentOptions(true);
  };
  
  const nextBillingDate = () => {
    const date = new Date();
    date.setMonth(date.getMonth() + 1);
    return date.toLocaleDateString('en-US', { year: 'numeric', month: 'short', day: 'numeric' });
  };

  return (
    <AppLayout pageTitle="Checkout">
      <div className="container max-w-4xl mx-auto py-10">
        <div className="mb-8">
          <h1 className="text-3xl font-bold">Complete Your Purchase</h1>
          <p className="text-muted-foreground mt-2">You're just one step away from unlocking premium features</p>
        </div>
        
        <div className="grid md:grid-cols-2 gap-8">
          <div>
            <Card className="shadow mb-6">
              <CardHeader>
                <CardTitle>Payment Details</CardTitle>
                <CardDescription>
                  Enter your payment information to complete your purchase
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="space-y-2">
                  <Label htmlFor="plan">Select Plan</Label>
                  <Select
                    value={selectedPlan.id}
                    onValueChange={(value) => {
                      const plan = plans.find(p => p.id === value);
                      if (plan) {
                        // Create a copy of the plan with the current billing period
                        const updatedPlan = {...plan, billingPeriod};
                        setSelectedPlan(updatedPlan);
                      }
                    }}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Select plan" />
                    </SelectTrigger>
                    <SelectContent>
                      {plans.map((plan) => (
                        <SelectItem key={plan.id} value={plan.id}>
                          {plan.name} - {plan.quota}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="billing">Billing Period</Label>
                  <Select
                    value={billingPeriod}
                    onValueChange={(value: "Monthly" | "Annual") => {
                      setBillingPeriod(value);
                      // Update the selected plan with the new billing period
                      setSelectedPlan(prev => ({...prev, billingPeriod: value}));
                    }}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Select billing period" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="Monthly">Monthly</SelectItem>
                      <SelectItem value="Annual">Annual (2 months free)</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="currency">Currency</Label>
                  <Select
                    value={currency}
                    onValueChange={(value) => setCurrency(value)}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Select currency" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="USD">USD - US Dollar</SelectItem>
                      <SelectItem value="INR">INR - Indian Rupee</SelectItem>
                      <SelectItem value="EUR">EUR - Euro</SelectItem>
                      <SelectItem value="GBP">GBP - British Pound</SelectItem>
                      <SelectItem value="CAD">CAD - Canadian Dollar</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                
                <div className="space-y-2">
                  <div className="border rounded-md p-3 bg-muted/30">
                    <div className="flex items-center gap-2 mb-2">
                      <CreditCard className="h-4 w-4 text-primary" />
                      <Smartphone className="h-4 w-4 text-primary" />
                      <span className="font-medium">Payment Methods</span>
                    </div>
                    <p className="text-xs text-muted-foreground">
                      We accept all major credit/debit cards, UPI, Google Pay through Razorpay, and international payments through PayPal.
                    </p>
                  </div>
                </div>
                
                <div className="border rounded-md p-4 bg-muted/50">
                  <div className="flex items-start space-x-2">
                    <AlertCircle className="h-4 w-4 mt-0.5 text-primary" />
                    <div>
                      <h4 className="font-medium">Subscription Notice</h4>
                      <p className="text-sm text-muted-foreground">
                        Your subscription will auto-renew. You can cancel anytime through your account settings page.
                      </p>
                    </div>
                  </div>
                </div>
                
                <div className="space-y-3">
                  <div className="flex items-center space-x-2">
                    <Checkbox id="terms" checked={termsAccepted} onCheckedChange={(checked) => setTermsAccepted(checked === true)} />
                    <label
                      htmlFor="terms"
                      className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
                    >
                      I accept the <span className="text-primary hover:underline cursor-pointer">Terms of Service</span>
                    </label>
                  </div>
                  
                  <div className="flex items-center space-x-2">
                    <Checkbox id="privacy" checked={privacyAccepted} onCheckedChange={(checked) => setPrivacyAccepted(checked === true)} />
                    <label
                      htmlFor="privacy"
                      className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
                    >
                      I accept the <span className="text-primary hover:underline cursor-pointer">Privacy Policy</span>
                    </label>
                  </div>
                  
                  <div className="flex items-center space-x-2">
                    <Checkbox id="consent" checked={subscriptionConsent} onCheckedChange={(checked) => setSubscriptionConsent(checked === true)} />
                    <label
                      htmlFor="consent"
                      className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
                    >
                      I consent to recurring billing and understand I can cancel anytime
                    </label>
                  </div>
                </div>
              </CardContent>
              <CardFooter>
                {!showPaymentOptions ? (
                  <Button 
                    className="w-full" 
                    onClick={handleProceedToPayment}
                    disabled={!termsAccepted || !privacyAccepted || !subscriptionConsent}
                  >
                    Proceed to Payment
                  </Button>
                ) : (
                  <div className="w-full space-y-4">
                    <div className="p-3 bg-primary/10 rounded-md mb-2">
                      <h4 className="text-sm font-semibold flex items-center">
                        <ShieldAlert className="h-4 w-4 mr-2" />
                        Payment Summary
                      </h4>
                      <div className="mt-2 text-sm">
                        <div className="flex justify-between pb-1">
                          <span>Plan:</span>
                          <span className="font-medium">{selectedPlan.name}</span>
                        </div>
                        <div className="flex justify-between pb-1">
                          <span>Billing:</span>
                          <span className="font-medium">{selectedPlan.billingPeriod}</span>
                        </div>
                        <div className="flex justify-between pb-1">
                          <span>Amount:</span>
                          <span className="font-medium">{currency} {selectedPlan.billingPeriod === "Annual" ? selectedPlan.annualPrice : selectedPlan.price}</span>
                        </div>
                      </div>
                    </div>
                    
                    <div className="mb-4">
                      <div className="text-sm font-medium mb-2">Payment Method</div>
                      <div className="grid grid-cols-2 gap-2">
                        <Button 
                          variant={paymentMethod === "razorpay" ? "default" : "outline"}
                          className="flex items-center justify-center py-2"
                          onClick={() => setPaymentMethod("razorpay")}
                        >
                          <IndianRupee className="h-4 w-4 mr-2" />
                          Razorpay
                        </Button>
                        <Button 
                          variant={paymentMethod === "paypal" ? "default" : "outline"}
                          className="flex items-center justify-center py-2"
                          onClick={() => setPaymentMethod("paypal")}
                        >
                          <CircleDollarSign className="h-4 w-4 mr-2" />
                          PayPal
                        </Button>
                      </div>
                      <div className="text-xs text-muted-foreground mt-1">
                        {paymentMethod === "razorpay" 
                          ? "For Indian customers: Pay with credit/debit cards, UPI, Google Pay, etc." 
                          : "For international customers: Pay with PayPal, credit/debit cards, etc."
                        }
                      </div>
                    </div>
                    
                    {paymentMethod === "razorpay" ? (
                      <RazorpayButton
                        amount={selectedPlan.billingPeriod === "Annual" ? selectedPlan.annualPrice : selectedPlan.price}
                        currency={currency}
                        planName={selectedPlan.name}
                        planId={selectedPlan.id}
                        billingPeriod={selectedPlan.billingPeriod}
                        quota={selectedPlan.quota}
                        onSuccess={(response) => {
                          // Will be handled by the component
                        }}
                        onError={(error) => {
                          toast({
                            title: "Payment Failed",
                            description: error.message || "Something went wrong with your payment. Please try again.",
                            variant: "destructive",
                          });
                        }}
                      />
                    ) : (
                      <div className="border rounded p-3 bg-secondary/20">
                        <PayPalButton 
                          amount={(selectedPlan.billingPeriod === "Annual" ? selectedPlan.annualPrice : selectedPlan.price).toString()}
                          currency={currency}
                          intent="CAPTURE"
                        />
                        <div className="text-xs text-muted-foreground mt-2 text-center">
                          Click the PayPal button above to complete your purchase
                        </div>
                      </div>
                    )}
                    
                    <Button 
                      variant="outline" 
                      className="w-full mt-2" 
                      onClick={() => setShowPaymentOptions(false)}
                    >
                      Go Back
                    </Button>
                  </div>
                )}
              </CardFooter>
            </Card>
            
            {!showPaymentOptions && (
              <Button 
                variant="outline" 
                className="w-full" 
                onClick={() => navigate('/pricing')}
              >
                Back to Pricing
              </Button>
            )}
          </div>
          
          <div>
            <Card className="shadow">
              <CardHeader>
                <CardTitle>Order Summary</CardTitle>
                <CardDescription>Review your subscription details</CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="space-y-3">
                  <div className="flex justify-between text-sm">
                    <span className="text-muted-foreground">Plan</span>
                    <span className="font-medium">{selectedPlan.name}</span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span className="text-muted-foreground">Description</span>
                    <span className="font-medium">{selectedPlan.description}</span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span className="text-muted-foreground">Billing Cycle</span>
                    <span className="font-medium">{selectedPlan.billingPeriod}</span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span className="text-muted-foreground">Next Billing Date</span>
                    <span className="font-medium">{nextBillingDate()}</span>
                  </div>
                </div>
                
                <div className="border-t pt-4">
                  <div className="flex justify-between">
                    <span className="font-medium">Total</span>
                    <span className="font-bold">
                      {currency} {
                        selectedPlan.billingPeriod === "Annual" 
                          ? selectedPlan.annualPrice.toFixed(2) 
                          : selectedPlan.price.toFixed(2)
                      }
                    </span>
                  </div>
                  <div className="text-xs text-muted-foreground mt-1">
                    {selectedPlan.billingPeriod === "Annual" 
                      ? `Billed annually (${currency} ${Math.round(selectedPlan.annualPrice / 12).toFixed(2)}/mo equivalent)`
                      : `Billed monthly`
                    }
                  </div>
                  {selectedPlan.billingPeriod === "Annual" && (
                    <div className="text-xs text-primary-600 font-medium mt-1">
                      You save {currency} {Math.round(selectedPlan.price * 12 - selectedPlan.annualPrice).toFixed(2)} with annual billing (2 months free)
                    </div>
                  )}
                </div>
                
                <div className="space-y-3">
                  <div className="flex items-center space-x-2 text-sm">
                    <ShieldAlert className="h-4 w-4 text-primary" />
                    <span>Secure checkout with 256-bit encryption</span>
                  </div>
                  <div className="flex items-center space-x-2 text-sm">
                    <IndianRupee className="h-4 w-4 text-primary" />
                    <span>Processed securely by Razorpay</span>
                  </div>
                </div>
                
                <div className="border-t pt-4 text-sm">
                  <h4 className="font-medium mb-2">What's included:</h4>
                  <ul className="space-y-2">
                    <li className="flex items-center">
                      <svg className="mr-2 h-4 w-4 text-green-500" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                      </svg>
                      Unlimited tasks, events & bills
                    </li>
                    <li className="flex items-center">
                      <svg className="mr-2 h-4 w-4 text-green-500" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                      </svg>
                      Calendar integrations
                    </li>
                    <li className="flex items-center">
                      <svg className="mr-2 h-4 w-4 text-green-500" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                      </svg>
                      Advanced analytics
                    </li>
                    <li className="flex items-center">
                      <svg className="mr-2 h-4 w-4 text-green-500" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                      </svg>
                      Autopay for bills
                    </li>
                    <li className="flex items-center">
                      <svg className="mr-2 h-4 w-4 text-green-500" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                      </svg>
                      Priority email support
                    </li>
                  </ul>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </AppLayout>
  );
}