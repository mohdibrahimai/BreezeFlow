import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { useLocation, Link } from "wouter";
import { Helmet } from "react-helmet";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import {
  Form,
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";

// Username lookup form schema
const usernameSchema = z.object({
  username: z.string().min(1, "Username is required"),
});

// Security answer form schema 
const securityAnswerSchema = z.object({
  answer: z.string().min(1, "Security answer is required"),
});

// Password reset form schema
const resetPasswordSchema = z.object({
  password: z.string().min(6, "Password must be at least 6 characters"),
  confirmPassword: z.string().min(6, "Password must be at least 6 characters"),
}).refine(data => data.password === data.confirmPassword, {
  message: "Passwords don't match",
  path: ["confirmPassword"],
});

type UsernameFormValues = z.infer<typeof usernameSchema>;
type SecurityAnswerFormValues = z.infer<typeof securityAnswerSchema>;
type ResetPasswordFormValues = z.infer<typeof resetPasswordSchema>;

export default function ForgotPasswordPage() {
  const { toast } = useToast();
  const [, setLocation] = useLocation();
  
  // State to track the recovery process
  const [step, setStep] = useState<"username" | "security" | "reset">("username");
  const [username, setUsername] = useState<string>("");
  const [securityQuestion, setSecurityQuestion] = useState<string>("");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  
  // Initialize forms
  const usernameForm = useForm<UsernameFormValues>({
    resolver: zodResolver(usernameSchema),
    defaultValues: {
      username: "",
    },
  });
  
  const securityForm = useForm<SecurityAnswerFormValues>({
    resolver: zodResolver(securityAnswerSchema),
    defaultValues: {
      answer: "",
    },
  });
  
  const resetForm = useForm<ResetPasswordFormValues>({
    resolver: zodResolver(resetPasswordSchema),
    defaultValues: {
      password: "",
      confirmPassword: "",
    },
  });
  
  // Handle username form submission
  const onUsernameSubmit = async (data: UsernameFormValues) => {
    setLoading(true);
    setError(null);
    
    try {
      const response = await apiRequest("POST", "/api/forgot-password/lookup", {
        username: data.username,
      });
      
      const result = await response.json();
      
      if (response.ok) {
        setUsername(data.username);
        setSecurityQuestion(result.securityQuestion);
        setStep("security");
        toast({
          title: "User found",
          description: "Please answer your security question to reset your password.",
        });
      } else {
        setError(result.message || "User not found. Please check the username and try again.");
      }
    } catch (err) {
      setError("An error occurred. Please try again later.");
    } finally {
      setLoading(false);
    }
  };
  
  // Handle security answer form submission
  const onSecurityAnswerSubmit = async (data: SecurityAnswerFormValues) => {
    setLoading(true);
    setError(null);
    
    try {
      const response = await apiRequest("POST", "/api/forgot-password/verify-answer", {
        username,
        answer: data.answer,
      });
      
      const result = await response.json();
      
      if (response.ok) {
        setStep("reset");
        toast({
          title: "Security answer verified",
          description: "You can now reset your password.",
        });
      } else {
        setError(result.message || "Incorrect security answer. Please try again.");
      }
    } catch (err) {
      setError("An error occurred. Please try again later.");
    } finally {
      setLoading(false);
    }
  };
  
  // Handle password reset form submission
  const onResetPasswordSubmit = async (data: ResetPasswordFormValues) => {
    setLoading(true);
    setError(null);
    
    try {
      const response = await apiRequest("POST", "/api/forgot-password/reset", {
        username,
        password: data.password,
      });
      
      const result = await response.json();
      
      if (response.ok) {
        toast({
          title: "Password reset successful",
          description: "Your password has been reset. You can now log in with your new password.",
        });
        setLocation("/auth");
      } else {
        setError(result.message || "Failed to reset password. Please try again.");
      }
    } catch (err) {
      setError("An error occurred. Please try again later.");
    } finally {
      setLoading(false);
    }
  };
  
  return (
    <>
      <Helmet>
        <title>Forgot Password | BreezeFlow</title>
        <meta name="description" content="Reset your BreezeFlow password using security questions" />
      </Helmet>
      
      <div className="flex min-h-screen bg-gradient-to-b from-background via-background to-muted/20">
        <div className="flex flex-col items-center justify-center w-full max-w-6xl mx-auto px-4 py-8">
          <Link href="/" className="mb-8 flex items-center text-3xl font-bold text-primary">
            <span className="mr-2">🌬️</span>
            BreezeFlow
          </Link>
          
          <Card className="w-full max-w-md">
            <CardHeader>
              <CardTitle>Reset Your Password</CardTitle>
              <CardDescription>
                {step === "username" && "Enter your username to get started"}
                {step === "security" && "Answer your security question to verify your identity"}
                {step === "reset" && "Create a new password for your account"}
              </CardDescription>
            </CardHeader>
            
            <CardContent>
              {error && (
                <Alert variant="destructive" className="mb-4">
                  <AlertDescription>{error}</AlertDescription>
                </Alert>
              )}
              
              {step === "username" && (
                <Form {...usernameForm}>
                  <form onSubmit={usernameForm.handleSubmit(onUsernameSubmit)} className="space-y-4">
                    <FormField
                      control={usernameForm.control}
                      name="username"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Username</FormLabel>
                          <FormControl>
                            <Input placeholder="Enter your username" {...field} />
                          </FormControl>
                          <FormDescription>
                            We'll use this to find your account
                          </FormDescription>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <Button type="submit" className="w-full" disabled={loading}>
                      {loading ? "Looking up account..." : "Continue"}
                    </Button>
                  </form>
                </Form>
              )}
              
              {step === "security" && (
                <Form {...securityForm}>
                  <form onSubmit={securityForm.handleSubmit(onSecurityAnswerSubmit)} className="space-y-4">
                    <div className="p-4 mb-4 bg-muted rounded-md">
                      <p className="font-medium">Security Question:</p>
                      <p className="text-sm italic mt-1">{securityQuestion}</p>
                    </div>
                    
                    <FormField
                      control={securityForm.control}
                      name="answer"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Your Answer</FormLabel>
                          <FormControl>
                            <Input placeholder="Enter your answer" {...field} />
                          </FormControl>
                          <FormDescription>
                            Answers are case-sensitive
                          </FormDescription>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <Button type="submit" className="w-full" disabled={loading}>
                      {loading ? "Verifying..." : "Verify Answer"}
                    </Button>
                  </form>
                </Form>
              )}
              
              {step === "reset" && (
                <Form {...resetForm}>
                  <form onSubmit={resetForm.handleSubmit(onResetPasswordSubmit)} className="space-y-4">
                    <FormField
                      control={resetForm.control}
                      name="password"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>New Password</FormLabel>
                          <FormControl>
                            <Input type="password" placeholder="Enter new password" {...field} />
                          </FormControl>
                          <FormDescription>
                            Must be at least 6 characters
                          </FormDescription>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <FormField
                      control={resetForm.control}
                      name="confirmPassword"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Confirm Password</FormLabel>
                          <FormControl>
                            <Input type="password" placeholder="Confirm new password" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <Button type="submit" className="w-full" disabled={loading}>
                      {loading ? "Resetting..." : "Reset Password"}
                    </Button>
                  </form>
                </Form>
              )}
            </CardContent>
            
            <CardFooter className="flex justify-center border-t pt-6">
              <div className="text-center">
                <p className="text-sm text-muted-foreground">
                  Remember your password?{" "}
                  <Link href="/auth" className="underline text-primary hover:text-primary/80">
                    Sign in
                  </Link>
                </p>
              </div>
            </CardFooter>
          </Card>
        </div>
      </div>
    </>
  );
}