import React from 'react';
import { AppLayout } from '@/components/layout/app-layout';
import { BadgeCard } from '@/components/ui/badge-card';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Progress } from '@/components/ui/progress';
import { useQuery } from '@tanstack/react-query';
import { useAuth } from '@/hooks/use-auth';
import { 
  Award, 
  Trophy, 
  Star, 
  Medal, 
  Flame, 
  Zap,
  Users
} from 'lucide-react';
import { Helmet } from 'react-helmet';

// Mock leaderboard data for demo purposes
const DEMO_LEADERBOARD = [
  { id: 1, username: 'alex_productivity', score: 850, streak: 15 },
  { id: 2, username: 'sarah_organized', score: 765, streak: 12 },
  { id: 3, username: 'mike_taskmaster', score: 720, streak: 10 },
  { id: 4, username: 'emma_planner', score: 680, streak: 8 },
  { id: 5, username: 'david_timely', score: 655, streak: 7 },
];

export default function RewardsPage() {
  const { user } = useAuth();
  const { data: rewards } = useQuery({
    queryKey: ['/api/rewards'],
  });
  
  // Calculate level based on flow score
  const userScore = user?.flow_score || 0;
  const userLevel = Math.floor(userScore / 100);
  const progressToNextLevel = userScore % 100;
  
  // Total points earned
  const totalPointsEarned = rewards?.reduce((sum, reward) => sum + reward.points_awarded, 0) || 0;
  
  // Total badges earned
  const totalBadges = rewards?.length || 0;
  
  // Current streak days
  const streakDays = user?.streak_days || 0;
  
  // Find user position in leaderboard
  const userLeaderboardPosition = () => {
    // In a real app, this would come from the API
    return DEMO_LEADERBOARD.findIndex(entry => entry.username === user?.username) + 1 || "N/A";
  };

  return (
    <AppLayout pageTitle="Rewards">
      <Helmet>
        <title>Rewards - BreezeFlow</title>
        <meta name="description" content="Track your achievements and rewards in BreezeFlow's gamified productivity system." />
      </Helmet>
      
      <div className="mb-6">
        <h1 className="text-2xl font-semibold text-gray-900 dark:text-white">Rewards</h1>
        <p className="text-gray-600 dark:text-gray-400">Track your achievements and progress</p>
      </div>
      
      {/* Flow Score Card */}
      <Card className="mb-6">
        <CardHeader className="pb-2">
          <CardTitle className="text-lg font-medium">Your Flow Score</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex items-center justify-between mb-4">
            <div>
              <div className="text-3xl font-bold text-primary">{userScore}</div>
              <div className="text-sm text-gray-500 dark:text-gray-400">Level {userLevel}</div>
            </div>
            <div className="flex items-center bg-primary-100 dark:bg-primary-900/30 px-3 py-1 rounded-full">
              <Flame className="h-4 w-4 text-primary-600 dark:text-primary-400 mr-1" />
              <span className="text-sm font-medium text-primary-600 dark:text-primary-400">{streakDays} day streak</span>
            </div>
          </div>
          
          <div>
            <div className="flex justify-between mb-1 text-sm">
              <div>Progress to Level {userLevel + 1}</div>
              <div>{progressToNextLevel}%</div>
            </div>
            <Progress value={progressToNextLevel} className="h-2" />
          </div>
        </CardContent>
      </Card>
      
      {/* Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium">Total Points</CardTitle>
            <Star className="h-5 w-5 text-yellow-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{totalPointsEarned}</div>
            <p className="text-xs text-gray-500 dark:text-gray-400">Points earned from completed tasks</p>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium">Badges Earned</CardTitle>
            <Medal className="h-5 w-5 text-amber-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{totalBadges}</div>
            <p className="text-xs text-gray-500 dark:text-gray-400">Achievement badges collected</p>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium">Leaderboard Rank</CardTitle>
            <Trophy className="h-5 w-5 text-amber-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">#{userLeaderboardPosition()}</div>
            <p className="text-xs text-gray-500 dark:text-gray-400">Your current position</p>
          </CardContent>
        </Card>
      </div>
      
      {/* Badges Section */}
      <div className="mb-6">
        <h2 className="text-lg font-semibold mb-4">Your Badges</h2>
        <BadgeCard limit={6} />
      </div>
      
      {/* Leaderboard Section */}
      <div>
        <div className="flex items-center mb-4">
          <h2 className="text-lg font-semibold">Leaderboard</h2>
          <Users className="h-5 w-5 ml-2 text-primary-600 dark:text-primary-400" />
        </div>
        
        <Card>
          <CardContent className="p-0">
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead>
                  <tr className="border-b border-gray-200 dark:border-gray-700">
                    <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">Rank</th>
                    <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">User</th>
                    <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">Flow Score</th>
                    <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">Streak</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-gray-200 dark:divide-gray-700">
                  {DEMO_LEADERBOARD.map((entry, index) => (
                    <tr 
                      key={entry.id}
                      className={entry.username === user?.username ? 
                        "bg-primary-50 dark:bg-primary-900/20" : 
                        index % 2 === 0 ? "bg-white dark:bg-gray-900" : "bg-gray-50 dark:bg-gray-800"}
                    >
                      <td className="px-4 py-3 whitespace-nowrap text-sm font-medium text-gray-900 dark:text-white">
                        {index + 1}
                      </td>
                      <td className="px-4 py-3 whitespace-nowrap text-sm text-gray-500 dark:text-gray-400">
                        {entry.username === user?.username ? (
                          <span className="font-medium text-primary-600 dark:text-primary-400">{entry.username} (You)</span>
                        ) : (
                          entry.username
                        )}
                      </td>
                      <td className="px-4 py-3 whitespace-nowrap text-sm text-gray-500 dark:text-gray-400">
                        {entry.score}
                      </td>
                      <td className="px-4 py-3 whitespace-nowrap text-sm text-gray-500 dark:text-gray-400">
                        <div className="flex items-center">
                          <Flame className="h-4 w-4 text-orange-500 mr-1" />
                          <span>{entry.streak} days</span>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </CardContent>
        </Card>
      </div>
    </AppLayout>
  );
}
