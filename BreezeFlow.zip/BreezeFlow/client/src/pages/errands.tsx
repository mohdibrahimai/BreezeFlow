import React from 'react';
import { AppLayout } from '@/components/layout/app-layout';
import { ErrandList } from '@/components/ui/errand-list';
import { QuickAdd } from '@/components/ui/quick-add';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { useQuery } from '@tanstack/react-query';
import { ShoppingCart, CheckCircle, AlarmClock, DollarSign } from 'lucide-react';
import { Helmet } from 'react-helmet';

export default function ErrandsPage() {
  const { data: errands, isLoading } = useQuery({
    queryKey: ['/api/errands'],
  });

  // Calculate errand statistics
  const upcomingErrands = errands?.filter(errand => errand.status === 'upcoming').length || 0;
  const completedErrands = errands?.filter(errand => errand.status === 'completed').length || 0;
  
  // Calculate total amount of upcoming errands
  const totalErrandAmount = React.useMemo(() => {
    if (!errands) return 0;
    
    return errands
      .filter(errand => errand.status === 'upcoming' && errand.amount)
      .reduce((sum, errand) => sum + errand.amount, 0);
  }, [errands]);
  
  // Count autopay enabled errands
  const autopayErrands = errands?.filter(errand => errand.autopay).length || 0;

  return (
    <AppLayout pageTitle="Errands">
      <Helmet>
        <title>Errands - BreezeFlow</title>
        <meta name="description" content="Track and manage your errands and shopping tasks with BreezeFlow." />
      </Helmet>
      
      <div className="mb-6">
        <h1 className="text-2xl font-semibold text-gray-900 dark:text-white">Errands</h1>
        <p className="text-gray-600 dark:text-gray-400">Track and manage your shopping and errands</p>
      </div>
      
      <div className="mb-6">
        <QuickAdd />
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-6">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium">Upcoming</CardTitle>
            <ShoppingCart className="h-4 w-4 text-primary" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{upcomingErrands}</div>
            <p className="text-xs text-gray-500 dark:text-gray-400">Errands to complete</p>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium">Completed</CardTitle>
            <CheckCircle className="h-4 w-4 text-green-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{completedErrands}</div>
            <p className="text-xs text-gray-500 dark:text-gray-400">Errands done</p>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium">Total Amount</CardTitle>
            <DollarSign className="h-4 w-4 text-amber-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              {new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD' }).format(totalErrandAmount)}
            </div>
            <p className="text-xs text-gray-500 dark:text-gray-400">For upcoming errands</p>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium">Autopay</CardTitle>
            <AlarmClock className="h-4 w-4 text-indigo-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{autopayErrands}</div>
            <p className="text-xs text-gray-500 dark:text-gray-400">Auto-scheduled errands</p>
          </CardContent>
        </Card>
      </div>
      
      <ErrandList />
    </AppLayout>
  );
}
