import { useAuth } from '@/hooks/use-auth';
import { useQuery } from '@tanstack/react-query';
import { getQueryFn } from '@/lib/queryClient';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Progress } from '@/components/ui/progress';
import { Loader2, Clock, DollarSign, BarChart, Calendar, Settings, Award } from 'lucide-react';
import { BarChart as RechartsBarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';

interface ROIData {
  hoursSaved: number;
  moneySaved: number;
  actionCount: number;
  days: number;
}

export default function ROIDashboard() {
  const { user } = useAuth();
  
  const { data: roiData, isLoading } = useQuery<ROIData>({
    queryKey: ['/api/roi'],
    queryFn: getQueryFn({ on401: 'throw' }),
    enabled: !!user,
  });
  
  // Sample chart data based on ROI
  const chartData = [
    { name: 'Time Saved', value: roiData?.hoursSaved || 0 },
    { name: 'Money Saved', value: roiData?.moneySaved || 0 },
    { name: 'Actions Completed', value: roiData?.actionCount || 0 },
  ];
  
  // Loading state
  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-[70vh]">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }
  
  return (
    <div className="container mx-auto py-8">
      <h1 className="text-3xl font-bold mb-8">ROI Dashboard</h1>
      
      <div className="grid gap-6 mb-8">
        <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
          <Card className="bg-card hover:shadow-lg transition-shadow">
            <CardHeader className="flex flex-row items-center justify-between pb-2">
              <CardTitle className="text-lg font-medium">Time Saved</CardTitle>
              <Clock className="h-5 w-5 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold">{roiData?.hoursSaved.toFixed(1) || 0} hrs</div>
              <p className="text-xs text-muted-foreground">
                That's about {Math.round((roiData?.hoursSaved || 0) * 60)} minutes saved in the last {roiData?.days || 30} days
              </p>
              <Progress className="h-2 mt-4" value={(roiData?.hoursSaved || 0) * 10} />
            </CardContent>
          </Card>
          
          <Card className="bg-card hover:shadow-lg transition-shadow">
            <CardHeader className="flex flex-row items-center justify-between pb-2">
              <CardTitle className="text-lg font-medium">Money Saved</CardTitle>
              <DollarSign className="h-5 w-5 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold">${roiData?.moneySaved.toFixed(2) || 0}</div>
              <p className="text-xs text-muted-foreground">
                That's about ${((roiData?.moneySaved || 0) * 12 / (roiData?.days || 30)).toFixed(2)} per year at this rate
              </p>
              <Progress className="h-2 mt-4" value={(roiData?.moneySaved || 0) * 5} />
            </CardContent>
          </Card>
          
          <Card className="bg-card hover:shadow-lg transition-shadow">
            <CardHeader className="flex flex-row items-center justify-between pb-2">
              <CardTitle className="text-lg font-medium">Actions Completed</CardTitle>
              <BarChart className="h-5 w-5 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold">{roiData?.actionCount || 0}</div>
              <p className="text-xs text-muted-foreground">
                That's {((roiData?.actionCount || 0) / (roiData?.days || 30)).toFixed(1)} actions per day
              </p>
              <Progress className="h-2 mt-4" value={(roiData?.actionCount || 0) * 3} />
            </CardContent>
          </Card>
        </div>
      </div>
      
      <Tabs defaultValue="chart" className="w-full">
        <TabsList className="grid w-full md:w-auto grid-cols-4">
          <TabsTrigger value="chart">Chart View</TabsTrigger>
          <TabsTrigger value="yearly">Annual Projection</TabsTrigger>
          <TabsTrigger value="activity">Activity Breakdown</TabsTrigger>
          <TabsTrigger value="settings">Settings</TabsTrigger>
        </TabsList>
        
        <TabsContent value="chart" className="border rounded-md p-4 mt-4">
          <Card>
            <CardHeader>
              <CardTitle>Your BreezeFlow ROI</CardTitle>
              <CardDescription>
                See how much time and money you've saved using BreezeFlow.
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="h-[300px] mt-4">
                <ResponsiveContainer width="100%" height="100%">
                  <RechartsBarChart data={chartData}>
                    <CartesianGrid strokeDasharray="3 3" opacity={0.3} />
                    <XAxis dataKey="name" />
                    <YAxis />
                    <Tooltip />
                    <Bar dataKey="value" fill="#3b82f6" radius={[4, 4, 0, 0]} />
                  </RechartsBarChart>
                </ResponsiveContainer>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
        
        <TabsContent value="yearly" className="mt-4">
          <Card>
            <CardHeader>
              <CardTitle>Annual ROI Projection</CardTitle>
              <CardDescription>
                Based on your current usage patterns, here's your projected annual savings.
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid md:grid-cols-2 gap-6">
                <div className="flex flex-col gap-2">
                  <div className="flex items-center gap-2">
                    <Clock className="h-5 w-5 text-muted-foreground" />
                    <span className="font-medium">Annual time saved:</span>
                    <span className="font-bold">
                      {((roiData?.hoursSaved || 0) * 365 / (roiData?.days || 30)).toFixed(1)} hours
                    </span>
                  </div>
                  <p className="text-sm text-muted-foreground pl-7">
                    That's about {Math.round(((roiData?.hoursSaved || 0) * 365 / (roiData?.days || 30)) / 24)} full days per year
                  </p>
                </div>
                
                <div className="flex flex-col gap-2">
                  <div className="flex items-center gap-2">
                    <DollarSign className="h-5 w-5 text-muted-foreground" />
                    <span className="font-medium">Annual money saved:</span>
                    <span className="font-bold">
                      ${((roiData?.moneySaved || 0) * 365 / (roiData?.days || 30)).toFixed(2)}
                    </span>
                  </div>
                  <p className="text-sm text-muted-foreground pl-7">
                    That's about ${(((roiData?.moneySaved || 0) * 365 / (roiData?.days || 30)) / 30).toFixed(2)} per month
                  </p>
                </div>
              </div>
              
              <div className="mt-8 border-t pt-6">
                <h3 className="font-medium mb-4">Lifetime value of BreezeFlow:</h3>
                <div className="bg-primary/10 p-4 rounded-md">
                  <div className="text-xl font-bold">
                    ${((roiData?.moneySaved || 0) * 365 * 5 / (roiData?.days || 30)).toFixed(2)}
                  </div>
                  <p className="text-sm text-muted-foreground">
                    Estimated 5-year savings based on your current usage
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
        
        <TabsContent value="activity" className="mt-4">
          <Card>
            <CardHeader>
              <CardTitle>Activity Breakdown</CardTitle>
              <CardDescription>
                See where you're saving the most time and money.
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="border p-4 rounded-md">
                  <div className="flex justify-between items-center mb-2">
                    <div className="flex items-center gap-2">
                      <Calendar className="h-5 w-5 text-muted-foreground" />
                      <span className="font-medium">Calendar Management</span>
                    </div>
                    <span className="text-sm">~{Math.round((roiData?.hoursSaved || 0) * 0.4)} hours saved</span>
                  </div>
                  <Progress className="h-2" value={40} />
                </div>
                
                <div className="border p-4 rounded-md">
                  <div className="flex justify-between items-center mb-2">
                    <div className="flex items-center gap-2">
                      <Award className="h-5 w-5 text-muted-foreground" />
                      <span className="font-medium">Task Automation</span>
                    </div>
                    <span className="text-sm">~{Math.round((roiData?.hoursSaved || 0) * 0.35)} hours saved</span>
                  </div>
                  <Progress className="h-2" value={35} />
                </div>
                
                <div className="border p-4 rounded-md">
                  <div className="flex justify-between items-center mb-2">
                    <div className="flex items-center gap-2">
                      <Settings className="h-5 w-5 text-muted-foreground" />
                      <span className="font-medium">Bill Management</span>
                    </div>
                    <span className="text-sm">~{Math.round((roiData?.hoursSaved || 0) * 0.25)} hours saved</span>
                  </div>
                  <Progress className="h-2" value={25} />
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
        
        <TabsContent value="settings" className="mt-4">
          <Card>
            <CardHeader>
              <CardTitle>ROI Dashboard Settings</CardTitle>
              <CardDescription>
                Customize how your ROI is calculated and displayed.
              </CardDescription>
            </CardHeader>
            <CardContent>
              <p className="text-muted-foreground">
                Settings options will be added in a future update. Currently, we're tracking your time and money saved based on your usage patterns.
              </p>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}