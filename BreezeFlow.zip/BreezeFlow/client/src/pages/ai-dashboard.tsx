import React from "react";
import { useAuth } from "@/hooks/use-auth";
import { useQuery } from "@tanstack/react-query";
import { Task, Event } from "@shared/schema";
import { 
  BatchProcessScores, 
  SmartScheduler, 
  PriorityScoreIndicator,
  ProductivityInsights
} from "@/components/ml";
import { useToast } from "@/hooks/use-toast";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { Button } from "@/components/ui/button";
import { Link } from "wouter";
import { 
  Brain, 
  Calendar, 
  ChevronLeft,
  ClipboardList, 
  Gem, 
  Lightbulb,
  Sparkles
} from "lucide-react";

export default function AIDashboard() {
  const { user } = useAuth();
  const { toast } = useToast();

  // Get user tasks
  const { data: tasks, isLoading: isLoadingTasks } = useQuery<Task[]>({
    queryKey: ['/api/tasks'],
    enabled: !!user,
  });
  
  // Count ML-enhanced tasks
  const tasksWithScore = tasks?.filter(task => 
    task.priority_score !== null && task.status !== 'done'
  ).length || 0;
  
  // Check if the user has ML-enhanced tasks
  const hasEnhancedTasks = tasksWithScore > 0;
  
  // Check if user plan allows ML features
  const isPremiumPlan = user?.plan === 'starter' || user?.plan === 'pro' || user?.plan === 'team';
  
  if (!user) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="text-center">
          <h1 className="text-2xl font-bold">Please log in</h1>
          <p className="text-muted-foreground">You need to be logged in to access this page.</p>
        </div>
      </div>
    );
  }
  
  if (!isPremiumPlan) {
    return (
      <div className="container mx-auto py-8 px-4">
        <div className="text-center mb-8">
          <Gem className="h-12 w-12 mx-auto mb-4 text-purple-500" />
          <h1 className="text-3xl font-bold mb-2">Premium Feature</h1>
          <p className="text-muted-foreground">
            Smart task prioritization is available on Starter, Pro, and Team plans.
          </p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 max-w-5xl mx-auto">
          <div className="p-6 border rounded-lg shadow-sm bg-gradient-to-br from-blue-50 to-indigo-50">
            <Sparkles className="h-8 w-8 mb-3 text-blue-500" />
            <h3 className="text-xl font-medium mb-2">ML Task Prioritization</h3>
            <p className="text-gray-600">
              Let AI determine which tasks are most important based on your completion history and work patterns.
            </p>
          </div>
          
          <div className="p-6 border rounded-lg shadow-sm bg-gradient-to-br from-green-50 to-emerald-50">
            <Brain className="h-8 w-8 mb-3 text-green-500" />
            <h3 className="text-xl font-medium mb-2">Smart Scheduling</h3>
            <p className="text-gray-600">
              Automatically organize your day with AI that optimizes your calendar and tasks.
            </p>
          </div>
          
          <div className="p-6 border rounded-lg shadow-sm bg-gradient-to-br from-purple-50 to-pink-50">
            <Lightbulb className="h-8 w-8 mb-3 text-purple-500" />
            <h3 className="text-xl font-medium mb-2">Productivity Insights</h3>
            <p className="text-gray-600">
              Get personalized recommendations to improve your workflow and save time.
            </p>
          </div>
        </div>
        
        <div className="text-center mt-8">
          <button 
            className="px-6 py-3 bg-gradient-to-r from-blue-500 to-indigo-600 text-white rounded-md font-medium shadow-md hover:shadow-lg transition-all"
            onClick={() => toast({
              title: "Upgrade Available",
              description: "Please visit the pricing page to upgrade your plan."
            })}
          >
            Upgrade Your Plan
          </button>
        </div>
      </div>
    );
  }
  
  return (
    <div className="container mx-auto py-8 px-4">
      <div className="flex justify-between items-start mb-6">
        <Link href="/dashboard">
          <Button variant="ghost" size="sm" className="mb-4">
            <ChevronLeft className="mr-1 h-4 w-4" />
            Back to Dashboard
          </Button>
        </Link>
      </div>
      
      <div className="mb-8">
        <h1 className="text-3xl font-bold flex items-center">
          <Brain className="mr-3 h-8 w-8 text-primary" />
          AI Assistant Dashboard
        </h1>
        <p className="text-muted-foreground mt-1">
          Enhance your productivity with machine learning powered tools
        </p>
      </div>
      
      {!hasEnhancedTasks && (
        <Alert className="mb-8 bg-blue-50 border-blue-200">
          <Lightbulb className="h-4 w-4" />
          <AlertTitle>Get Started with AI Prioritization</AlertTitle>
          <AlertDescription>
            Use the batch processor below to analyze your tasks and generate ML-powered priority scores. 
            This helps BreezeFlow determine which tasks are most important for you.
          </AlertDescription>
        </Alert>
      )}
      
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-8">
        <BatchProcessScores userId={user.id} />
        
        <div className="space-y-6">
          <div className="p-6 border rounded-lg shadow-sm bg-gradient-to-br from-indigo-50 to-purple-50">
            <div className="flex items-center mb-3">
              <Brain className="h-6 w-6 mr-2 text-indigo-600" />
              <h2 className="text-xl font-semibold">How ML Prioritization Works</h2>
            </div>
            <ul className="space-y-2 text-gray-700">
              <li className="flex items-start">
                <span className="inline-flex items-center justify-center h-6 w-6 rounded-full bg-indigo-100 text-indigo-800 mr-2 text-sm font-medium">1</span>
                <span>BreezeFlow analyzes your task completion patterns and history</span>
              </li>
              <li className="flex items-start">
                <span className="inline-flex items-center justify-center h-6 w-6 rounded-full bg-indigo-100 text-indigo-800 mr-2 text-sm font-medium">2</span>
                <span>Our ML model assigns priority scores from 0-100 to each task</span>
              </li>
              <li className="flex items-start">
                <span className="inline-flex items-center justify-center h-6 w-6 rounded-full bg-indigo-100 text-indigo-800 mr-2 text-sm font-medium">3</span>
                <span>Higher scores indicate tasks you're more likely to complete on time</span>
              </li>
              <li className="flex items-start">
                <span className="inline-flex items-center justify-center h-6 w-6 rounded-full bg-indigo-100 text-indigo-800 mr-2 text-sm font-medium">4</span>
                <span>Your productivity metrics are calculated based on these scores</span>
              </li>
            </ul>
          </div>
          
          <div className="p-6 border rounded-lg shadow-sm bg-gradient-to-br from-green-50 to-emerald-50">
            <div className="flex items-center mb-3">
              <ClipboardList className="h-6 w-6 mr-2 text-green-600" />
              <h2 className="text-xl font-semibold">Productivity Metrics</h2>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div className="p-3 bg-white rounded-lg border border-gray-100 shadow-sm">
                <p className="text-sm text-gray-500">Time Saved</p>
                <p className="text-2xl font-bold text-green-600">{Math.round((tasksWithScore || 0) * 30)} min</p>
              </div>
              <div className="p-3 bg-white rounded-lg border border-gray-100 shadow-sm">
                <p className="text-sm text-gray-500">Tasks Enhanced</p>
                <p className="text-2xl font-bold text-indigo-600">{tasksWithScore || 0}</p>
              </div>
              <div className="p-3 bg-white rounded-lg border border-gray-100 shadow-sm">
                <p className="text-sm text-gray-500">Money Saved</p>
                <p className="text-2xl font-bold text-emerald-600">${Math.round((tasksWithScore || 0) * 5)}</p>
              </div>
              <div className="p-3 bg-white rounded-lg border border-gray-100 shadow-sm">
                <p className="text-sm text-gray-500">Efficiency Gain</p>
                <p className="text-2xl font-bold text-purple-600">{tasksWithScore ? Math.min(95, tasksWithScore * 5) : 0}%</p>
              </div>
            </div>
          </div>
        </div>
      </div>
      
      <div className="mb-8">
        <SmartScheduler userId={user.id} />
      </div>
      
      <div className="mb-8">
        <div className="flex items-center mb-4">
          <Lightbulb className="h-6 w-6 mr-2 text-yellow-500" />
          <h2 className="text-2xl font-semibold">Productivity Insights</h2>
        </div>
        <ProductivityInsights userId={user.id} />
      </div>
    </div>
  );
}