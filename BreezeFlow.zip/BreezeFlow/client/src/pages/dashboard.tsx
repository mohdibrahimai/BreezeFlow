import React from 'react';
import { AppLayout } from '@/components/layout/app-layout';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { useQuery } from '@tanstack/react-query';
import { useAuth } from '@/hooks/use-auth';
import { UpcomingEvents } from '@/components/ui/upcoming-events';
import { FlowScore } from '@/components/ui/flow-score';
import { QuickAdd } from '@/components/ui/quick-add';
import { TaskBoard } from '@/components/ui/task-board';
import { CalendarView } from '@/components/ui/calendar-view';
import { ReminderList } from '@/components/ui/reminder-list';
import { CheckSquare, CheckCircle, CreditCard, Calendar } from 'lucide-react';
import { Helmet } from 'react-helmet';

export default function Dashboard() {
  const { user } = useAuth();
  
  interface Task {
    id: number;
    status: string;
    title: string;
    priority: string;
    // other fields...
  }
  
  interface Event {
    id: number;
    title: string;
    start: string;
    end: string;
    // other fields...
  }
  
  interface Bill {
    id: number;
    status: string;
    provider: string;
    amount: number | null;
    due_date: string | null;
    // other fields...
  }
  
  const { data: tasks } = useQuery<Task[]>({
    queryKey: ['/api/tasks'],
  });
  
  const { data: events } = useQuery<Event[]>({
    queryKey: ['/api/events'],
  });
  
  const { data: bills } = useQuery<Bill[]>({
    queryKey: ['/api/bills'],
  });
  
  // Calculate stats
  const todayTasks = tasks?.filter(task => task.status === 'today').length || 0;
  const doneTasks = tasks?.filter(task => task.status === 'done').length || 0;
  const upcomingEvents = events?.length || 0;
  const upcomingBills = bills?.filter(bill => bill.status === 'upcoming').length || 0;

  return (
    <AppLayout pageTitle="Dashboard">
      <Helmet>
        <title>Dashboard - BreezeFlow</title>
        <meta name="description" content="View your personalized BreezeFlow dashboard with tasks, events, and productivity metrics." />
      </Helmet>
      
      <div className="mb-6">
        <h1 className="text-2xl font-semibold text-gray-900 dark:text-white">Dashboard</h1>
        <p className="text-gray-600 dark:text-gray-400">Welcome back, {user?.name}!</p>
      </div>
      
      {/* Stats Overview */}
      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-4 mb-6">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium">Today's Tasks</CardTitle>
            <CheckSquare className="h-4 w-4 text-primary" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{todayTasks}</div>
            <p className="text-xs text-gray-500 dark:text-gray-400">Tasks to complete</p>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium">Completed Tasks</CardTitle>
            <CheckCircle className="h-4 w-4 text-green-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{doneTasks}</div>
            <p className="text-xs text-gray-500 dark:text-gray-400">Tasks completed</p>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium">Upcoming Events</CardTitle>
            <Calendar className="h-4 w-4 text-blue-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{upcomingEvents}</div>
            <p className="text-xs text-gray-500 dark:text-gray-400">Scheduled events</p>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium">Bills Due</CardTitle>
            <CreditCard className="h-4 w-4 text-red-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{upcomingBills}</div>
            <p className="text-xs text-gray-500 dark:text-gray-400">Upcoming payments</p>
          </CardContent>
        </Card>
      </div>
      
      {/* Overview Banner */}
      <div className="grid grid-cols-1 gap-6 md:grid-cols-3 mb-6">
        <UpcomingEvents />
        <div className="md:col-span-1">
          <FlowScore 
            flowScore={user?.flow_score || 0} 
            streakDays={user?.streak_days || 0} 
          />
        </div>
        <div className="md:col-span-1">
          <QuickAdd />
        </div>
      </div>
      
      {/* Bill Reminders & Task Board Layout */}
      <div className="grid grid-cols-1 lg:grid-cols-4 gap-6 mb-6">
        <div className="lg:col-span-1">
          <ReminderList />
        </div>
        <div className="lg:col-span-3">
          {/* Task Board */}
          <TaskBoard />
        </div>
      </div>
      
      {/* Calendar */}
      <CalendarView />
    </AppLayout>
  );
}
