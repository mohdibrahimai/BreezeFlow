import React from "react";
import { useMutation, useQuery } from "@tanstack/react-query";
import { Task } from "@shared/schema";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";
import { Brain, Loader } from "lucide-react";
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import {
  Alert,
  AlertDescription,
  AlertTitle,
} from "@/components/ui/alert";
import { Badge } from "@/components/ui/badge";

interface BatchProcessScoresProps {
  userId: number;
}

export function BatchProcessScores({ userId }: BatchProcessScoresProps) {
  const { toast } = useToast();
  
  // Get all tasks
  const { data: tasks, isLoading: isLoadingTasks } = useQuery<Task[]>({
    queryKey: ['/api/tasks'],
    enabled: !!userId, // Only fetch if we have a userId
  });
  
  // Count tasks with and without scores
  const tasksWithScore = tasks?.filter(task => task.priority_score !== null && task.status !== 'done') || [];
  const tasksWithoutScore = tasks?.filter(task => (task.priority_score === null || task.priority_score === undefined) && task.status !== 'done') || [];
  const totalActiveTasks = tasks?.filter(task => task.status !== 'done').length || 0;
  
  // Mutation to calculate all priority scores
  const batchCalculateMutation = useMutation({
    mutationFn: async () => {
      const taskIds = tasksWithoutScore.map(task => task.id);
      const res = await apiRequest("POST", "/api/ml/batchPriorityScore", { taskIds });
      return await res.json();
    },
    onSuccess: (data) => {
      // Update the tasks with the new scores in the cache
      const cachedTasks = queryClient.getQueryData<Task[]>(['/api/tasks']);
      if (cachedTasks) {
        const updatedTasks = cachedTasks.map(task => {
          const scoreData = data.find((item: { taskId: number; score: number }) => item.taskId === task.id);
          if (scoreData) {
            return { ...task, priority_score: scoreData.score };
          }
          return task;
        });
        queryClient.setQueryData(['/api/tasks'], updatedTasks);
      }
      
      toast({
        title: "Priority Scores Updated",
        description: `Calculated scores for ${data.length} tasks`,
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Failed to calculate priority scores",
        description: error.message,
        variant: "destructive",
      });
    },
  });
  
  const handleBatchProcess = () => {
    if (tasksWithoutScore.length === 0) {
      toast({
        title: "No tasks to process",
        description: "All active tasks already have priority scores",
      });
      return;
    }
    
    batchCalculateMutation.mutate();
  };
  
  // Determine if button should be disabled
  const isButtonDisabled = 
    isLoadingTasks || 
    batchCalculateMutation.isPending || 
    tasksWithoutScore.length === 0;
  
  return (
    <Card className="w-full">
      <CardHeader>
        <CardTitle className="flex items-center">
          <Brain className="mr-2" />
          Smart Task Prioritization
        </CardTitle>
        <CardDescription>
          Use machine learning to prioritize your tasks based on your completion history
        </CardDescription>
      </CardHeader>
      
      <CardContent>
        {isLoadingTasks ? (
          <div className="flex justify-center py-4">
            <Loader className="animate-spin" />
          </div>
        ) : (
          <>
            <div className="flex flex-wrap gap-2 mb-4">
              <Badge variant="outline" className="bg-blue-50">
                Total active tasks: {totalActiveTasks}
              </Badge>
              <Badge variant="outline" className="bg-green-50">
                Tasks with score: {tasksWithScore.length}
              </Badge>
              <Badge variant="outline" className="bg-yellow-50">
                Tasks without score: {tasksWithoutScore.length}
              </Badge>
            </div>
            
            {tasksWithScore.length > 0 && (
              <Alert className="mb-4 bg-green-50 border-green-200">
                <AlertTitle>ML Prioritization Active</AlertTitle>
                <AlertDescription>
                  {tasksWithScore.length} of your active tasks are using ML-based prioritization.
                  This helps determine which tasks are most important for you.
                </AlertDescription>
              </Alert>
            )}
            
            {tasksWithoutScore.length > 0 && (
              <Alert className="mb-4 bg-yellow-50 border-yellow-200">
                <AlertTitle>Tasks Need Processing</AlertTitle>
                <AlertDescription>
                  {tasksWithoutScore.length} tasks don't have priority scores yet.
                  Click 'Calculate All Scores' to prioritize them with machine learning.
                </AlertDescription>
              </Alert>
            )}
          </>
        )}
      </CardContent>
      
      <CardFooter>
        <Button 
          className="w-full"
          onClick={handleBatchProcess}
          disabled={isButtonDisabled}
        >
          {batchCalculateMutation.isPending ? (
            <>
              <Loader className="mr-2 h-4 w-4 animate-spin" />
              Processing...
            </>
          ) : (
            <>
              <Brain className="mr-2 h-4 w-4" />
              Calculate All Scores
            </>
          )}
        </Button>
      </CardFooter>
    </Card>
  );
}