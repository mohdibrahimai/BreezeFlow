import React, { useState } from 'react';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { useMutation, useQueryClient } from '@tanstack/react-query';
import { Loader2, RefreshCcw, ChevronUp, ChevronDown, AlertCircle, CheckCircle } from 'lucide-react';
import { useToast } from "@/hooks/use-toast";
import { Progress } from '@/components/ui/progress';
import { Badge } from '@/components/ui/badge';
import { apiRequest } from '@/lib/queryClient';

interface BatchProcessScoresProps {
  userId: number;
}

interface BatchScoreResults {
  stats: {
    total_tasks: number;
    average_score: number;
    total_estimated_minutes: number;
    high_priority_count: number;
    medium_priority_count: number;
    low_priority_count: number;
  };
  categories: {
    high_priority: Array<{
      id: number;
      title: string;
      score: number;
      message: string;
      risk_factors: string[];
      suggestions: string[];
      estimated_completion_minutes: number;
    }>;
    medium_priority: Array<any>;
    low_priority: Array<any>;
  };
  insights: {
    common_risk_factors: Array<{ factor: string; count: number }>;
    common_suggestions: Array<{ suggestion: string; count: number }>;
  };
  time_management: {
    estimated_hours: number;
    recommended_daily_tasks: number;
    focus_areas: string[];
  };
}

export function BatchProcessScores({ userId }: BatchProcessScoresProps) {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [expandedCategory, setExpandedCategory] = useState<string | null>('high_priority');
  
  const processMutation = useMutation({
    mutationFn: async () => {
      const res = await apiRequest('POST', '/api/ml/batch-process-scores', { userId });
      return res.json() as Promise<BatchScoreResults>;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/ml/productivity-insights', userId] });
      toast({
        title: "Scores processed successfully",
        description: "All your tasks have been analyzed with the latest ML model.",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Processing failed",
        description: error.message,
        variant: "destructive",
      });
    },
  });
  
  const handleProcess = () => {
    processMutation.mutate();
  };
  
  const handleToggleCategory = (category: string) => {
    setExpandedCategory(expandedCategory === category ? null : category);
  };
  
  return (
    <Card className="w-full">
      <CardHeader>
        <CardTitle>Task Priority Analysis</CardTitle>
        <CardDescription>
          Use machine learning to analyze and prioritize your tasks
        </CardDescription>
      </CardHeader>
      <CardContent>
        {!processMutation.data ? (
          <div className="flex flex-col items-center justify-center py-8 space-y-4">
            <div className="rounded-full bg-muted p-6">
              <RefreshCcw className="h-8 w-8 text-primary" />
            </div>
            <div className="text-center space-y-2">
              <h3 className="text-lg font-medium">Run Task Analysis</h3>
              <p className="text-sm text-muted-foreground max-w-md">
                Process all your tasks with our Smart Priority ML model to get personalized scores and insights.
              </p>
            </div>
            <Button 
              onClick={handleProcess} 
              disabled={processMutation.isPending}
              className="mt-4"
            >
              {processMutation.isPending && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
              {processMutation.isPending ? 'Processing...' : 'Analyze Tasks'}
            </Button>
          </div>
        ) : (
          <div className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="bg-muted rounded-lg p-4">
                <h3 className="text-sm font-medium mb-2">Priority Distribution</h3>
                <div className="space-y-2">
                  <div className="flex justify-between text-xs">
                    <span>High Priority</span>
                    <span>{processMutation.data.stats.high_priority_count} tasks</span>
                  </div>
                  <Progress 
                    value={(processMutation.data.stats.high_priority_count / processMutation.data.stats.total_tasks) * 100} 
                    className="h-2 bg-red-200"
                  />
                  
                  <div className="flex justify-between text-xs mt-2">
                    <span>Medium Priority</span>
                    <span>{processMutation.data.stats.medium_priority_count} tasks</span>
                  </div>
                  <Progress 
                    value={(processMutation.data.stats.medium_priority_count / processMutation.data.stats.total_tasks) * 100} 
                    className="h-2 bg-amber-200"
                  />
                  
                  <div className="flex justify-between text-xs mt-2">
                    <span>Low Priority</span>
                    <span>{processMutation.data.stats.low_priority_count} tasks</span>
                  </div>
                  <Progress 
                    value={(processMutation.data.stats.low_priority_count / processMutation.data.stats.total_tasks) * 100} 
                    className="h-2 bg-green-200"
                  />
                </div>
              </div>
              
              <div className="bg-muted rounded-lg p-4">
                <h3 className="text-sm font-medium mb-2">Time Required</h3>
                <div className="flex items-center justify-center h-[80%]">
                  <div className="text-center">
                    <span className="text-4xl font-bold block">
                      {processMutation.data.time_management.estimated_hours}
                    </span>
                    <span className="text-xs text-muted-foreground">
                      estimated hours
                    </span>
                  </div>
                </div>
              </div>
              
              <div className="bg-muted rounded-lg p-4">
                <h3 className="text-sm font-medium mb-2">Recommendation</h3>
                <div className="space-y-2">
                  <p className="text-sm">
                    Focus on completing <span className="font-bold">{processMutation.data.time_management.recommended_daily_tasks}</span> tasks per day.
                  </p>
                  
                  <h4 className="text-xs font-medium mt-3">Focus areas:</h4>
                  <div className="flex flex-wrap gap-1">
                    {processMutation.data.time_management.focus_areas.map((area, index) => (
                      <Badge key={index} variant="outline">{area}</Badge>
                    ))}
                  </div>
                </div>
              </div>
            </div>
            
            <div className="space-y-3">
              <h3 className="text-sm font-medium">Task Categories</h3>
              
              <div 
                className="bg-muted rounded-lg p-3 cursor-pointer" 
                onClick={() => handleToggleCategory('high_priority')}
              >
                <div className="flex justify-between items-center">
                  <div className="flex items-center">
                    <AlertCircle className="mr-2 h-4 w-4 text-red-500" />
                    <span className="font-medium">High Priority ({processMutation.data.categories.high_priority.length})</span>
                  </div>
                  {expandedCategory === 'high_priority' ? <ChevronUp className="h-4 w-4" /> : <ChevronDown className="h-4 w-4" />}
                </div>
                
                {expandedCategory === 'high_priority' && (
                  <div className="mt-3 space-y-2">
                    {processMutation.data.categories.high_priority.length > 0 ? (
                      processMutation.data.categories.high_priority.map((task) => (
                        <div key={task.id} className="bg-white rounded p-2 text-sm">
                          <div className="flex justify-between">
                            <span className="font-medium">{task.title}</span>
                            <Badge variant="outline">Score: {task.score}</Badge>
                          </div>
                          <p className="text-xs text-muted-foreground mt-1">{task.message}</p>
                          {task.risk_factors.length > 0 && (
                            <div className="mt-2">
                              <span className="text-xs font-medium">Risk factors:</span>
                              <ul className="text-xs ml-4 mt-1">
                                {task.risk_factors.map((factor, idx) => (
                                  <li key={idx} className="list-disc">{factor}</li>
                                ))}
                              </ul>
                            </div>
                          )}
                        </div>
                      ))
                    ) : (
                      <p className="text-sm text-muted-foreground">No high priority tasks found.</p>
                    )}
                  </div>
                )}
              </div>
              
              <div 
                className="bg-muted rounded-lg p-3 cursor-pointer" 
                onClick={() => handleToggleCategory('medium_priority')}
              >
                <div className="flex justify-between items-center">
                  <div className="flex items-center">
                    <AlertCircle className="mr-2 h-4 w-4 text-amber-500" />
                    <span className="font-medium">Medium Priority ({processMutation.data.categories.medium_priority.length})</span>
                  </div>
                  {expandedCategory === 'medium_priority' ? <ChevronUp className="h-4 w-4" /> : <ChevronDown className="h-4 w-4" />}
                </div>
                
                {expandedCategory === 'medium_priority' && (
                  <div className="mt-3 space-y-2">
                    {processMutation.data.categories.medium_priority.length > 0 ? (
                      processMutation.data.categories.medium_priority.slice(0, 3).map((task) => (
                        <div key={task.id} className="bg-white rounded p-2 text-sm">
                          <div className="flex justify-between">
                            <span className="font-medium">{task.title}</span>
                            <Badge variant="outline">Score: {task.score}</Badge>
                          </div>
                        </div>
                      ))
                    ) : (
                      <p className="text-sm text-muted-foreground">No medium priority tasks found.</p>
                    )}
                    
                    {processMutation.data.categories.medium_priority.length > 3 && (
                      <div className="text-center text-xs text-muted-foreground">
                        +{processMutation.data.categories.medium_priority.length - 3} more tasks
                      </div>
                    )}
                  </div>
                )}
              </div>
              
              <div 
                className="bg-muted rounded-lg p-3 cursor-pointer" 
                onClick={() => handleToggleCategory('low_priority')}
              >
                <div className="flex justify-between items-center">
                  <div className="flex items-center">
                    <CheckCircle className="mr-2 h-4 w-4 text-green-500" />
                    <span className="font-medium">Low Priority ({processMutation.data.categories.low_priority.length})</span>
                  </div>
                  {expandedCategory === 'low_priority' ? <ChevronUp className="h-4 w-4" /> : <ChevronDown className="h-4 w-4" />}
                </div>
                
                {expandedCategory === 'low_priority' && (
                  <div className="mt-3 space-y-2">
                    {processMutation.data.categories.low_priority.length > 0 ? (
                      processMutation.data.categories.low_priority.slice(0, 3).map((task) => (
                        <div key={task.id} className="bg-white rounded p-2 text-sm">
                          <div className="flex justify-between">
                            <span className="font-medium">{task.title}</span>
                            <Badge variant="outline">Score: {task.score}</Badge>
                          </div>
                        </div>
                      ))
                    ) : (
                      <p className="text-sm text-muted-foreground">No low priority tasks found.</p>
                    )}
                    
                    {processMutation.data.categories.low_priority.length > 3 && (
                      <div className="text-center text-xs text-muted-foreground">
                        +{processMutation.data.categories.low_priority.length - 3} more tasks
                      </div>
                    )}
                  </div>
                )}
              </div>
            </div>
            
            <Button 
              onClick={handleProcess} 
              disabled={processMutation.isPending}
              variant="outline"
              className="w-full"
            >
              {processMutation.isPending && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
              {processMutation.isPending ? 'Processing...' : 'Reanalyze Tasks'}
            </Button>
          </div>
        )}
      </CardContent>
      <CardFooter className="text-xs text-muted-foreground">
        Powered by BreezeFlow's Smart Priority ML Engine
      </CardFooter>
    </Card>
  );
}

export default BatchProcessScores;