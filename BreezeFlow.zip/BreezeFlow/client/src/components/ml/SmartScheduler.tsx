import React, { useState } from 'react';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Calendar } from "@/components/ui/calendar";
import { useMutation, useQuery } from '@tanstack/react-query';
import { Loader2, Calendar as CalendarIcon, Clock, CheckCircle2, X } from 'lucide-react';
import { useToast } from "@/hooks/use-toast";
import { format } from 'date-fns';
import { Badge } from '@/components/ui/badge';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { cn } from '@/lib/utils';
import { apiRequest } from '@/lib/queryClient';

interface SmartSchedulerProps {
  userId: number;
}

interface TimeBlock {
  title: string;
  startISO: string;
  endISO: string;
  taskId?: number;
  isFixed?: boolean;
}

interface OptimizedSchedule {
  timeBlocks: TimeBlock[];
  unscheduledTasks?: { id: number; title: string }[];
}

export function SmartScheduler({ userId }: SmartSchedulerProps) {
  const { toast } = useToast();
  const [date, setDate] = useState<Date>(new Date());
  const [isGenerating, setIsGenerating] = useState(false);
  
  const { data: schedule, isLoading } = useQuery<OptimizedSchedule, Error>({
    queryKey: ['/api/ml/optimized-schedule', format(date, 'yyyy-MM-dd'), userId],
    queryFn: () => {
      return fetch(`/api/ml/optimized-schedule?date=${format(date, 'yyyy-MM-dd')}&userId=${userId}`)
        .then(res => {
          if (!res.ok) throw new Error('Failed to fetch schedule');
          return res.json();
        });
    },
    enabled: false, // Don't fetch automatically
  });
  
  const generateMutation = useMutation({
    mutationFn: async () => {
      setIsGenerating(true);
      const res = await apiRequest('POST', '/api/ml/generate-schedule', { 
        userId,
        date: format(date, 'yyyy-MM-dd')
      });
      const data = await res.json();
      setIsGenerating(false);
      return data as OptimizedSchedule;
    },
    onSuccess: () => {
      toast({
        title: "Schedule optimized",
        description: "Your daily schedule has been optimized based on task priorities.",
      });
    },
    onError: (error: Error) => {
      setIsGenerating(false);
      toast({
        title: "Optimization failed",
        description: error.message,
        variant: "destructive",
      });
    },
  });
  
  const handleGenerateSchedule = () => {
    generateMutation.mutate();
  };
  
  const formatTime = (isoString: string) => {
    return format(new Date(isoString), 'h:mm a');
  };
  
  const getScheduleData = () => {
    return generateMutation.data || schedule;
  };
  
  const scheduleData = getScheduleData();
  
  return (
    <Card className="w-full">
      <CardHeader>
        <CardTitle>Smart Schedule Optimizer</CardTitle>
        <CardDescription>
          Generate an AI-optimized daily schedule based on your tasks and priorities
        </CardDescription>
      </CardHeader>
      <CardContent>
        <div className="grid grid-cols-1 md:grid-cols-5 gap-6">
          <div className="md:col-span-2">
            <div className="space-y-4">
              <div className="space-y-2">
                <h3 className="text-sm font-medium">Select Date</h3>
                <Popover>
                  <PopoverTrigger asChild>
                    <Button
                      variant="outline"
                      className="w-full justify-start text-left font-normal"
                    >
                      <CalendarIcon className="mr-2 h-4 w-4" />
                      {date ? format(date, 'PPP') : <span>Pick a date</span>}
                    </Button>
                  </PopoverTrigger>
                  <PopoverContent className="w-auto p-0">
                    <Calendar
                      mode="single"
                      selected={date}
                      onSelect={(date) => date && setDate(date)}
                      initialFocus
                    />
                  </PopoverContent>
                </Popover>
              </div>
              
              <div className="pt-4">
                <Button 
                  onClick={handleGenerateSchedule} 
                  disabled={isGenerating || isLoading}
                  className="w-full"
                >
                  {(isGenerating || isLoading) && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                  {isGenerating ? 'Generating Schedule...' : 'Generate Optimized Schedule'}
                </Button>
              </div>
              
              {scheduleData?.unscheduledTasks && scheduleData.unscheduledTasks.length > 0 && (
                <div className="pt-4 border-t mt-4">
                  <h3 className="text-sm font-medium mb-3">Unscheduled Tasks</h3>
                  <div className="space-y-2">
                    {scheduleData.unscheduledTasks.map((task) => (
                      <div 
                        key={task.id} 
                        className="text-sm bg-muted p-2 rounded-md flex justify-between items-center"
                      >
                        <span>{task.title}</span>
                        <X className="h-4 w-4 text-muted-foreground" />
                      </div>
                    ))}
                  </div>
                  <p className="text-xs text-muted-foreground mt-2">
                    These tasks could not be scheduled due to time constraints.
                  </p>
                </div>
              )}
            </div>
          </div>
          
          <div className="md:col-span-3">
            <h3 className="text-sm font-medium mb-3">Daily Schedule</h3>
            
            {!scheduleData || scheduleData.timeBlocks.length === 0 ? (
              <div className="border rounded-md flex flex-col items-center justify-center py-12 px-4 text-center">
                <Clock className="h-10 w-10 text-muted-foreground mb-4" />
                <h3 className="text-lg font-medium">No Schedule Generated</h3>
                <p className="text-sm text-muted-foreground max-w-sm mt-2">
                  Select a date and generate your optimized schedule to see your AI-powered daily plan here.
                </p>
              </div>
            ) : (
              <div className="space-y-3">
                {scheduleData.timeBlocks.map((block, index) => (
                  <div 
                    key={index} 
                    className={cn(
                      "border rounded-md p-3",
                      block.isFixed ? "bg-muted/50" : block.taskId ? "border-primary/10 bg-primary/5" : ""
                    )}
                  >
                    <div className="flex justify-between items-start">
                      <div>
                        <h4 className="text-sm font-medium">{block.title}</h4>
                        <div className="flex items-center text-xs text-muted-foreground mt-1">
                          <Clock className="h-3 w-3 mr-1" />
                          <span>
                            {formatTime(block.startISO)} - {formatTime(block.endISO)}
                          </span>
                        </div>
                      </div>
                      
                      <div>
                        {block.isFixed ? (
                          <Badge variant="outline" className="text-xs">Fixed</Badge>
                        ) : block.taskId ? (
                          <CheckCircle2 className="h-4 w-4 text-primary" />
                        ) : null}
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      </CardContent>
      <CardFooter className="text-xs text-muted-foreground">
        Schedule optimization based on your task priority scores and calendar events
      </CardFooter>
    </Card>
  );
}

export default SmartScheduler;