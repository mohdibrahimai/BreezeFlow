import React from 'react';
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip";
import { AlertCircle, XCircle, CheckCircle, Clock, AlertTriangle } from 'lucide-react';

interface PriorityScoreIndicatorProps {
  score: number;
  size?: 'sm' | 'md' | 'lg';
  showTooltip?: boolean;
  tooltipPlacement?: 'top' | 'right' | 'bottom' | 'left';
}

export function PriorityScoreIndicator({ 
  score, 
  size = 'md', 
  showTooltip = true,
  tooltipPlacement = 'top'
}: PriorityScoreIndicatorProps) {
  // Get icon and color based on score
  const getIconAndColor = () => {
    if (score >= 80) {
      return {
        icon: <CheckCircle className={getSizeClass()} />,
        color: 'text-green-500',
        label: 'High Priority',
        description: 'This task should be prioritized above others'
      };
    } else if (score >= 60) {
      return {
        icon: <AlertCircle className={getSizeClass()} />,
        color: 'text-amber-500',
        label: 'Medium Priority',
        description: 'This task should be completed soon'
      };
    } else if (score >= 40) {
      return {
        icon: <AlertTriangle className={getSizeClass()} />,
        color: 'text-orange-500',
        label: 'Normal Priority',
        description: 'This task is of normal importance'
      };
    } else if (score >= 20) {
      return {
        icon: <Clock className={getSizeClass()} />,
        color: 'text-slate-500',
        label: 'Low Priority',
        description: 'This task can be done when you have time'
      };
    } else {
      return {
        icon: <XCircle className={getSizeClass()} />,
        color: 'text-muted-foreground',
        label: 'Very Low Priority',
        description: 'Consider whether this task is still needed'
      };
    }
  };
  
  // Get size class for the icon
  const getSizeClass = () => {
    switch (size) {
      case 'sm':
        return 'h-3 w-3';
      case 'lg':
        return 'h-5 w-5';
      case 'md':
      default:
        return 'h-4 w-4';
    }
  };
  
  const { icon, color, label, description } = getIconAndColor();
  
  const indicator = (
    <div className={`flex items-center ${color}`}>
      {icon}
      {size === 'lg' && <span className="ml-1.5 text-sm font-medium">{label}</span>}
    </div>
  );
  
  if (!showTooltip) {
    return indicator;
  }
  
  return (
    <TooltipProvider>
      <Tooltip>
        <TooltipTrigger asChild>
          {indicator}
        </TooltipTrigger>
        <TooltipContent side={tooltipPlacement} className="space-y-1">
          <p className="font-medium">{label} ({score}/100)</p>
          <p className="text-xs text-muted-foreground">{description}</p>
        </TooltipContent>
      </Tooltip>
    </TooltipProvider>
  );
}

export default PriorityScoreIndicator;