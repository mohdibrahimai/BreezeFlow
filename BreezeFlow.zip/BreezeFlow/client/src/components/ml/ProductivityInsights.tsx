import React from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { useQuery } from '@tanstack/react-query';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, PieChart, Pie, Cell } from 'recharts';
import { Badge } from '@/components/ui/badge';
import { AlertTriangle, Clock, TrendingUp, Lightbulb } from 'lucide-react';
import { Skeleton } from '@/components/ui/skeleton';

interface TagUsage {
  tag: string;
  count: number;
}

interface InsightsData {
  task_stats: {
    total: number;
    completed: number;
    completion_rate: number;
    overdue: number;
    with_priority_scores: number;
  };
  productivity_metrics: {
    average_priority_score: number | null;
    most_productive_hour: number | null;
    high_priority_completion_rate: number | null;
  };
  tag_usage: TagUsage[];
  personalized_tips: string[];
}

interface ProductivityInsightsProps {
  userId: number;
}

export default function ProductivityInsights({ userId }: ProductivityInsightsProps) {
  const { data: insights, isLoading, error } = useQuery<InsightsData>({
    queryKey: ['/api/ml/productivity-insights', userId],
    queryFn: () => {
      return fetch(`/api/ml/productivity-insights?userId=${userId}`)
        .then(res => {
          if (!res.ok) throw new Error('Failed to fetch insights');
          return res.json();
        });
    }
  });
  
  const renderChart = () => {
    if (!insights || !insights.task_stats) return null;
    
    const chartData = [
      {
        name: 'Completed',
        value: insights.task_stats.completed,
        fill: '#22c55e'
      },
      {
        name: 'Pending',
        value: insights.task_stats.total - insights.task_stats.completed,
        fill: '#f59e0b'
      },
      {
        name: 'Overdue',
        value: insights.task_stats.overdue,
        fill: '#ef4444'
      }
    ];
    
    return (
      <div className="h-[180px] w-full">
        <ResponsiveContainer width="100%" height="100%">
          <PieChart>
            <Pie
              data={chartData}
              cx="50%"
              cy="50%"
              labelLine={false}
              outerRadius={80}
              dataKey="value"
              label={({ name, percent }) => 
                `${name}: ${(percent * 100).toFixed(0)}%`
              }
            >
              {chartData.map((entry, index) => (
                <Cell key={`cell-${index}`} fill={entry.fill} />
              ))}
            </Pie>
            <Tooltip formatter={(value) => [`${value} tasks`, '']} />
          </PieChart>
        </ResponsiveContainer>
      </div>
    );
  };
  
  const renderTagChart = () => {
    if (!insights || !insights.tag_usage || insights.tag_usage.length === 0) return null;
    
    const tagData = insights.tag_usage
      .slice(0, 5)
      .map(item => ({
        name: item.tag,
        count: item.count
      }));
    
    return (
      <div className="h-[180px] w-full">
        <ResponsiveContainer width="100%" height="100%">
          <BarChart data={tagData}>
            <CartesianGrid strokeDasharray="3 3" vertical={false} />
            <XAxis dataKey="name" fontSize={12} tickMargin={5} />
            <YAxis fontSize={12} />
            <Tooltip 
              formatter={(value) => [`${value} tasks`, 'Count']}
              labelStyle={{ color: 'black' }}
            />
            <Bar dataKey="count" fill="#8884d8" barSize={30} />
          </BarChart>
        </ResponsiveContainer>
      </div>
    );
  };
  
  if (isLoading) {
    return (
      <Card>
        <CardHeader>
          <CardTitle>
            <Skeleton className="h-8 w-48" />
          </CardTitle>
          <CardDescription>
            <Skeleton className="h-4 w-full" />
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <Skeleton className="h-[180px] w-full mb-4" />
              <Skeleton className="h-4 w-2/3 mb-2" />
              <Skeleton className="h-4 w-1/2" />
            </div>
            <div>
              <Skeleton className="h-[180px] w-full mb-4" />
              <Skeleton className="h-4 w-3/4 mb-2" />
              <Skeleton className="h-4 w-1/2" />
            </div>
          </div>
          <div className="mt-6">
            <Skeleton className="h-6 w-40 mb-4" />
            <Skeleton className="h-4 w-full mb-2" />
            <Skeleton className="h-4 w-full mb-2" />
            <Skeleton className="h-4 w-2/3" />
          </div>
        </CardContent>
      </Card>
    );
  }
  
  if (error || !insights) {
    return (
      <Card>
        <CardHeader>
          <CardTitle>Productivity Insights</CardTitle>
          <CardDescription className="text-red-500">
            Error loading insights. Please try again later.
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="flex items-center justify-center p-8">
            <AlertTriangle className="h-12 w-12 text-amber-500" />
          </div>
        </CardContent>
      </Card>
    );
  }
  
  return (
    <Card>
      <CardHeader>
        <CardTitle>Productivity Insights</CardTitle>
        <CardDescription>
          Analysis of your task management patterns and productivity trends
        </CardDescription>
      </CardHeader>
      <CardContent>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div>
            <h3 className="text-base font-medium mb-3 flex items-center">
              <TrendingUp className="mr-2 h-5 w-5 text-primary" />
              Task Completion Analysis
            </h3>
            
            {insights.task_stats.total > 0 ? (
              <>
                {renderChart()}
                <div className="mt-2 text-sm text-muted-foreground">
                  {insights.task_stats.completion_rate < 50 ? (
                    <span className="text-amber-600">
                      Your task completion rate is {Math.round(insights.task_stats.completion_rate)}% - 
                      there's room for improvement!
                    </span>
                  ) : insights.task_stats.completion_rate < 80 ? (
                    <span className="text-emerald-600">
                      Good job! Your task completion rate is {Math.round(insights.task_stats.completion_rate)}%.
                    </span>
                  ) : (
                    <span className="text-green-600 font-medium">
                      Excellent! Your task completion rate is {Math.round(insights.task_stats.completion_rate)}%.
                    </span>
                  )}
                </div>
              </>
            ) : (
              <div className="h-[180px] flex items-center justify-center bg-muted/30 rounded-md">
                <div className="text-center text-muted-foreground">
                  <Clock className="mx-auto h-10 w-10 opacity-50 mb-2" />
                  <p>No task data available</p>
                  <p className="text-xs mt-1">Start adding tasks to see insights</p>
                </div>
              </div>
            )}
          </div>
          
          <div>
            <h3 className="text-base font-medium mb-3 flex items-center">
              <Badge variant="outline" className="mr-2 py-1">
                # Tags
              </Badge>
              Most Used Tags
            </h3>
            
            {insights.tag_usage && insights.tag_usage.length > 0 ? (
              <>
                {renderTagChart()}
                <div className="mt-2 text-sm text-muted-foreground">
                  {insights.tag_usage.length === 1 ? (
                    <span>You're using the tag "{insights.tag_usage[0].tag}" frequently.</span>
                  ) : (
                    <span>You use {insights.tag_usage.length} different tags to organize your tasks.</span>
                  )}
                </div>
              </>
            ) : (
              <div className="h-[180px] flex items-center justify-center bg-muted/30 rounded-md">
                <div className="text-center text-muted-foreground">
                  <Badge variant="outline" className="mx-auto opacity-50 mb-2 px-6 py-1 text-base">
                    #tag
                  </Badge>
                  <p>No tags used yet</p>
                  <p className="text-xs mt-1">Use tags to better organize your tasks</p>
                </div>
              </div>
            )}
          </div>
        </div>
        
        <div className="mt-8">
          <h3 className="text-base font-medium mb-3 flex items-center">
            <Lightbulb className="mr-2 h-5 w-5 text-amber-500" />
            Personal Productivity Tips
          </h3>
          
          <div className="space-y-3">
            {insights.personalized_tips.length > 0 ? (
              insights.personalized_tips.map((tip, index) => (
                <div key={index} className="p-3 bg-amber-50 border border-amber-100 rounded-md">
                  <p className="text-sm">{tip}</p>
                </div>
              ))
            ) : (
              <div className="p-4 bg-muted/30 rounded-md text-center">
                <p className="text-muted-foreground">Complete more tasks to receive personalized productivity tips</p>
              </div>
            )}
          </div>
        </div>
        
        {insights.productivity_metrics.average_priority_score !== null && (
          <div className="mt-8 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
            <div className="p-4 bg-primary/5 border rounded-md">
              <h4 className="text-sm font-medium text-primary mb-1">Average Priority Score</h4>
              <div className="flex items-baseline">
                <span className="text-2xl font-bold">{Math.round(insights.productivity_metrics.average_priority_score)}</span>
                <span className="text-sm ml-1 text-muted-foreground">/100</span>
              </div>
            </div>
            
            {insights.productivity_metrics.most_productive_hour !== null && (
              <div className="p-4 bg-green-50 border border-green-100 rounded-md">
                <h4 className="text-sm font-medium text-green-700 mb-1">Most Productive Hour</h4>
                <div className="flex items-baseline">
                  <span className="text-2xl font-bold">{insights.productivity_metrics.most_productive_hour}</span>
                  <span className="text-sm ml-1 text-muted-foreground">{insights.productivity_metrics.most_productive_hour >= 12 ? 'PM' : 'AM'}</span>
                </div>
              </div>
            )}
            
            {insights.productivity_metrics.high_priority_completion_rate !== null && (
              <div className="p-4 bg-blue-50 border border-blue-100 rounded-md">
                <h4 className="text-sm font-medium text-blue-700 mb-1">High Priority Completion</h4>
                <div className="flex items-baseline">
                  <span className="text-2xl font-bold">{Math.round(insights.productivity_metrics.high_priority_completion_rate)}%</span>
                </div>
              </div>
            )}
          </div>
        )}
      </CardContent>
    </Card>
  );
}