import React from 'react';
import { Menu, X } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { AppLogo } from '@/components/ui/app-logo';
import { Sheet, SheetContent, SheetTrigger } from '@/components/ui/sheet';
import { Sidebar } from './sidebar';

interface MobileNavProps {
  sidebarOpen: boolean;
  setSidebarOpen: (open: boolean) => void;
  pageTitle?: string;
}

export const MobileNav: React.FC<MobileNavProps> = ({ 
  sidebarOpen, 
  setSidebarOpen,
  pageTitle = 'BreezeFlow'
}) => {
  return (
    <div className="relative z-10 flex-shrink-0 flex h-16 bg-white dark:bg-gray-900 border-b border-gray-200 dark:border-gray-800 md:hidden">
      <div className="flex-1 flex items-center justify-between px-4">
        <div className="flex items-center">
          <Sheet open={sidebarOpen} onOpenChange={setSidebarOpen}>
            <SheetTrigger asChild>
              <Button variant="ghost" size="icon" className="mr-2">
                <Menu className="h-6 w-6" />
                <span className="sr-only">Open sidebar</span>
              </Button>
            </SheetTrigger>
            <SheetContent side="left" className="p-0">
              <Sidebar />
            </SheetContent>
          </Sheet>
          <div className="flex items-center">
            <AppLogo />
            <h1 className="ml-4 text-lg font-medium">{pageTitle}</h1>
          </div>
        </div>
      </div>
    </div>
  );
};
