import React, { useState } from 'react';
import { Link, useLocation } from 'wouter';
import { AppLogo } from '@/components/ui/app-logo';
import { useAuth } from '@/hooks/use-auth';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { 
  Home, 
  CheckSquare, 
  Calendar, 
  ShoppingCart, 
  CreditCard, 
  Award, 
  Settings,
  Users,
  BarChart3,
  Bot,
  MessageSquare,
  Brain
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import ChatDrawer from '@/components/ui/ChatDrawer';

interface SidebarLink {
  href: string;
  label: string;
  icon: React.ReactNode;
  adminOnly?: boolean;
}

export function Sidebar() {
  const [location] = useLocation();
  const { user, logoutMutation } = useAuth();
  const [isChatOpen, setIsChatOpen] = useState(false);

  const links: SidebarLink[] = [
    { href: '/dashboard', label: 'Dashboard', icon: <Home className="h-5 w-5" /> },
    { href: '/tasks', label: 'Tasks', icon: <CheckSquare className="h-5 w-5" /> },
    { href: '/calendar', label: 'Calendar', icon: <Calendar className="h-5 w-5" /> },
    { href: '/errands', label: 'Errands', icon: <ShoppingCart className="h-5 w-5" /> },
    { href: '/bills', label: 'Bills', icon: <CreditCard className="h-5 w-5" /> },
    { href: '/rewards', label: 'Rewards', icon: <Award className="h-5 w-5" /> },
    { href: '/ai-dashboard', label: 'ML Assistant', icon: <Brain className="h-5 w-5" /> },
    { href: '/roi-dashboard', label: 'ROI Dashboard', icon: <BarChart3 className="h-5 w-5" /> },
    { href: '/settings', label: 'Settings', icon: <Settings className="h-5 w-5" /> },
    { href: '/admin', label: 'Admin', icon: <Users className="h-5 w-5" />, adminOnly: true },
  ];

  // Filter admin links if user is not admin
  const filteredLinks = links.filter(link => !link.adminOnly || (user && user.id === 1));

  return (
    <div className="flex flex-col h-full bg-white shadow-md dark:bg-gray-900">
      <div className="p-4">
        <AppLogo />
      </div>

      <nav className="mt-5 flex-1 px-2 space-y-1">
        {filteredLinks.map((link) => {
          const isActive = location === link.href;
          return (
            <div key={link.href}>
              <Link href={link.href}>
                <div
                  className={`group flex items-center px-2 py-2 text-sm font-medium rounded-md cursor-pointer ${
                    isActive
                      ? 'bg-primary-50 text-primary-600 dark:bg-primary-900 dark:text-primary-300'
                      : 'text-gray-600 hover:bg-gray-50 hover:text-gray-900 dark:text-gray-300 dark:hover:bg-gray-800 dark:hover:text-white'
                  }`}
                >
                  <span className={`mr-3 flex-shrink-0 ${isActive ? 'text-primary-600 dark:text-primary-300' : 'text-gray-400 group-hover:text-gray-500 dark:text-gray-400 dark:group-hover:text-gray-300'}`}>
                    {link.icon}
                  </span>
                  {link.label}
                </div>
              </Link>
            </div>
          );
        })}
      </nav>

      {/* Chat Assistant Toggle Button */}
      {user && (
        <div className="mx-2 mb-4">
          <Button
            variant="outline"
            className="w-full flex items-center justify-center gap-2 border-dashed"
            onClick={() => setIsChatOpen(true)}
          >
            <Bot className="h-4 w-4" />
            <span>Open BreezeMind</span>
          </Button>
        </div>
      )}

      {/* Chat Drawer Component */}
      <ChatDrawer isOpen={isChatOpen} onClose={() => setIsChatOpen(false)} />

      {user && (
        <div className="flex-shrink-0 flex border-t border-gray-200 dark:border-gray-700 p-4">
          <div className="flex-shrink-0 w-full group">
            <div className="flex items-center">
              <Avatar>
                <AvatarImage src={`https://api.dicebear.com/7.x/initials/svg?seed=${user.name}`} alt={user.name} />
                <AvatarFallback>{user.name.charAt(0)}</AvatarFallback>
              </Avatar>
              <div className="ml-3">
                <p className="text-sm font-medium text-gray-700 dark:text-gray-300">{user.name}</p>
                <p className="text-xs font-medium text-gray-500 dark:text-gray-400 capitalize">{user.plan} Plan</p>
              </div>
            </div>
            <Button
              variant="ghost" 
              size="sm"
              className="w-full mt-3 text-gray-500 hover:text-gray-700 dark:text-gray-400 dark:hover:text-white"
              onClick={() => logoutMutation.mutate()}
              disabled={logoutMutation.isPending}
            >
              {logoutMutation.isPending ? 'Logging out...' : 'Sign out'}
            </Button>
          </div>
        </div>
      )}
    </div>
  );
}
