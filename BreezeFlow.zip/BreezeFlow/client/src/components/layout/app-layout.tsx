import React, { ReactNode, useState } from 'react';
import { Sidebar } from './sidebar';
import { MobileNav } from './mobile-nav';
import { useAuth } from '@/hooks/use-auth';
import { Loader2 } from 'lucide-react';

interface AppLayoutProps {
  children: ReactNode;
  pageTitle?: string;
}

export const AppLayout: React.FC<AppLayoutProps> = ({ children, pageTitle }) => {
  const { isLoading } = useAuth();
  const [sidebarOpen, setSidebarOpen] = useState(false);
  
  if (isLoading) {
    return (
      <div className="flex h-screen items-center justify-center bg-gray-50 dark:bg-gray-900">
        <Loader2 className="h-12 w-12 animate-spin text-primary" />
      </div>
    );
  }

  return (
    <div className="min-h-screen flex flex-col md:flex-row bg-gray-100 dark:bg-gray-900">
      {/* Mobile Nav */}
      <MobileNav 
        sidebarOpen={sidebarOpen} 
        setSidebarOpen={setSidebarOpen} 
        pageTitle={pageTitle}
      />
      
      {/* Sidebar - hidden on mobile */}
      <div className="hidden md:flex md:w-64 md:flex-shrink-0">
        <Sidebar />
      </div>
      
      {/* Main Content */}
      <div className="flex-1 flex flex-col overflow-hidden">
        <main className="flex-1 relative overflow-y-auto focus:outline-none p-4 md:p-6">
          {children}
        </main>
      </div>
    </div>
  );
};
