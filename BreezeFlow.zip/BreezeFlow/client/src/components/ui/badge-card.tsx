import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { useQuery } from '@tanstack/react-query';
import { Skeleton } from "@/components/ui/skeleton";
import { 
  Award, 
  Trophy, 
  Star, 
  Zap, 
  Medal, 
  Flame, 
  CheckCircle, 
  Clock, 
  Calendar
} from 'lucide-react';
import { format, parseISO } from 'date-fns';

interface BadgeInfo {
  id: number;
  badge_name: string;
  date_earned: string;
  points_awarded: number;
  icon: React.ReactNode;
  description: string;
}

export function BadgeCard({ limit = 6 }: { limit?: number }) {
  const { data: rewards, isLoading, error } = useQuery({
    queryKey: ['/api/rewards'],
  });
  
  // Map badge names to icons and descriptions
  const getBadgeInfo = (reward: any): BadgeInfo => {
    const badgeName = reward.badge_name.toLowerCase();
    
    let icon;
    let description = '';
    
    if (badgeName.includes('streak')) {
      icon = <Flame className="h-6 w-6 text-orange-500" />;
      description = 'Completed tasks for multiple days in a row';
    } else if (badgeName.includes('master')) {
      icon = <Trophy className="h-6 w-6 text-yellow-500" />;
      description = 'Achieved mastery in a specific area';
    } else if (badgeName.includes('achievement')) {
      icon = <Award className="h-6 w-6 text-purple-500" />;
      description = 'Reached a significant milestone';
    } else if (badgeName.includes('star')) {
      icon = <Star className="h-6 w-6 text-yellow-500" />;
      description = 'Performed exceptionally well';
    } else if (badgeName.includes('quick')) {
      icon = <Zap className="h-6 w-6 text-blue-500" />;
      description = 'Completed tasks in record time';
    } else if (badgeName.includes('medal')) {
      icon = <Medal className="h-6 w-6 text-amber-500" />;
      description = 'Won a competitive challenge';
    } else if (badgeName.includes('punctual')) {
      icon = <Clock className="h-6 w-6 text-green-500" />;
      description = 'Always on time and meeting deadlines';
    } else if (badgeName.includes('organizer')) {
      icon = <Calendar className="h-6 w-6 text-indigo-500" />;
      description = 'Keeping your schedule well organized';
    } else {
      icon = <CheckCircle className="h-6 w-6 text-green-500" />;
      description = 'Completed a significant achievement';
    }
    
    return {
      ...reward,
      icon,
      description
    };
  };

  // Sort rewards by date, latest first
  const sortedRewards = React.useMemo(() => {
    if (!rewards) return [];
    
    return [...rewards]
      .sort((a, b) => {
        const dateA = new Date(a.date_earned);
        const dateB = new Date(b.date_earned);
        return dateB.getTime() - dateA.getTime();
      })
      .slice(0, limit)
      .map(getBadgeInfo);
  }, [rewards, limit]);

  // Format date
  const formatDate = (dateString: string) => {
    try {
      const date = parseISO(dateString);
      return format(date, 'MMM d, yyyy');
    } catch (e) {
      return dateString;
    }
  };

  return (
    <Card>
      <CardHeader className="pb-2">
        <CardTitle className="text-lg font-medium">Recent Badges</CardTitle>
      </CardHeader>
      <CardContent>
        {isLoading ? (
          <div className="grid grid-cols-2 sm:grid-cols-3 gap-4">
            {[...Array(limit)].map((_, i) => (
              <Skeleton key={i} className="h-24 w-full" />
            ))}
          </div>
        ) : error ? (
          <div className="text-sm text-red-500">Error loading badges</div>
        ) : sortedRewards.length > 0 ? (
          <div className="grid grid-cols-2 sm:grid-cols-3 gap-4">
            {sortedRewards.map((badge) => (
              <div 
                key={badge.id} 
                className="bg-gray-50 dark:bg-gray-800 rounded-lg p-3 flex flex-col items-center text-center"
              >
                <div className="rounded-full bg-gray-100 dark:bg-gray-700 p-2 mb-2">
                  {badge.icon}
                </div>
                <h4 className="text-sm font-medium text-gray-900 dark:text-white mb-1">{badge.badge_name}</h4>
                <div className="text-xs text-gray-500 dark:text-gray-400 mb-1">+{badge.points_awarded} pts</div>
                <div className="text-xs text-gray-400 dark:text-gray-500">{formatDate(badge.date_earned)}</div>
              </div>
            ))}
          </div>
        ) : (
          <div className="text-center py-6 text-gray-500 dark:text-gray-400">
            <Award className="h-10 w-10 mx-auto mb-2 opacity-40" />
            <p className="text-sm">No badges earned yet</p>
            <p className="text-xs mt-1">Complete tasks to earn your first badge</p>
          </div>
        )}
      </CardContent>
    </Card>
  );
}
