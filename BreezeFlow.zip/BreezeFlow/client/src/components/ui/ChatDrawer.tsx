import React, { useState, useRef, useEffect } from 'react';
import { Send, X, Loader2, MoveUpRight, Calendar } from 'lucide-react';
import { useAuth } from '@/hooks/use-auth';
import { useToast } from '@/hooks/use-toast';
import { apiRequest } from '@/lib/queryClient';
import { Textarea } from '@/components/ui/textarea';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { cn } from "@/lib/utils";

interface ChatMessage {
  id: string;
  role: 'user' | 'assistant' | 'system';
  content: string;
  timestamp: Date;
  isLoading?: boolean;
  functionResult?: {
    taskId?: number;
    timeBlocks?: Array<{
      title: string;
      startISO: string;
      endISO: string;
    }>;
    [key: string]: any;
  };
}

interface ChatDrawerProps {
  isOpen: boolean;
  onClose: () => void;
}

export function ChatDrawer({ isOpen, onClose }: ChatDrawerProps) {
  const { user } = useAuth();
  const { toast } = useToast();
  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      id: '0',
      role: 'assistant',
      content: 'Hi! I\'m BreezeMind, your personal productivity assistant. How can I help you today?',
      timestamp: new Date(),
    }
  ]);
  const [inputValue, setInputValue] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLTextAreaElement>(null);
  const [requestCount, setRequestCount] = useState(0);
  const [lastRequestTime, setLastRequestTime] = useState<Date | null>(null);
  
  // Throttle requests for free tier - 5 per hour
  const MAX_REQUESTS_PER_HOUR = user?.plan === 'free' ? 5 : Infinity;
  const ONE_HOUR_MS = 60 * 60 * 1000;
  
  useEffect(() => {
    if (isOpen && inputRef.current) {
      inputRef.current.focus();
    }
  }, [isOpen]);
  
  useEffect(() => {
    scrollToBottom();
  }, [messages]);
  
  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };
  
  const handleInputChange = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
    setInputValue(e.target.value);
  };
  
  const handleKeyDown = (e: React.KeyboardEvent) => {
    // Send message on Enter (without shift)
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSendMessage();
    }
  };
  
  const checkRateLimit = (): boolean => {
    if (!lastRequestTime) return true;
    
    const now = new Date();
    const timeSinceLastRequest = now.getTime() - lastRequestTime.getTime();
    
    // Reset counter if more than an hour has passed
    if (timeSinceLastRequest > ONE_HOUR_MS) {
      setRequestCount(0);
      return true;
    }
    
    // Check if the limit has been reached
    return requestCount < MAX_REQUESTS_PER_HOUR;
  };
  
  const handleSendMessage = async () => {
    if (inputValue.trim() === '' || isLoading) return;
    
    // Check rate limit for free tier users
    if (!checkRateLimit()) {
      toast({
        title: "Request limit reached",
        description: `Free tier is limited to ${MAX_REQUESTS_PER_HOUR} AI requests per hour. Please upgrade for unlimited access.`,
        variant: "destructive"
      });
      return;
    }
    
    const messageId = Date.now().toString();
    const userMessage: ChatMessage = {
      id: messageId,
      role: 'user',
      content: inputValue,
      timestamp: new Date(),
    };
    
    // Prepare loading message
    const loadingMessage: ChatMessage = {
      id: `${messageId}-loading`,
      role: 'assistant',
      content: '',
      timestamp: new Date(),
      isLoading: true,
    };
    
    setMessages((prev) => [...prev, userMessage, loadingMessage]);
    setInputValue('');
    setIsLoading(true);
    
    try {
      // Update rate limit counters
      setRequestCount((prev) => prev + 1);
      setLastRequestTime(new Date());
      
      // Handle the streaming response
      await handleStreamingResponse(messageId);
    } catch (error) {
      console.error('Error sending message:', error);
      setMessages((prev) => 
        prev.map(msg => 
          msg.id === `${messageId}-loading` 
            ? { ...msg, isLoading: false, content: "Sorry, I encountered an error processing your request." } 
            : msg
        )
      );
      
      toast({
        title: "Error",
        description: "Failed to get a response. Please try again.",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };
  
  const handleStreamingResponse = async (messageId: string) => {
    try {
      const response = await apiRequest('POST', '/api/copilot', { message: inputValue });
      if (!response.ok) throw new Error('Network response was not ok');
      
      const reader = response.body?.getReader();
      if (!reader) throw new Error('Response reader not available');
      
      let accumulatedContent = '';
      let functionResult: ChatMessage['functionResult'] = undefined;
      
      // Process the stream chunks
      while (true) {
        const { done, value } = await reader.read();
        if (done) break;
        
        // Convert the chunk to text
        const chunk = new TextDecoder().decode(value);
        const lines = chunk.split('\n\n');
        
        for (const line of lines) {
          if (line.startsWith('data: ')) {
            try {
              const data = JSON.parse(line.substring(6));
              
              if (data.type === 'content') {
                accumulatedContent += data.content;
                
                // Update the loading message with current content
                setMessages((prev) => 
                  prev.map(msg => 
                    msg.id === `${messageId}-loading` 
                      ? { ...msg, content: accumulatedContent } 
                      : msg
                  )
                );
              } else if (data.type === 'function_result') {
                functionResult = data.result;
              } else if (data.type === 'error') {
                throw new Error(data.content);
              } else if (data.type === 'done') {
                // Finalize the message when done
                setMessages((prev) => 
                  prev.map(msg => 
                    msg.id === `${messageId}-loading` 
                      ? { 
                          ...msg, 
                          isLoading: false, 
                          content: accumulatedContent, 
                          functionResult 
                        } 
                      : msg
                  )
                );
              }
            } catch (e) {
              console.error('Error parsing streaming data:', e, line);
            }
          }
        }
      }
    } catch (error) {
      console.error('Streaming error:', error);
      throw error;
    }
  };
  
  // Format message content to display Markdown-like syntax
  const formatMessageContent = (content: string) => {
    // Handle bold (**text**)
    let formattedContent = content.replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>');
    
    // Handle italics (*text*)
    formattedContent = formattedContent.replace(/\*(.*?)\*/g, '<em>$1</em>');
    
    // Handle line breaks
    formattedContent = formattedContent.replace(/\n/g, '<br>');
    
    return formattedContent;
  };
  
  return (
    <div className={cn(
      "fixed right-0 top-0 z-50 flex h-full w-80 flex-col bg-background transform transition-transform duration-300 shadow-xl",
      isOpen ? "translate-x-0" : "translate-x-full"
    )}>
      {/* Header */}
      <div className="flex items-center justify-between border-b p-4">
        <h2 className="text-lg font-semibold">BreezeMind Assistant</h2>
        <Button variant="ghost" size="icon" onClick={onClose}>
          <X className="h-4 w-4" />
        </Button>
      </div>
      
      {/* Messages */}
      <div className="flex-1 overflow-y-auto p-4">
        {messages.map((message) => (
          <div 
            key={message.id} 
            className={cn(
              "mb-4 last:mb-0",
              message.role === 'user' ? "flex justify-end" : "flex justify-start"
            )}
          >
            <div 
              className={cn(
                "rounded-lg px-3 py-2 max-w-[80%]",
                message.role === 'user' 
                  ? "bg-primary text-primary-foreground" 
                  : "bg-secondary text-secondary-foreground"
              )}
            >
              {message.isLoading ? (
                <div className="flex items-center space-x-2">
                  <Loader2 className="h-4 w-4 animate-spin" />
                  <span>{message.content || "Thinking..."}</span>
                </div>
              ) : (
                <>
                  <div 
                    dangerouslySetInnerHTML={{ __html: formatMessageContent(message.content) }} 
                    className="whitespace-pre-wrap break-words"
                  />
                  
                  {/* Display function results if available */}
                  {message.functionResult && message.functionResult.taskId && (
                    <div className="mt-2">
                      <Badge variant="outline" className="text-xs">
                        <MoveUpRight className="mr-1 h-3 w-3" />
                        Task created
                      </Badge>
                    </div>
                  )}
                  
                  {message.functionResult && message.functionResult.timeBlocks && (
                    <div className="mt-2">
                      <Badge variant="outline" className="text-xs">
                        <Calendar className="mr-1 h-3 w-3" />
                        Schedule optimized
                      </Badge>
                    </div>
                  )}
                </>
              )}
            </div>
          </div>
        ))}
        <div ref={messagesEndRef} />
      </div>
      
      {/* Input */}
      <div className="border-t p-4">
        <div className="flex items-end gap-2">
          <Textarea
            ref={inputRef}
            value={inputValue}
            onChange={handleInputChange}
            onKeyDown={handleKeyDown}
            placeholder="Type your message..."
            className="min-h-[60px] flex-1 resize-none"
            maxLength={1000}
            disabled={isLoading}
          />
          <Button 
            size="icon" 
            onClick={handleSendMessage}
            disabled={inputValue.trim() === '' || isLoading}
          >
            {isLoading ? <Loader2 className="h-4 w-4 animate-spin" /> : <Send className="h-4 w-4" />}
          </Button>
        </div>
        
        {/* Rate limit indicator for free tier */}
        {user?.plan === 'free' && (
          <div className="mt-2 text-xs text-muted-foreground">
            {requestCount}/{MAX_REQUESTS_PER_HOUR} AI requests used this hour
            {requestCount >= MAX_REQUESTS_PER_HOUR && (
              <span className="block mt-1 text-destructive">
                Limit reached. Upgrade for unlimited access.
              </span>
            )}
          </div>
        )}
      </div>
    </div>
  );
}

export default ChatDrawer;