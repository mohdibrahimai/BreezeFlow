import React from 'react';
import { Button } from '@/components/ui/button';
import { cn } from '@/lib/utils';
import { RippleEffect } from '@/components/ui/RippleEffect';
import { useHoverAnimation } from '@/lib/animation-utils';

interface AnimatedButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: 'default' | 'destructive' | 'outline' | 'secondary' | 'ghost' | 'link';
  size?: 'default' | 'sm' | 'lg' | 'icon';
  ripple?: boolean;
  animateHover?: boolean;
}

interface HoverProps {
  className?: string;
  onMouseEnter?: () => void;
  onMouseLeave?: () => void;
  'data-hovered'?: string;
}

const AnimatedButton: React.FC<AnimatedButtonProps> = ({
  children,
  className,
  variant = 'default',
  size = 'default',
  ripple = true,
  animateHover = true,
  ...props
}) => {
  const hoverProps: HoverProps = animateHover ? useHoverAnimation() : {};
  
  const button = (
    <Button
      variant={variant}
      size={size}
      className={cn(
        animateHover && hoverProps.className ? hoverProps.className : '',
        className
      )}
      {...(animateHover && hoverProps.onMouseEnter && hoverProps.onMouseLeave ? {
        onMouseEnter: hoverProps.onMouseEnter,
        onMouseLeave: hoverProps.onMouseLeave,
      } : {})}
      {...props}
    >
      {children}
    </Button>
  );
  
  if (ripple) {
    return <RippleEffect>{button}</RippleEffect>;
  }
  
  return button;
};

export { AnimatedButton };