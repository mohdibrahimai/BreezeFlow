import React from 'react';
import { useQuery } from '@tanstack/react-query';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { CircleDollarSign, CreditCard } from 'lucide-react';
import { format } from 'date-fns';
import { Button } from './button';
import { Skeleton } from './skeleton';
import { TooltipProvider, Tooltip, TooltipTrigger, TooltipContent } from "@/components/ui/tooltip";

interface Payment {
  id: number;
  transaction_id: string;
  amount: number;
  currency: string;
  status: string;
  payment_method: string;
  created_at: string;
  metadata: {
    planId: string;
    billingPeriod: string;
    order_id: string;
  };
}

export function PaymentHistory() {
  const { data: payments, isLoading, error } = useQuery<Payment[]>({
    queryKey: ['/api/payments'],
    // If there's an error, it will show the error UI instead of throwing
    retry: 1,
  });

  const formatCurrency = (amount: number, currency: string) => {
    const formatter = new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: currency,
      minimumFractionDigits: 2,
      maximumFractionDigits: 2,
    });
    return formatter.format(amount);
  };

  const getStatusBadge = (status: string) => {
    switch (status.toLowerCase()) {
      case 'completed':
      case 'successful':
      case 'success':
        return <Badge variant="outline" className="bg-green-50 text-green-700 border-green-200">Completed</Badge>;
      case 'pending':
        return <Badge variant="outline" className="bg-yellow-50 text-yellow-700 border-yellow-200">Pending</Badge>;
      case 'failed':
        return <Badge variant="outline" className="bg-red-50 text-red-700 border-red-200">Failed</Badge>;
      case 'refunded':
        return <Badge variant="outline" className="bg-blue-50 text-blue-700 border-blue-200">Refunded</Badge>;
      default:
        return <Badge variant="outline">{status}</Badge>;
    }
  };

  const getPlanBadge = (planId: string) => {
    switch (planId) {
      case 'starter':
        return <Badge className="bg-blue-100 text-blue-800">Starter</Badge>;
      case 'pro':
        return <Badge className="bg-purple-100 text-purple-800">Pro</Badge>;
      case 'team':
        return <Badge className="bg-amber-100 text-amber-800">Team</Badge>;
      default:
        return <Badge>{planId}</Badge>;
    }
  };

  const formatPaymentMethod = (method: string) => {
    if (method.toLowerCase() === 'razorpay') {
      return 'Razorpay';
    }
    return method.charAt(0).toUpperCase() + method.slice(1);
  };

  if (isLoading) {
    return (
      <Card className="w-full">
        <CardHeader>
          <CardTitle className="text-lg font-medium">Payment History</CardTitle>
          <CardDescription>Your recent transactions</CardDescription>
        </CardHeader>
        <CardContent>
          {[1, 2, 3].map((i) => (
            <div key={i} className="flex items-center justify-between py-4 border-b">
              <div className="flex items-center gap-3">
                <Skeleton className="h-8 w-8 rounded-full" />
                <div className="space-y-2">
                  <Skeleton className="h-4 w-[120px]" />
                  <Skeleton className="h-3 w-[80px]" />
                </div>
              </div>
              <div className="flex flex-col items-end">
                <Skeleton className="h-4 w-[60px]" />
                <Skeleton className="h-3 w-[100px] mt-2" />
              </div>
            </div>
          ))}
        </CardContent>
      </Card>
    );
  }

  if (error) {
    return (
      <Card className="w-full">
        <CardHeader>
          <CardTitle className="text-lg font-medium">Payment History</CardTitle>
          <CardDescription>Your recent transactions</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="py-8 text-center">
            <p className="text-muted-foreground">There was an error loading your payment history.</p>
            <Button variant="outline" className="mt-4">Retry</Button>
          </div>
        </CardContent>
      </Card>
    );
  }

  if (!payments || payments.length === 0) {
    return (
      <Card className="w-full">
        <CardHeader>
          <CardTitle className="text-lg font-medium">Payment History</CardTitle>
          <CardDescription>Your recent transactions</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="py-8 text-center border rounded-lg">
            <CircleDollarSign className="mx-auto h-12 w-12 text-muted-foreground opacity-30" />
            <p className="mt-4 text-muted-foreground">No payment history found.</p>
            <p className="text-sm text-muted-foreground">Transactions will appear here after your first payment.</p>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <TooltipProvider>
      <Card className="w-full">
        <CardHeader>
          <CardTitle className="text-lg font-medium">Payment History</CardTitle>
          <CardDescription>Your recent transactions</CardDescription>
        </CardHeader>
        <CardContent className="p-0">
          <div className="max-h-[400px] overflow-auto">
            {payments.map((payment) => (
              <div key={payment.id} className="flex items-center justify-between p-4 border-b hover:bg-muted/50">
                <div className="flex items-center gap-3">
                  <div className="h-10 w-10 rounded-full bg-primary/10 flex items-center justify-center">
                    <CreditCard className="h-5 w-5 text-primary" />
                  </div>
                  <div>
                    <div className="font-medium flex items-center">
                      {payment.metadata?.planId 
                        ? getPlanBadge(payment.metadata.planId) 
                        : <Badge>Payment</Badge>
                      }
                      {payment.metadata?.billingPeriod && (
                        <Badge variant="outline" className="ml-2">
                          {payment.metadata.billingPeriod}
                        </Badge>
                      )}
                    </div>
                    <div className="text-sm text-muted-foreground flex items-center">
                      <span className="mr-2">{formatPaymentMethod(payment.payment_method)}</span>
                      <Tooltip>
                        <TooltipTrigger asChild>
                          <Badge variant="outline" className="text-xs cursor-help">
                            {payment.transaction_id.slice(0, 8)}...
                          </Badge>
                        </TooltipTrigger>
                        <TooltipContent>
                          <p className="text-xs">Transaction ID: {payment.transaction_id}</p>
                        </TooltipContent>
                      </Tooltip>
                    </div>
                  </div>
                </div>
                <div className="flex flex-col items-end">
                  <div className="font-medium">
                    {formatCurrency(payment.amount, payment.currency)}
                  </div>
                  <div className="text-xs text-muted-foreground flex items-center mt-1">
                    <span className="mr-2">{format(new Date(payment.created_at), 'MMM d, yyyy')}</span>
                    {getStatusBadge(payment.status)}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
        <CardFooter className="bg-muted/30">
          <div className="w-full text-xs text-muted-foreground text-center pt-2">
            For invoice requests or payment issues, please contact support.
          </div>
        </CardFooter>
      </Card>
    </TooltipProvider>
  );
}