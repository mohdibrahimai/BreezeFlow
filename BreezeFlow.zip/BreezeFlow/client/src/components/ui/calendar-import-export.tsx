import React, { useState, useRef } from 'react';
import { useMutation } from '@tanstack/react-query';
import { apiRequest } from '@/lib/queryClient';
import { useToast } from '@/hooks/use-toast';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardHeader, CardTitle, CardDescription, CardContent, CardFooter } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Loader2, Download, Upload, Calendar } from 'lucide-react';

/**
 * CalendarImportExport component for importing and exporting calendar events
 * using iCalendar (ICS) format
 */
export function CalendarImportExport() {
  const { toast } = useToast();
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [selectedFile, setSelectedFile] = useState<File | null>(null);

  // Handle file selection
  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files.length > 0) {
      setSelectedFile(e.target.files[0]);
    }
  };

  // Export calendar mutation
  const exportCalendarMutation = useMutation({
    mutationFn: async () => {
      const response = await apiRequest('GET', '/api/icalendar/export', null, {
        responseType: 'blob'
      });
      
      if (!response.ok) {
        throw new Error('Failed to export calendar');
      }
      
      // Create a download link for the file
      const blob = await response.blob();
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = 'breezeflow-calendar.ics';
      document.body.appendChild(a);
      a.click();
      window.URL.revokeObjectURL(url);
      document.body.removeChild(a);
      
      return { success: true };
    },
    onSuccess: () => {
      toast({
        title: 'Calendar Exported',
        description: 'Your calendar has been successfully exported as an ICS file.',
      });
    },
    onError: (error) => {
      toast({
        title: 'Export Failed',
        description: error instanceof Error ? error.message : 'Unknown error',
        variant: 'destructive',
      });
    },
  });

  // Import calendar mutation
  const importCalendarMutation = useMutation({
    mutationFn: async () => {
      if (!selectedFile) {
        throw new Error('No file selected');
      }
      
      const formData = new FormData();
      formData.append('calendar', selectedFile);
      
      const response = await apiRequest('POST', '/api/icalendar/import', formData, {
        contentType: 'multipart/form-data',
      });
      
      if (!response.ok) {
        throw new Error('Failed to import calendar');
      }
      
      return response.json();
    },
    onSuccess: (data) => {
      toast({
        title: 'Calendar Imported',
        description: `Successfully imported ${data.importedCount} events.`,
      });
      setSelectedFile(null);
      if (fileInputRef.current) {
        fileInputRef.current.value = '';
      }
    },
    onError: (error) => {
      toast({
        title: 'Import Failed',
        description: error instanceof Error ? error.message : 'Unknown error',
        variant: 'destructive',
      });
    },
  });

  const handleImport = () => {
    if (!selectedFile) {
      toast({
        title: 'No File Selected',
        description: 'Please select an ICS file to import.',
        variant: 'destructive',
      });
      return;
    }
    
    importCalendarMutation.mutate();
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center">
          <Calendar className="mr-2 h-5 w-5" />
          Calendar Import & Export
        </CardTitle>
        <CardDescription>
          Import events from other calendars or export your BreezeFlow calendar
        </CardDescription>
      </CardHeader>
      <CardContent>
        <Tabs defaultValue="export" className="w-full">
          <TabsList className="grid grid-cols-2 mb-4">
            <TabsTrigger value="export">Export Calendar</TabsTrigger>
            <TabsTrigger value="import">Import Calendar</TabsTrigger>
          </TabsList>
          
          <TabsContent value="export" className="space-y-4">
            <div className="text-sm text-gray-600 dark:text-gray-400 mb-4">
              <p>Export your BreezeFlow calendar as an ICS file that you can import into other calendar applications like Google Calendar, Apple Calendar, or Microsoft Outlook.</p>
            </div>
            
            <Button 
              onClick={() => exportCalendarMutation.mutate()}
              disabled={exportCalendarMutation.isPending}
              className="w-full"
            >
              {exportCalendarMutation.isPending ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Exporting...
                </>
              ) : (
                <>
                  <Download className="mr-2 h-4 w-4" />
                  Export Calendar (ICS)
                </>
              )}
            </Button>
          </TabsContent>
          
          <TabsContent value="import" className="space-y-4">
            <div className="text-sm text-gray-600 dark:text-gray-400 mb-4">
              <p>Import events from an ICS file into your BreezeFlow calendar. You can export ICS files from most calendar applications like Google Calendar, Apple Calendar, or Microsoft Outlook.</p>
            </div>
            
            <div className="space-y-3">
              <Label htmlFor="calendar-file">Select iCalendar (.ics) File</Label>
              <Input
                id="calendar-file"
                type="file"
                accept=".ics"
                ref={fileInputRef}
                onChange={handleFileChange}
                className="cursor-pointer"
              />
              {selectedFile && (
                <p className="text-xs text-gray-600 dark:text-gray-400">
                  Selected file: {selectedFile.name}
                </p>
              )}
            </div>
            
            <Button 
              onClick={handleImport}
              disabled={importCalendarMutation.isPending || !selectedFile}
              className="w-full"
            >
              {importCalendarMutation.isPending ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Importing...
                </>
              ) : (
                <>
                  <Upload className="mr-2 h-4 w-4" />
                  Import Calendar
                </>
              )}
            </Button>
          </TabsContent>
        </Tabs>
      </CardContent>
      <CardFooter className="flex justify-between text-xs text-gray-500 dark:text-gray-400 border-t pt-4">
        <p>Supported format: iCalendar (.ics)</p>
        <p>Max file size: 5MB</p>
      </CardFooter>
    </Card>
  );
}