import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Switch } from '@/components/ui/switch';
import { 
  ShoppingCart, 
  CheckCircle, 
  Edit, 
  Trash, 
  Calendar,
  DollarSign
} from 'lucide-react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { apiRequest } from '@/lib/queryClient';
import { useToast } from '@/hooks/use-toast';
import { Skeleton } from '@/components/ui/skeleton';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { format, parseISO } from 'date-fns';

export function ErrandList() {
  const [editingErrandId, setEditingErrandId] = useState<number | null>(null);
  const [dialogOpen, setDialogOpen] = useState(false);
  const [formData, setFormData] = useState({
    vendor: '',
    amount: '',
    due_date: '',
    autopay: false,
    status: 'upcoming'
  });
  
  const { toast } = useToast();
  const queryClient = useQueryClient();
  
  const { data: errands, isLoading } = useQuery({
    queryKey: ['/api/errands'],
  });
  
  const updateErrandMutation = useMutation({
    mutationFn: async (data: any) => {
      const res = await apiRequest('PUT', `/api/errands/${data.id}`, data);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/errands'] });
      toast({
        title: 'Errand updated',
        description: 'Your errand was updated successfully.',
      });
      setDialogOpen(false);
    },
    onError: (error) => {
      toast({
        title: 'Error updating errand',
        description: error.message,
        variant: 'destructive',
      });
    },
  });
  
  const toggleStatusMutation = useMutation({
    mutationFn: async ({ id, status }: { id: number; status: string }) => {
      const res = await apiRequest('PUT', `/api/errands/${id}`, { status });
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/errands'] });
      toast({
        title: 'Status updated',
        description: 'Errand status was updated successfully.',
      });
    },
    onError: (error) => {
      toast({
        title: 'Error updating status',
        description: error.message,
        variant: 'destructive',
      });
    },
  });
  
  const editErrand = (errand: any) => {
    setEditingErrandId(errand.id);
    setFormData({
      vendor: errand.vendor,
      amount: errand.amount ? errand.amount.toString() : '',
      due_date: errand.due_date || '',
      autopay: errand.autopay || false,
      status: errand.status
    });
    setDialogOpen(true);
  };
  
  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value, type, checked } = e.target;
    setFormData({
      ...formData,
      [name]: type === 'checkbox' ? checked : value,
    });
  };
  
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (editingErrandId) {
      updateErrandMutation.mutate({
        id: editingErrandId,
        ...formData,
        amount: formData.amount ? parseInt(formData.amount) : undefined,
      });
    }
  };
  
  const toggleStatus = (id: number, currentStatus: string) => {
    const newStatus = currentStatus === 'upcoming' ? 'completed' : 'upcoming';
    toggleStatusMutation.mutate({ id, status: newStatus });
  };
  
  // Group errands by status
  const upcomingErrands = errands?.filter(errand => errand.status === 'upcoming') || [];
  const completedErrands = errands?.filter(errand => errand.status === 'completed') || [];
  
  // Format date
  const formatDate = (dateString: string) => {
    if (!dateString) return '';
    try {
      const date = parseISO(dateString);
      return format(date, 'MMM d, yyyy');
    } catch (e) {
      return dateString;
    }
  };
  
  // Format amount
  const formatAmount = (amount: number) => {
    if (!amount && amount !== 0) return '';
    return new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD' }).format(amount);
  };

  return (
    <>
      <Card>
        <CardHeader className="pb-2">
          <CardTitle className="text-lg font-medium">Errands</CardTitle>
        </CardHeader>
        <CardContent>
          {isLoading ? (
            <div className="space-y-4">
              {[1, 2, 3].map((i) => (
                <Skeleton key={i} className="h-16 w-full" />
              ))}
            </div>
          ) : errands?.length === 0 ? (
            <div className="text-center py-6 text-gray-500 dark:text-gray-400">
              <ShoppingCart className="h-10 w-10 mx-auto mb-2 opacity-40" />
              <p className="text-sm">No errands found</p>
              <p className="text-xs mt-1">Add errands from the Quick Add menu</p>
            </div>
          ) : (
            <>
              {/* Upcoming Errands */}
              {upcomingErrands.length > 0 && (
                <div className="mb-6">
                  <h3 className="text-sm font-medium text-gray-900 dark:text-white mb-3">Upcoming</h3>
                  <div className="space-y-3">
                    {upcomingErrands.map((errand) => (
                      <div key={errand.id} className="bg-white dark:bg-gray-800 p-3 rounded-md shadow-sm border border-gray-200 dark:border-gray-700">
                        <div className="flex justify-between items-start">
                          <div>
                            <div className="flex items-center">
                              <ShoppingCart className="h-4 w-4 text-primary-500 mr-2" />
                              <span className="text-sm font-medium text-gray-900 dark:text-white">{errand.vendor}</span>
                            </div>
                            <div className="flex items-center mt-1 text-xs text-gray-500 dark:text-gray-400">
                              {errand.amount !== null && (
                                <div className="flex items-center mr-3">
                                  <DollarSign className="h-3 w-3 mr-1" />
                                  {formatAmount(errand.amount)}
                                </div>
                              )}
                              {errand.due_date && (
                                <div className="flex items-center">
                                  <Calendar className="h-3 w-3 mr-1" />
                                  {formatDate(errand.due_date)}
                                </div>
                              )}
                            </div>
                          </div>
                          <div className="flex items-center">
                            <Button 
                              size="sm" 
                              variant="ghost" 
                              onClick={() => toggleStatus(errand.id, errand.status)}
                              className="h-8 w-8 p-0 mr-1"
                            >
                              <CheckCircle className="h-4 w-4" />
                              <span className="sr-only">Mark as completed</span>
                            </Button>
                            <Button 
                              size="sm" 
                              variant="ghost" 
                              onClick={() => editErrand(errand)}
                              className="h-8 w-8 p-0"
                            >
                              <Edit className="h-4 w-4" />
                              <span className="sr-only">Edit errand</span>
                            </Button>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}
              
              {/* Completed Errands */}
              {completedErrands.length > 0 && (
                <div>
                  <h3 className="text-sm font-medium text-gray-900 dark:text-white mb-3">Completed</h3>
                  <div className="space-y-3">
                    {completedErrands.map((errand) => (
                      <div key={errand.id} className="bg-white dark:bg-gray-800 p-3 rounded-md shadow-sm border border-gray-200 dark:border-gray-700 opacity-75">
                        <div className="flex justify-between items-start">
                          <div>
                            <div className="flex items-center">
                              <CheckCircle className="h-4 w-4 text-green-500 mr-2" />
                              <span className="text-sm font-medium line-through text-gray-500 dark:text-gray-400">{errand.vendor}</span>
                            </div>
                            <div className="flex items-center mt-1 text-xs text-gray-400 dark:text-gray-500">
                              {errand.amount !== null && (
                                <div className="flex items-center mr-3">
                                  <DollarSign className="h-3 w-3 mr-1" />
                                  {formatAmount(errand.amount)}
                                </div>
                              )}
                            </div>
                          </div>
                          <div className="flex items-center">
                            <Button 
                              size="sm" 
                              variant="ghost" 
                              onClick={() => toggleStatus(errand.id, errand.status)}
                              className="h-8 w-8 p-0 mr-1 text-gray-400"
                            >
                              <ShoppingCart className="h-4 w-4" />
                              <span className="sr-only">Mark as upcoming</span>
                            </Button>
                            <Button 
                              size="sm" 
                              variant="ghost" 
                              onClick={() => editErrand(errand)}
                              className="h-8 w-8 p-0 text-gray-400"
                            >
                              <Edit className="h-4 w-4" />
                              <span className="sr-only">Edit errand</span>
                            </Button>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </>
          )}
        </CardContent>
      </Card>

      {/* Edit Dialog */}
      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="sm:max-w-[425px]">
          <DialogHeader>
            <DialogTitle>Edit Errand</DialogTitle>
            <DialogDescription>
              Make changes to your errand here.
            </DialogDescription>
          </DialogHeader>
          
          <form onSubmit={handleSubmit}>
            <div className="space-y-4 py-4">
              <div className="space-y-2">
                <Label htmlFor="vendor">Vendor</Label>
                <Input 
                  id="vendor" 
                  name="vendor" 
                  value={formData.vendor} 
                  onChange={handleChange} 
                />
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="amount">Amount</Label>
                <Input 
                  id="amount" 
                  name="amount" 
                  type="number" 
                  value={formData.amount} 
                  onChange={handleChange} 
                />
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="due_date">Due Date</Label>
                <Input 
                  id="due_date" 
                  name="due_date" 
                  type="date" 
                  value={formData.due_date} 
                  onChange={handleChange} 
                />
              </div>
              
              <div className="flex items-center space-x-2">
                <Switch 
                  id="autopay" 
                  name="autopay" 
                  checked={formData.autopay} 
                  onCheckedChange={(checked) => setFormData({ ...formData, autopay: checked })} 
                />
                <Label htmlFor="autopay">Autopay</Label>
              </div>
            </div>
            
            <DialogFooter>
              <Button 
                type="submit" 
                disabled={updateErrandMutation.isPending}
              >
                {updateErrandMutation.isPending ? 'Saving...' : 'Save changes'}
              </Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>
    </>
  );
}
