import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { useQuery } from '@tanstack/react-query';
import { Skeleton } from "@/components/ui/skeleton";
import { formatDistanceToNow, format, parseISO } from 'date-fns';
import { Calendar, Video, Briefcase, Utensils, Car, Home, Coffee, Users } from 'lucide-react';

// Helper function to get icon based on title keywords
const getEventIcon = (title: string) => {
  const lowerTitle = title.toLowerCase();
  
  if (lowerTitle.includes('meeting') || lowerTitle.includes('call')) {
    return <Video className="text-primary-500 mr-3 flex-shrink-0 h-5 w-5" />;
  } else if (lowerTitle.includes('work') || lowerTitle.includes('project')) {
    return <Briefcase className="text-primary-500 mr-3 flex-shrink-0 h-5 w-5" />;
  } else if (lowerTitle.includes('dinner') || lowerTitle.includes('lunch') || lowerTitle.includes('breakfast')) {
    return <Utensils className="text-primary-500 mr-3 flex-shrink-0 h-5 w-5" />;
  } else if (lowerTitle.includes('drive') || lowerTitle.includes('commute')) {
    return <Car className="text-primary-500 mr-3 flex-shrink-0 h-5 w-5" />;
  } else if (lowerTitle.includes('home') || lowerTitle.includes('house')) {
    return <Home className="text-primary-500 mr-3 flex-shrink-0 h-5 w-5" />;
  } else if (lowerTitle.includes('coffee') || lowerTitle.includes('break')) {
    return <Coffee className="text-primary-500 mr-3 flex-shrink-0 h-5 w-5" />;
  } else if (lowerTitle.includes('team') || lowerTitle.includes('group')) {
    return <Users className="text-primary-500 mr-3 flex-shrink-0 h-5 w-5" />;
  } else {
    return <Calendar className="text-primary-500 mr-3 flex-shrink-0 h-5 w-5" />;
  }
};

// Helper function to format time
const formatEventTime = (dateString: string) => {
  try {
    const date = parseISO(dateString);
    return format(date, 'h:mm a');
  } catch (e) {
    return dateString; // Return as is if parsing fails
  }
};

// Helper function to get relative time
const getRelativeTime = (dateString: string) => {
  try {
    const date = parseISO(dateString);
    return formatDistanceToNow(date, { addSuffix: true });
  } catch (e) {
    return dateString;
  }
};

export function UpcomingEvents() {
  const { data: events, isLoading, error } = useQuery({
    queryKey: ['/api/events'],
  });
  
  // Sort events by start time
  const sortedEvents = React.useMemo(() => {
    if (!events) return [];
    
    return [...events]
      .sort((a, b) => {
        const dateA = new Date(a.start);
        const dateB = new Date(b.start);
        return dateA.getTime() - dateB.getTime();
      })
      .filter(event => {
        const eventDate = new Date(event.start);
        return eventDate >= new Date(); // Only future events
      })
      .slice(0, 3); // Get only the next 3 events
  }, [events]);

  return (
    <Card className="bg-primary-50 dark:bg-primary-900/20">
      <CardHeader className="pb-2">
        <CardTitle className="text-lg font-medium">Upcoming Events</CardTitle>
      </CardHeader>
      <CardContent>
        {isLoading ? (
          <div className="space-y-4">
            {[1, 2, 3].map(i => (
              <div key={i} className="flex justify-between items-start">
                <div className="flex">
                  <Skeleton className="h-5 w-5 mr-3" />
                  <Skeleton className="h-5 w-40" />
                </div>
                <Skeleton className="h-5 w-16" />
              </div>
            ))}
          </div>
        ) : error ? (
          <div className="text-sm text-red-500">Error loading events</div>
        ) : sortedEvents.length > 0 ? (
          <ul className="divide-y divide-gray-200 dark:divide-gray-700">
            {sortedEvents.map((event) => (
              <li key={event.id} className="py-3 flex justify-between">
                <div className="flex items-center">
                  {getEventIcon(event.title)}
                  <span className="text-sm font-medium text-gray-900 dark:text-white">{event.title}</span>
                </div>
                <div className="flex flex-col items-end">
                  <div className="text-sm text-gray-500 dark:text-gray-400">{formatEventTime(event.start)}</div>
                  <div className="text-xs text-gray-400 dark:text-gray-500">{getRelativeTime(event.start)}</div>
                </div>
              </li>
            ))}
          </ul>
        ) : (
          <div className="text-center py-6 text-gray-500 dark:text-gray-400">
            <Calendar className="h-10 w-10 mx-auto mb-2 opacity-40" />
            <p className="text-sm">No upcoming events</p>
            <p className="text-xs mt-1">Add events from the Quick Add menu</p>
          </div>
        )}
      </CardContent>
    </Card>
  );
}
