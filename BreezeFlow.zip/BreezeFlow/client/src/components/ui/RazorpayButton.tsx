import React, { useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { apiRequest } from '@/lib/queryClient';
import { useToast } from '@/hooks/use-toast';

declare global {
  interface Window {
    Razorpay: any;
  }
}

interface RazorpayButtonProps {
  amount: number;
  currency: string;
  planName: string;
  planId: string;
  billingPeriod: string;
  quota: string;
  onSuccess?: (response: any) => void;
  onError?: (error: any) => void;
}

const RazorpayButton: React.FC<RazorpayButtonProps> = ({
  amount,
  currency,
  planName,
  planId,
  billingPeriod,
  quota,
  onSuccess,
  onError
}) => {
  const { toast } = useToast();
  const [isLoading, setIsLoading] = React.useState(false);
  
  // Since we're using a single button for all payment methods,
  // We'll default to showing all payment options
  const finalPreferredMethod = "all";

  const loadRazorpayScript = () => {
    return new Promise((resolve) => {
      const script = document.createElement('script');
      script.src = 'https://checkout.razorpay.com/v1/checkout.js';
      script.onload = resolve;
      document.body.appendChild(script);
    });
  };

  const handlePayment = async () => {
    setIsLoading(true);
    
    try {
      toast({
        title: "Initializing Payment",
        description: "Please wait while we prepare your payment...",
      });
      
      // Load the Razorpay script if it's not already loaded
      if (!window.Razorpay) {
        await loadRazorpayScript();
      }
      
      // Create order on the server
      const response = await apiRequest('POST', '/api/razorpay/create-order', {
        amount: parseFloat(amount.toString()), // Server handles currency conversion and paise conversion
        currency,
        planName,
        planId,
        billingPeriod,
        quota
      });
      
      const orderData = await response.json();
      
      if (!orderData.id) {
        throw new Error('Failed to create order');
      }
      
      // Initialize Razorpay checkout with preferred payment method
      const options = {
        key: import.meta.env.VITE_RAZORPAY_KEY_ID || orderData.key_id || "", // Get key from environment or server
        amount: orderData.amount,
        currency: orderData.currency,
        name: 'BreezeFlow',
        description: `${planName} Subscription - ${billingPeriod}`,
        order_id: orderData.id,
        // Simplified configuration with all payment methods
        config: {
          display: {
            // Use default Razorpay blocks to show all payment methods
            preferences: {
              show_default_blocks: true
            },
            // Better UPI app selection
            upi: {
              // Display all payment options
              flow: "intent",
              // Specifically list major UPI apps for better visibility
              apps: ["google_pay", "phonepe", "paytm", "amazon_pay", "bhim"]
            }
          }
        },
        notes: {
          address: "BreezeFlow Headquarters"
        },
        handler: function(response: any) {
          // Verify payment on the server
          verifyPayment(response);
          if (onSuccess) onSuccess(response);
        },
        prefill: {
          name: 'BreezeFlow User', 
          email: 'customer@example.com',
          contact: '9999999999',
          method: 'upi'
        },
        theme: {
          color: '#6366F1' // Match your primary color
        },
        modal: {
          ondismiss: function() {
            setIsLoading(false);
            toast({
              title: 'Payment Cancelled',
              description: 'You have cancelled the payment process.',
              variant: 'destructive'
            });
          }
        }
      };
      
      console.log("Initializing Razorpay with options:", {
        key: options.key,
        amount: options.amount,
        currency: options.currency,
        orderId: options.order_id,
        preferredMethod: finalPreferredMethod
      });

      // Create and configure Razorpay instance
      const razorpayInstance = new window.Razorpay(options);
      
      // Log any errors during checkout
      razorpayInstance.on('payment.failed', function(response: any) {
        console.error("Razorpay payment failed:", response.error);
        toast({
          title: "Payment Failed",
          description: response.error.description || "Your payment attempt was unsuccessful. Please try again.",
          variant: "destructive"
        });
      });
      
      // Handle all payment errors
      razorpayInstance.on('payment.error', function(resp: any) {
        console.error("Payment error:", resp);
      });
      
      // Open the checkout
      razorpayInstance.open();
    } catch (error) {
      console.error('Razorpay payment error:', error);
      setIsLoading(false);
      
      // Get more specific error message if available
      let errorMessage = 'There was an error processing your payment. Please try again.';
      
      if (error instanceof Error) {
        if (error.message.includes('Failed to create order')) {
          errorMessage = 'Unable to initialize payment. Please check your network connection and try again.';
        } else if (error.message.includes('razorpay_payment_id')) {
          errorMessage = 'Payment verification failed. Please contact support with your transaction reference.';
        }
      }
      
      toast({
        title: 'Payment Failed',
        description: errorMessage,
        variant: 'destructive'
      });
      
      if (onError) onError(error);
    }
  };

  const verifyPayment = async (paymentResponse: any) => {
    try {
      const response = await apiRequest('POST', '/api/razorpay/verify-payment', {
        razorpay_order_id: paymentResponse.razorpay_order_id,
        razorpay_payment_id: paymentResponse.razorpay_payment_id,
        razorpay_signature: paymentResponse.razorpay_signature
      });
      
      const data = await response.json();
      
      if (data.success) {
        setIsLoading(false);
        // Show a more detailed success message
        toast({
          title: 'Payment Successful!',
          description: `Your ${planName} ${billingPeriod} subscription has been activated. Thank you for your payment.`,
          variant: 'default',
          className: 'bg-green-50 dark:bg-green-900 border-green-200 dark:border-green-800',
        });
        
        // Add short delay to allow toast to be seen before redirecting
        setTimeout(() => {
          window.location.href = '/dashboard';
        }, 3000);
      } else {
        throw new Error('Payment verification failed');
      }
    } catch (error) {
      console.error('Payment verification error:', error);
      setIsLoading(false);
      toast({
        title: 'Payment Verification Failed',
        description: 'There was an error verifying your payment. Please contact support.',
        variant: 'destructive'
      });
    }
  };

  return (
    <div className="space-y-2">
      <Button 
        onClick={handlePayment} 
        disabled={isLoading} 
        className="w-full"
      >
        {isLoading ? (
          <div className="flex items-center">
            <svg className="animate-spin -ml-1 mr-2 h-4 w-4 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
              <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
              <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
            </svg>
            Processing...
          </div>
        ) : (
          <div className="flex items-center justify-center">
            <svg className="h-4 w-4 mr-2" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
              <path d="M21 4H3C1.89543 4 1 4.89543 1 6V18C1 19.1046 1.89543 20 3 20H21C22.1046 20 23 19.1046 23 18V6C23 4.89543 22.1046 4 21 4Z" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
              <path d="M1 10H23" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
            </svg>
            <svg className="h-4 w-4 mr-2" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
              <rect x="2" y="4" width="20" height="16" rx="2" stroke="currentColor" strokeWidth="2"/>
              <path d="M14 15C14 13.3431 12.6569 12 11 12C9.34315 12 8 13.3431 8 15" stroke="currentColor" strokeWidth="2" strokeLinecap="round"/>
              <circle cx="11" cy="9" r="1" fill="currentColor"/>
              <path d="M22 9L17 9" stroke="currentColor" strokeWidth="2" strokeLinecap="round"/>
            </svg>
            Pay Now
          </div>
        )}
      </Button>
      <div className="text-xs text-center text-muted-foreground space-y-1">
        <p>Secure payment processed by Razorpay</p>
        <p className="font-semibold">We accept all major credit/debit cards, UPI, Google Pay, PhonePe and more</p>
      </div>
      
      {/* Add clear explanation of Razorpay test mode if applicable */}
      {import.meta.env.DEV && (
        <div className="mt-1 p-2 bg-yellow-50 dark:bg-yellow-900/20 border border-yellow-200 dark:border-yellow-800 rounded-md">
          <p className="text-xs text-yellow-800 dark:text-yellow-400">
            <span className="font-semibold">Development Mode:</span> This is currently in test mode. For UPI payments, use test credentials provided by Razorpay or switch to card payment with test card number: 4111 1111 1111 1111
          </p>
        </div>
      )}
      
      {/* UPI Payment Guidance */}
      <div className="mt-1 p-2 bg-blue-50 dark:bg-blue-900/20 border border-blue-200 dark:border-blue-800 rounded-md">
        <p className="text-xs text-blue-800 dark:text-blue-400">
          <span className="font-semibold">UPI Payments:</span> For the best experience on mobile devices, choose the "Pay with UPI App" option. This automatically redirects you to your installed UPI app (Google Pay, PhonePe, Paytm, etc.). If scanning QR codes, ensure you're using the latest version of your UPI app.
        </p>
      </div>
    </div>
  );
};

export default RazorpayButton;