import React, { useState, useEffect, lazy, Suspense } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Pencil, Trash, Check } from 'lucide-react';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Form, FormControl, FormField, FormItem, FormLabel } from '@/components/ui/form';
import { Button } from '@/components/ui/button';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { apiRequest } from '@/lib/queryClient';
import { useToast } from '@/hooks/use-toast';
import { Task } from '@shared/schema';
import { UndoSnackbar } from './undo-snackbar';

// Lazy load confetti to avoid loading it when reduce motion is enabled
const Confetti = lazy(() => import('@/components/confetti'));

const taskSchema = z.object({
  id: z.number().optional(),
  title: z.string().min(1, "Title is required"),
  description: z.string().optional(),
  status: z.string(),
  priority: z.string(),
  due_date: z.string().optional(),
  points: z.number().optional(),
});

export function TaskBoard() {
  const [editingTask, setEditingTask] = useState<Task | null>(null);
  const [dialogOpen, setDialogOpen] = useState(false);
  const [showConfetti, setShowConfetti] = useState(false);
  const [showUndoSnackbar, setShowUndoSnackbar] = useState(false);
  const [completedTask, setCompletedTask] = useState<Task | null>(null);
  const [taskHighlight, setTaskHighlight] = useState<number | null>(null);
  const { toast } = useToast();
  const queryClient = useQueryClient();
  
  // Get user preferences
  const { data: userData } = useQuery({ 
    queryKey: ['/api/user'],
  });
  
  const form = useForm({
    resolver: zodResolver(taskSchema),
    defaultValues: {
      title: '',
      description: '',
      status: 'backlog',
      priority: 'medium',
      due_date: '',
      points: 10,
    },
  });
  
  const { data: tasks, isLoading } = useQuery({
    queryKey: ['/api/tasks'],
  });
  
  const updateTaskMutation = useMutation({
    mutationFn: async (data: any) => {
      const res = await apiRequest('PUT', `/api/tasks/${data.id}`, data);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/tasks'] });
      toast({
        title: 'Task updated',
        description: 'Your task was updated successfully.',
      });
      setDialogOpen(false);
    },
    onError: (error) => {
      toast({
        title: 'Error updating task',
        description: error.message,
        variant: 'destructive',
      });
    },
  });
  
  const deleteTaskMutation = useMutation({
    mutationFn: async (id: number) => {
      await apiRequest('DELETE', `/api/tasks/${id}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/tasks'] });
      toast({
        title: 'Task deleted',
        description: 'Your task was deleted successfully.',
      });
      setDialogOpen(false);
    },
    onError: (error) => {
      toast({
        title: 'Error deleting task',
        description: error.message,
        variant: 'destructive',
      });
    },
  });
  
  const editTask = (task: Task) => {
    setEditingTask(task);
    form.reset({
      id: task.id,
      title: task.title,
      description: task.description || '',
      status: task.status,
      priority: task.priority,
      due_date: task.due_date || '',
      points: task.points || 10,
    });
    setDialogOpen(true);
  };
  
  const handleSubmit = (data: any) => {
    updateTaskMutation.mutate(data);
  };
  
  const handleDelete = () => {
    if (editingTask) {
      deleteTaskMutation.mutate(editingTask.id);
    }
  };
  
  // Track ROI when a task is completed
  const trackTaskCompletionROI = async (task: Task) => {
    try {
      // Estimate time saved based on task priority
      const timeSavedMinutes = task.priority === 'high' ? 45 : task.priority === 'medium' ? 30 : 15;
      
      // Calculate money saved based on user's hourly rate instead of fixed points
      const hourlyRate = userData?.hourly_rate || 60; // Default to $60/hr if not set
      const moneySavedCents = Math.round((timeSavedMinutes / 60) * hourlyRate * 100); // Convert to cents
      
      // Track the usage event
      await fetch('/api/roi/usage-event', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          eventType: 'task_completed',
          timeSavedMinutes,
          moneySavedCents,
        }),
      });
      
      console.log('ROI tracked for task completion:', { 
        task, 
        timeSavedMinutes, 
        moneySavedCents,
        hourlyRate,
        calculatedValue: `${(moneySavedCents/100).toFixed(2)} ${userData?.currency || 'USD'}`
      });
    } catch (error) {
      console.error('Failed to track ROI:', error);
    }
  };

  const markAsDone = (task: Task) => {
    // Store the task for potential undo
    setCompletedTask(task);
    
    // Only trigger confetti or feedback when moving from another status to done
    if (task.status !== 'done') {
      // Check for reduce motion preference
      if (userData?.pref_reduce_motion) {
        // Use highlight effect instead of confetti for accessibility
        setTaskHighlight(task.id);
        setTimeout(() => setTaskHighlight(null), 2000);
      } else {
        // Show confetti for users without reduce motion preference
        setShowConfetti(true);
        setTimeout(() => setShowConfetti(false), 3000);
      }
      
      // Track ROI when transitioning to done
      trackTaskCompletionROI(task);
      
      // Show undo snackbar
      setShowUndoSnackbar(true);
      
      // Auto-hide the undo snackbar after 10 seconds
      setTimeout(() => {
        setShowUndoSnackbar(false);
      }, 10000);
    }
    
    // Optimistically update the UI
    updateTaskMutation.mutate({
      ...task,
      status: 'done',
    });
  };
  
  // Handle undo operation
  const handleUndo = () => {
    if (completedTask) {
      // Restore the task to its previous state
      updateTaskMutation.mutate({
        ...completedTask,
        // Don't change the status, keep it as it was
      });
      
      // Hide the snackbar
      setShowUndoSnackbar(false);
      
      // Clear the completed task
      setCompletedTask(null);
      
      // Show feedback
      toast({
        title: "Task restored",
        description: "Task has been restored to its previous state.",
      });
    }
  };
  
  const backlogTasks = tasks?.filter(task => task.status === 'backlog') || [];
  const todayTasks = tasks?.filter(task => task.status === 'today') || [];
  const doneTasks = tasks?.filter(task => task.status === 'done') || [];
  
  const getPriorityBadge = (priority: string) => {
    switch (priority) {
      case 'high':
        return <Badge variant="destructive">High</Badge>;
      case 'medium':
        return <Badge variant="default">Medium</Badge>;
      case 'low':
        return <Badge variant="secondary">Low</Badge>;
      default:
        return <Badge variant="outline">Medium</Badge>;
    }
  };

  return (
    <>
      {/* Show confetti for task completion celebration when enabled */}
      {showConfetti && (
        <Suspense fallback={null}>
          <Confetti />
        </Suspense>
      )}
      
      {/* Show undo snackbar when a task is completed */}
      {showUndoSnackbar && completedTask && (
        <UndoSnackbar
          message={`Task "${completedTask.title}" marked as done`}
          onUndo={handleUndo}
          onClose={() => setShowUndoSnackbar(false)}
          duration={10000}
        />
      )}
      
      <div className="mt-6">
        <h3 className="text-lg leading-6 font-medium text-gray-900 dark:text-white mb-4">
          Tasks
        </h3>
        {isLoading ? (
          <div className="grid grid-cols-1 gap-5 sm:grid-cols-3">
            {[0, 1, 2].map((i) => (
              <Card key={i} className="h-64 animate-pulse">
                <CardHeader className="pb-2">
                  <div className="h-5 w-20 bg-gray-200 dark:bg-gray-700 rounded"></div>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    {[0, 1, 2].map((j) => (
                      <div key={j} className="bg-gray-100 dark:bg-gray-800 p-3 rounded-md">
                        <div className="h-4 w-3/4 bg-gray-200 dark:bg-gray-700 rounded mb-2"></div>
                        <div className="h-3 w-1/2 bg-gray-200 dark:bg-gray-700 rounded"></div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        ) : (
          <div className="grid grid-cols-1 gap-5 sm:grid-cols-3">
            {/* Backlog Column */}
            <Card className="bg-gray-50 dark:bg-gray-900">
              <CardHeader className="pb-2">
                <div className="flex justify-between items-center">
                  <CardTitle className="text-sm font-medium">Backlog</CardTitle>
                  <Badge variant="outline" className="text-xs font-medium">
                    {backlogTasks.length}
                  </Badge>
                </div>
              </CardHeader>
              <CardContent className="overflow-y-auto max-h-[60vh]">
                <div className="space-y-3">
                  {backlogTasks.map((task) => (
                    <div 
                      key={task.id} 
                      className={`bg-white dark:bg-gray-800 p-3 rounded-md shadow-sm border 
                        ${taskHighlight === task.id 
                          ? 'border-2 border-green-500 dark:border-green-400 animate-highlight' 
                          : 'border-gray-200 dark:border-gray-700'
                        }`}
                    >
                      <div className="flex justify-between">
                        <span className="text-sm font-medium text-gray-900 dark:text-white">{task.title}</span>
                        {getPriorityBadge(task.priority)}
                      </div>
                      {task.description && (
                        <p className="text-xs text-gray-500 dark:text-gray-400 mt-1">{task.description}</p>
                      )}
                      <div className="flex justify-between items-center mt-3">
                        <div className="text-xs text-gray-500 dark:text-gray-400">{task.due_date}</div>
                        <div className="text-xs font-medium text-primary-600 dark:text-primary-400">+{task.points} pts</div>
                      </div>
                      <div className="flex justify-end space-x-2 mt-2">
                        <Button size="sm" variant="ghost" onClick={() => editTask(task)}>
                          <Pencil className="h-3 w-3" />
                        </Button>
                        <Button size="sm" variant="ghost" onClick={() => markAsDone(task)}>
                          <Check className="h-3 w-3" />
                        </Button>
                      </div>
                    </div>
                  ))}
                  {backlogTasks.length === 0 && (
                    <div className="text-center text-gray-500 dark:text-gray-400 text-sm p-4">
                      No tasks in backlog
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>

            {/* Today Column */}
            <Card className="bg-primary-50 dark:bg-primary-900/20">
              <CardHeader className="pb-2">
                <div className="flex justify-between items-center">
                  <CardTitle className="text-sm font-medium">Today</CardTitle>
                  <Badge variant="primary" className="text-xs font-medium">
                    {todayTasks.length}
                  </Badge>
                </div>
              </CardHeader>
              <CardContent className="overflow-y-auto max-h-[60vh]">
                <div className="space-y-3">
                  {todayTasks.map((task) => (
                    <div 
                      key={task.id} 
                      className={`bg-white dark:bg-gray-800 p-3 rounded-md shadow-sm border 
                        ${taskHighlight === task.id 
                          ? 'border-2 border-green-500 dark:border-green-400 animate-highlight' 
                          : 'border-gray-200 dark:border-gray-700'
                        }`}
                    >
                      <div className="flex justify-between">
                        <span className="text-sm font-medium text-gray-900 dark:text-white">{task.title}</span>
                        {getPriorityBadge(task.priority)}
                      </div>
                      {task.description && (
                        <p className="text-xs text-gray-500 dark:text-gray-400 mt-1">{task.description}</p>
                      )}
                      <div className="flex justify-between items-center mt-3">
                        <div className="text-xs text-gray-500 dark:text-gray-400">{task.due_date || 'Today'}</div>
                        <div className="text-xs font-medium text-primary-600 dark:text-primary-400">+{task.points} pts</div>
                      </div>
                      <div className="flex justify-end space-x-2 mt-2">
                        <Button size="sm" variant="ghost" onClick={() => editTask(task)}>
                          <Pencil className="h-3 w-3" />
                        </Button>
                        <Button size="sm" variant="ghost" onClick={() => markAsDone(task)}>
                          <Check className="h-3 w-3" />
                        </Button>
                      </div>
                    </div>
                  ))}
                  {todayTasks.length === 0 && (
                    <div className="text-center text-gray-500 dark:text-gray-400 text-sm p-4">
                      No tasks for today
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>

            {/* Done Column */}
            <Card className="bg-green-50 dark:bg-green-900/20">
              <CardHeader className="pb-2">
                <div className="flex justify-between items-center">
                  <CardTitle className="text-sm font-medium">Done</CardTitle>
                  <Badge variant="success" className="text-xs font-medium">
                    {doneTasks.length}
                  </Badge>
                </div>
              </CardHeader>
              <CardContent className="overflow-y-auto max-h-[60vh]">
                <div className="space-y-3">
                  {doneTasks.map((task) => (
                    <div 
                      key={task.id} 
                      className={`bg-white dark:bg-gray-800 p-3 rounded-md shadow-sm border opacity-75
                        ${taskHighlight === task.id 
                          ? 'border-2 border-green-500 dark:border-green-400 animate-highlight' 
                          : 'border-gray-200 dark:border-gray-700'
                        }`}
                    >
                      <div className="flex justify-between">
                        <span className="text-sm font-medium line-through text-gray-500 dark:text-gray-400">{task.title}</span>
                        <Badge variant="outline" className="text-xs font-medium">
                          <Check className="h-3 w-3 mr-1" /> Done
                        </Badge>
                      </div>
                      {task.description && (
                        <p className="text-xs line-through text-gray-400 dark:text-gray-500 mt-1">{task.description}</p>
                      )}
                      <div className="flex justify-between items-center mt-3">
                        <div className="text-xs text-gray-400 dark:text-gray-500">{task.completed_at ? new Date(task.completed_at).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) : ''}</div>
                        <div className="text-xs font-medium text-green-600 dark:text-green-400">+{task.points} pts</div>
                      </div>
                      <div className="flex justify-end space-x-2 mt-2">
                        <Button size="sm" variant="ghost" onClick={() => editTask(task)}>
                          <Pencil className="h-3 w-3" />
                        </Button>
                      </div>
                    </div>
                  ))}
                  {doneTasks.length === 0 && (
                    <div className="text-center text-gray-500 dark:text-gray-400 text-sm p-4">
                      No completed tasks
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>
          </div>
        )}
      </div>

      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="sm:max-w-[425px]">
          <DialogHeader>
            <DialogTitle>
              {editingTask ? 'Edit Task' : 'Create Task'}
            </DialogTitle>
            <DialogDescription>
              {editingTask ? 'Make changes to your task here.' : 'Add a new task to your list.'}
            </DialogDescription>
          </DialogHeader>
          
          <Form {...form}>
            <div className="space-y-4">
              <FormField
                control={form.control}
                name="title"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Title</FormLabel>
                    <FormControl>
                      <Input placeholder="Task title" {...field} />
                    </FormControl>
                  </FormItem>
                )}
              />
              
              <FormField
                control={form.control}
                name="description"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Description</FormLabel>
                    <FormControl>
                      <Textarea placeholder="Task description" {...field} />
                    </FormControl>
                  </FormItem>
                )}
              />
              
              <FormField
                control={form.control}
                name="status"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Status</FormLabel>
                    <Select 
                      onValueChange={field.onChange} 
                      defaultValue={field.value}
                    >
                      <FormControl>
                        <SelectTrigger>
                          <SelectValue placeholder="Select status" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        <SelectItem value="backlog">Backlog</SelectItem>
                        <SelectItem value="today">Today</SelectItem>
                        <SelectItem value="done">Done</SelectItem>
                      </SelectContent>
                    </Select>
                  </FormItem>
                )}
              />
              
              <FormField
                control={form.control}
                name="priority"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Priority</FormLabel>
                    <Select 
                      onValueChange={field.onChange} 
                      defaultValue={field.value}
                    >
                      <FormControl>
                        <SelectTrigger>
                          <SelectValue placeholder="Select priority" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        <SelectItem value="low">Low</SelectItem>
                        <SelectItem value="medium">Medium</SelectItem>
                        <SelectItem value="high">High</SelectItem>
                      </SelectContent>
                    </Select>
                  </FormItem>
                )}
              />
              
              <FormField
                control={form.control}
                name="due_date"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Due Date</FormLabel>
                    <FormControl>
                      <Input type="date" {...field} />
                    </FormControl>
                  </FormItem>
                )}
              />
            </div>
          </Form>

          <DialogFooter className="flex justify-between">
            {editingTask && (
              <Button 
                variant="destructive" 
                onClick={handleDelete}
                disabled={deleteTaskMutation.isPending}
              >
                {deleteTaskMutation.isPending ? 'Deleting...' : <><Trash className="h-4 w-4 mr-2" /> Delete</>}
              </Button>
            )}
            <div className="flex space-x-2">
              <Button variant="secondary" onClick={() => setDialogOpen(false)}>
                Cancel
              </Button>
              <Button 
                type="submit" 
                onClick={form.handleSubmit(handleSubmit)}
                disabled={updateTaskMutation.isPending}
              >
                {updateTaskMutation.isPending ? 'Saving...' : 'Save Changes'}
              </Button>
            </div>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </>
  );
}
