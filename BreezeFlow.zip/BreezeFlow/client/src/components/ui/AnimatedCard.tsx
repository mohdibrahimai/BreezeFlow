import React from 'react';
import { Card, CardContent, CardFooter, CardHeader } from '@/components/ui/card';
import { cn } from '@/lib/utils';
import { useEntranceAnimation } from '@/lib/animation-utils';

interface AnimatedCardProps {
  children: React.ReactNode;
  className?: string;
  headerContent?: React.ReactNode;
  footerContent?: React.ReactNode;
  delay?: number;
}

const AnimatedCard: React.FC<AnimatedCardProps> = ({
  children,
  className,
  headerContent,
  footerContent,
  delay = 0,
}) => {
  const entranceProps = useEntranceAnimation(delay);
  
  return (
    <Card 
      className={cn(entranceProps.className, className)} 
      style={entranceProps.style}
      data-state={entranceProps['data-state']}
    >
      {headerContent && <CardHeader>{headerContent}</CardHeader>}
      <CardContent>{children}</CardContent>
      {footerContent && <CardFooter>{footerContent}</CardFooter>}
    </Card>
  );
};

// Animated card list will stagger the animations of each card
export const AnimatedCardList: React.FC<{
  children: React.ReactNode;
  baseDelay?: number;
  className?: string;
}> = ({ children, baseDelay = 50, className }) => {
  // Clone and add staggered animation to each child
  const childrenWithAnimation = React.Children.map(children, (child, index) => {
    if (React.isValidElement(child) && child.type === AnimatedCard) {
      return React.cloneElement(child as React.ReactElement<any>, {
        delay: baseDelay * (index + 1),
      });
    }
    return child;
  });
  
  return (
    <div className={cn('grid gap-4', className)}>
      {childrenWithAnimation}
    </div>
  );
};

export { AnimatedCard };