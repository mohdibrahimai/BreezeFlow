import React from 'react';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { format, parseISO } from 'date-fns';
import { formatAmount } from '@/lib/utils';
import { Edit, Trash, CheckCircle, Calendar, AlertCircle, RotateCcw } from 'lucide-react';
import { Switch } from '@/components/ui/switch';
import { cn } from '@/lib/utils';
import { Badge } from '@/components/ui/badge';

interface Bill {
  id: number;
  user_id: number;
  provider: string;
  amount: number | null;
  due_date: string | null;
  status: 'upcoming' | 'paid';
  autopay: boolean;
  category: string | null;
  recurring: boolean;
  recurring_interval: string | null;
  reminder_days: number | null;
  notes: string | null;
  created_at?: Date;
  paid_at?: Date | null;
  last_reminded_at?: Date | null;
}

interface BillItemProps {
  bill: Bill;
  onEdit: (bill: Bill) => void;
  onDelete: (bill: Bill) => void;
  onToggleStatus: (id: number, status: string) => void;
  badge?: React.ReactNode;
  className?: string;
}

export function BillItem({ bill, onEdit, onDelete, onToggleStatus, badge, className = '' }: BillItemProps) {
  // Format date for display
  const formatDate = (dateString: string | null): string => {
    if (!dateString) return 'No due date';
    try {
      const date = parseISO(dateString);
      return format(date, 'MMM d, yyyy');
    } catch {
      return dateString;
    }
  };
  
  // Determine category badge color based on category name
  const getCategoryColor = (category: string | null): string => {
    if (!category) return 'bg-gray-100 text-gray-800 dark:bg-gray-700 dark:text-gray-300';
    
    const categoryMap: Record<string, string> = {
      'Housing': 'bg-blue-100 text-blue-800 dark:bg-blue-900/30 dark:text-blue-300',
      'Utilities': 'bg-purple-100 text-purple-800 dark:bg-purple-900/30 dark:text-purple-300',
      'Subscription': 'bg-pink-100 text-pink-800 dark:bg-pink-900/30 dark:text-pink-300',
      'Insurance': 'bg-green-100 text-green-800 dark:bg-green-900/30 dark:text-green-300',
      'Loan': 'bg-amber-100 text-amber-800 dark:bg-amber-900/30 dark:text-amber-300',
      'Credit Card': 'bg-red-100 text-red-800 dark:bg-red-900/30 dark:text-red-300',
      'Healthcare': 'bg-emerald-100 text-emerald-800 dark:bg-emerald-900/30 dark:text-emerald-300',
      'Entertainment': 'bg-violet-100 text-violet-800 dark:bg-violet-900/30 dark:text-violet-300',
      'Education': 'bg-indigo-100 text-indigo-800 dark:bg-indigo-900/30 dark:text-indigo-300',
      'Transportation': 'bg-orange-100 text-orange-800 dark:bg-orange-900/30 dark:text-orange-300',
    };
    
    return categoryMap[category] || 'bg-gray-100 text-gray-800 dark:bg-gray-700 dark:text-gray-300';
  };
  
  // Get recurring interval text
  const getRecurringText = (interval: string | null): string => {
    if (!interval) return 'Monthly';
    
    const intervalMap: Record<string, string> = {
      'monthly': 'Monthly',
      'quarterly': 'Quarterly',
      'yearly': 'Yearly',
      'weekly': 'Weekly',
      'biweekly': 'Bi-weekly',
    };
    
    return intervalMap[interval.toLowerCase()] || interval;
  };

  return (
    <div className={cn(
      "relative group bg-white dark:bg-gray-800 rounded-xl shadow-sm transition-all duration-300 hover:shadow-md",
      className
    )}>
      <div className="p-4">
        <div className="flex justify-between items-start">
          <div className="flex-grow">
            <div className="flex items-center justify-between mb-1">
              <h3 className="text-lg font-semibold text-gray-900 dark:text-white">{bill.provider}</h3>
              <div className="flex items-center space-x-1">
                {badge}
                {bill.recurring && (
                  <Badge variant="outline" className="ml-2 flex items-center border-purple-200 bg-purple-50 text-purple-800 dark:bg-purple-900/20 dark:text-purple-300 dark:border-purple-800/30">
                    <RotateCcw className="mr-1 h-3 w-3" />
                    {getRecurringText(bill.recurring_interval)}
                  </Badge>
                )}
              </div>
            </div>
            
            <div className="flex items-center justify-between mb-3">
              <div className="flex items-center">
                {bill.category && (
                  <span className={cn("px-2 py-0.5 text-xs rounded-full mr-2", getCategoryColor(bill.category))}>
                    {bill.category}
                  </span>
                )}
                {bill.autopay && (
                  <span className="px-2 py-0.5 text-xs bg-green-100 text-green-800 dark:bg-green-900/30 dark:text-green-300 rounded-full">
                    Autopay
                  </span>
                )}
              </div>
              <span className="text-xl font-bold text-gray-900 dark:text-white">
                {formatAmount(bill.amount)}
              </span>
            </div>
            
            <div className="flex items-center justify-between text-sm">
              <div className="flex items-center text-gray-500 dark:text-gray-400">
                <Calendar className="h-4 w-4 mr-1" />
                <span>{formatDate(bill.due_date)}</span>
              </div>
              
              <div className="flex items-center space-x-2">
                <Switch
                  id={`bill-status-${bill.id}`}
                  checked={bill.status === 'paid'}
                  onCheckedChange={() => onToggleStatus(bill.id, bill.status)}
                  className="data-[state=checked]:bg-green-500"
                />
                <span className={bill.status === 'paid' ? 'text-green-600 dark:text-green-400' : 'text-gray-500 dark:text-gray-400'}>
                  {bill.status === 'paid' ? 'Paid' : 'Mark paid'}
                </span>
              </div>
            </div>
            
            {bill.notes && (
              <div className="mt-2 text-sm text-gray-500 dark:text-gray-400 bg-gray-50 dark:bg-gray-700/30 p-2 rounded-md">
                {bill.notes}
              </div>
            )}
          </div>
        </div>
        
        <div className="absolute right-3 top-3 opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex space-x-1">
          <Button 
            variant="ghost" 
            size="icon" 
            className="h-8 w-8" 
            onClick={() => onEdit(bill)}
          >
            <Edit className="h-4 w-4 text-gray-500 hover:text-blue-500 dark:text-gray-400 dark:hover:text-blue-400" />
          </Button>
          <Button 
            variant="ghost" 
            size="icon" 
            className="h-8 w-8" 
            onClick={() => onDelete(bill)}
          >
            <Trash className="h-4 w-4 text-gray-500 hover:text-red-500 dark:text-gray-400 dark:hover:text-red-400" />
          </Button>
        </div>
      </div>
    </div>
  );
}

export default BillItem;