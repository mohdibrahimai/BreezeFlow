import { useState, useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { CalendarClock, AlertCircle, Bell, Check, PlusCircle, Edit, RefreshCw, Settings } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { apiRequest } from "@/lib/queryClient";
import { Link } from "wouter";

interface BillWithDaysRemaining {
  id: number;
  provider: string;
  amount: number | null;
  due_date: string | null;
  daysUntilDue: number;
  category: string | null;
}

interface RemindersResponse {
  bills: BillWithDaysRemaining[];
}

export function ReminderList() {
  const { data, isLoading, isError, refetch } = useQuery<RemindersResponse>({
    queryKey: ['/api/reminders'],
    refetchOnWindowFocus: false
  });

  const acknowledgeReminder = async (billId: number) => {
    try {
      await apiRequest('POST', `/api/reminders/${billId}/acknowledge`);
      refetch(); // Refresh the list after acknowledgment
    } catch (error) {
      console.error('Error acknowledging reminder:', error);
    }
  };

  // Helper to get the appropriate severity color based on days remaining
  const getSeverityColor = (days: number) => {
    if (days <= 2) return "destructive";
    if (days <= 5) return "warning";
    return "default";
  };

  // Helper to format currency
  const formatCurrency = (amount: number | null) => {
    if (amount === null) return "N/A";
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD'
    }).format(amount);
  };

  if (isLoading) {
    return (
      <Card className="animate-pulse">
        <CardHeader className="bg-gray-100 dark:bg-gray-800 h-12"></CardHeader>
        <CardContent className="pt-4">
          <div className="space-y-4">
            <div className="h-5 bg-gray-200 dark:bg-gray-700 rounded"></div>
            <div className="h-5 bg-gray-200 dark:bg-gray-700 rounded w-3/4"></div>
            <div className="h-5 bg-gray-200 dark:bg-gray-700 rounded w-1/2"></div>
          </div>
        </CardContent>
      </Card>
    );
  }

  if (isError) {
    return (
      <Card className="border-destructive">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <AlertCircle className="h-5 w-5 text-destructive" />
            Error Loading Reminders
          </CardTitle>
        </CardHeader>
        <CardContent>
          <p className="mb-4">Failed to load upcoming bill reminders. Please try again later.</p>
          
          <div className="bg-muted p-4 rounded-lg">
            <h3 className="text-sm font-medium mb-2">Reminder Management</h3>
            <p className="text-sm text-muted-foreground mb-4">
              Would you like to add new reminders or manage existing ones?
            </p>
            
            <div className="flex flex-col space-y-3">
              <Link href="/bills">
                <Button className="w-full justify-start" variant="outline">
                  <PlusCircle className="mr-2 h-4 w-4" />
                  Add New Bill Reminder
                </Button>
              </Link>
              
              <Link href="/tasks">
                <Button className="w-full justify-start" variant="outline">
                  <PlusCircle className="mr-2 h-4 w-4" />
                  Add New Task Reminder
                </Button>
              </Link>
              
              <Link href="/bills?filter=upcoming">
                <Button className="w-full justify-start" variant="outline">
                  <Edit className="mr-2 h-4 w-4" />
                  Manage Bill Reminders
                </Button>
              </Link>
            </div>
          </div>
        </CardContent>
        <CardFooter className="flex justify-between">
          <Button onClick={() => refetch()} variant="outline">
            <RefreshCw className="mr-2 h-4 w-4" />
            Retry
          </Button>
          <Button variant="ghost" size="sm" asChild>
            <Link href="/settings">
              <Settings className="mr-2 h-4 w-4" />
              Reminder Settings
            </Link>
          </Button>
        </CardFooter>
      </Card>
    );
  }

  // If no reminders or empty data
  if (!data || !data.bills || data.bills.length === 0) {
    return (
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Bell className="h-5 w-5" />
            Bill Reminders
          </CardTitle>
          <CardDescription>You have no upcoming bills due soon</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="flex flex-col items-center justify-center py-6 text-center text-muted-foreground">
            <CalendarClock className="h-12 w-12 mb-3 opacity-20" />
            <p>All caught up! No bills need your attention right now.</p>
          </div>
          
          <div className="mt-6 bg-muted p-4 rounded-lg">
            <h3 className="text-sm font-medium mb-2">Reminder Management</h3>
            <p className="text-sm text-muted-foreground mb-4">
              Would you like to set up new reminders or manage existing ones?
            </p>
            
            <div className="flex flex-col space-y-3">
              <Link href="/bills">
                <Button className="w-full justify-start" variant="outline">
                  <PlusCircle className="mr-2 h-4 w-4" />
                  Add New Bill Reminder
                </Button>
              </Link>
              
              <Link href="/tasks">
                <Button className="w-full justify-start" variant="outline">
                  <PlusCircle className="mr-2 h-4 w-4" />
                  Add New Task Reminder
                </Button>
              </Link>
              
              <Link href="/bills?filter=upcoming">
                <Button className="w-full justify-start" variant="outline">
                  <Edit className="mr-2 h-4 w-4" />
                  Manage Bill Reminders
                </Button>
              </Link>
            </div>
          </div>
        </CardContent>
      </Card>
    );
  }

  // Sort bills by days until due
  const sortedBills = [...data.bills].sort((a, b) => a.daysUntilDue - b.daysUntilDue);

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Bell className="h-5 w-5" />
          Bill Reminders
        </CardTitle>
        <CardDescription>You have {sortedBills.length} upcoming {sortedBills.length === 1 ? 'bill' : 'bills'} that {sortedBills.length === 1 ? 'needs' : 'need'} your attention</CardDescription>
      </CardHeader>
      <CardContent>
        <ul className="space-y-3">
          {sortedBills.map((bill) => (
            <li key={bill.id} className="flex items-center justify-between p-3 rounded-md border">
              <div className="flex flex-col">
                <div className="flex items-center gap-2">
                  <span className="font-medium">{bill.provider}</span>
                  {bill.category && (
                    <Badge variant="outline" className="text-xs">
                      {bill.category}
                    </Badge>
                  )}
                </div>
                <div className="text-sm text-muted-foreground">
                  {formatCurrency(bill.amount)} • Due in {bill.daysUntilDue} {bill.daysUntilDue === 1 ? 'day' : 'days'}
                </div>
              </div>
              <Badge variant={getSeverityColor(bill.daysUntilDue)}>
                {bill.daysUntilDue <= 2 ? 'Urgent' : bill.daysUntilDue <= 5 ? 'Soon' : 'Upcoming'}
              </Badge>
              <Button 
                size="sm" 
                variant="ghost" 
                onClick={() => acknowledgeReminder(bill.id)}
                className="ml-2"
                title="Acknowledge reminder"
              >
                <Check className="h-4 w-4" />
              </Button>
            </li>
          ))}
        </ul>
      </CardContent>
    </Card>
  );
}