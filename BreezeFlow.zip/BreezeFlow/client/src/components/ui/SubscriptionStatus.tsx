import React, { useState } from 'react';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { useAuth } from '@/hooks/use-auth';
import { CircleDollarSign, AlertCircle, Calendar, ChevronRight, Loader2, ShieldCheck } from 'lucide-react';
import { useLocation } from 'wouter';
import { useToast } from '@/hooks/use-toast';
import { format } from 'date-fns';

interface SubscriptionStatusProps {
  onUpgrade?: () => void;
}

export function SubscriptionStatus({ onUpgrade }: SubscriptionStatusProps) {
  const { user } = useAuth();
  const [loading, setLoading] = useState(false);
  const [, navigate] = useLocation();
  const { toast } = useToast();

  if (!user) return null;

  const planLabels = {
    free: {
      name: 'Free Plan',
      description: 'Basic features with limited usage',
      color: 'bg-gray-100 text-gray-800 dark:bg-gray-800 dark:text-gray-100'
    },
    starter: {
      name: 'Starter Plan',
      description: 'Essential features for everyday productivity',
      color: 'bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-100'
    },
    pro: {
      name: 'Pro Plan',
      description: 'Advanced features for power users',
      color: 'bg-purple-100 text-purple-800 dark:bg-purple-900 dark:text-purple-100'
    },
    team: {
      name: 'Team Plan',
      description: 'Collaborative features for small teams',
      color: 'bg-amber-100 text-amber-800 dark:bg-amber-900 dark:text-amber-100'
    }
  };

  const currentPlan = user.plan || 'free';
  const isActivePlan = user.plan_active || false;
  const expiryDate = user.plan_expiry ? new Date(user.plan_expiry) : null;

  const handleUpgrade = () => {
    if (onUpgrade) {
      onUpgrade();
    } else {
      setLoading(true);
      navigate('/pricing');
    }
  };

  const getPlanQuota = (plan: string) => {
    switch (plan) {
      case 'free':
        return '75 actions / month';
      case 'starter':
        return '750 actions / month';
      case 'pro':
      case 'team':
        return 'Unlimited actions';
      default:
        return 'Unknown quota';
    }
  };

  const handleRenew = () => {
    setLoading(true);
    navigate('/checkout?plan=' + currentPlan);
  };

  const getStatusLabel = () => {
    if (!isActivePlan) {
      return (
        <Badge variant="destructive" className="ml-2">
          Inactive
        </Badge>
      );
    }

    if (expiryDate && expiryDate < new Date()) {
      return (
        <Badge variant="destructive" className="ml-2">
          Expired
        </Badge>
      );
    }

    return (
      <Badge variant="default" className="bg-green-500 ml-2">
        Active
      </Badge>
    );
  };

  return (
    <Card className="w-full">
      <CardHeader className="pb-3">
        <div className="flex items-center justify-between">
          <CardTitle className="text-lg font-medium">Subscription Status</CardTitle>
          {getStatusLabel()}
        </div>
        <CardDescription>
          Manage your plan and billing details
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-4 pt-0">
        <div className="flex items-center justify-between py-2">
          <div className="flex items-center">
            <CircleDollarSign className="mr-2 h-5 w-5 text-primary" />
            <div>
              <div className="font-medium">Current Plan</div>
              <div className="text-sm text-muted-foreground">
                {planLabels[currentPlan as keyof typeof planLabels]?.name || 'Unknown Plan'}
              </div>
            </div>
          </div>
          <Badge className={planLabels[currentPlan as keyof typeof planLabels]?.color || ''}>
            {currentPlan.charAt(0).toUpperCase() + currentPlan.slice(1)}
          </Badge>
        </div>

        <div className="flex items-center justify-between py-2 border-t">
          <div className="flex items-center">
            <ShieldCheck className="mr-2 h-5 w-5 text-primary" />
            <div>
              <div className="font-medium">Usage Quota</div>
              <div className="text-sm text-muted-foreground">
                {getPlanQuota(currentPlan)}
              </div>
            </div>
          </div>
        </div>

        {expiryDate && (
          <div className="flex items-center justify-between py-2 border-t">
            <div className="flex items-center">
              <Calendar className="mr-2 h-5 w-5 text-primary" />
              <div>
                <div className="font-medium">Next Billing Date</div>
                <div className="text-sm text-muted-foreground">
                  {format(expiryDate, 'PPP')}
                </div>
              </div>
            </div>
            {expiryDate && expiryDate < new Date(Date.now() + 7 * 24 * 60 * 60 * 1000) && (
              <Badge variant="outline" className="bg-yellow-50 text-yellow-800 border-yellow-200 dark:bg-yellow-900 dark:text-yellow-200 dark:border-yellow-800">
                Renewal Soon
              </Badge>
            )}
          </div>
        )}

        {!isActivePlan && currentPlan !== 'free' && (
          <div className="flex items-center justify-between py-2 border-t">
            <div className="flex items-center">
              <AlertCircle className="mr-2 h-5 w-5 text-destructive" />
              <div>
                <div className="font-medium">Subscription Expired</div>
                <div className="text-sm text-muted-foreground">
                  Your plan benefits are currently inactive
                </div>
              </div>
            </div>
          </div>
        )}
      </CardContent>
      <CardFooter className="flex justify-between">
        {currentPlan === 'free' ? (
          <Button className="w-full" onClick={handleUpgrade} disabled={loading}>
            {loading ? (
              <>
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                Loading...
              </>
            ) : (
              <>
                Upgrade Plan
                <ChevronRight className="ml-1 h-4 w-4" />
              </>
            )}
          </Button>
        ) : (
          <div className="w-full flex gap-3">
            <Button variant="outline" className="flex-1" onClick={() => navigate('/settings')}>
              Manage Plan
            </Button>
            <Button 
              className="flex-1" 
              onClick={handleRenew} 
              disabled={loading || Boolean(expiryDate && expiryDate > new Date(Date.now() + 7 * 24 * 60 * 60 * 1000))}
            >
              {loading ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Loading...
                </>
              ) : (
                'Renew Plan'
              )}
            </Button>
          </div>
        )}
      </CardFooter>
    </Card>
  );
}