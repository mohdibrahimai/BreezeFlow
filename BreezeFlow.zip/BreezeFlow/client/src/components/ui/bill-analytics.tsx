import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { 
  LineChart,
  PieChart,
  BarChart,
  LineUp,
  BarChart3,
  PieChart as PieChartIcon,
  Calendar
} from 'lucide-react';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { format, parseISO, isThisMonth, isAfter, addMonths } from 'date-fns';
import { Badge } from './badge';
import { formatAmount } from '@/lib/utils';

// Define Bill type (same as in bill-list.tsx)
interface Bill {
  id: number;
  user_id: number;
  provider: string;
  amount: number | null;
  due_date: string | null;
  status: 'upcoming' | 'paid';
  autopay: boolean;
  category: string | null;
  recurring: boolean;
  recurring_interval: string | null;
  reminder_days: number | null;
  notes: string | null;
  created_at?: Date;
  paid_at?: Date | null;
  last_reminded_at?: Date | null;
}

type BillAnalyticsProps = {
  bills: Bill[];
};

export function BillAnalytics({ bills }: BillAnalyticsProps) {
  // Using formatAmount from utils.ts
  
  // Group bills by category
  const billsByCategory = bills.reduce((acc, bill) => {
    const category = bill.category || 'Uncategorized';
    if (!acc[category]) {
      acc[category] = {
        count: 0,
        amount: 0,
      };
    }
    
    acc[category].count += 1;
    acc[category].amount += bill.amount || 0;
    
    return acc;
  }, {} as Record<string, { count: number; amount: number }>);
  
  // Get categories sorted by amount
  const categoriesByAmount = Object.entries(billsByCategory)
    .sort((a, b) => b[1].amount - a[1].amount)
    .map(([category, data]) => ({
      category,
      ...data,
    }));
  
  // Calculate upcoming monthly and yearly totals
  const upcomingBills = bills.filter(bill => bill.status === 'upcoming');
  
  const monthlyTotal = upcomingBills.reduce((sum, bill) => {
    if (!bill.amount) return sum;
    
    if (bill.recurring) {
      if (bill.recurring_interval === 'yearly') {
        return sum + (bill.amount / 12); // Convert yearly to monthly
      } else if (bill.recurring_interval === 'quarterly') {
        return sum + (bill.amount / 3); // Convert quarterly to monthly
      }
    }
    
    return sum + bill.amount;
  }, 0);
  
  const yearlyTotal = monthlyTotal * 12;
  
  // Calculate this month's spending
  const thisMonthSpending = bills
    .filter(bill => {
      if (bill.status !== 'paid' || !bill.paid_at) return false;
      
      try {
        const paidDate = new Date(bill.paid_at);
        return isThisMonth(paidDate);
      } catch {
        return false;
      }
    })
    .reduce((sum, bill) => sum + (bill.amount || 0), 0);
  
  // Get upcoming bills for the next 30 days
  const next30DaysDate = addMonths(new Date(), 1);
  const upcomingIn30Days = upcomingBills.filter(bill => {
    if (!bill.due_date) return false;
    
    try {
      const dueDate = parseISO(bill.due_date);
      const now = new Date();
      return isAfter(dueDate, now) && !isAfter(dueDate, next30DaysDate);
    } catch {
      return false;
    }
  });
  
  const upcomingIn30DaysTotal = upcomingIn30Days.reduce((sum, bill) => sum + (bill.amount || 0), 0);
  
  return (
    <Card>
      <CardHeader className="pb-2">
        <CardTitle className="text-xl font-bold">Bill Analytics</CardTitle>
      </CardHeader>
      
      <CardContent>
        <Tabs defaultValue="overview">
          <TabsList className="grid grid-cols-3 mb-4">
            <TabsTrigger value="overview">
              <LineChart className="h-4 w-4 mr-2" />
              Overview
            </TabsTrigger>
            <TabsTrigger value="categories">
              <PieChartIcon className="h-4 w-4 mr-2" />
              Categories
            </TabsTrigger>
            <TabsTrigger value="upcoming">
              <Calendar className="h-4 w-4 mr-2" />
              Upcoming
            </TabsTrigger>
          </TabsList>
          
          {/* Overview Tab */}
          <TabsContent value="overview" className="space-y-4">
            <div className="bg-gradient-to-tr from-blue-50 to-blue-100 dark:from-blue-900/20 dark:to-indigo-900/20 p-4 rounded-xl shadow-sm">
              <h3 className="text-sm font-medium text-blue-700 dark:text-blue-400 mb-1">Estimated Monthly</h3>
              <p className="text-2xl font-bold text-blue-800 dark:text-blue-300">{formatAmount(monthlyTotal)}</p>
            </div>
            
            <div className="bg-gradient-to-tr from-indigo-50 to-indigo-100 dark:from-indigo-900/20 dark:to-purple-900/20 p-4 rounded-xl shadow-sm">
              <h3 className="text-sm font-medium text-indigo-700 dark:text-indigo-400 mb-1">Estimated Yearly</h3>
              <p className="text-2xl font-bold text-indigo-800 dark:text-indigo-300">{formatAmount(yearlyTotal)}</p>
            </div>
            
            <div className="bg-gradient-to-tr from-green-50 to-green-100 dark:from-green-900/20 dark:to-teal-900/20 p-4 rounded-xl shadow-sm">
              <h3 className="text-sm font-medium text-green-700 dark:text-green-400 mb-1">This Month Spending</h3>
              <p className="text-2xl font-bold text-green-800 dark:text-green-300">{formatAmount(thisMonthSpending)}</p>
            </div>
          </TabsContent>
          
          {/* Categories Tab */}
          <TabsContent value="categories" className="space-y-4">
            {categoriesByAmount.length > 0 ? (
              <div className="space-y-3">
                {categoriesByAmount.map(({ category, amount, count }) => (
                  <div key={category} className="flex items-center justify-between p-3 bg-white dark:bg-gray-800 rounded-lg shadow-sm">
                    <div className="flex items-center">
                      <Badge className="mr-2">{count}</Badge>
                      <span className="font-medium">{category}</span>
                    </div>
                    <span className="font-semibold">{formatAmount(amount)}</span>
                  </div>
                ))}
              </div>
            ) : (
              <div className="text-center py-6 text-gray-500 dark:text-gray-400">
                <p>No categories found. Add bills with categories to see analytics.</p>
              </div>
            )}
          </TabsContent>
          
          {/* Upcoming Tab */}
          <TabsContent value="upcoming" className="space-y-4">
            <div className="bg-gradient-to-tr from-amber-50 to-amber-100 dark:from-amber-900/20 dark:to-yellow-900/20 p-4 rounded-xl shadow-sm">
              <h3 className="text-sm font-medium text-amber-700 dark:text-amber-400 mb-1">Next 30 Days</h3>
              <p className="text-2xl font-bold text-amber-800 dark:text-amber-300">{formatAmount(upcomingIn30DaysTotal)}</p>
              <p className="text-xs text-amber-600 dark:text-amber-400 mt-1">{upcomingIn30Days.length} bills upcoming</p>
            </div>
            
            <div className="space-y-2">
              <h3 className="text-sm font-medium">Upcoming Timeline</h3>
              {upcomingIn30Days.length > 0 ? (
                upcomingIn30Days
                  .sort((a, b) => {
                    if (!a.due_date || !b.due_date) return 0;
                    return parseISO(a.due_date).getTime() - parseISO(b.due_date).getTime();
                  })
                  .map(bill => (
                    <div key={bill.id} className="flex items-center justify-between p-2 bg-white dark:bg-gray-800 rounded-lg border border-gray-100 dark:border-gray-700">
                      <div>
                        <p className="font-medium">{bill.provider}</p>
                        {bill.due_date && (
                          <p className="text-xs text-gray-500 dark:text-gray-400">
                            {format(parseISO(bill.due_date), 'MMMM d, yyyy')}
                          </p>
                        )}
                      </div>
                      <span className="font-semibold">{formatAmount(bill.amount)}</span>
                    </div>
                  ))
              ) : (
                <div className="text-center py-4 text-gray-500 dark:text-gray-400">
                  <p>No upcoming bills in the next 30 days.</p>
                </div>
              )}
            </div>
          </TabsContent>
        </Tabs>
      </CardContent>
    </Card>
  );
}

export default BillAnalytics;