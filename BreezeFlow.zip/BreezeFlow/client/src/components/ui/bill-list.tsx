import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import { Button } from '@/components/ui/button';
import { Switch } from '@/components/ui/switch';
import { BillItem } from '@/components/ui/bill-item';
import { 
  CreditCard, 
  CheckCircle, 
  Edit, 
  Trash, 
  Calendar,
  DollarSign,
  AlertCircle,
  BellRing,
  Wallet,
  ReceiptText,
  ChevronDown,
  LineChart,
  RotateCcw
} from 'lucide-react';
import { BillForm } from '@/components/ui/bill-form';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { apiRequest } from '@/lib/queryClient';
import { useToast } from '@/hooks/use-toast';
import { format, parseISO, isToday, isFuture, isPast, formatDistance, addDays } from 'date-fns';
import { Skeleton } from '@/components/ui/skeleton';
import { formatAmount } from '@/lib/utils';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Progress } from '@/components/ui/progress';
import { BillAnalytics } from '@/components/ui/bill-analytics';

// Define Bill type
interface Bill {
  id: number;
  user_id: number;
  provider: string;
  amount: number | null;
  due_date: string | null;
  status: 'upcoming' | 'paid';
  autopay: boolean;
  category: string | null;
  recurring: boolean;
  recurring_interval: string | null;
  reminder_days: number | null;
  notes: string | null;
  created_at?: Date;
  paid_at?: Date | null;
  last_reminded_at?: Date | null;
}

// Define types for Next Due Bill
interface ParsedBill extends Bill {
  parsedDate: Date;
}

export function BillList() {
  const [isAddingBill, setIsAddingBill] = useState(false);
  const [editingBill, setEditingBill] = useState<Bill | null>(null);
  const [showPastBills, setShowPastBills] = useState(false);
  const [showRecurringOnly, setShowRecurringOnly] = useState(false);
  const [confirmingDelete, setConfirmingDelete] = useState<Bill | null>(null);
  const { toast } = useToast();
  const queryClient = useQueryClient();
  
  // Query for bills data - IMPORTANT: This needs to be before any references to 'bills'
  const { data: bills = [], isLoading } = useQuery({
    queryKey: ['/api/bills'],
    select: (data) => data as Bill[],
  });
  
  // Filter bills by status
  const upcomingBills = bills.filter(bill => bill.status === 'upcoming');
  const paidBills = bills.filter(bill => bill.status === 'paid');
  
  // Calculate statistics
  const monthlyTotal = bills
    .filter(bill => bill.status === 'upcoming')
    .reduce((sum, bill) => sum + (bill.amount || 0), 0);
  
  const paidCount = paidBills.length;
  const totalCount = bills.length;
  
  const dueSoonCount = upcomingBills.filter(bill => {
    if (!bill.due_date) return false;
    const daysUntilDue = getDaysUntilDue(bill.due_date);
    return daysUntilDue !== null && daysUntilDue <= 7;
  }).length;
  
  const dueTodayCount = upcomingBills.filter(bill => {
    if (!bill.due_date) return false;
    try {
      return isToday(parseISO(bill.due_date));
    } catch {
      return false;
    }
  }).length;
  
  const dueSoonAmount = upcomingBills
    .filter(bill => {
      if (!bill.due_date) return false;
      const daysUntilDue = getDaysUntilDue(bill.due_date);
      return daysUntilDue !== null && daysUntilDue <= 7;
    })
    .reduce((sum, bill) => sum + (bill.amount || 0), 0);
  
  const recurringCount = bills.filter(bill => bill.recurring).length;
  
  const recurringMonthlyAmount = bills
    .filter(bill => bill.recurring && bill.status === 'upcoming')
    .reduce((sum, bill) => {
      const amount = bill.amount || 0;
      
      // Adjust amount based on recurring interval
      if (bill.recurring_interval === 'quarterly') {
        return sum + (amount / 3); // Divide quarterly by 3 to get monthly
      } else if (bill.recurring_interval === 'yearly') {
        return sum + (amount / 12); // Divide yearly by 12 to get monthly
      }
      
      return sum + amount; // Monthly is default
    }, 0);
  
  // Using the formatAmount utility function from utils.ts
  
  // Function to format dates
  const formatDate = (dateString: string | null): string => {
    if (!dateString) return '-';
    try {
      const date = parseISO(dateString);
      return format(date, 'MMM d, yyyy');
    } catch {
      return dateString;
    }
  };
  
  // Get days until a bill is due
  const getDaysUntilDue = (dueDate: string): number | null => {
    try {
      const date = parseISO(dueDate);
      if (!isFuture(date) && !isToday(date)) return null;
      
      const now = new Date();
      const diffTime = date.getTime() - now.getTime();
      const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
      return diffDays;
    } catch {
      return null;
    }
  };
  
  // Function to get badge for due dates
  const getDueBadge = (dueDate: string): React.ReactNode => {
    const daysUntilDue = getDaysUntilDue(dueDate);
    
    if (daysUntilDue === null) {
      try {
        const date = parseISO(dueDate);
        if (isPast(date) && !isToday(date)) {
          return <Badge variant="destructive">Overdue</Badge>;
        }
      } catch {
        return null;
      }
      return null;
    }
    
    if (daysUntilDue === 0) {
      return <Badge variant="warning">Today</Badge>;
    } else if (daysUntilDue <= 3) {
      return <Badge variant="warning">Soon</Badge>;
    } else if (daysUntilDue <= 7) {
      return <Badge variant="outline">{daysUntilDue} days</Badge>;
    }
    
    return null;
  };
  
  // Get next due bill for summary card
  const getNextDueBill = (): ParsedBill | null => {
    if (!bills || bills.length === 0) return null;
    
    // Filter upcoming bills with valid due dates and sort by date
    const billsWithDates = bills
      .filter(bill => bill.due_date && bill.status === 'upcoming')
      .map((bill) => ({
        ...bill,
        parsedDate: parseISO(bill.due_date)
      }))
      .filter((bill: ParsedBill) => isFuture(bill.parsedDate) || isToday(bill.parsedDate))
      .sort((a: ParsedBill, b: ParsedBill) => a.parsedDate.getTime() - b.parsedDate.getTime());
    
    return billsWithDates.length ? billsWithDates[0] : null;
  };
  
  const nextDueBill = getNextDueBill();

  // Toggle bill status
  const toggleStatusMutation = useMutation({
    mutationFn: async (args: { id: number; status: string }) => {
      const { id, status } = args;
      // Flip the status
      const newStatus = status === 'upcoming' ? 'paid' : 'upcoming';
      const response = await apiRequest('PATCH', `/api/bills/${id}`, {
        status: newStatus,
        paid_at: newStatus === 'paid' ? new Date().toISOString() : null
      });
      
      if (!response.ok) throw new Error('Failed to update bill status');
      return await response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/bills'] });
      toast({
        title: 'Status updated',
        description: 'Bill status has been updated successfully.',
      });
    },
    onError: (error) => {
      toast({
        title: 'Error',
        description: `Failed to update status: ${error.message}`,
        variant: 'destructive',
      });
    },
  });
  
  const toggleStatus = (id: number, status: string) => {
    toggleStatusMutation.mutate({ id, status });
  };
  
  // Delete bill
  const deleteMutation = useMutation({
    mutationFn: async (id: number) => {
      const response = await apiRequest('DELETE', `/api/bills/${id}`);
      if (!response.ok) throw new Error('Failed to delete bill');
      return await response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/bills'] });
      toast({
        title: 'Bill deleted',
        description: 'Bill has been removed successfully.',
      });
    },
    onError: (error) => {
      toast({
        title: 'Error',
        description: `Failed to delete bill: ${error.message}`,
        variant: 'destructive',
      });
    },
  });
  
  const deleteBill = (id: number) => {
    deleteMutation.mutate(id);
  };
  
  // Set up edit bill
  const editBill = (bill: Bill) => {
    setEditingBill(bill);
  };
  
  // Set up confirm delete
  const confirmDelete = (bill: Bill) => {
    setConfirmingDelete(bill);
  };

  return (
    <>
      <Card className="mb-6">
        <CardContent className="pt-6">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
            <div className="bg-gradient-to-tr from-blue-50 to-blue-100 dark:from-blue-900/20 dark:to-indigo-900/20 p-4 rounded-xl shadow-sm hover:shadow-md transition-all duration-300 group">
              <div className="flex justify-between items-start">
                <div>
                  <p className="text-xs text-blue-700 dark:text-blue-400 font-medium mb-1">Monthly Total</p>
                  <h3 className="text-xl md:text-2xl font-bold text-blue-700 dark:text-blue-300 group-hover:scale-105 transition-transform duration-300">
                    {formatAmount(monthlyTotal)}
                  </h3>
                </div>
                <div className="relative">
                  <div className="absolute -inset-1 bg-blue-400/20 rounded-lg blur opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
                  <Wallet className="relative text-blue-500 dark:text-blue-400 h-8 w-8 p-1.5 bg-white dark:bg-blue-900/30 rounded-lg shadow-sm group-hover:rotate-3 transition-transform duration-300" />
                </div>
              </div>
              {nextDueBill && (
                <div className="mt-4 text-xs text-blue-600 dark:text-blue-400">
                  <p className="font-medium">Next bill:</p>
                  <div className="flex items-center justify-between mt-1">
                    <span className="truncate pr-2">{nextDueBill.provider}</span>
                    <span className="font-semibold whitespace-nowrap">{formatAmount(nextDueBill.amount || 0)}</span>
                  </div>
                </div>
              )}
            </div>
            
            <div className="bg-gradient-to-tr from-green-50 to-green-100 dark:from-green-900/20 dark:to-teal-900/20 p-4 rounded-xl shadow-sm hover:shadow-md transition-all duration-300 group">
              <div className="flex justify-between items-start">
                <div>
                  <p className="text-xs text-green-700 dark:text-green-400 font-medium mb-1">Bills Paid</p>
                  <h3 className="text-xl md:text-2xl font-bold text-green-700 dark:text-green-300 group-hover:scale-105 transition-transform duration-300">
                    {paidCount}
                  </h3>
                </div>
                <div className="relative">
                  <div className="absolute -inset-1 bg-green-400/20 rounded-lg blur opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
                  <CheckCircle className="relative text-green-500 dark:text-green-400 h-8 w-8 p-1.5 bg-white dark:bg-green-900/30 rounded-lg shadow-sm group-hover:rotate-3 transition-transform duration-300" />
                </div>
              </div>
              <div className="mt-4">
                <div className="flex items-center justify-between text-xs text-green-600 dark:text-green-400">
                  <span>Progress</span>
                  <span className="font-semibold">{totalCount > 0 ? Math.round((paidCount / totalCount) * 100) : 0}%</span>
                </div>
                <Progress 
                  className="mt-1 h-2 bg-green-200 dark:bg-green-900/30" 
                  value={totalCount > 0 ? (paidCount / totalCount) * 100 : 0} 
                />
              </div>
            </div>
            
            <div className="bg-gradient-to-tr from-amber-50 to-amber-100 dark:from-amber-900/20 dark:to-yellow-900/20 p-4 rounded-xl shadow-sm hover:shadow-md transition-all duration-300 group">
              <div className="flex justify-between items-start">
                <div>
                  <p className="text-xs text-amber-700 dark:text-amber-400 font-medium mb-1">Due Soon</p>
                  <h3 className="text-xl md:text-2xl font-bold text-amber-700 dark:text-amber-300 group-hover:scale-105 transition-transform duration-300">
                    {dueSoonCount}
                  </h3>
                </div>
                <div className="relative">
                  <div className="absolute -inset-1 bg-amber-400/20 rounded-lg blur opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
                  <AlertCircle className="relative text-amber-500 dark:text-amber-400 h-8 w-8 p-1.5 bg-white dark:bg-amber-900/30 rounded-lg shadow-sm group-hover:rotate-3 transition-transform duration-300" />
                </div>
              </div>
              <div className="mt-4">
                <div className="flex items-center text-xs text-amber-600 dark:text-amber-400">
                  <span className="font-medium mr-1">Amount due:</span>
                  <span className="font-semibold">{formatAmount(dueSoonAmount)}</span>
                </div>
                <div className="flex items-center text-xs text-amber-600 dark:text-amber-400 mt-1">
                  <Calendar className="h-3 w-3 mr-1" />
                  <span>Within next 7 days</span>
                </div>
              </div>
            </div>
            
            <div className="bg-gradient-to-tr from-purple-50 to-purple-100 dark:from-purple-900/20 dark:to-indigo-900/20 p-4 rounded-xl shadow-sm hover:shadow-md transition-all duration-300 group">
              <div className="flex justify-between items-start">
                <div>
                  <p className="text-xs text-purple-700 dark:text-purple-400 font-medium mb-1">Recurring</p>
                  <h3 className="text-xl md:text-2xl font-bold text-purple-700 dark:text-purple-300 group-hover:scale-105 transition-transform duration-300">
                    {recurringCount}
                  </h3>
                </div>
                <div className="relative">
                  <div className="absolute -inset-1 bg-purple-400/20 rounded-lg blur opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
                  <RotateCcw className="relative text-purple-500 dark:text-purple-400 h-8 w-8 p-1.5 bg-white dark:bg-purple-900/30 rounded-lg shadow-sm group-hover:rotate-3 transition-transform duration-300" />
                </div>
              </div>
              <div className="mt-4">
                <div className="flex items-center text-xs text-purple-600 dark:text-purple-400">
                  <span className="font-medium mr-1">Monthly amount:</span>
                  <span className="font-semibold">{formatAmount(recurringMonthlyAmount)}</span>
                </div>
                <div className="flex items-center justify-between text-xs text-purple-600 dark:text-purple-400 mt-1">
                  <span>% of total expenses</span>
                  <span className="font-semibold">{monthlyTotal > 0 ? Math.round((recurringMonthlyAmount / monthlyTotal) * 100) : 0}%</span>
                </div>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
      
      <div className="flex flex-col md:flex-row gap-6">
        <div className="w-full md:w-2/3">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between pb-2">
              <CardTitle className="text-xl font-bold">Bills</CardTitle>
              <div className="flex items-center space-x-2">
                <Button
                  onClick={() => setIsAddingBill(true)}
                  className="bg-blue-600 hover:bg-blue-700"
                >
                  <CreditCard className="mr-2 h-4 w-4" />
                  Add Bill
                </Button>
              </div>
            </CardHeader>
            <CardContent>
              <div className="flex flex-col md:flex-row md:items-center justify-between mb-6">
                <div className="flex space-x-2 mb-2 md:mb-0">
                  <Tabs defaultValue="all" className="w-full">
                    <TabsList>
                      <TabsTrigger value="all">All Bills</TabsTrigger>
                      <TabsTrigger value="upcoming">Upcoming</TabsTrigger>
                      <TabsTrigger value="paid">Paid</TabsTrigger>
                      <TabsTrigger value="recurring">Recurring</TabsTrigger>
                    </TabsList>
                  </Tabs>
                </div>
                
                <div className="flex items-center space-x-4">
                  <div className="flex items-center space-x-2">
                    <Switch
                      id="show-past"
                      checked={showPastBills}
                      onCheckedChange={setShowPastBills}
                    />
                    <Label htmlFor="show-past" className="text-sm cursor-pointer">Show Past</Label>
                  </div>
                </div>
              </div>
              
              {isLoading ? (
                <div className="space-y-3">
                  {[1, 2, 3].map((i) => (
                    <div key={i} className="bg-white dark:bg-gray-800 p-4 rounded-xl">
                      <div className="flex justify-between items-start">
                        <div>
                          <Skeleton className="h-5 w-32 mb-2" />
                          <Skeleton className="h-4 w-40" />
                        </div>
                        <Skeleton className="h-8 w-20 rounded-md" />
                      </div>
                    </div>
                  ))}
                </div>
              ) : bills.length === 0 ? (
                <div className="flex flex-col items-center justify-center py-12 text-center">
                  <ReceiptText className="h-12 w-12 text-gray-400 mb-4" />
                  <h3 className="text-lg font-medium text-gray-900 dark:text-white mb-1">No bills yet</h3>
                  <p className="text-gray-500 dark:text-gray-400 max-w-sm mb-6">
                    Start adding your bills to keep track of your expenses and never miss a payment.
                  </p>
                  <Button onClick={() => setIsAddingBill(true)}>
                    <CreditCard className="mr-2 h-4 w-4" />
                    Add Your First Bill
                  </Button>
                </div>
              ) : (
                <>
                  <div className="space-y-6">
                    {/* Due Today Bills */}
                    {dueTodayCount > 0 && (
                      <div>
                        <h3 className="text-sm font-medium text-amber-500 dark:text-amber-400 mb-3 flex items-center">
                          <BellRing className="h-4 w-4 mr-1" /> Due Today
                        </h3>
                        <div className="space-y-3">
                          {upcomingBills
                            .filter(bill => {
                              if (!bill.due_date) return false;
                              try {
                                return isToday(parseISO(bill.due_date));
                              } catch {
                                return false;
                              }
                            })
                            .map((bill) => (
                              <BillItem
                                key={bill.id}
                                bill={bill}
                                onEdit={editBill}
                                onDelete={confirmDelete}
                                onToggleStatus={toggleStatus}
                                badge={
                                  <Badge variant="warning">Due Today</Badge>
                                }
                                className="border-l-4 border-l-amber-500"
                              />
                            ))}
                        </div>
                      </div>
                    )}
                    
                    {/* Upcoming Bills */}
                    <div>
                      <h3 className="text-sm font-medium text-blue-500 dark:text-blue-400 mb-3 flex items-center">
                        <Calendar className="h-4 w-4 mr-1" /> Upcoming
                      </h3>
                      <div className="space-y-3">
                        {upcomingBills
                          .filter(bill => {
                            if (!bill.due_date) return true; // Bills with no due date go here
                            try {
                              const dueDate = parseISO(bill.due_date);
                              return !isToday(dueDate) && isFuture(dueDate);
                            } catch {
                              return true;
                            }
                          })
                          .map((bill) => {
                            // Determine border color based on due date
                            let borderColorClass = "border-l-blue-500";
                            let badge = null;
                            
                            if (bill.due_date) {
                              const daysUntilDue = getDaysUntilDue(bill.due_date);
                              if (daysUntilDue !== null && daysUntilDue <= 3) {
                                borderColorClass = "border-l-amber-500";
                                badge = <Badge variant="warning">Due Soon</Badge>;
                              } else if (daysUntilDue !== null) {
                                badge = <Badge variant="outline">{daysUntilDue} days</Badge>;
                              }
                            }
                            
                            return (
                              <BillItem
                                key={bill.id}
                                bill={bill}
                                onEdit={editBill}
                                onDelete={confirmDelete}
                                onToggleStatus={toggleStatus}
                                badge={badge}
                                className={`border-l-4 ${borderColorClass}`}
                              />
                            );
                          })}
                      </div>
                    </div>
                    
                    {/* Paid Bills */}
                    {paidBills.length > 0 && (
                      <div>
                        <h3 className="text-sm font-medium text-green-500 dark:text-green-400 mb-3 flex items-center">
                          <CheckCircle className="h-4 w-4 mr-1" /> Paid
                        </h3>
                        <div className="space-y-3">
                          {paidBills
                            .slice(0, 5) // Show only recent 5 paid bills
                            .map((bill) => (
                              <BillItem
                                key={bill.id}
                                bill={bill}
                                onEdit={editBill}
                                onDelete={confirmDelete}
                                onToggleStatus={toggleStatus}
                                badge={<Badge variant="success">Paid</Badge>}
                                className="border-l-4 border-l-green-500 opacity-80"
                              />
                            ))}
                        </div>
                        {paidBills.length > 5 && (
                          <Button variant="ghost" className="mt-2 text-sm w-full">
                            Show {paidBills.length - 5} more paid bills
                            <ChevronDown className="ml-2 h-4 w-4" />
                          </Button>
                        )}
                      </div>
                    )}
                  </div>
                </>
              )}
            </CardContent>
          </Card>
        </div>
        
        <div className="w-full md:w-1/3">
          <BillAnalytics bills={bills} />
        </div>
      </div>

      {/* Add/Edit Bill Dialog */}
      {(isAddingBill || editingBill) && (
        <BillForm 
          isOpen={isAddingBill || !!editingBill}
          onClose={() => {
            setIsAddingBill(false);
            setEditingBill(null);
          }}
          bill={editingBill || undefined}
        />
      )}
      
      {/* Delete Confirmation Dialog */}
      {confirmingDelete && (
        <Dialog open={!!confirmingDelete} onOpenChange={() => setConfirmingDelete(null)}>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Delete Bill</DialogTitle>
              <DialogDescription>
                Are you sure you want to delete the bill from {confirmingDelete.provider}? 
                This action cannot be undone.
              </DialogDescription>
            </DialogHeader>
            <DialogFooter>
              <Button variant="outline" onClick={() => setConfirmingDelete(null)}>
                Cancel
              </Button>
              <Button 
                variant="destructive" 
                onClick={() => {
                  if (confirmingDelete) {
                    deleteBill(confirmingDelete.id);
                    setConfirmingDelete(null);
                  }
                }}
              >
                Delete
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      )}
    </>
  );
}

export default BillList;