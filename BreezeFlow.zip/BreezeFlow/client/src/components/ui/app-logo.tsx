import React from 'react';
import { Link } from 'wouter';

interface AppLogoProps {
  className?: string;
  size?: 'sm' | 'md' | 'lg';
  withText?: boolean;
  textClassName?: string;
  linkTo?: string;
}

export function AppLogo({
  className = '',
  size = 'md',
  withText = true,
  textClassName = '',
  linkTo = '/'
}: AppLogoProps) {
  const sizeClasses = {
    sm: 'h-6 w-6',
    md: 'h-8 w-8',
    lg: 'h-10 w-10'
  };

  const textSizeClasses = {
    sm: 'text-lg',
    md: 'text-xl',
    lg: 'text-2xl'
  };

  const logo = (
    <>
      <svg 
        className={`${sizeClasses[size]} text-primary ${className}`} 
        xmlns="http://www.w3.org/2000/svg" 
        fill="none" 
        viewBox="0 0 24 24" 
        stroke="currentColor"
      >
        <path 
          strokeLinecap="round" 
          strokeLinejoin="round" 
          strokeWidth="2" 
          d="M5 3v4M3 5h4M6 17v4m-2-2h4m5-16l2.286 6.857L21 12l-5.714 2.143L13 21l-2.286-6.857L5 12l5.714-2.143L13 3z" 
        />
      </svg>
      {withText && (
        <span className={`ml-2 ${textSizeClasses[size]} font-bold text-gray-900 dark:text-white ${textClassName}`}>
          BreezeFlow
        </span>
      )}
    </>
  );

  if (linkTo) {
    return (
      <Link href={linkTo} className="flex items-center">
        {logo}
      </Link>
    );
  }

  return <div className="flex items-center">{logo}</div>;
}
