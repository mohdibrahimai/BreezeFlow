import React from 'react';
import { cn } from '@/lib/utils';

/**
 * Shimmer effect for loading states
 */
interface ShimmerEffectProps {
  className?: string;
  width?: string | number;
  height?: string | number;
  rounded?: 'none' | 'sm' | 'md' | 'lg' | 'full';
}

export const ShimmerEffect: React.FC<ShimmerEffectProps> = ({
  className,
  width = '100%',
  height = '1rem',
  rounded = 'md',
}) => {
  const roundedMap = {
    none: 'rounded-none',
    sm: 'rounded-sm',
    md: 'rounded-md',
    lg: 'rounded-lg',
    full: 'rounded-full',
  };
  
  const style = {
    width: typeof width === 'number' ? `${width}px` : width,
    height: typeof height === 'number' ? `${height}px` : height,
  };
  
  return (
    <div
      className={cn(
        'bg-gradient-to-r from-gray-200 via-gray-100 to-gray-200 dark:from-gray-800 dark:via-gray-700 dark:to-gray-800 animate-shimmer bg-[length:400%_100%]',
        roundedMap[rounded],
        className
      )}
      style={style}
    />
  );
};

/**
 * Shimmer card for loading states
 */
export const ShimmerCard: React.FC<{ className?: string }> = ({ className }) => {
  return (
    <div className={cn('space-y-3 p-4 border rounded-lg', className)}>
      <ShimmerEffect height="1.25rem" width="70%" />
      <ShimmerEffect height="0.875rem" width="90%" />
      <ShimmerEffect height="0.875rem" width="60%" />
      <div className="pt-2">
        <ShimmerEffect height="2rem" width="40%" rounded="md" />
      </div>
    </div>
  );
};

/**
 * Shimmer avatar for loading user profile
 */
export const ShimmerAvatar: React.FC<{ size?: 'sm' | 'md' | 'lg' }> = ({ size = 'md' }) => {
  const sizeMap = {
    sm: '2rem',
    md: '3rem',
    lg: '5rem',
  };
  
  return <ShimmerEffect height={sizeMap[size]} width={sizeMap[size]} rounded="full" />;
};

/**
 * Shimmer text for loading text content
 */
export const ShimmerText: React.FC<{ lines?: number; width?: string }> = ({ 
  lines = 3,
  width = '100%'
}) => {
  return (
    <div className="space-y-2">
      {Array.from({ length: lines }, (_, index) => (
        <ShimmerEffect 
          key={index} 
          width={index === lines - 1 ? '70%' : width} 
          height="0.75rem" 
        />
      ))}
    </div>
  );
};

export default ShimmerEffect;