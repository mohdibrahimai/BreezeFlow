import React, { useEffect, useState } from 'react';

interface PageTransitionProps {
  children: React.ReactNode;
  className?: string;
}

/**
 * A component that adds a smooth entrance animation to page content
 */
export const PageTransition: React.FC<PageTransitionProps> = ({ 
  children, 
  className = ''
}) => {
  const [isVisible, setIsVisible] = useState(false);
  
  useEffect(() => {
    // Small delay to ensure the animation is noticeable
    const timer = setTimeout(() => {
      setIsVisible(true);
    }, 50);
    
    return () => clearTimeout(timer);
  }, []);
  
  return (
    <div
      className={`transition-all duration-500 ${
        isVisible 
          ? 'opacity-100 translate-y-0' 
          : 'opacity-0 translate-y-8'
      } ${className}`}
    >
      {children}
    </div>
  );
};

/**
 * A component that adds staggered entrance animations to its children
 */
export const StaggeredTransition: React.FC<{
  children: React.ReactNode;
  baseDelay?: number;
  staggerDelay?: number;
  className?: string;
}> = ({
  children,
  baseDelay = 100,
  staggerDelay = 50,
  className = '',
}) => {
  return (
    <div className={className}>
      {React.Children.map(children, (child, index) => (
        <div
          key={index}
          className="animate-fadeIn"
          style={{
            animationDelay: `${baseDelay + (staggerDelay * index)}ms`,
            animationFillMode: 'both',
          }}
        >
          {child}
        </div>
      ))}
    </div>
  );
};

export default PageTransition;