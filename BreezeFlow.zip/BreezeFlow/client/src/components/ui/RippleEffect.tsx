import React from 'react';
import { RippleType, useRippleEffect } from '@/lib/animation-utils';

interface RippleEffectProps {
  children: React.ReactNode;
  className?: string;
}

export const RippleEffect: React.FC<RippleEffectProps> = ({
  children,
  className = '',
}) => {
  const { onClick, className: rippleClassName, ripples } = useRippleEffect();
  
  return (
    <div 
      className={`${rippleClassName} ${className}`}
      onClick={onClick}
    >
      {children}
      {ripples.map((ripple: RippleType) => (
        <span
          key={ripple.id}
          className="absolute rounded-full bg-white/20 animate-ripple"
          style={{
            left: ripple.x + 'px',
            top: ripple.y + 'px',
            transform: 'translate(-50%, -50%)',
            pointerEvents: 'none',
            width: '20px',
            height: '20px'
          }}
        />
      ))}
    </div>
  );
};

export default RippleEffect;