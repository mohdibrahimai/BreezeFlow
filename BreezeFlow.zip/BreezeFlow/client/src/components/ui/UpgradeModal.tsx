import React from 'react';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { useLocation } from 'wouter';
import { Progress } from '@/components/ui/progress';
import { User } from '@shared/schema';

interface UpgradeModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  user: User;
  actionCount: number;
  quotaRemaining: number;
  hoursSaved: number;
  moneySaved: number;
}

const PLAN_LIMITS = {
  free: 50,
  starter: 500,
  pro: Infinity,
  team: Infinity
};

const NEXT_PLAN = {
  free: 'starter',
  starter: 'pro',
  pro: 'team',
  team: 'team'
};

const PLAN_DISPLAY_NAMES = {
  free: 'Free',
  starter: 'Starter',
  pro: 'Pro',
  team: 'Team'
};

export function UpgradeModal({
  open,
  onOpenChange,
  user,
  actionCount,
  quotaRemaining,
  hoursSaved,
  moneySaved
}: UpgradeModalProps) {
  const [, navigate] = useLocation();
  
  // Make sure we have a valid plan type
  const currentPlan = (user.plan as 'free' | 'starter' | 'pro' | 'team') || 'free';
  const planLimit = PLAN_LIMITS[currentPlan] || PLAN_LIMITS.free;
  const nextPlan = NEXT_PLAN[currentPlan] || 'starter';
  const usagePercentage = planLimit === Infinity ? 0 : Math.min(100, Math.round((actionCount / planLimit) * 100));
  
  const handleUpgrade = () => {
    onOpenChange(false);
    navigate(`/checkout?plan=${nextPlan}`);
  };
  
  // Format money saved as a currency value
  const formatMoney = (value: number) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: user.currency || 'USD',
      minimumFractionDigits: 0,
      maximumFractionDigits: 0
    }).format(value / 100); // Convert cents to dollars
  };
  
  // No need to show upgrade modal for Team plan users
  if (currentPlan === 'team') {
    return null;
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[425px]">
        <DialogHeader>
          <DialogTitle>Upgrade Your BreezeFlow Plan</DialogTitle>
          <DialogDescription>
            You're getting great value from BreezeFlow. Upgrade to unlock even more productivity features!
          </DialogDescription>
        </DialogHeader>
        
        <div className="mt-4 space-y-4">
          {/* Usage Progress */}
          <div className="space-y-2">
            <div className="flex justify-between text-sm">
              <span>Monthly Usage</span>
              <span>{actionCount} / {planLimit === Infinity ? 'Unlimited' : planLimit} actions</span>
            </div>
            <Progress value={usagePercentage} />
            <div className="text-sm text-muted-foreground">
              {quotaRemaining > 0 ? (
                <span>You have {quotaRemaining} actions remaining this month</span>
              ) : (
                <span className="text-destructive font-medium">You've reached your monthly limit</span>
              )}
            </div>
          </div>
          
          {/* ROI Stats */}
          <div className="bg-muted p-4 rounded-lg">
            <h4 className="text-sm font-medium mb-2">Your BreezeFlow ROI</h4>
            <div className="grid grid-cols-2 gap-2">
              <div>
                <p className="text-2xl font-bold">{hoursSaved.toFixed(1)}</p>
                <p className="text-xs text-muted-foreground">Hours Saved</p>
              </div>
              <div>
                <p className="text-2xl font-bold">{formatMoney(moneySaved)}</p>
                <p className="text-xs text-muted-foreground">Money Saved</p>
              </div>
            </div>
          </div>
          
          {/* Next Plan Benefits */}
          <div className="space-y-2">
            <h4 className="text-sm font-medium">Upgrade to {PLAN_DISPLAY_NAMES[nextPlan as keyof typeof PLAN_DISPLAY_NAMES]} and get:</h4>
            <ul className="text-sm space-y-1">
              {nextPlan === 'starter' && (
                <>
                  <li>• 500 monthly actions (10x more than Free)</li>
                  <li>• Priority customer support</li>
                  <li>• Advanced task automation</li>
                </>
              )}
              {nextPlan === 'pro' && (
                <>
                  <li>• Unlimited monthly actions</li>
                  <li>• Advanced ROI analytics</li>
                  <li>• Custom integrations</li>
                  <li>• Premium support</li>
                </>
              )}
              {nextPlan === 'team' && (
                <>
                  <li>• Unlimited monthly actions</li>
                  <li>• Team collaboration features</li>
                  <li>• Advanced permissions</li>
                  <li>• Dedicated account manager</li>
                </>
              )}
            </ul>
          </div>
        </div>
        
        <DialogFooter className="mt-4">
          <Button variant="outline" onClick={() => onOpenChange(false)}>
            Maybe Later
          </Button>
          <Button onClick={handleUpgrade}>
            Upgrade to {PLAN_DISPLAY_NAMES[nextPlan as keyof typeof PLAN_DISPLAY_NAMES]}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}