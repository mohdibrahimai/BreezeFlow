import React from 'react';
import { cn } from '@/lib/utils';
import { getStaggeredAnimation } from '@/lib/animation-utils';

interface AnimatedListProps {
  items: React.ReactNode[];
  className?: string;
  itemClassName?: string;
  baseDelay?: number;
  as?: 'ul' | 'ol' | 'div';
}

export const AnimatedList: React.FC<AnimatedListProps> = ({
  items,
  className,
  itemClassName,
  baseDelay = 50,
  as = 'ul',
}) => {
  const ListTag = as;
  
  return (
    <ListTag className={cn('space-y-2', className)}>
      {items.map((item, index) => {
        const animProps = getStaggeredAnimation(index, baseDelay);
        
        if (as === 'ul' || as === 'ol') {
          return (
            <li
              key={index}
              className={cn(animProps.className, itemClassName)}
              style={animProps.style}
            >
              {item}
            </li>
          );
        }
        
        return (
          <div
            key={index}
            className={cn(animProps.className, itemClassName)}
            style={animProps.style}
          >
            {item}
          </div>
        );
      })}
    </ListTag>
  );
};

export default AnimatedList;