import React from 'react';
import { Progress } from '@/components/ui/progress';
import { 
  Trophy, 
  Flame, 
  Zap, 
  Star,
  Award,
  Medal
} from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';

interface FlowScoreProps {
  flowScore: number;
  streakDays: number;
  badges?: { name: string; icon: string }[];
  className?: string;
}

export function FlowScore({
  flowScore,
  streakDays,
  badges = [],
  className = '',
}: FlowScoreProps) {
  // Calculate progress percentage
  const level = Math.floor(flowScore / 100);
  const progressToNextLevel = flowScore % 100;
  const progressPercentage = Math.min(progressToNextLevel, 100);
  
  const badgesThisWeek = badges.length > 0 ? badges.length : Math.min(3, Math.max(1, Math.floor(streakDays / 3)));
  
  const renderBadgeIcon = (iconName: string) => {
    switch (iconName) {
      case 'flame':
        return <Flame className="h-3 w-3" />;
      case 'star':
        return <Star className="h-3 w-3" />;
      case 'zap':
        return <Zap className="h-3 w-3" />;
      case 'award':
        return <Award className="h-3 w-3" />;
      case 'medal':
        return <Medal className="h-3 w-3" />;
      default:
        return <Trophy className="h-3 w-3" />;
    }
  };

  return (
    <Card className={`overflow-hidden ${className}`}>
      <CardHeader className="pb-2">
        <CardTitle className="text-lg font-medium text-gray-900 dark:text-white">
          Flow Score
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="text-3xl font-bold text-accent-600 dark:text-accent-500">{flowScore}</div>
        <div className="mt-3">
          <div className="flex mb-2 items-center justify-between">
            <div>
              <span className="text-xs font-semibold inline-block py-1 px-2 uppercase rounded-full text-accent-600 bg-accent-200 dark:bg-accent-900 dark:text-accent-300">
                Level {level} Progress
              </span>
            </div>
            <div className="text-right">
              <span className="text-xs font-semibold inline-block text-accent-600 dark:text-accent-400">
                {progressPercentage}%
              </span>
            </div>
          </div>
          <Progress value={progressPercentage} className="h-2 bg-accent-200 dark:bg-accent-900" indicatorClassName="bg-accent-500" />
        </div>
        <div className="flex items-center mt-3">
          <div className="text-sm text-gray-600 dark:text-gray-400">Current Streak:</div>
          <div className="ml-2 text-sm font-medium text-accent-600 dark:text-accent-400">{streakDays} days</div>
        </div>
        <div className="flex items-center mt-1">
          <div className="flex -space-x-1">
            {[...Array(badgesThisWeek)].map((_, i) => (
              <span key={i} className="inline-flex items-center justify-center h-6 w-6 rounded-full bg-accent-100 text-accent-800 dark:bg-accent-900 dark:text-accent-300">
                {badges[i] ? renderBadgeIcon(badges[i].icon) : renderBadgeIcon(['flame', 'star', 'zap'][i % 3])}
              </span>
            ))}
          </div>
          <div className="ml-3 text-xs text-gray-500 dark:text-gray-400">{badgesThisWeek} badge{badgesThisWeek !== 1 ? 's' : ''} this week</div>
        </div>
      </CardContent>
    </Card>
  );
}
