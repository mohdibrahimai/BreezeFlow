import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { ChevronLeft, ChevronRight } from 'lucide-react';
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { apiRequest } from '@/lib/queryClient';
import { format, addMonths, subMonths, startOfMonth, endOfMonth, eachDayOfInterval, isSameMonth, isToday, isSameDay } from 'date-fns';
import { Badge } from '@/components/ui/badge';
import { cn } from '@/lib/utils';
import { Skeleton } from "@/components/ui/skeleton";

export function CalendarView() {
  const [currentMonth, setCurrentMonth] = useState(new Date());
  const queryClient = useQueryClient();
  
  const { data: events, isLoading: eventsLoading } = useQuery({
    queryKey: ['/api/events'],
  });
  
  const { data: tasks, isLoading: tasksLoading } = useQuery({
    queryKey: ['/api/tasks'],
  });
  
  const isLoading = eventsLoading || tasksLoading;
  
  const nextMonth = () => {
    setCurrentMonth(addMonths(currentMonth, 1));
  };
  
  const prevMonth = () => {
    setCurrentMonth(subMonths(currentMonth, 1));
  };
  
  const daysInMonth = eachDayOfInterval({
    start: startOfMonth(currentMonth),
    end: endOfMonth(currentMonth),
  });
  
  // Get day of week of first day (0 = Sunday, 6 = Saturday)
  const startDay = startOfMonth(currentMonth).getDay();
  
  // Get days from previous month to fill in calendar start
  const prevMonthDays = startDay;
  
  // Calculate total cells needed (max 6 rows of 7 days)
  const totalCells = Math.ceil((prevMonthDays + daysInMonth.length) / 7) * 7;
  
  // Get number of days needed from next month
  const nextMonthDays = totalCells - (prevMonthDays + daysInMonth.length);
  
  // Create array of day numbers for display
  const calendarDays = [];
  
  // Add previous month days
  for (let i = prevMonthDays - 1; i >= 0; i--) {
    const prevDate = subMonths(currentMonth, 1);
    prevDate.setDate(endOfMonth(prevDate).getDate() - i);
    calendarDays.push({
      date: prevDate,
      isCurrentMonth: false,
    });
  }
  
  // Add current month days
  daysInMonth.forEach(date => {
    calendarDays.push({
      date,
      isCurrentMonth: true,
    });
  });
  
  // Add next month days
  for (let i = 1; i <= nextMonthDays; i++) {
    const nextDate = addMonths(currentMonth, 1);
    nextDate.setDate(i);
    calendarDays.push({
      date: nextDate,
      isCurrentMonth: false,
    });
  }
  
  // Get events for a specific day
  const getEventsForDay = (date) => {
    if (!events) return [];
    
    return events.filter(event => {
      const eventDate = new Date(event.start);
      return isSameDay(eventDate, date);
    });
  };
  
  // Get tasks for a specific day
  const getTasksForDay = (date) => {
    if (!tasks) return [];
    
    return tasks.filter(task => {
      if (!task.due_date) return false;
      const taskDate = new Date(task.due_date);
      return isSameDay(taskDate, date);
    });
  };

  return (
    <Card className="mt-6">
      <CardHeader className="pb-2 flex justify-between items-center">
        <CardTitle className="text-lg font-medium">Calendar</CardTitle>
        <div className="flex space-x-3 items-center">
          <Button size="sm" variant="outline" onClick={prevMonth}>
            <ChevronLeft className="h-4 w-4" />
          </Button>
          <span className="text-sm font-medium">{format(currentMonth, 'MMMM yyyy')}</span>
          <Button size="sm" variant="outline" onClick={nextMonth}>
            <ChevronRight className="h-4 w-4" />
          </Button>
        </div>
      </CardHeader>
      <CardContent>
        {isLoading ? (
          <div className="space-y-4">
            <div className="grid grid-cols-7 gap-px text-center text-xs font-medium text-gray-700 dark:text-gray-300">
              {['S', 'M', 'T', 'W', 'T', 'F', 'S'].map((day, i) => (
                <div key={i} className="py-2">{day}</div>
              ))}
            </div>
            <div className="grid grid-cols-7 gap-px">
              {Array.from({ length: 35 }).map((_, i) => (
                <Skeleton key={i} className="h-24 w-full" />
              ))}
            </div>
          </div>
        ) : (
          <div className="border-t border-gray-200 dark:border-gray-700">
            <div className="grid grid-cols-7 gap-px bg-gray-200 dark:bg-gray-700 text-center text-xs font-medium text-gray-700 dark:text-gray-300">
              <div className="bg-white dark:bg-gray-800 py-2">S</div>
              <div className="bg-white dark:bg-gray-800 py-2">M</div>
              <div className="bg-white dark:bg-gray-800 py-2">T</div>
              <div className="bg-white dark:bg-gray-800 py-2">W</div>
              <div className="bg-white dark:bg-gray-800 py-2">T</div>
              <div className="bg-white dark:bg-gray-800 py-2">F</div>
              <div className="bg-white dark:bg-gray-800 py-2">S</div>
            </div>
            <div className="grid grid-cols-7 gap-px bg-gray-200 dark:bg-gray-700">
              {calendarDays.map((day, index) => {
                const isToday_ = isToday(day.date);
                const dayEvents = getEventsForDay(day.date);
                const dayTasks = getTasksForDay(day.date);
                
                return (
                  <div 
                    key={index} 
                    className={cn(
                      "bg-white dark:bg-gray-800 p-2 min-h-24 max-h-24 overflow-y-auto",
                      isToday_ && "bg-primary-50 dark:bg-primary-900/20",
                      !day.isCurrentMonth && "text-gray-400 dark:text-gray-500"
                    )}
                  >
                    <span className={cn(
                      "text-sm inline-block",
                      isToday_ && "font-medium"
                    )}>
                      {format(day.date, 'd')}
                    </span>
                    
                    <div className="space-y-1 mt-1">
                      {dayEvents.map((event, i) => (
                        <div key={`event-${i}`} className="bg-primary-100 dark:bg-primary-900/40 p-1 text-xs rounded text-primary-800 dark:text-primary-300 truncate">
                          {event.title}
                        </div>
                      ))}
                      
                      {dayTasks.map((task, i) => (
                        <div 
                          key={`task-${i}`} 
                          className={cn(
                            "p-1 text-xs rounded truncate",
                            task.priority === 'high' ? "bg-red-100 dark:bg-red-900/40 text-red-800 dark:text-red-300" :
                            task.priority === 'medium' ? "bg-primary-100 dark:bg-primary-900/40 text-primary-800 dark:text-primary-300" :
                            "bg-green-100 dark:bg-green-900/40 text-green-800 dark:text-green-300"
                          )}
                        >
                          {task.title}
                        </div>
                      ))}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
}
