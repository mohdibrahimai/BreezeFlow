import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Form, FormControl, FormDescription, FormField, FormItem, FormLabel } from '@/components/ui/form';
import { useMutation, useQueryClient } from '@tanstack/react-query';
import { apiRequest } from '@/lib/queryClient';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { useAuth } from '@/hooks/use-auth';
import { useToast } from '@/hooks/use-toast';
import { Plus, Calendar, CheckSquare, ShoppingCart, CreditCard } from 'lucide-react';
import { Switch } from '@/components/ui/switch';

// Task schema
const taskSchema = z.object({
  title: z.string().min(1, "Title is required"),
  description: z.string().optional(),
  status: z.string().default("backlog"),
  priority: z.string().default("medium"),
  due_date: z.string().optional(),
  points: z.number().default(10),
});

// Event schema
const eventSchema = z.object({
  title: z.string().min(1, "Title is required"),
  start: z.string().min(1, "Start time is required"),
  end: z.string().min(1, "End time is required"),
  location: z.string().optional(),
});

// Errand schema
const errandSchema = z.object({
  vendor: z.string().min(1, "Vendor is required"),
  amount: z.number().optional(),
  due_date: z.string().optional(),
  status: z.string().default("upcoming"),
  autopay: z.boolean().default(false),
});

// Bill schema
const billSchema = z.object({
  provider: z.string().min(1, "Provider is required"),
  amount: z.number().optional(),
  due_date: z.string().optional(),
  status: z.string().default("upcoming"),
  autopay: z.boolean().default(false),
  recurring: z.boolean().default(false),
  recurring_interval: z.string().optional(),
});

type QuickAddType = 'task' | 'event' | 'errand' | 'bill';

export function QuickAdd() {
  const [dialogOpen, setDialogOpen] = useState(false);
  const [activeType, setActiveType] = useState<QuickAddType>('task');
  const { user } = useAuth();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  
  const taskForm = useForm({
    resolver: zodResolver(taskSchema),
    defaultValues: {
      title: '',
      description: '',
      status: 'backlog',
      priority: 'medium',
      due_date: '',
      points: 10,
    },
  });
  
  const eventForm = useForm({
    resolver: zodResolver(eventSchema),
    defaultValues: {
      title: '',
      start: '',
      end: '',
      location: '',
    },
  });
  
  const errandForm = useForm({
    resolver: zodResolver(errandSchema),
    defaultValues: {
      vendor: '',
      amount: undefined,
      due_date: '',
      status: 'upcoming',
      autopay: false,
    },
  });
  
  const billForm = useForm({
    resolver: zodResolver(billSchema),
    defaultValues: {
      provider: '',
      amount: undefined,
      due_date: '',
      status: 'upcoming',
      autopay: false,
      recurring: false,
      recurring_interval: 'monthly',
    },
  });
  
  const taskMutation = useMutation({
    mutationFn: async (data: any) => {
      const res = await apiRequest('POST', '/api/tasks', {
        ...data,
        user_id: user?.id,
      });
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/tasks'] });
      toast({
        title: 'Task created',
        description: 'Your task was created successfully.',
      });
      setDialogOpen(false);
      taskForm.reset();
    },
    onError: (error) => {
      toast({
        title: 'Error creating task',
        description: error.message,
        variant: 'destructive',
      });
    },
  });
  
  const eventMutation = useMutation({
    mutationFn: async (data: any) => {
      const res = await apiRequest('POST', '/api/events', {
        ...data,
        user_id: user?.id,
      });
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/events'] });
      toast({
        title: 'Event created',
        description: 'Your event was created successfully.',
      });
      setDialogOpen(false);
      eventForm.reset();
    },
    onError: (error) => {
      toast({
        title: 'Error creating event',
        description: error.message,
        variant: 'destructive',
      });
    },
  });
  
  const errandMutation = useMutation({
    mutationFn: async (data: any) => {
      const res = await apiRequest('POST', '/api/errands', {
        ...data,
        user_id: user?.id,
      });
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/errands'] });
      toast({
        title: 'Errand created',
        description: 'Your errand was created successfully.',
      });
      setDialogOpen(false);
      errandForm.reset();
    },
    onError: (error) => {
      toast({
        title: 'Error creating errand',
        description: error.message,
        variant: 'destructive',
      });
    },
  });
  
  const billMutation = useMutation({
    mutationFn: async (data: any) => {
      const res = await apiRequest('POST', '/api/bills', {
        ...data,
        user_id: user?.id,
      });
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/bills'] });
      toast({
        title: 'Bill created',
        description: 'Your bill was created successfully.',
      });
      setDialogOpen(false);
      billForm.reset();
    },
    onError: (error) => {
      toast({
        title: 'Error creating bill',
        description: error.message,
        variant: 'destructive',
      });
    },
  });
  
  const openQuickAdd = (type: QuickAddType) => {
    setActiveType(type);
    setDialogOpen(true);
  };
  
  const handleSubmit = () => {
    switch (activeType) {
      case 'task':
        taskForm.handleSubmit((data) => taskMutation.mutate(data))();
        break;
      case 'event':
        eventForm.handleSubmit((data) => eventMutation.mutate(data))();
        break;
      case 'errand':
        errandForm.handleSubmit((data) => errandMutation.mutate(data))();
        break;
      case 'bill':
        billForm.handleSubmit((data) => billMutation.mutate(data))();
        break;
    }
  };

  return (
    <>
      <Card>
        <CardHeader className="pb-2">
          <CardTitle className="text-lg font-medium">Quick Add</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex flex-wrap gap-4">
            <Button 
              className="flex items-center"
              onClick={() => openQuickAdd('task')}
            >
              <CheckSquare className="mr-2 h-4 w-4" /> Task
            </Button>
            <Button 
              className="flex items-center"
              variant="secondary"
              onClick={() => openQuickAdd('event')}
            >
              <Calendar className="mr-2 h-4 w-4" /> Event
            </Button>
            <Button 
              className="flex items-center"
              variant="accent"
              onClick={() => openQuickAdd('errand')}
            >
              <ShoppingCart className="mr-2 h-4 w-4" /> Errand
            </Button>
            <Button 
              className="flex items-center"
              variant="outline"
              onClick={() => openQuickAdd('bill')}
            >
              <CreditCard className="mr-2 h-4 w-4" /> Bill
            </Button>
          </div>
        </CardContent>
      </Card>

      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="sm:max-w-[425px]">
          <DialogHeader>
            <DialogTitle className="capitalize">
              {activeType === 'task' && 'Add New Task'}
              {activeType === 'event' && 'Add New Event'}
              {activeType === 'errand' && 'Add New Errand'}
              {activeType === 'bill' && 'Add New Bill'}
            </DialogTitle>
            <DialogDescription>
              Fill out the form below to create a new {activeType}.
            </DialogDescription>
          </DialogHeader>
          
          {activeType === 'task' && (
            <Form {...taskForm}>
              <div className="space-y-4">
                <FormField
                  control={taskForm.control}
                  name="title"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Title</FormLabel>
                      <FormControl>
                        <Input placeholder="Task title" {...field} />
                      </FormControl>
                    </FormItem>
                  )}
                />
                
                <FormField
                  control={taskForm.control}
                  name="description"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Description</FormLabel>
                      <FormControl>
                        <Textarea placeholder="Task description" {...field} />
                      </FormControl>
                    </FormItem>
                  )}
                />
                
                <FormField
                  control={taskForm.control}
                  name="priority"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Priority</FormLabel>
                      <Select 
                        onValueChange={field.onChange} 
                        defaultValue={field.value}
                      >
                        <FormControl>
                          <SelectTrigger>
                            <SelectValue placeholder="Select priority" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          <SelectItem value="low">Low</SelectItem>
                          <SelectItem value="medium">Medium</SelectItem>
                          <SelectItem value="high">High</SelectItem>
                        </SelectContent>
                      </Select>
                    </FormItem>
                  )}
                />
                
                <FormField
                  control={taskForm.control}
                  name="due_date"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Due Date</FormLabel>
                      <FormControl>
                        <Input type="date" {...field} />
                      </FormControl>
                    </FormItem>
                  )}
                />
              </div>
            </Form>
          )}
          
          {activeType === 'event' && (
            <Form {...eventForm}>
              <div className="space-y-4">
                <FormField
                  control={eventForm.control}
                  name="title"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Title</FormLabel>
                      <FormControl>
                        <Input placeholder="Event title" {...field} />
                      </FormControl>
                    </FormItem>
                  )}
                />
                
                <FormField
                  control={eventForm.control}
                  name="start"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Start Date & Time</FormLabel>
                      <FormControl>
                        <Input type="datetime-local" {...field} />
                      </FormControl>
                    </FormItem>
                  )}
                />
                
                <FormField
                  control={eventForm.control}
                  name="end"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>End Date & Time</FormLabel>
                      <FormControl>
                        <Input type="datetime-local" {...field} />
                      </FormControl>
                    </FormItem>
                  )}
                />
                
                <FormField
                  control={eventForm.control}
                  name="location"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Location</FormLabel>
                      <FormControl>
                        <Input placeholder="Event location" {...field} />
                      </FormControl>
                    </FormItem>
                  )}
                />
              </div>
            </Form>
          )}
          
          {activeType === 'errand' && (
            <Form {...errandForm}>
              <div className="space-y-4">
                <FormField
                  control={errandForm.control}
                  name="vendor"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Vendor</FormLabel>
                      <FormControl>
                        <Input placeholder="Errand vendor" {...field} />
                      </FormControl>
                    </FormItem>
                  )}
                />
                
                <FormField
                  control={errandForm.control}
                  name="amount"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Amount</FormLabel>
                      <FormControl>
                        <Input 
                          type="number" 
                          placeholder="0.00" 
                          onChange={(e) => field.onChange(e.target.value ? parseFloat(e.target.value) : undefined)}
                          value={field.value || ''}
                        />
                      </FormControl>
                    </FormItem>
                  )}
                />
                
                <FormField
                  control={errandForm.control}
                  name="due_date"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Due Date</FormLabel>
                      <FormControl>
                        <Input type="date" {...field} />
                      </FormControl>
                    </FormItem>
                  )}
                />
              </div>
            </Form>
          )}
          
          {activeType === 'bill' && (
            <Form {...billForm}>
              <div className="space-y-4">
                <FormField
                  control={billForm.control}
                  name="provider"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Provider</FormLabel>
                      <FormControl>
                        <Input placeholder="Bill provider" {...field} />
                      </FormControl>
                    </FormItem>
                  )}
                />
                
                <FormField
                  control={billForm.control}
                  name="amount"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Amount</FormLabel>
                      <FormControl>
                        <Input 
                          type="number" 
                          placeholder="0.00" 
                          onChange={(e) => field.onChange(e.target.value ? parseFloat(e.target.value) : undefined)}
                          value={field.value || ''}
                        />
                      </FormControl>
                    </FormItem>
                  )}
                />
                
                <FormField
                  control={billForm.control}
                  name="due_date"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Due Date</FormLabel>
                      <FormControl>
                        <Input type="date" {...field} />
                      </FormControl>
                    </FormItem>
                  )}
                />
                
                <FormField
                  control={billForm.control}
                  name="recurring"
                  render={({ field }) => (
                    <FormItem className="flex flex-row items-center justify-between rounded-lg border p-3 shadow-sm">
                      <div className="space-y-0.5">
                        <FormLabel>Recurring Bill</FormLabel>
                        <FormDescription>
                          Does this bill repeat regularly?
                        </FormDescription>
                      </div>
                      <FormControl>
                        <Switch
                          checked={field.value}
                          onCheckedChange={field.onChange}
                        />
                      </FormControl>
                    </FormItem>
                  )}
                />
                
                {billForm.watch("recurring") && (
                  <FormField
                    control={billForm.control}
                    name="recurring_interval"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Frequency</FormLabel>
                        <Select
                          onValueChange={field.onChange}
                          defaultValue={field.value}
                        >
                          <FormControl>
                            <SelectTrigger>
                              <SelectValue placeholder="Select frequency" />
                            </SelectTrigger>
                          </FormControl>
                          <SelectContent>
                            <SelectItem value="daily">Daily</SelectItem>
                            <SelectItem value="weekly">Weekly</SelectItem>
                            <SelectItem value="monthly">Monthly</SelectItem>
                            <SelectItem value="annually">Annually</SelectItem>
                          </SelectContent>
                        </Select>
                      </FormItem>
                    )}
                  />
                )}
                
                <FormField
                  control={billForm.control}
                  name="autopay"
                  render={({ field }) => (
                    <FormItem className="flex flex-row items-center space-x-3 space-y-0">
                      <FormControl>
                        <input
                          type="checkbox"
                          className="h-4 w-4 text-primary-600 focus:ring-primary-500 border-gray-300 rounded"
                          checked={field.value}
                          onChange={(e) => field.onChange(e.target.checked)}
                        />
                      </FormControl>
                      <FormLabel className="text-sm font-medium text-gray-700">Enable Autopay</FormLabel>
                    </FormItem>
                  )}
                />
              </div>
            </Form>
          )}

          <DialogFooter>
            <Button variant="secondary" onClick={() => setDialogOpen(false)}>
              Cancel
            </Button>
            <Button 
              type="submit" 
              onClick={handleSubmit}
              disabled={
                taskMutation.isPending || 
                eventMutation.isPending || 
                errandMutation.isPending || 
                billMutation.isPending
              }
            >
              {taskMutation.isPending || eventMutation.isPending || errandMutation.isPending || billMutation.isPending ? (
                'Saving...'
              ) : (
                <>
                  <Plus className="mr-2 h-4 w-4" /> Create {activeType}
                </>
              )}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </>
  );
}
