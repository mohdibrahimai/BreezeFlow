import React, { useEffect, useState } from 'react';
import { Button } from '@/components/ui/button';
import { X } from 'lucide-react';

interface UndoSnackbarProps {
  message: string;
  onUndo: () => void;
  onClose: () => void;
  duration?: number; // in milliseconds
}

export function UndoSnackbar({
  message,
  onUndo,
  onClose,
  duration = 10000, // default to 10 seconds
}: UndoSnackbarProps) {
  const [progress, setProgress] = useState(100);
  const [intervalId, setIntervalId] = useState<NodeJS.Timeout | null>(null);
  
  // Set up the progress countdown
  useEffect(() => {
    const interval = setInterval(() => {
      setProgress((prev) => {
        const newProgress = prev - (100 / (duration / 100));
        return newProgress <= 0 ? 0 : newProgress;
      });
    }, 100);
    
    setIntervalId(interval);
    
    // Auto-close after duration
    const timeout = setTimeout(() => {
      onClose();
    }, duration);
    
    return () => {
      if (intervalId) clearInterval(intervalId);
      clearInterval(interval);
      clearTimeout(timeout);
    };
  }, [duration, onClose]);
  
  // Clean up when dismissed
  const handleDismiss = () => {
    if (intervalId) clearInterval(intervalId);
    onClose();
  };
  
  return (
    <div className="fixed bottom-4 right-4 z-50 flex items-center justify-between bg-white dark:bg-gray-800 rounded-md shadow-lg p-4 min-w-[300px] max-w-md animate-in slide-in-from-bottom-5">
      <div className="flex-1 mr-4">
        <p className="text-sm font-medium text-gray-900 dark:text-gray-100">{message}</p>
      </div>
      <div className="flex items-center space-x-2">
        <Button 
          variant="link" 
          size="sm" 
          onClick={() => {
            onUndo();
            handleDismiss();
          }}
          className="text-primary-600 dark:text-primary-500 hover:text-primary-700 dark:hover:text-primary-400 px-2"
        >
          Undo
        </Button>
        <Button 
          variant="ghost" 
          size="sm" 
          className="rounded-full h-6 w-6 p-0" 
          onClick={handleDismiss}
        >
          <X className="h-4 w-4" />
        </Button>
      </div>
      
      {/* Progress bar */}
      <div className="absolute bottom-0 left-0 h-1 bg-primary-600 dark:bg-primary-500" style={{ width: `${progress}%` }} />
    </div>
  );
}