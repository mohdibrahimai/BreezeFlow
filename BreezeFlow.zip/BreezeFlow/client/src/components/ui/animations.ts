// Export all animation components and utilities in one place for easy access

// Animation components
export { default as AnimatedButton, AnimatedButton as Button } from './AnimatedButton';
export { default as AnimatedCard, AnimatedCard as Card, AnimatedCardList } from './AnimatedCard';
export { default as AnimatedList } from './AnimatedList';
export { default as RippleEffect } from './RippleEffect';
export { default as PageTransition, StaggeredTransition } from './PageTransition';
export { default as AnimatedToast } from './AnimatedToast';
export { default as ShimmerEffect, ShimmerCard, ShimmerAvatar, ShimmerText } from './ShimmerEffect';

// Animation utilities
export { 
  useEntranceAnimation,
  useHoverAnimation,
  usePulseAnimation,
  getStaggeredAnimation,
  useRippleEffect
} from '@/lib/animation-utils';

// Re-export types used in animations
export type { RippleType } from '@/lib/animation-utils';