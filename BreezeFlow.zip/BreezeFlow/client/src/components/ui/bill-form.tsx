import React from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { format } from 'date-fns';
import { useMutation, useQueryClient } from '@tanstack/react-query';
import { apiRequest } from '@/lib/queryClient';
import { useToast } from '@/hooks/use-toast';

import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import {
  Form,
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from '@/components/ui/form';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Switch } from '@/components/ui/switch';
import { Loader2, CreditCard, CalendarIcon } from 'lucide-react';
import { Calendar } from '@/components/ui/calendar';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { cn } from '@/lib/utils';

interface Bill {
  id: number;
  user_id: number;
  provider: string;
  amount: number | null;
  due_date: string | null;
  status: 'upcoming' | 'paid';
  autopay: boolean;
  category: string | null;
  recurring: boolean;
  recurring_interval: string | null;
  reminder_days: number | null;
  notes: string | null;
  created_at?: Date;
  paid_at?: Date | null;
  last_reminded_at?: Date | null;
}

interface BillFormProps {
  isOpen: boolean;
  onClose: () => void;
  bill?: Bill;
}

// List of predefined bill categories
const BILL_CATEGORIES = [
  'Housing',
  'Utilities',
  'Subscription',
  'Insurance',
  'Loan',
  'Credit Card',
  'Healthcare',
  'Entertainment',
  'Education',
  'Transportation',
  'Other'
];

// List of recurring intervals
const RECURRING_INTERVALS = [
  { value: 'monthly', label: 'Monthly' },
  { value: 'quarterly', label: 'Quarterly (every 3 months)' },
  { value: 'yearly', label: 'Yearly' },
  { value: 'weekly', label: 'Weekly' },
  { value: 'biweekly', label: 'Bi-weekly (every 2 weeks)' }
];

// List of reminder options
const REMINDER_OPTIONS = [
  { value: 1, label: '1 day before' },
  { value: 3, label: '3 days before' },
  { value: 5, label: '5 days before' },
  { value: 7, label: '1 week before' },
  { value: 14, label: '2 weeks before' },
  { value: 30, label: '1 month before' }
];

// Define the schema for bill validation
const billSchema = z.object({
  provider: z.string().min(2, 'Provider name is required'),
  amount: z.string().transform((val) => {
    const parsed = parseFloat(val);
    return isNaN(parsed) ? null : parsed;
  }),
  due_date: z.date().nullable(),
  status: z.enum(['upcoming', 'paid']).default('upcoming'),
  autopay: z.boolean().default(false),
  category: z.string().nullable(),
  recurring: z.boolean().default(false),
  recurring_interval: z.string().nullable(),
  reminder_days: z.number().nullable(),
  notes: z.string().nullable(),
});

type BillFormValues = z.infer<typeof billSchema>;

export function BillForm({ isOpen, onClose, bill }: BillFormProps) {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  
  // Set up form with default values
  const form = useForm<BillFormValues>({
    resolver: zodResolver(billSchema),
    defaultValues: bill
      ? {
          provider: bill.provider,
          amount: bill.amount !== null ? String(bill.amount) : '',
          due_date: bill.due_date ? new Date(bill.due_date) : null,
          status: bill.status,
          autopay: bill.autopay,
          category: bill.category,
          recurring: bill.recurring,
          recurring_interval: bill.recurring_interval,
          reminder_days: bill.reminder_days,
          notes: bill.notes,
        }
      : {
          provider: '',
          amount: '',
          due_date: null,
          status: 'upcoming',
          autopay: false,
          category: null,
          recurring: false,
          recurring_interval: null,
          reminder_days: null,
          notes: null,
        },
  });
  
  const isRecurring = form.watch('recurring');
  
  // Handle form submission for creating/updating a bill
  const mutation = useMutation({
    mutationFn: async (values: BillFormValues) => {
      // Prepare data for API
      const data = {
        ...values,
        due_date: values.due_date ? values.due_date.toISOString() : null,
      };
      
      let response;
      
      if (bill) {
        // Update existing bill
        response = await apiRequest('PATCH', `/api/bills/${bill.id}`, data);
      } else {
        // Create new bill
        response = await apiRequest('POST', '/api/bills', data);
      }
      
      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.message || 'An error occurred');
      }
      
      return await response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/bills'] });
      toast({
        title: bill ? 'Bill updated' : 'Bill created',
        description: bill
          ? 'Your bill has been successfully updated.'
          : 'Your bill has been successfully created.',
      });
      onClose();
    },
    onError: (error: Error) => {
      toast({
        title: 'Error',
        description: `Failed to ${bill ? 'update' : 'create'} bill: ${error.message}`,
        variant: 'destructive',
      });
    },
  });
  
  const onSubmit = (values: BillFormValues) => {
    mutation.mutate(values);
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-[550px]">
        <DialogHeader>
          <DialogTitle>{bill ? 'Edit Bill' : 'Add New Bill'}</DialogTitle>
          <DialogDescription>
            {bill 
              ? 'Update the details of your existing bill.' 
              : 'Enter the details of your bill to keep track of your expenses.'}
          </DialogDescription>
        </DialogHeader>
        
        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
            {/* Provider Field */}
            <FormField
              control={form.control}
              name="provider"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Provider</FormLabel>
                  <FormControl>
                    <Input placeholder="e.g. Netflix, Rent, Electric Company" {...field} />
                  </FormControl>
                  <FormDescription>
                    The name of the company or service you're paying.
                  </FormDescription>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            {/* Amount Field */}
            <FormField
              control={form.control}
              name="amount"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Amount</FormLabel>
                  <FormControl>
                    <div className="relative">
                      <span className="absolute inset-y-0 left-0 flex items-center pl-3 text-gray-500">
                        $
                      </span>
                      <Input 
                        type="number" 
                        step="0.01" 
                        placeholder="0.00" 
                        className="pl-7" 
                        {...field} 
                      />
                    </div>
                  </FormControl>
                  <FormDescription>
                    The amount due for this bill.
                  </FormDescription>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            {/* Due Date Field */}
            <FormField
              control={form.control}
              name="due_date"
              render={({ field }) => (
                <FormItem className="flex flex-col">
                  <FormLabel>Due Date</FormLabel>
                  <Popover>
                    <PopoverTrigger asChild>
                      <FormControl>
                        <Button
                          variant="outline"
                          className={cn(
                            "w-full pl-3 text-left font-normal",
                            !field.value && "text-gray-500"
                          )}
                        >
                          {field.value ? (
                            format(field.value, "MMMM d, yyyy")
                          ) : (
                            <span>Pick a date</span>
                          )}
                          <CalendarIcon className="ml-auto h-4 w-4 opacity-50" />
                        </Button>
                      </FormControl>
                    </PopoverTrigger>
                    <PopoverContent className="w-auto p-0" align="start">
                      <Calendar
                        mode="single"
                        selected={field.value || undefined}
                        onSelect={field.onChange}
                        initialFocus
                      />
                    </PopoverContent>
                  </Popover>
                  <FormDescription>
                    When this bill is due to be paid.
                  </FormDescription>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            {/* Category Field */}
            <FormField
              control={form.control}
              name="category"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Category</FormLabel>
                  <Select 
                    onValueChange={field.onChange} 
                    defaultValue={field.value || undefined}
                  >
                    <FormControl>
                      <SelectTrigger>
                        <SelectValue placeholder="Select a category" />
                      </SelectTrigger>
                    </FormControl>
                    <SelectContent>
                      {BILL_CATEGORIES.map((category) => (
                        <SelectItem key={category} value={category}>
                          {category}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  <FormDescription>
                    Categorize your bill for better organization.
                  </FormDescription>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            {/* Recurring Toggle */}
            <FormField
              control={form.control}
              name="recurring"
              render={({ field }) => (
                <FormItem className="flex flex-row items-center justify-between rounded-lg border p-4">
                  <div className="space-y-0.5">
                    <FormLabel className="text-base">Recurring Bill</FormLabel>
                    <FormDescription>
                      Is this a recurring bill that you pay regularly?
                    </FormDescription>
                  </div>
                  <FormControl>
                    <Switch
                      checked={field.value}
                      onCheckedChange={field.onChange}
                    />
                  </FormControl>
                </FormItem>
              )}
            />
            
            {/* Recurring Interval (conditional) */}
            {isRecurring && (
              <FormField
                control={form.control}
                name="recurring_interval"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Recurring Interval</FormLabel>
                    <Select 
                      onValueChange={field.onChange} 
                      defaultValue={field.value || 'monthly'}
                    >
                      <FormControl>
                        <SelectTrigger>
                          <SelectValue placeholder="How often does this bill recur?" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        {RECURRING_INTERVALS.map((interval) => (
                          <SelectItem key={interval.value} value={interval.value}>
                            {interval.label}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    <FormDescription>
                      How frequently does this bill need to be paid?
                    </FormDescription>
                    <FormMessage />
                  </FormItem>
                )}
              />
            )}
            
            {/* Reminder Days */}
            <FormField
              control={form.control}
              name="reminder_days"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Payment Reminder</FormLabel>
                  <Select 
                    onValueChange={(value) => field.onChange(parseInt(value, 10))} 
                    defaultValue={field.value?.toString() || undefined}
                  >
                    <FormControl>
                      <SelectTrigger>
                        <SelectValue placeholder="When to remind you?" />
                      </SelectTrigger>
                    </FormControl>
                    <SelectContent>
                      <SelectItem value="">No reminder</SelectItem>
                      {REMINDER_OPTIONS.map((option) => (
                        <SelectItem key={option.value} value={option.value.toString()}>
                          {option.label}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  <FormDescription>
                    When would you like to be reminded about this bill?
                  </FormDescription>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            {/* Autopay Toggle */}
            <FormField
              control={form.control}
              name="autopay"
              render={({ field }) => (
                <FormItem className="flex flex-row items-center justify-between rounded-lg border p-4">
                  <div className="space-y-0.5">
                    <FormLabel className="text-base">Autopay Enabled</FormLabel>
                    <FormDescription>
                      Is this bill set up for automatic payments?
                    </FormDescription>
                  </div>
                  <FormControl>
                    <Switch
                      checked={field.value}
                      onCheckedChange={field.onChange}
                    />
                  </FormControl>
                </FormItem>
              )}
            />
            
            {/* Notes Field */}
            <FormField
              control={form.control}
              name="notes"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Notes</FormLabel>
                  <FormControl>
                    <Textarea 
                      placeholder="Any additional information about this bill..."
                      className="resize-none"
                      {...field}
                      value={field.value || ''}
                    />
                  </FormControl>
                  <FormDescription>
                    Optional notes or additional information about this bill.
                  </FormDescription>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            <DialogFooter className="pt-4">
              <Button 
                type="button" 
                variant="outline" 
                onClick={onClose} 
                disabled={mutation.isPending}
              >
                Cancel
              </Button>
              <Button 
                type="submit"
                disabled={mutation.isPending}
                className="bg-blue-600 hover:bg-blue-700"
              >
                {mutation.isPending ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    Saving...
                  </>
                ) : (
                  <>
                    <CreditCard className="mr-2 h-4 w-4" />
                    {bill ? 'Update Bill' : 'Add Bill'}
                  </>
                )}
              </Button>
            </DialogFooter>
          </form>
        </Form>
      </DialogContent>
    </Dialog>
  );
}

export default BillForm;