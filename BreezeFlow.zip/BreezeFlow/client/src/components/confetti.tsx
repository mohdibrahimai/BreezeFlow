import React, { useEffect, useRef } from 'react';

interface ConfettiProps {
  duration?: number;
}

export const Confetti: React.FC<ConfettiProps> = ({ duration = 3000 }) => {
  const containerRef = useRef<HTMLDivElement>(null);
  
  useEffect(() => {
    if (!containerRef.current) return;
    
    const container = containerRef.current;
    const colors = ['#3B82F6', '#8B5CF6', '#F59E0B', '#10B981', '#EF4444'];
    const confettiCount = 150;
    
    for (let i = 0; i < confettiCount; i++) {
      const confetti = document.createElement('div');
      
      const size = Math.random() * 10 + 5;
      confetti.style.width = `${size}px`;
      confetti.style.height = `${size}px`;
      confetti.style.position = 'absolute';
      confetti.style.backgroundColor = colors[Math.floor(Math.random() * colors.length)];
      confetti.style.top = '-10px';
      confetti.style.left = `${Math.random() * 100}%`;
      confetti.style.opacity = `${Math.random() + 0.5}`;
      confetti.style.borderRadius = Math.random() > 0.5 ? '50%' : '0';
      confetti.style.transform = `rotate(${Math.random() * 360}deg)`;
      
      // Animate fall with slightly random duration and delay
      const animDuration = (Math.random() * 3 + 2);
      confetti.style.animation = `fall ${animDuration}s linear forwards`;
      confetti.style.animationDelay = `${Math.random() * 1.5}s`;
      
      container.appendChild(confetti);
    }
    
    // Clean up confetti after animation completes
    const timeoutId = setTimeout(() => {
      if (container && container.parentNode) {
        while (container.firstChild) {
          container.removeChild(container.firstChild);
        }
      }
    }, duration);
    
    return () => {
      clearTimeout(timeoutId);
      while (container.firstChild) {
        container.removeChild(container.firstChild);
      }
    };
  }, [duration]);
  
  return (
    <div 
      ref={containerRef}
      className="fixed inset-0 pointer-events-none z-50"
      style={{
        '--confetti-animation': `
          @keyframes fall {
            to {
              transform: translateY(100vh) rotate(720deg);
              opacity: 0;
            }
          }
        ` as any
      }}
    >
      <style>
        {`
          @keyframes fall {
            to {
              transform: translateY(100vh) rotate(720deg);
              opacity: 0;
            }
          }
        `}
      </style>
    </div>
  );
};

export default Confetti;
