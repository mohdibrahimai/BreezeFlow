import React from "react";
import { useMutation, useQuery } from "@tanstack/react-query";
import { Task } from "@shared/schema";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { Button } from "@/components/ui/button";
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip";
import { Progress } from "@/components/ui/progress";
import { BadgeInfo, RefreshCw } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

interface PriorityScoreIndicatorProps {
  task: Task;
  size?: 'sm' | 'md' | 'lg';
}

export function PriorityScoreIndicator({ task, size = 'md' }: PriorityScoreIndicatorProps) {
  const { toast } = useToast();
  
  // Determine if we should show the indicator based on task status
  const shouldShowIndicator = task.status !== 'done';
  
  // Use existing score if available or calculate
  const score = task.priority_score || null;
  
  // Size-dependent styles
  const sizeClasses = {
    sm: 'h-1 w-16',
    md: 'h-2 w-24',
    lg: 'h-3 w-32'
  };
  
  // Calculate appropriate text size and spacing
  const textSizeClasses = {
    sm: 'text-xs ml-1',
    md: 'text-sm ml-2',
    lg: 'text-base ml-3'
  };
  
  // Icon size based on component size
  const iconSizeMap = {
    sm: 14,
    md: 18, 
    lg: 22
  };
  
  // Style for score color
  const getScoreColor = (score: number | null) => {
    if (score === null) return 'bg-gray-300';
    if (score >= 80) return 'bg-green-500'; 
    if (score >= 60) return 'bg-lime-500';
    if (score >= 40) return 'bg-yellow-500';
    if (score >= 20) return 'bg-orange-500';
    return 'bg-red-500';
  };
  
  // Mutation to calculate priority score
  const calculateScoreMutation = useMutation({
    mutationFn: async (taskId: number) => {
      const res = await apiRequest("GET", `/api/ml/priorityScore/${taskId}`);
      return await res.json();
    },
    onSuccess: (data) => {
      // Update the task with the new score in the cache
      const cachedTasks = queryClient.getQueryData<Task[]>(['/api/tasks']);
      if (cachedTasks) {
        const updatedTasks = cachedTasks.map(t => 
          t.id === task.id ? { ...t, priority_score: data.score } : t
        );
        queryClient.setQueryData(['/api/tasks'], updatedTasks);
      }
      
      toast({
        title: "Priority Score Updated",
        description: `Task "${task.title}" has a priority score of ${data.score}/100`,
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Failed to calculate priority score",
        description: error.message,
        variant: "destructive",
      });
    },
  });
  
  if (!shouldShowIndicator) {
    return null;
  }
  
  return (
    <div className="flex items-center">
      <TooltipProvider>
        <Tooltip>
          <TooltipTrigger asChild>
            <div className="flex items-center">
              <div className={`${sizeClasses[size]} bg-gray-200 rounded overflow-hidden`}>
                <div 
                  className={`h-full ${getScoreColor(score)}`} 
                  style={{ width: `${score !== null ? score : 0}%` }}
                />
              </div>
              
              {score !== null && (
                <span className={`${textSizeClasses[size]} font-medium`}>
                  {score}
                </span>
              )}
              
              {score === null && (
                <BadgeInfo className={`${textSizeClasses[size]} text-gray-400`} size={iconSizeMap[size]} />
              )}
            </div>
          </TooltipTrigger>
          <TooltipContent>
            <p>
              {score !== null 
                ? `Priority Score: ${score}/100 (${Math.round(score * 0.6)} min saved)`
                : 'No priority score calculated yet. Click to calculate.'}
            </p>
          </TooltipContent>
        </Tooltip>
      </TooltipProvider>
      
      <Button
        variant="ghost"
        size="icon"
        className="ml-1 h-6 w-6"
        onClick={() => calculateScoreMutation.mutate(task.id)}
        disabled={calculateScoreMutation.isPending}
      >
        <RefreshCw 
          size={iconSizeMap[size]} 
          className={`${calculateScoreMutation.isPending ? 'animate-spin' : ''}`}
        />
      </Button>
    </div>
  );
}