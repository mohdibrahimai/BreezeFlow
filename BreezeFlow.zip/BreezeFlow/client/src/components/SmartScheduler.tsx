import React, { useState } from "react";
import { useMutation, useQuery } from "@tanstack/react-query";
import { Task, Event } from "@shared/schema";
import { apiRequest } from "@/lib/queryClient";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";
import { Calendar, Check, ClipboardCheck, Clock, Loader } from "lucide-react";
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import {
  Alert,
  AlertDescription,
  AlertTitle,
} from "@/components/ui/alert";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { ScrollArea } from "@/components/ui/scroll-area";

interface TimeBlock {
  title: string;
  startISO: string;
  endISO: string;
  taskId?: number;
  isFixed?: boolean;
}

import { format } from "date-fns";
import { Checkbox } from "@/components/ui/checkbox";

interface SmartSchedulerProps {
  userId: number;
}

export function SmartScheduler({ userId }: SmartSchedulerProps) {
  const { toast } = useToast();
  const [selectedTaskIds, setSelectedTaskIds] = useState<number[]>([]);
  const [activeTab, setActiveTab] = useState<string>("schedule");
  
  // Get tasks and events
  const { data: tasks } = useQuery<Task[]>({
    queryKey: ['/api/tasks'],
    enabled: !!userId,
  });
  
  const { data: events } = useQuery<Event[]>({
    queryKey: ['/api/events'],
    enabled: !!userId,
  });
  
  // Mutation to optimize schedule
  const optimizeScheduleMutation = useMutation({
    mutationFn: async () => {
      const res = await apiRequest("POST", "/api/copilot/schedule/optimize");
      return await res.json();
    },
    onSuccess: (data) => {
      toast({
        title: "Schedule Optimized",
        description: `Created an optimized schedule with ${data.timeBlocks.length} blocks`,
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Failed to optimize schedule",
        description: error.message,
        variant: "destructive",
      });
    },
  });
  
  const handleOptimize = () => {
    optimizeScheduleMutation.mutate();
  };
  
  const activeTasks = tasks?.filter(task => task.status !== 'done') || [];
  const tasksWithScore = activeTasks.filter(task => task.priority_score !== null);
  const upcomingEvents = events?.filter(event => new Date(event.start) > new Date()) || [];
  
  const toggleTaskSelection = (taskId: number) => {
    setSelectedTaskIds(prev => 
      prev.includes(taskId) 
        ? prev.filter(id => id !== taskId)
        : [...prev, taskId]
    );
  };
  
  // Format time blocks for display
  const formatTimeBlock = (block: TimeBlock) => {
    const startTime = new Date(block.startISO);
    const endTime = new Date(block.endISO);
    
    return {
      ...block,
      formattedTime: `${format(startTime, 'h:mm a')} - ${format(endTime, 'h:mm a')}`,
      formattedDuration: `${Math.round((endTime.getTime() - startTime.getTime()) / (1000 * 60))} min`
    };
  };
  
  const formattedTimeBlocks = optimizeScheduleMutation.data?.timeBlocks
    .map((block: TimeBlock) => formatTimeBlock(block))
    .filter((block: TimeBlock & { formattedTime: string; formattedDuration: string }) => 
      !block.isFixed || (block.title !== "Start of Day" && block.title !== "End of Day"))
    .sort((a: TimeBlock, b: TimeBlock) => 
      new Date(a.startISO).getTime() - new Date(b.startISO).getTime());
  
  const unscheduledTasks = optimizeScheduleMutation.data?.unscheduledTasks || [];
  
  return (
    <Card className="w-full">
      <CardHeader>
        <CardTitle className="flex items-center">
          <Calendar className="mr-2" />
          Smart Schedule Optimizer
        </CardTitle>
        <CardDescription>
          Intelligently organize your day based on ML-generated task priorities and your calendar
        </CardDescription>
      </CardHeader>
      
      <CardContent>
        <div className="flex flex-wrap gap-2 mb-4">
          <Badge variant="outline" className="bg-blue-50">
            Active tasks: {activeTasks.length}
          </Badge>
          <Badge variant="outline" className="bg-green-50">
            Tasks with ML score: {tasksWithScore.length}
          </Badge>
          <Badge variant="outline" className="bg-purple-50">
            Calendar events: {upcomingEvents.length}
          </Badge>
        </div>
        
        {optimizeScheduleMutation.data ? (
          <Tabs defaultValue="schedule" className="w-full" value={activeTab} onValueChange={setActiveTab}>
            <TabsList className="grid w-full grid-cols-3">
              <TabsTrigger value="schedule">Schedule</TabsTrigger>
              <TabsTrigger value="unscheduled">Unscheduled</TabsTrigger>
              <TabsTrigger value="tasks">All Tasks</TabsTrigger>
            </TabsList>
            
            <TabsContent value="schedule">
              <ScrollArea className="h-[400px] rounded-md border p-4">
                {formattedTimeBlocks?.length ? (
                  <div className="space-y-4">
                    {formattedTimeBlocks.map((block: TimeBlock & { formattedTime: string; formattedDuration: string }, idx: number) => (
                      <div 
                        key={idx} 
                        className={`p-3 rounded-lg border ${block.isFixed ? 'bg-gray-50' : 'bg-blue-50 border-blue-200'}`}
                      >
                        <div className="flex justify-between items-start">
                          <div>
                            <h3 className="font-medium">{block.title}</h3>
                            <div className="text-sm text-gray-500 flex items-center">
                              <Clock className="h-3 w-3 mr-1" />
                              {block.formattedTime}
                              <span className="mx-2">•</span>
                              {block.formattedDuration}
                            </div>
                          </div>
                          {!block.isFixed && (
                            <Checkbox 
                              checked={selectedTaskIds.includes(block.taskId || 0)}
                              onCheckedChange={() => block.taskId && toggleTaskSelection(block.taskId)}
                            />
                          )}
                        </div>
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="flex flex-col items-center justify-center h-full text-center">
                    <Calendar className="h-12 w-12 text-gray-300 mb-2" />
                    <p className="text-gray-500">No schedule created yet.</p>
                    <p className="text-gray-400 text-sm">Generate your optimized schedule to see it here.</p>
                  </div>
                )}
              </ScrollArea>
            </TabsContent>
            
            <TabsContent value="unscheduled">
              <ScrollArea className="h-[400px] rounded-md border p-4">
                {unscheduledTasks.length ? (
                  <div className="space-y-3">
                    {unscheduledTasks.map((task: Task) => (
                      <div key={task.id} className="p-3 rounded-lg border bg-orange-50 border-orange-200">
                        <div className="flex justify-between items-center">
                          <div>
                            <h3 className="font-medium">{task.title}</h3>
                            <div className="text-sm text-gray-500">
                              Priority: <span className="font-medium">{task.priority}</span>
                              {task.priority_score !== null && (
                                <span className="ml-2">• Score: {task.priority_score}</span>
                              )}
                            </div>
                          </div>
                          <Checkbox 
                            checked={selectedTaskIds.includes(task.id)}
                            onCheckedChange={() => toggleTaskSelection(task.id)}
                          />
                        </div>
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="flex flex-col items-center justify-center h-full text-center">
                    <ClipboardCheck className="h-12 w-12 text-gray-300 mb-2" />
                    <p className="text-gray-500">No unscheduled tasks.</p>
                    <p className="text-gray-400 text-sm">All tasks were successfully scheduled!</p>
                  </div>
                )}
              </ScrollArea>
            </TabsContent>
            
            <TabsContent value="tasks">
              <ScrollArea className="h-[400px] rounded-md border p-4">
                {activeTasks.length ? (
                  <div className="space-y-3">
                    {activeTasks.map(task => (
                      <div 
                        key={task.id} 
                        className={`p-3 rounded-lg border ${
                          task.priority_score !== null ? 'bg-green-50 border-green-200' : 'bg-gray-50'
                        }`}
                      >
                        <div className="flex justify-between items-center">
                          <div>
                            <h3 className="font-medium">{task.title}</h3>
                            <div className="text-sm text-gray-500">
                              Priority: <span className="font-medium">{task.priority}</span>
                              {task.priority_score !== null && (
                                <span className="ml-2">• Score: {task.priority_score}</span>
                              )}
                            </div>
                          </div>
                          <Checkbox 
                            checked={selectedTaskIds.includes(task.id)}
                            onCheckedChange={() => toggleTaskSelection(task.id)}
                          />
                        </div>
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="flex flex-col items-center justify-center h-full text-center">
                    <ClipboardCheck className="h-12 w-12 text-gray-300 mb-2" />
                    <p className="text-gray-500">No active tasks.</p>
                    <p className="text-gray-400 text-sm">Create some tasks to schedule them!</p>
                  </div>
                )}
              </ScrollArea>
            </TabsContent>
          </Tabs>
        ) : (
          <Alert className="mb-4">
            <AlertTitle>Optimize Your Day</AlertTitle>
            <AlertDescription>
              Our AI can create an optimal schedule based on your tasks' ML-generated priority scores 
              and your calendar events. Click "Optimize Schedule" to get started.
            </AlertDescription>
          </Alert>
        )}
      </CardContent>
      
      <CardFooter className="flex justify-between">
        {optimizeScheduleMutation.data && (
          <Button variant="outline" onClick={() => optimizeScheduleMutation.reset()}>
            Reset
          </Button>
        )}
        
        <Button 
          className={optimizeScheduleMutation.data ? "ml-auto" : "w-full"}
          onClick={handleOptimize}
          disabled={optimizeScheduleMutation.isPending}
        >
          {optimizeScheduleMutation.isPending ? (
            <>
              <Loader className="mr-2 h-4 w-4 animate-spin" />
              Optimizing...
            </>
          ) : (
            <>
              {optimizeScheduleMutation.data ? (
                <>
                  <Check className="mr-2 h-4 w-4" />
                  Re-optimize Schedule
                </>
              ) : (
                <>
                  <Calendar className="mr-2 h-4 w-4" />
                  Optimize Schedule
                </>
              )}
            </>
          )}
        </Button>
      </CardFooter>
    </Card>
  );
}