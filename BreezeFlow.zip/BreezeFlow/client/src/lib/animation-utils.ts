import { useEffect, useState } from 'react';

/**
 * Custom hook for adding entrance animations to elements
 * @param delay Optional delay before animation starts (in ms)
 * @returns Animation classes and props for the animated element
 */
export const useEntranceAnimation = (delay: number = 0) => {
  const [isVisible, setIsVisible] = useState(false);
  
  useEffect(() => {
    const timer = setTimeout(() => {
      setIsVisible(true);
    }, delay);
    
    return () => clearTimeout(timer);
  }, [delay]);
  
  return {
    className: `transition-all duration-300 ease-out ${
      isVisible 
        ? 'opacity-100 translate-y-0' 
        : 'opacity-0 translate-y-4'
    }`,
    style: { transitionDelay: `${delay}ms` },
    'data-state': isVisible ? 'visible' : 'hidden'
  };
};

/**
 * Custom hook for adding hover animation effects
 * @returns Props and handlers for the hover effect
 */
export const useHoverAnimation = () => {
  const [isHovered, setIsHovered] = useState(false);
  
  return {
    className: `transition-transform duration-200 ${
      isHovered ? 'scale-105' : 'scale-100'
    }`,
    onMouseEnter: () => setIsHovered(true),
    onMouseLeave: () => setIsHovered(false),
    'data-hovered': isHovered ? 'true' : 'false'
  };
};

/**
 * Custom hook for adding subtle pulse animation to elements
 * @param interval Time between pulses in ms
 * @returns Animation class and state
 */
export const usePulseAnimation = (interval: number = 2000) => {
  const [isPulsing, setIsPulsing] = useState(false);
  
  useEffect(() => {
    const timer = setInterval(() => {
      setIsPulsing(prev => !prev);
    }, interval);
    
    return () => clearInterval(timer);
  }, [interval]);
  
  return {
    className: `transition-transform duration-300 ${
      isPulsing ? 'scale-105' : 'scale-100'
    }`,
    'data-pulse': isPulsing ? 'active' : 'inactive'
  };
};

/**
 * Create a staggered animation for list items
 * @param index Position in the list (0-based)
 * @param baseDelay Base delay before animation starts
 * @returns Animation properties for the item
 */
export const getStaggeredAnimation = (index: number, baseDelay: number = 50) => {
  return {
    className: 'animate-fadeIn',
    style: { 
      animationDelay: `${baseDelay * (index + 1)}ms`,
      animationFillMode: 'both' 
    }
  };
};

/**
 * Hook for managing ripple animations on click
 * @returns Props and handler for creating ripple effect
 */
export interface RippleType {
  x: number;
  y: number;
  id: number;
}

export const useRippleEffect = () => {
  const [ripples, setRipples] = useState<RippleType[]>([]);
  
  const handleClick = (event: React.MouseEvent<HTMLElement>) => {
    const element = event.currentTarget;
    const rect = element.getBoundingClientRect();
    
    const x = event.clientX - rect.left;
    const y = event.clientY - rect.top;
    
    const newRipple = { x, y, id: Date.now() };
    
    setRipples(prev => [...prev, newRipple]);
    
    setTimeout(() => {
      setRipples(prev => prev.filter(r => r.id !== newRipple.id));
    }, 1000);
  };
  
  return {
    onClick: handleClick,
    className: 'relative overflow-hidden',
    ripples
  };
};