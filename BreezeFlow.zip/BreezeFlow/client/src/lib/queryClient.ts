import { QueryClient, QueryFunction } from "@tanstack/react-query";

async function throwIfResNotOk(res: Response) {
  if (!res.ok) {
    const text = (await res.text()) || res.statusText;
    throw new Error(`${res.status}: ${text}`);
  }
}

// Track if we're currently refreshing the token to avoid infinite refresh loops
let isRefreshing = false;
let refreshPromise: Promise<void> | null = null;

// Function to refresh the access token
async function refreshAccessToken(): Promise<void> {
  if (isRefreshing) {
    return refreshPromise as Promise<void>;
  }
  
  isRefreshing = true;
  refreshPromise = fetch('/api/refresh-token', {
    method: 'POST',
    credentials: 'include',
  })
  .then(async (res) => {
    if (!res.ok) {
      throw new Error('Failed to refresh token');
    }
  })
  .finally(() => {
    isRefreshing = false;
    refreshPromise = null;
  });
  
  return refreshPromise;
}

interface ApiRequestOptions {
  responseType?: 'json' | 'text' | 'blob';
  contentType?: 'application/json' | 'multipart/form-data';
}

export async function apiRequest(
  method: string,
  url: string,
  data?: unknown | undefined,
  options: ApiRequestOptions = {}
): Promise<Response> {
  const { contentType = 'application/json', responseType } = options;
  
  let headers: Record<string, string> = {};
  let body: any = undefined;
  
  if (data) {
    if (contentType === 'application/json') {
      headers['Content-Type'] = contentType;
      body = JSON.stringify(data);
    } else if (contentType === 'multipart/form-data') {
      // For multipart/form-data, don't set Content-Type header
      // Let the browser set it with the boundary
      body = data;
    }
  }
  
  let res = await fetch(url, {
    method,
    headers,
    body,
    credentials: "include",
  });

  // If we get a 401 error, try to refresh the token and retry the request
  if (res.status === 401 && url !== '/api/refresh-token' && url !== '/api/login') {
    try {
      // Attempt to refresh the token
      await refreshAccessToken();
      
      // Retry the original request with the new token
      res = await fetch(url, {
        method,
        headers,
        body,
        credentials: "include",
      });
    } catch (error) {
      // If refresh fails, let the original 401 response propagate
      console.error("Token refresh failed:", error);
    }
  }

  await throwIfResNotOk(res);
  
  // Allow caller to specify the expected response type
  if (responseType === 'blob') {
    // Don't try to parse the response, just return it
    return res;
  }
  
  return res;
}

type UnauthorizedBehavior = "returnNull" | "throw";
export const getQueryFn: <T>(options: {
  on401: UnauthorizedBehavior;
}) => QueryFunction<T> =
  ({ on401: unauthorizedBehavior }) =>
  async ({ queryKey }) => {
    let res = await fetch(queryKey[0] as string, {
      credentials: "include",
    });

    // If we get a 401 response, try to refresh the token and retry (unless handling /api/user)
    if (res.status === 401 && queryKey[0] !== '/api/refresh-token' && unauthorizedBehavior !== "returnNull") {
      try {
        // Attempt to refresh the token
        await refreshAccessToken();
        
        // Retry the original request with the new token
        res = await fetch(queryKey[0] as string, {
          credentials: "include",
        });
      } catch (error) {
        console.error("Token refresh failed:", error);
      }
    }

    if (unauthorizedBehavior === "returnNull" && res.status === 401) {
      return null;
    }

    await throwIfResNotOk(res);
    return await res.json();
  };

export const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      queryFn: getQueryFn({ on401: "throw" }),
      refetchInterval: false,
      refetchOnWindowFocus: false,
      staleTime: Infinity,
      retry: false,
    },
    mutations: {
      retry: false,
    },
  },
});
