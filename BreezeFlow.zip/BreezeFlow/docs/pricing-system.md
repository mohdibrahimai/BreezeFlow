# BreezeFlow Pricing & Quota System

This document describes the pricing tiers, quota system, and implementation details for BreezeFlow's subscription management.

## Pricing Tiers

BreezeFlow offers four pricing tiers:

| Tier | Monthly Price | Annual Price | Monthly Actions |
|------|--------------|--------------|----------------|
| Free | $0 | $0 | 50 |
| Starter | $7 | $70 | 500 |
| Pro | $19 | $190 | Unlimited |
| Team | $12/user | $120/user | Unlimited |

Annual billing offers a 16% discount compared to monthly billing.

## Quota Management System

The quota system tracks and enforces usage limits based on the user's subscription plan:

### Key Components

1. **Usage Event Tracking**: 
   - Every significant user action (task completion, event creation, etc.) is tracked in the `usage_events` table
   - This tracking serves two purposes: quota enforcement and ROI calculation

2. **Concurrency Protection**:
   - `checkAndIncrementQuota` function in DatabaseStorage implements transaction-based protection
   - Uses `SELECT FOR UPDATE` to lock rows being counted during quota checks
   - Prevents race conditions where multiple simultaneous actions might bypass limits

3. **Quota Middleware**:
   - `checkQuota` middleware enforces limits on protected API routes
   - Returns 402 Payment Required status when quota is exceeded
   - Sets X-Headers with quota information for client-side indicators

4. **Plan Requirements**:
   - `requirePlan` middleware restricts access to premium features
   - Enforces minimum plan tier for specific functionality

### Quota Enforcement Flow

1. User makes a request to a protected endpoint
2. `checkQuota` middleware verifies the user's plan and current usage
3. Database transaction locks usage count during verification (concurrency protection)
4. If quota is not exceeded, the usage count is incremented and request proceeds
5. If quota is exceeded, a 402 status is returned with upgrade information

## Razorpay Integration

### Plan Configuration

- Plan IDs are managed in `server/planIdMap.ts`
- Environment variables provide production plan IDs
- Fallback "sandbox" IDs used in development

### Payment Flow

1. User selects a plan on the pricing page
2. Client creates a Razorpay order via `/api/create-razorpay-order`
3. User completes payment in Razorpay checkout
4. Payment verified via `/api/verify-razorpay-payment`
5. User's plan is updated and quota is refreshed

### Currency Handling

- Prices for Indian users are displayed in INR
- Prices for international users are displayed in USD
- Conversion rate of approximately 83 INR to 1 USD is applied

## Migration Process

When deploying the new pricing system to production:

1. Run the `migrations/addStarterPlan.ts` script to update database schema
2. Set up Razorpay plan IDs using `scripts/setupPlans.ts`
3. Update environment variables with production keys and plan IDs
4. Configure Razorpay webhooks for subscription management

## Client-Side Integration

The client application provides several UI components for quota management:

1. **Progress Component**: Visual indicator of quota usage
2. **Settings Page**: Displays current plan, features, and usage
3. **Pricing Page**: Offers plan comparison and upgrade options
4. **Upgrade Modal**: Appears when quota is exceeded during usage

## API Endpoints

| Endpoint | Method | Description |
|----------|--------|-------------|
| `/api/user/quota` | GET | Returns user's current quota status |
| `/api/plans/upgrade-path` | GET | Provides information about the next plan tier |
| `/api/create-razorpay-order` | POST | Creates a new order for payment |
| `/api/verify-razorpay-payment` | POST | Verifies and processes payment |