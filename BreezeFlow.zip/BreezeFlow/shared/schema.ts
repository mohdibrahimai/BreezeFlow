import { pgTable, text, serial, integer, boolean, timestamp, json, real, decimal } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
  name: text("name").notNull(),
  email: text("email").notNull().unique(),
  plan: text("plan", { enum: ["free", "starter", "pro", "team"] }).notNull().default("free"),
  plan_active: boolean("plan_active").notNull().default(false),
  plan_expiry: timestamp("plan_expiry"),
  role: text("role", { enum: ["user", "admin"] }).notNull().default("user"),
  paypal_customer_id: text("paypal_customer_id"),
  paypal_subscription_id: text("paypal_subscription_id"),
  last_payment_date: timestamp("last_payment_date"),
  flow_score: integer("flow_score").notNull().default(0),
  streak_days: integer("streak_days").notNull().default(0),
  hourly_rate: decimal("hourly_rate", { precision: 10, scale: 2 }).notNull().default("60"),
  currency: text("currency").notNull().default("USD"),
  pref_reduce_motion: boolean("pref_reduce_motion").notNull().default(false),
  google_calendar_connected: boolean("google_calendar_connected").default(false),
  google_refresh_token: text("google_refresh_token"),
  outlook_calendar_connected: boolean("outlook_calendar_connected").default(false),
  outlook_refresh_token: text("outlook_refresh_token"),
  reset_token: text("reset_token"),
  reset_token_expires: timestamp("reset_token_expires"),
  security_question: text("security_question"),
  security_answer: text("security_answer"),
});

export const tasks = pgTable("tasks", {
  id: serial("id").primaryKey(),
  user_id: integer("user_id").notNull(),
  title: text("title").notNull(),
  description: text("description"),
  status: text("status").notNull(), // "backlog", "today", "done"
  priority: text("priority").notNull(), // "low", "medium", "high"
  due_date: text("due_date"),
  points: integer("points").notNull().default(10),
  completed_at: text("completed_at"),
  created_at: timestamp("created_at").notNull().defaultNow(),
  priority_score: integer("priority_score"), // ML-generated score (0-100)
  tags: text("tags"), // Comma-separated tags
  estimated_minutes: integer("estimated_minutes"), // Estimated time in minutes
  reminder_time: timestamp("reminder_time"), // Reminder timestamp
});

export const events = pgTable("events", {
  id: serial("id").primaryKey(),
  user_id: integer("user_id").notNull(),
  title: text("title").notNull(),
  start: text("start").notNull(),
  end: text("end").notNull(),
  location: text("location"),
  auto_scheduled: boolean("auto_scheduled").notNull().default(false),
});

export const errands = pgTable("errands", {
  id: serial("id").primaryKey(),
  user_id: integer("user_id").notNull(),
  vendor: text("vendor").notNull(),
  amount: integer("amount"),
  due_date: text("due_date"),
  autopay: boolean("autopay").notNull().default(false),
  status: text("status").notNull(), // "upcoming", "completed"
});

export const bills = pgTable("bills", {
  id: serial("id").primaryKey(),
  user_id: integer("user_id").notNull(),
  name: text("name").notNull().default(""), // Bill name/title
  provider: text("provider").notNull(),
  payee: text("payee"), // Payee name for consolidation opportunities
  amount: integer("amount"),
  due_date: text("due_date"),
  payment_date: text("payment_date"), // Date when payment was made
  autopay: boolean("autopay").notNull().default(false),
  status: text("status").notNull(), // "upcoming", "paid"
  category: text("category").default("uncategorized"), // "utilities", "rent", "subscription", "insurance", etc.
  recurring: boolean("recurring").notNull().default(false),
  recurring_interval: text("recurring_interval"), // "monthly", "quarterly", "yearly"
  reminder_days: integer("reminder_days"), // days before due date to send reminder
  reminder_days_before: integer("reminder_days_before"), // Days before due date for reminder
  notes: text("notes"),
  created_at: timestamp("created_at").notNull().defaultNow(),
  paid_at: timestamp("paid_at"),
  last_reminded_at: timestamp("last_reminded_at"),
});

export const rewards = pgTable("rewards", {
  id: serial("id").primaryKey(),
  user_id: integer("user_id").notNull(),
  badge_name: text("badge_name").notNull(),
  date_earned: text("date_earned").notNull(),
  points_awarded: integer("points_awarded").notNull(),
});

export const invites = pgTable("invites", {
  id: serial("id").primaryKey(),
  inviter_id: integer("inviter_id").notNull(),
  invitee_email: text("invitee_email").notNull(),
  status: text("status").notNull(), // "pending", "accepted", "rejected"
});

export const payments = pgTable("payments", {
  id: serial("id").primaryKey(),
  user_id: integer("user_id").notNull(),
  transaction_id: text("transaction_id").notNull().unique(),
  subscription_id: text("subscription_id"),
  amount: integer("amount").notNull(),
  currency: text("currency").notNull(),
  status: text("status").notNull(), // "completed", "pending", "failed", "refunded"
  payment_method: text("payment_method").notNull(), // "paypal", "credit_card"
  created_at: timestamp("created_at").notNull().defaultNow(),
  metadata: json("metadata"), // Additional payment details
});

export const usage_events = pgTable("usage_events", {
  id: serial("id").primaryKey(),
  user_id: integer("user_id").notNull(),
  action: text("action").notNull(), // "task_completed", "bill_paid", "errand_completed", etc.
  timestamp: timestamp("timestamp").notNull().defaultNow(),
  estimated_minutes_saved: real("estimated_minutes_saved").notNull().default(0),
  estimated_money_saved: real("estimated_money_saved").notNull().default(0),
  metadata: json("metadata"), // Additional context about the action
});

// Insert Schemas
export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
  name: true,
  email: true,
  plan: true,
  security_question: true,
  security_answer: true,
});

export const insertTaskSchema = createInsertSchema(tasks).pick({
  user_id: true,
  title: true,
  description: true,
  status: true,
  priority: true,
  due_date: true,
  points: true,
  tags: true,
  estimated_minutes: true,
  reminder_time: true,
});

export const insertEventSchema = createInsertSchema(events).pick({
  user_id: true,
  title: true,
  start: true,
  end: true,
  location: true,
  auto_scheduled: true,
});

export const insertErrandSchema = createInsertSchema(errands).pick({
  user_id: true,
  vendor: true,
  amount: true,
  due_date: true,
  autopay: true,
  status: true,
});

export const insertBillSchema = createInsertSchema(bills).pick({
  user_id: true,
  name: true,
  provider: true,
  payee: true,
  amount: true,
  due_date: true,
  payment_date: true,
  autopay: true,
  status: true,
  category: true,
  recurring: true,
  recurring_interval: true,
  reminder_days: true,
  reminder_days_before: true,
  notes: true,
});

export const insertRewardSchema = createInsertSchema(rewards).pick({
  user_id: true,
  badge_name: true,
  date_earned: true,
  points_awarded: true,
});

export const insertInviteSchema = createInsertSchema(invites).pick({
  inviter_id: true,
  invitee_email: true,
  status: true,
});

export const insertPaymentSchema = createInsertSchema(payments).pick({
  user_id: true,
  transaction_id: true,
  subscription_id: true,
  amount: true,
  currency: true,
  status: true,
  payment_method: true,
  metadata: true,
});

export const insertUsageEventSchema = createInsertSchema(usage_events).pick({
  user_id: true,
  action: true,
  timestamp: true,
  estimated_minutes_saved: true,
  estimated_money_saved: true,
  metadata: true,
});

// Login Schema
export const loginSchema = z.object({
  username: z.string().min(1, "Username is required"),
  password: z.string().min(1, "Password is required"),
});

// Types
export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;

export type InsertTask = z.infer<typeof insertTaskSchema>;
export type Task = typeof tasks.$inferSelect;

export type InsertEvent = z.infer<typeof insertEventSchema>;
export type Event = typeof events.$inferSelect;

export type InsertErrand = z.infer<typeof insertErrandSchema>;
export type Errand = typeof errands.$inferSelect;

export type InsertBill = z.infer<typeof insertBillSchema>;
export type Bill = typeof bills.$inferSelect;

export type InsertReward = z.infer<typeof insertRewardSchema>;
export type Reward = typeof rewards.$inferSelect;

export type InsertInvite = z.infer<typeof insertInviteSchema>;
export type Invite = typeof invites.$inferSelect;

export type InsertPayment = z.infer<typeof insertPaymentSchema>;
export type Payment = typeof payments.$inferSelect;

export type InsertUsageEvent = z.infer<typeof insertUsageEventSchema>;
export type UsageEvent = typeof usage_events.$inferSelect;

export type LoginData = z.infer<typeof loginSchema>;
